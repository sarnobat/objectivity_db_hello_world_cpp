/*
 * @(#)ActivateInfo.java
 * 
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

/**
 * Defines behavior shared by all activate information objects.
 *
 * <p>After a persistent object's data is fetched from the database,
 * an activate event occurs.  The object's <tt>activate</tt> method handles 
 * the activate event; the parameter to that method is an activate 
 * information object containing information about any exceptions that occurred 
 * during the fetch operation.
 *
 * <p>Objectivity for Java traps any errors that occur during a fetch 
 * operation and records these errors within the corresponding activate 
 * information object as a vector of 
 * <a href="FetchErrorInfo.html">fetch-error information objects</a>,
 * one for each fetch error that occurred. 
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 */
public interface ActivateInfo
    extends PersistentEventInfo
{
	/**
	 * Tests whether errors occurred during the fetch operation described by 
	 * this activate information object.</p>
	 *
	 * @return		True if errors occurred; otherwise false.
	 */
    boolean hasFetchErrors() ;

	/**
	 * Gets this activate information object's
	 * <a href="FetchErrorInfo.html">fetch-error information objects</a>.</p> 
	 *
	 * @return		The vector of fetch-error information objects
	 * describing the errors that occurred during the fetch operation.
	 */
    java.util.Vector getFetchErrors() ;
}