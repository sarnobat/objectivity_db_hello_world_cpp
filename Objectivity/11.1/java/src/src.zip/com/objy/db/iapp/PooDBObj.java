/*
 * @(#)PooDBObj.java
 *
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.iapp ;

import com.objy.db.app.ooId ;
import com.objy.db.app.ooFDObj ;
import com.objy.db.app.Iterator ;
import com.objy.db.app.QuerySplitter;
import com.objy.db.app.storage.ClusterStrategy;
import com.objy.db.app.storage.ooAPObj;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.app.storage.ooDBObj;
import com.objy.db.app.storage.ooDefaultContObj;
import com.objy.query.ObjectQualifier;

import com.objy.db.ObjectNameNotFoundException ;
import com.objy.db.ObjectNameNotUniqueException ;

/**
 * Reserved for internal use.
 */
public interface PooDBObj
       extends   PHasSession
{
    ooDBObj getTarget() ;

    ooFDObj getFD() ;

    ooId getOid() ;

    ooDefaultContObj getDefaultContainer() ;

    ooDefaultContObj getDefaultContainer(int lockMode) ;

    long getContainerCount() ;

    String getName() ;

    String getFileName() ;

    String getHostName() ;

    String getPathName() ;

    boolean isReadOnly() ;

    void setReadOnly(boolean value) ;

    long getNumber() ;

    int getPageSize() ;

    //
    // Locking
    //
    void lock(int lockMode) ;

    void update() ;

    //
    // Deleting
    //
    void delete() ;

    void delete(boolean catalogOnly);
    
    void cluster(Object object, ClusterStrategy strategy);

    //-------
    // Scopes
    //-------
    void nameObj(Object o, String scopeName) ;

    void unnameObj(Object obj) ;

    String lookupObjName(Object obj) ;

    Object lookupObj(String scopeName) ;

    Object lookupObj(String scopeName, int lockMode) ;

    //--------
    // FTO-DRO
    //--------
    boolean isReplicated() ;

    long getImageCount() ;

    ooAPObj getTieBreaker() ;

    void setTieBreaker(PooAPObj ap) ;

    void changePartition(PooAPObj ap) ;

    long getImageWeight(PooAPObj ap) ;

    String getImagePathName(PooAPObj ap) ;

    String getImageFileName(PooAPObj ap) ;

    String getImageHostName(PooAPObj ap) ;

    void setImageWeight(PooAPObj ap, long weight) ;

    boolean isImageAvailable(PooAPObj ap) ;

    // DAD New HA Stuff
    int availability() ;

    // DAD New HA Stuff
    boolean isImageAccessible(PooAPObj ap) ;

    // DAD New HA Stuff
    void ensureImageInQuorum(PooAPObj ap) ;

    // DAD New HA Stuff
    ooAPObj getReadImage() ;

    // DAD New HA Stuff
    void setReadImage(PooAPObj ap) ;

    boolean hasImageIn(PooAPObj ap) ;

    void deleteImage(PooAPObj ap) ;

    void deleteImage(PooAPObj ap, boolean deleteDBifLast) ;

    void replicate(PooAPObj ap, String hostName, String pathName, long weight);

    ooAPObj getContainingPartition() ;

    Iterator containingImage() ;

    //---------------------
    // Container Management
    //---------------------
    void addContainer(
        ooContObj cont,
        String name,
        long hash,
        long initPages,
        long growthFactor);

    void addContainer(
        ooContObj cont,
        int userContId,
        String name,
        long initPages,
        long growthFactor);

    void addExternalContainer(
        ooContObj cont,
        int userContId,
        String name,
        long initPages,
        long growthFactor,
        String hostName,
        String pathName,
        int pageSize);

    int numberOfExternalContainers() ;

    boolean hasContainer(String name) ;

    boolean hasContainer(int contId) ;

    void flush() ;

    //---------------------
    // Container Management
    //---------------------
    ooContObj lookupContainer(String name) ;

    ooContObj lookupContainer(String name, int lockMode) ;

    ooContObj lookupContainer(int contId) ;

    ooContObj lookupContainer(int contId, int lockMode) ;

    //---------------
    // Scan Iterators
    //---------------
    Iterator scan(String className) ;

    Iterator scan(String className, String predicate) ;

    Iterator scan(String className, String predicate, int access) ;
    
	Iterator scan(String className, ObjectQualifier oq);

    //---------------
    // ParallelScan Iterators
    //---------------
    Iterator parallelScan(String className, String predicate) ;

    Iterator parallelScan(String className, String predicate, QuerySplitter qs) ;
    
	Iterator parallelScan(String className, ObjectQualifier oq, QuerySplitter qs);

    //-------------------
    // Contains Iterators
    //-------------------
    Iterator contains() ;

    void bind(Object object, String name) throws ObjectNameNotUniqueException ;

    void unbind(String name) throws ObjectNameNotFoundException ;

    Object lookup(String name) throws ObjectNameNotFoundException ;

    Iterator rootNames() ;

    //----------
    // Indexes
    //----------
    void addIndex(String indexName, String className, String fieldList);

    void addUniqueIndex(String indexName, String className, String fieldList);

    void dropIndex(String indexName) ;

    boolean hasIndex(String indexName) ;

    boolean indexConsistent(String indexName) ;

    //--------------------
    //  Schema Evolution
    //--------------------
    void convertObjects() ;

    //---------------
    // FTO-DRO Quorum
    //---------------
    void setNonQuorumReadAllowed(boolean value) ;

    boolean isNonQuorumReadAllowed() ;

    void negotiateQuorum(int lockMode) ;

    boolean isNonQuorumRead() ;

	boolean change(String dbSystemName, String dbHostName, String dbPathName, boolean catalogOnly, String outputFileName);
	
    void doNewConts(long nearDB, ooContObj[] conts, int numberOfContainers, 
    		int percentGrowth);

}



