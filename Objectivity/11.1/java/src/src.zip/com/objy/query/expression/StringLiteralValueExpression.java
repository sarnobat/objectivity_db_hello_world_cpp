package com.objy.query.expression;
/**
 * Represents a String literal value node.
 *
 */
public class StringLiteralValueExpression extends LiteralValueExpression 
{
    /**
     * Constructs a string literal value node with a string.
     * @param value A string 
     */
    public StringLiteralValueExpression(String value) 
    {
        Util.verifyStringArgument(value);
        setIdAfterNullCheck(Binding.create(value));
    }
    /**
     * Constructs a string literal value node with an ID.
     * @param id
     */
    StringLiteralValueExpression(long id) 
    {
        setIdAfterNullCheck(id);
    }
    
    /**
     * Sets the string literal value to the specified string.
     */
    public void setValue(String value)
    {
        throwExceptionIfInvalidOrClosed(mId);
        Util.verifyStringArgument(value);
        Binding.setValue(getId(), value);
    }

    /**
     * Returns the string literal value.
     */
    public String getValue()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getValue(getId());
    }
    
    /**
     * Returns the type of the expression (oocStringLiteralExpression).
     */
    @Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.StringLiteralValueExpression; 
    }
    
    @Override
    public String toString()
    {
    	return "'" + getValue() + "'";
    }
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitStringLiteralValue(this);
    }
    
    static class Binding
    {
        private static native long create(String string);
        private static native void setValue(long id, String value) ;
        // Returns the string literal value as wchar_t*.
        private static native String getValue(long id) ;
        
    }
}
