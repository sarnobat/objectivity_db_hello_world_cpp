/*
 * @(#)ooDBObj.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app.storage ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.ObjectIsDeadException ;
import com.objy.db.ObjectNameNotUniqueException ;
import com.objy.db.ObjectNameNotFoundException ;

import com.objy.db.iapp.PooDBObj ;
import com.objy.db.app.Connection;
import com.objy.db.app.Iterator;
import com.objy.db.app.QuerySplitter;
import com.objy.db.app.Session;
import com.objy.db.app.ooAbstractObj;
import com.objy.db.app.ooFDObj;
import com.objy.db.app.ooId;
import com.objy.query.ObjectQualifier;

/**
 * <p>Represents an Objectivity/DB database.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>A <i>database</i> is the second highest level in the Objectivity/DB
 * hierarchy; a federated database contains one or more databases and every
 * database contains one or more containers.
 * For additional information about databases and a discussion of how
 * an application can create and work with databases,
 * see <A HREF="../../../../../../guide/jgdStorage.html#Databases">
 * Databases</A>.
 *
 * <p><i>(HA)</i> The <tt>ooDBObj</tt> class also represents a
 * <A HREF="../../../../../../guide/jgdImages.html#_top_">
 * database image</a>, which you can create if you have bought and installed
 * Objectivity/DB High Availability (Objectivity/HA).
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR><td VALIGN="top" WIDTH="1%"><B>Locking</B></TD>
 * <TD><A HREF="#lock(int)">lock(int)</A>
 * </TD></TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information About&nbsp;the&nbsp;Database</B></TD>
 * <TD><A HREF="#getName()">getName()<BR></A>
 * 	<A HREF="#getOid()">getOid()<BR></A>
 * 	<A HREF="#getFileName()">getFileName()</A><BR>
 * 	<A HREF="#getHostName()">getHostName()</A><BR>
 * 	<A HREF="#getPathName()">getPathName()</A><BR>
 * 	<A HREF="#getDefaultContainer()">getDefaultContainer()</A><BR>
 * 	<A HREF="#getDefaultContainer(int)">getDefaultContainer(int)</A><BR>
 * 	<A HREF="#getContainerCount()">getContainerCount()</A><BR>
 *	<A HREF="#numberOfExternalContainers()">numberOfExternalContainers()</A><BR>
 * 	<A HREF="#getSession()">getSession()</A><BR>
 * 	<A HREF="#getFD()">getFD()</A><BR>
 * 	<A HREF="#getNumber()">getNumber()</A><BR>
 * 	<A HREF="#getPageSize()">getPageSize()</A><BR>
 *	<A HREF="#getContainingPartition()">getContainingPartition()</A><I> (HA)</I><BR>
 *	<A HREF="#getImageCount()">getImageCount()</A><I> (HA)</I><BR>
 *	<A HREF="#getTieBreaker()">getTieBreaker()</A><I> (HA)</I>
 * </td></TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Testing&nbsp;the&nbsp;Database</B></TD>
 * <TD>
 *     <A HREF="#isReadOnly()">isReadOnly()</A><BR>
 *     <A HREF="#isDead()">isDead()</A><BR>
 * 	   <A HREF="#hasContainer(java.lang.String)">hasContainer(String)</A><br>
 *     <A HREF="#hasContainer(int)">hasContainer(int)</A><br>
 *     <a href="#hasIndex(java.lang.String)">hasIndex(String)</a><br>
 *     <a href="#indexConsistent(java.lang.String)">indexConsistent(String)</a><br>
 *     <A HREF="#isReplicated()">isReplicated()</A><I> (HA)</I><BR>
 *     <A HREF="#hasImageIn(com.objy.db.app.storage.ooAPObj)">hasImageIn(ooAPObj)</A><I> (HA)</I><BR>
 *     <A HREF="#availability()">availability()</A> <I>(HA)</I><BR>
 *     <A HREF="#isNonQuorumReadAllowed()">isNonQuorumReadAllowed()</A> <I>(HA)</I><BR>
 *     <A HREF="#isNonQuorumRead()">isNonQuorumRead()</A> <I>(HA)</I>
 * </td></TR>
 *
 * <tr><td VALIGN="top" WIDTH="1%"><B>Modifying&nbsp;the&nbsp;Database</b></td>
 * <td>
 *     <A HREF="#setReadOnly(boolean)">setReadOnly(boolean)</A><br>
 *     <A HREF="#delete()">delete()</A><br>
 *     <A HREF="#delete(boolean)">delete(boolean)</A><br>
 *     <A HREF="#change(java.lang.String, java.lang.String, java.lang.String, boolean, java.lang.String)">change(String, String, String, boolean, String)</A><I></I><BR>
 *     <A HREF="#changePartition(com.objy.db.app.storage.ooAPObj)">changePartition(ooAPObj)</A><I> (HA)</I><BR>
 *     <A HREF="#setTieBreaker(com.objy.db.app.storage.ooAPObj)">setTieBreaker(ooAPObj)</A><I> (HA)</I>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Contained&nbsp;Objects</B></TD>
 * <TD><A HREF="#scan(java.lang.String)">scan(String)</A><BR>
 *  <A HREF="#contains()">contains()</A><BR>
 * 	<A HREF="#scan(java.lang.String, java.lang.String)">scan(String, String)</A><BR>
 *  <A HREF="#getDefaultContainer()">getDefaultContainer()</A><BR>
 *  <A HREF="#getDefaultContainer(int)">getDefaultContainer(int)</A><BR>
 * 	<A HREF="#lookupContainer(java.lang.String)">lookupContainer(String)</A><br>
 * 	<A HREF="#lookupContainer(java.lang.String, int)">lookupContainer(String, int)</A><br>
 * 	<A HREF="#lookupContainer(int)">lookupContainer(int)</A><br>
 * 	<A HREF="#lookupContainer(int, int)">lookupContainer(int, int)</A><br>
 *  <A HREF="#parallelScan(java.lang.String, java.lang.String)">parallelScan(String, String)</A><br>
 *  <A HREF="#parallelScan(java.lang.String, com.objy.query.ObjectQualifier)">parallelScan(String, ObjectQualifier)</A><br>
 *  <A HREF="#parallelScan(java.lang.String, java.lang.String, com.objy.db.app.QuerySplitter)">parallelScan(String, String, QuerySplitter)</A><br>
 *  <A HREF="#parallelScan(java.lang.String, com.objy.query.ObjectQualifier, com.objy.db.app.QuerySplitter)">parallelScan(String, ObjectQualifier, QuerySplitter)</A>
 * </TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Containing&nbsp;Objects</B></TD>
 * <TD>
 * 	<A HREF="#getFD()">getFD()</A><BR>
 *  <A HREF="#getContainingPartition()">getContainingPartition()</A><I> (HA)</I><BR>
 *  <A HREF="#containingImage()">containingImage()</A><I> (HA)</I>
 * </TR>
 *
 * <tr><td VALIGN="top" WIDTH="1%"><B>Clustering</b></td><td>
 * 	<a href="#cluster(java.lang.Object)">cluster(Object)</a><br>
 * 	<a href="#cluster(java.lang.Object, com.objy.db.app.storage.ClusterStrategy)">cluster(Object, ClusterStrategy)</a>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Working&nbsp;With&nbsp;Named&nbsp;Roots</B></TD>
 * <TD><A HREF="#bind(java.lang.Object, java.lang.String)">bind(Object, String)</A><BR>
 * 	<A HREF="#unbind(java.lang.String)">unbind(String)</A><BR>
 * 	<A HREF="#lookup(java.lang.String)">lookup(String)</A><BR>
 * 	<A HREF="#rootNames()">rootNames()</A> </TD>
 * </TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Working&nbsp;With Scope-Named&nbsp;Objects</B></TD>
 * <TD><a href="#nameObj(java.lang.Object, java.lang.String)">nameObj(Object, String)</a><br>
 * 	<a href="#unnameObj(java.lang.Object)">unnameObj(Object)</a><br>
 * 	<A HREF="#lookupObj(java.lang.String)">lookupObj(String)</A><br>
 * 	<A HREF="#lookupObj(java.lang.String, int)">lookupObj(String, int)</A><br>
 * 	<a href="#lookupObjName(java.lang.Object)">lookupObjName(Object)</a>
 * 	</TD></TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><A NAME="ooDBObj.ooContObj"></A><B>Working&nbsp;With&nbsp;Containers</B></TD>
 * <TD>
 * 	<A HREF="#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">addContainer(ooContObj, int, String, long, long)</A> <BR>
 * 	<A HREF="#addContainer(com.objy.db.app.storage.ooContObj, java.lang.String, long, long, long)">addContainer(ooContObj, String, long, long, long)</A> <BR>
 * 	<A HREF="#addExternalContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long, java.lang.String, java.lang.String, int)">addExternalContainer(ooContObj, int, String, long, long, String, String, int)</A> <BR>
 * 	<A HREF="#getContainerCount()">getContainerCount()</A><BR>
 * 	<A HREF="#hasContainer(java.lang.String)">hasContainer(String)</A><BR>
 * 	<A HREF="#hasContainer(int)">hasContainer(int)</A><BR>
 * 	<A HREF="#lookupContainer(java.lang.String)">lookupContainer(String)</A><BR>
 * 	<A HREF="#lookupContainer(java.lang.String, int)">lookupContainer(String, int)</A><BR>
 * 	<A HREF="#lookupContainer(int)">lookupContainer(int)</A><br>
 * 	<A HREF="#lookupContainer(int, int)">lookupContainer(int, int)</A><br>
 *	<A HREF="#getDefaultContainer()">getDefaultContainer()</A><BR>
 *	<A HREF="#getDefaultContainer(int)">getDefaultContainer(int)</A><BR>
 *	<A HREF="#numberOfExternalContainers()">numberOfExternalContainers()</A>
 * </TD></TR>
 *
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Indexes</b></td>
 * 	<td>
 *     <a href="#addIndex(java.lang.String, java.lang.String, java.lang.String)">addIndex(String, String, String)</a><br>
 *     <a href="#addUniqueIndex(java.lang.String, java.lang.String, java.lang.String)">addUniqueIndex(String, String, String)</a><br>
 *     <a href="#dropIndex(java.lang.String)">dropIndex(String)</a><br>
 *     <a href="#hasIndex(java.lang.String)">hasIndex(String)</a><br>
 *     <a href="#indexConsistent(java.lang.String)">indexConsistent(String)</a>
 * 	</td></tr>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Updating&nbsp;the Objectivity/DB&nbsp;cache</B></TD>
 * <TD><A HREF="#flush()">flush()</A>
 * </TD></TR>
 *
 * <tr><td VALIGN="top" WIDTH="1%"><B>Converting&nbsp;Objects</b></td><td>
 * 	<a href="#convertObjects()">convertObjects()</a>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Creating&nbsp;and&nbsp;Deleting Images</B><I>&nbsp;(HA)</I></TD>
 * 	<td>
 *     <A HREF="#replicate(com.objy.db.app.storage.ooAPObj, java.lang.String, java.lang.String, long)">replicate(ooAPObj, String, String, long)</A><BR>
 *     <A HREF="#deleteImage(com.objy.db.app.storage.ooAPObj)">deleteImage(ooAPObj)</A><BR>
 *     <A HREF="#deleteImage(com.objy.db.app.storage.ooAPObj, boolean)">deleteImage(ooAPObj, boolean)</A><BR>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information About&nbsp;an&nbsp;Image</B><I>&nbsp;(HA)</I></TD>
 * 	<td>
 *  <A HREF="#getImageFileName(com.objy.db.app.storage.ooAPObj)">getImageFileName(ooAPObj)</A><BR>
 *  <A HREF="#getImagePathName(com.objy.db.app.storage.ooAPObj)">getImagePathName(ooAPObj)</A><BR>
 *  <A HREF="#getImageHostName(com.objy.db.app.storage.ooAPObj)">getImageHostName(ooAPObj)</A><BR>
 *  <A HREF="#getImageWeight(com.objy.db.app.storage.ooAPObj)">getImageWeight(ooAPObj)</A>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Testing&nbsp;an&nbsp;Image</B><I> (HA)</I></TD>
 * 	<td>
 *     <A HREF="#isImageAccessible(com.objy.db.app.storage.ooAPObj)">isImageAccessible(ooAPObj)</A><BR>
 *     <A HREF="#isImageAvailable(com.objy.db.app.storage.ooAPObj)">isImageAvailable(ooAPObj)</A>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Modifying&nbsp;an&nbsp;Image</B><I> (HA)</I></TD>
 * 	<td>
 *     <A HREF="#setImageWeight(com.objy.db.app.storage.ooAPObj, long)">setImageWeight(ooAPObj, long)</A>
 * 	</td></tr>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><A NAME="ooDBObj.ooAPObj"></A><B>Working&nbsp;With Quorum and Nonquorum&nbsp;Reads</B><I>&nbsp;(HA)</I></TD>
 * <TD>
 *     <A HREF="#getReadImage()">getReadImage()</A><br>
 *     <A HREF="#setReadImage(com.objy.db.app.storage.ooAPObj)">setReadImage(ooAPObj)</A><br>
 *     <A HREF="#setNonQuorumReadAllowed(boolean)">setNonQuorumReadAllowed(boolean)</A><br>
 *     <A HREF="#isNonQuorumReadAllowed()">isNonQuorumReadAllowed()</A><br>
 *     <A HREF="#isNonQuorumRead()">isNonQuorumRead()</A>
 * </TD></TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><A NAME="ooDBObj.ooAPObj"></A>
 * <B>Resynchronizing Images</B><I>&nbsp;(HA)</I></TD>
 * <TD>
 *     <A HREF="#negotiateQuorum(int)">negotiateQuorum(int)</A><BR>
 *     <A HREF="#ensureImageInQuorum(com.objy.db.app.storage.ooAPObj)">ensureImageInQuorum(ooAPObj)</A>
 * </TD></TR>
 *
 *
 * </TABLE>
 *
 */
final public class ooDBObj
    extends ooAbstractObj
{
    private transient PooDBObj persistor ;

    private ooDBObj()
        { }

	/**
	 * Reserved for internal use; to create a database, call one of the
	 * <a href="ooFDObj.html#newDB(java.lang.String)"><tt>newDB</tt></a>
	 * methods of a federated database.
	 *
	 * <p>You should not use this constructor directly.</p>
	 */
    public ooDBObj(PooDBObj persistor) {
        if (persistor == null)
            throw new ObjyRuntimeException("Users should not directly instantiate ooDBObj");
        this.persistor = persistor ;
    }

	/**
	 * Gets the session in which this database was created or retrieved.</p>
	 *
	 * @return	The session in which this database was created or retrieved.
	 */
    public Session getSession()
        { return persistor().getSession() ; }

    /**
     * Finds the default container of this database.</p>
     *
     * @return      The default container of this database.
     */
    public ooDefaultContObj getDefaultContainer()
        { return persistor().getDefaultContainer(); }

    /**
     * Finds the default container of this database, locking it as
     * specified.</p>
     *
     * @param 	 lockMode	The type of lock to obtain for the container;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
     * </dl></dl></p>
     *
     * @return      The default container of this database; the container
     * is locked as specified by <tt><i>lockMode</i></tt>.
     */
    public ooDefaultContObj getDefaultContainer(int lockMode)
        { return persistor().getDefaultContainer(lockMode); }

    /**
     * Gets the full pathname of this database's file.</p>
     *
     * </p>(<i>HA</i>) You can call
     * {@link #getImageFileName <tt>getImageFileName</tt>}
     * instead of this method for a replicated database.</p>
     *
     * @return      The full pathname of this database's file.
     */
    public String getFileName()
        { return persistor().getFileName() ; }

    /**
     * Gets the name of the host on which this database's file is
     * located.</p>
     *
     * </p>(<i>HA</i>) You can call
     * {@link #getImageHostName <tt>getImageHostName</tt>}
     * instead of this method for a replicated database.</p>
     *
     * @return      The name of the host on which this database's file
     * is located.
     */
    public String getHostName()
        { return persistor().getHostName() ; }

    /**
     * Gets the system name of this database.</p>
     *
     * @return      The system name of this database.
     */
    public String getName()
        { return persistor().getName() ; }

    /**
     * Gets the number of containers in this database.</p>
     *
     * @return      The total number of containers (embedded and external)
	 * in this database.</p>
	 *
	 * @see		#numberOfExternalContainers
     */
    public long getContainerCount()
        { return persistor().getContainerCount() ; }

	/**
	 * Gets the object identifier of this database.</p>
	 *
   	 * @return		The object identifier of this database.
	 */
    public ooId getOid()
        { return persistor().getOid() ; }

    /**
     * Gets the full pathname of the directory where the
     * database file is located.</p>
     *
     * </p>(<i>HA</i>) You can call
     * {@link #getImagePathName <tt>getImagePathName</tt>}
     * instead of this method for a replicated database.</p>
     *
     * @return      The full pathname of the directory where this database's file
     * is located.
     */
    public String getPathName()
        { return persistor().getPathName() ; }

	/**
	 * Gets the federated database that contains this database.</p>
	 *
	 * <p>This method must be called within a transaction.</p>

	 * @return	The federated database that contains this database.
	 */
    public ooFDObj getFD()
        { return persistor().getFD() ; }

	/**
	 * Tests whether this database object is dead.
	 *
	 * <p>A database object becomes a dead object when you
	 * <a href="#delete()">delete</a> the database,
	 * abort the transaction in which the database was created of found, or
     * terminate the session to which the object belongs.</p>
     *
	 * @return	    True if this database object is a dead object; otherwise, false.
	 */
    public boolean isDead()
        { return persistor == null ; }

    /**
     * Deletes this database.
     *
     * <p>Deleting a database:
	 * <p><ul type=disc>
	 * <li> Removes all of its 
     * containers and basic objects. Until the current
     * transaction is committed, this database continues to exist in your
     * application's memory, but it and all of its contained objects are
     * marked dead.</p>
	 *
	 * <li>Deletes its file from the file system, along
	 * with the container files of any external containers belonging to the database.
	 * Aborting the transaction restores the deleted file or files.</p>
	 * 
	 * <li>Checks for relationships from the deleted objects to 
	 * destination objects in other databases. If any of these relationships have
	 * delete propagation enabled, the destination objects are deleted as well.</p>
	 * 
	 * <li>Automatically maintains referential integrity 
	 * by removing any bidirectional relationships between objects 
	 * in the deleted database and objects in other databases. 
	 * (It is your responsibility to adjust any unidirectional relationships to destination objects 
	 * in the deleted database.)
	 * </ul></p>
	 *
	 * <p> If this database is read-only, you must
	 * use the {@link #setReadOnly <tt>setReadOnly</tt>}
	 * method to change it back to read/write before you can delete it.</p>
     *
     *
     * @exception   com.objy.db.ObjectIsDeadException   If an attempt is made
     * to perform delete on a dead object.</p>
     */
    public void delete()
        { persistor().delete() ; }

    /**
     * Deletes this database, optionally preserving the database's file.
	 * 
	 * <p>Calling this method with <tt><i>catalogOnly</i></tt> set to false is equivalent to calling
	 * the database's {@link #delete <tt>delete</tt>} method.
     * 
	 * <p> You can set <tt><i>catalogOnly</i></tt> to <tt>true</tt> if you want to
	 * preserve the database file, or if you want to delete a database whose file is no longer accessible.
	 * It is the application's responsibility to propagate the deletion to related
	 * destination objects as appropriate, and to maintain the referential integrity
	 * of bidirectional relationships and federated-database-wide indexes.
	 * 
     *
     * <p> If this database is read-only, you must
     * use the {@link #setReadOnly <tt>setReadOnly</tt>}
     * method to change it back to read/write before you can delete it.</p>
     *
     * @param  catalogOnly  True to delete this database's entry from the 
	 *    federated database's global catalog, without deleting the database's file;
	 *    false to delete the database's file as well as deleting its entry from the global catalog. 
     * 
     * @exception   com.objy.db.ObjectIsDeadException   If an attempt is made
     * to perform delete on a dead object.</p>
     */
    public void delete(boolean catalogOnly)
        { persistor().delete(catalogOnly) ; }

    /**
     * Explicitly places the specified kind of lock on this database.
     *
     * <p>The lock mode is limited by the open mode of
	 * this database object's session.
     * A session open mode of <tt>openReadWrite</tt> permits lock modes of
     * <tt>WRITE</tt> or <tt>READ</tt>; a session open mode of <tt>openReadOnly</tt>
     * only permits the lock mode <tt>READ</tt>.
	 *
     * <p>Either kind of lock prevents other transactions from concurrently
     * getting read/write access to the database (or its contents).
     *
	 * <p>If this database is already locked, you can call this method to upgrade a
	 * read lock to a write lock, but not to downgrade a write lock to a read
     * lock.</p>
     *
     * @param 	 mode	The kind of lock to place on
     * this database; one
     * of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Place a read lock on the database.</dd>
	 *  <dt><tt>WRITE</tt><dd>Place a a write lock on the database.</dd>
	 * </dd></dl></dl>
	 *
	 */
    public void lock(int mode)
        { persistor().lock(mode) ; }

    /**
     * Transfers the data of all modified persistent objects in this database
     * to the session's Objectivity/DB cache.
     *
     * <p>After the successful execution of this method, the objects are no
     * longer marked as modified.
     *
     * <P>This method makes the data of modified objects available to the
     * process that calls the method, but does not make the changes
     * permanent and available to other processes. When you checkpoint or
     * commit the transaction, the changes become permanent in the federated
     * database.</p>
     */
    public void flush()
        { persistor().flush() ; }

	/**
	 * Makes the specified object persistent, clustering it with this
	 * database, subject to the session's clustering strategy.</p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent. The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The session's
	 * clustering strategy determines where to locate the object relative
	 * to this database. See
     * <a href="../../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd>This method
	 * adds it to this database
	 * with no system name, 5 initial pages, and a growth factor of 10%.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @see     <a href="#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>addContainer(ooContObj, int, String, long, long)</tt></a>
     * @see     <a href="#addExternalContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long, java.lang.String, java.lang.String, int)">
	 * <tt>addExternalContainer(ooContObj, int, String, long, long, String, String, int)</tt></a>
	 */
    public void cluster(Object object)
        { persistor().cluster(object, getSession().getClusterStrategy()); }

	/**
	 * Makes the specified object persistent, clustering it with this
	 * database, subject to the specified clustering strategy.</p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent. The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The specified
	 * clustering strategy determines where to locate the object relative
	 * to this database. See
     * <a href="../../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd>This method
	 * adds it to this database
	 * with no system name, 5 initial pages, and a growth factor of 10%.</dd>
	 * </dd></dl></dl></p>
	 *
     * @param 	 strategy    Clustering strategy to determine
     * the location of a basic object.
     * This parameter is ignored if
     * <tt><i>object</i></tt> is a container.</p>
     *
	 * @see     <a href="#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>addContainer(ooContObj, int, String, long, long)</tt></a>
     * @see     <a href="#addExternalContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long, java.lang.String, java.lang.String, int)">
	 * <tt>addExternalContainer(ooContObj, int, String, long, long, String, String, int)</tt></a>
	 */
    public void cluster(Object object, ClusterStrategy strategy)
        { persistor().cluster(object, strategy); }

	/**
	 * Names the specified object in the scope of this database.
     *
     * <p>If the specified object is transient, this method makes it persistent.
     * If the specified object is already persistent, this method locks it
	 * for write.
	 *
	 * <p>This method locks this database for write.</p>
	 *
	 * @param 	 object	The object to be named.</p>
	 *
	 * @param 	 scopeName	The name for the specified
	 * object in the scope of this database.
     * This string must consist of only ASCII characters and must be unique
	 * within  the name scope of this database.</p>
     *
     * @see #lookupObj(String)
     * @see #unnameObj(Object)
	 */
    public void nameObj(Object object, String scopeName)
        { persistor().nameObj(object, scopeName) ; }

	/**
	 * Removes the specified object's name from the
	 * name scope of this database.
	 *
	 * <p>This method locks both this database and
	 * <tt><i>object</i></tt> for write.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * removed.</p>
	 *
	 * @exception   ObjyRuntimeException    If
	 * <tt><i>object</i></tt> has no name
	 * in the scope of this database.</p>
	 *
     * @see #lookupObj(String)
     * @see #nameObj(Object, String)
	 */
    public void unnameObj(Object object)
        { persistor().unnameObj(object) ; }

	/**
	 * Finds the object with the specified scope name in the scope defined
     * by this database.</p>
	 *
	 * @param 	 scopeName	The scope name to look up.</p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this database. The returned object is locked for read.</p>
	 *
	 * @exception   ObjyRuntimeException    If there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this
     * database.</p>
	 *
	 * @see #lookupObjName(Object)
	 */
    public Object lookupObj(String scopeName)
        { return persistor().lookupObj(scopeName) ; }

	/**
	 * Finds the object with the specified scope name in the scope defined
     * by this database, locking the
	 * found object as specified.</p>
	 *
	 * @param 	 scopeName	The scope name to look
	 * up.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this database; the returned object
	 * is locked as specified by <tt><i>lockMode</i></tt>.</p>
	 *
	 * @exception   ObjyRuntimeException    If there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this
     * database.</p>
	 *
	 * @see #lookupObjName(Object)
	 */
    public Object lookupObj(String scopeName, int lockMode)
        { return persistor().lookupObj(scopeName, lockMode) ; }

	/**
	 * Looks up the name of the specified object in the scope defined
     * by this database.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * looked up.</p>
	 *
	 * @return		The scope name of the specified object in the name scope
	 * of this database.</p>
	 *
	 * @exception   ObjyRuntimeException    If <tt><i>object</i></tt> has no
	 * name in the scope of this database.</p>
	 *
	 * @see #lookupObj(String)
	 */
    public String lookupObjName(Object object)
        { return persistor().lookupObjName(object) ; }

    /**
     * <i>(HA)</i> Tests whether there is more than one image of this
	 * database.</p>
	 *
     * @return      True if there is more than one image of this
	 * database; otherwise, false.
     */
    public boolean isReplicated()
        { return persistor().isReplicated() ; }

    /**
     * <i>(HA)</i> Gets the number of images of this database.</p>
     *
     * @return      The number of images. For any existing database,
     * there is always at least one image.
     */
    public long getImageCount()
        { return persistor().getImageCount() ; }

    /**
     * <i>(HA)</i> Finds the tie-breaker autonomous partition of this
	 * database.</p>
	 *
     * @return      The tie-breaker partition, or null if there is none.</p>
     *
     * @see #setTieBreaker(ooAPObj)
     */
    public ooAPObj getTieBreaker()
        { return persistor().getTieBreaker(); }

    /**
     * <i>(HA)</i> Sets the tie-breaker autonomous partition of this
	 * database.</p>
	 *
     * @param 	 partition    The tie-breaker
	 * autonomous partition. Any existing
     * tie breaker for this database is eliminated if
	 * <tt><i>partition</i></tt> is null.</p>
	 *
	 * @exception   ObjyRuntimeException    If
	 * <tt><i>partition</i></tt> already contains an
	 * image of this database.</p>
	 *
     * @see #getTieBreaker
     */
    public void setTieBreaker(ooAPObj partition)
        { persistor().setTieBreaker((partition != null) ? partition.persistor() : null); }

    /**
     * <i>(HA)</i> Changes the autonomous partition that contains
     * this database.
     *
     * <p>The database is assigned to the partition <tt><i>partition</i></tt>
     * and is removed from its current controlling partition.
     *
     * <p>This method updates logical containment
     * information in the catalogs of the autonomous partitions.
     * If you also want to change the physical location of a database file,
     * you can do so using the database's {@link #change <tt>change</tt>} method
	 * or the Objectivity/DB <tt>oochangedb</tt> tool.
     *
     * <p>You may not combine this operation with other updates to the
     * database in the same transaction. You should consider executing
     * <tt>changePartition</tt> in a separate transaction.
     *
     * <p>If this database is read-only, you must use the
     * {@link #setReadOnly <tt>setReadOnly</tt>}  method to change it
     * back to read/write before you can change its partition.
     *
     * @param 	 partition  The autonomous partition that
     * is to control the database.
     *
     * @exception   ObjyRuntimeException    If multiple images of this
     * database exist.</p>
     */
    public void changePartition(ooAPObj partition)
        { persistor().changePartition(partition.persistor()) ; }

    /**
     * <i>(HA)</i> Gets the weight of the image of this database controlled in the
     * specified autonomous partition.</p>
     *
     * @param 	 partition  The partition controlling this
     * database's image.</p>
     *
     * @return      The weight assigned to the image in the specified
     * partition.</p>
     *
     * @see #setImageWeight(ooAPObj, long)
     */
    public long getImageWeight(ooAPObj partition)
        { return persistor().getImageWeight(partition.persistor()) ; }

    /**
     * <i>(HA)</i> Gets the directory location of this database's image file controlled by
     * the specified autonomous partition.</p>
     *
     * @param 	 partition  The autonomous partition
     * controlling this database's image.</p>
     *
     * @return      The full pathname of the directory where this database's image
     * file is located.</p>
     */
    public String getImagePathName(ooAPObj partition)
        { return persistor().getImagePathName(partition.persistor()) ; }

    /**
     * <i>(HA)</i> Gets the filename of this database's image
     * controlled by the specified autonomous partition.</p>
     *
     * @param 	 partition The autonomous partition
     * controlling this database's image.</p>
     *
     * @return      The filename of this database's image.
     */
    public String getImageFileName(ooAPObj partition)
        { return persistor().getImageFileName(partition.persistor()) ; }

     /**
     * <i>(HA)</i> Gets the host location of this database's image file controlled by
     * the specified autonomous partition.</p>
     *
     * @param 	 partition  The autonomous partition
     * controlling this database's image.</p>
     *
     * @return      The name of the host on which this database's image file
     * is located.
     */
    public String getImageHostName(ooAPObj partition)
        { return persistor().getImageHostName(partition.persistor()) ; }

    /**
     * <i>(HA)</i> Sets the weight of this database's image in the
     * specified autonomous partition.</p>
     *
     * <p>You cannot change the weight of an image of a read-only database.
     * If this database is read-only, you must call the
     * {@link #setReadOnly <tt>setReadOnly</tt>} method to change it
     * back to read/write before you can change the weight of an individual
     * image.</p>
     *
     * @param 	 partition  The partition controlling
	 * the database image.</p>
	 *
     * @param 	 weight  The weight to assign to the image; the weight
     * must be greater than 0.</p>
     *
     * @see #getImageWeight(ooAPObj)
     */
    public void setImageWeight(ooAPObj partition, long weight)
        { persistor().setImageWeight(partition.persistor(), weight) ; }

    /**
     * <i>(HA)</i> Tests whether the specified image of this database is currently
	 * available for various uses.</p>
	 *
	 * <p>The specified image is considered available as follows:
	 * <p><ul type=disc>
	 * <li>Available for both reading and updating if the application can access a quorum
	 * of images for this database, and the specified image is one of the
	 * quorum images. </p>
	 * <li>Available for nonquorum reading if the application cannot access a quorum of
	 * images for this database, but the image is accessible and in the
	 * most recently recorded quorum for the database. (This ensures consistency
	 * with any pages cached before access to the quorum was lost.)
	 * </ul></p>
     *
     * @param 	 partition  The autonomous partition controlling the image
	 * to be tested.</p>
     *
     * @return      True if the image of this database in the
     * specified autonomous partition is available; otherwise, false.</p>
	 *
	 * @see #availability
	 *
     */
    public boolean isImageAvailable(ooAPObj partition)
        { return persistor().isImageAvailable(partition.persistor()) ;}

    // DAD New HA Stuff
	/**
	 * <i>(HA)</i> Returns the last known availability status of this database.</p>
	 *
    * @return		The availability status of this database; one
     * of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>ALL_AVAILABLE</tt><dd>The database is available for both reading and updating, because a quorum
	 * of its images can be accessed; furthermore, this quorum consists of all of the database's images.</dd>
	 *  <dt><tt>QUORUM_AVAILABLE</tt><dd>The database is available for both reading and updating, because a quorum of its images
	 * can be accessed; however, the quorum consists of only a subset of the database's images.</dd>
	 *  <dt><tt>NON_QUORUM_READ_AVAILABLE</tt><dd>The database is potentially available for nonquorum reading,
	 * because at least one image can be accessed, but the accessible image(s) do not constitute a quorum.</dd>
	 *  <dt><tt>UNAVAILABLE</tt><dd>The database is not available for any purpose, because
	 * none of its images can be accessed.</dd>
	 *  <dt><tt>UNKNOWN_AVAILABILITY</tt><dd>The database's availability is not currently known, possibly due to an error.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @see #isImageAccessible
	 * @see #isImageAvailable
	 */
    public int availability()
        { return persistor().availability() ; }

    // DAD New HA Stuff

	/**
	 * <i>(HA)</i> Tests whether the specified image of this database is currently
	 * accessible to the application.</p>
	 *
	 * <p>The specified image is considered accessible if the application can successfully
	 * open the image file using AMS, contact the lock server of the controlling partition,
	 * and write to the controlling partition's journal directory. If any of these actions
	 * cannot be completed before the session's network timeout period elapses, this
	 * method concludes that the image is inaccessible.</p>
	 *
	 * <p>Consequently, the accuracy of the result is affected by the network timeout
	 * period. If the period is too short, attempts to access the image may time out
	 * prematurely, and the image may be incorrectly reported as inaccessible. (On the
	 * other hand, if the period is very long, the test for accessibility may cause a
	 * noticeable delay.)</p>
	 *
	 * @param 	 partition  The autonomous partition controlling the image
	 * to be tested.</p>
	 *
	 * @return      True if the image of this database in the
	 * specified autonomous partition is accessible; otherwise, false.</p>
	 *
	 * @see #availability
	 *
	 */
    public boolean isImageAccessible(ooAPObj partition)
        { return persistor().isImageAccessible(partition.persistor()) ;}

    // DAD New HA Stuff
	/**
	 * <i>(HA)</i> Ensures the specified image of this database is in the quorum for
	 * the database.</p>
	 *
	 * <p>If this database has a nonquorum image that has recently become
	 * accessible, you can use this method to restore the image into
	 * service�that is, to add the image back into the quorum for the database and
	 * synchronize its contents with the other quorum images. </p>
	 *
	 * <p>This method provides a fast way to restore a particular image into an
	 * existing quorum, but may overlook other nonquorum images of the database
	 * that have recently become accessible. In particular, this method checks whether
	 * the currently recorded quorum for this database is still valid, and, if
	 * so, simply adds the specified image to the existing quorum list without testing
	 * for other accessible nonquorum images that could also be added to the quorum.
	 * (A full quorum calculation is performed only if the existing quorum list no
	 * longer contains enough accessible images to constitute a quorum.)
	 * This method performs no action if the
	 * specified image is already in the quorum or if this database is not
	 * replicated.</p>
	 *
	 *
	 * @param 	 partition  The autonomous partition controlling that controls the
	 * desired database image.</p>
	 *
	 *
	 * @see #negotiateQuorum
	 * @see ooAPObj#ensureAllImagesInQuorums
	 *
	 */
    public void ensureImageInQuorum(ooAPObj partition)
        { persistor().ensureImageInQuorum(partition.persistor()) ; }

    // DAD New HA Stuff
	/**
	 * <i>(HA)</i> Finds the current session's read image for this database.</p>
	 *
	 * This method finds the image for reading this database in the
	 * current session, regardless of whether the read image was set automatically when
	 * the database was first opened, or by an explicit call to <tt>setReadImage</tt>.</p>
	 *
	 * @return       The autonomous
	 * partition controlling the read image, or 0 if this
	 * database has no read image in the current session.</p>
	 *
	 * @see #setReadImage
	 *
	 */
    public ooAPObj getReadImage()
        { return persistor().getReadImage(); }

    // DAD New HA Stuff
	/**
	 * <i>(HA)</i> Sets the specified image to be the read image for this database.</p>
	 *
	 * This method specifies the particular database image from which storage
	 * pages will be read during the current session. The specified image is used as the
	 * read image until a transaction aborts or the image becomes inaccessible.
	 *
	 * An application usually sets a read image to exercise control over load balancing
	 * or network usage. If you do not call this method, the read image is
	 * chosen by Objectivity/DB. If you call this method after a read image
	 * has been chosen, the specified image replaces it.</p>
	 *
	 * @param 	 partition  The autonomous
	 * partition controlling the image to be read.</p>
	 *
	 * @see		#getReadImage
	 */
    public void setReadImage(ooAPObj partition)
        { persistor().setReadImage(partition.persistor()) ; }

    /**
     * <i>(HA)</i> Tests whether an image of this database
     * exists in the specified autonomous partition.</p>
     *
     * @param 	 partition  The autonomous
     * partition to test.</p>
     *
     * @return      True if an image exists in the partition;
     * otherwise, false.
	 *
     */
    public boolean hasImageIn(ooAPObj partition)
        { return persistor().hasImageIn(partition.persistor()) ;}

    /**
     * <i>(HA)</i> Deletes the image of this database controlled by the
     * specified autonomous partition.
     *
     * <p>If the specified partition contains the <i>last</i> image of this
     * database, that image is <i>not</i> deleted.</p>
     *
     *
     * @param 	 partition  The autonomous partition controlling the image.
     */
    public void deleteImage(ooAPObj partition)
        { persistor().deleteImage(partition.persistor()) ; }

    /**
     * <i>(HA)</i> Deletes the image of this database in the specified
     * autonomous partition, possibly deleting the last image of
     * this database.
     *
     * <p>If the specified partition contains the last image of this
     * database and <tt><i>deleteDBifLast</i></tt>
     * is true, that image and the database itself are deleted.
     * If <tt><i>deleteDBifLast</i></tt> is false, the last image is not
     * deleted.</p>
     *
     *
     * @param 	 partition  The autonomous partition
	 * controlling the image.</p>
	 *
     * @param 	 deleteDBifLast True to delete the
     * specified image even if it is the last image of this database;
     * otherwise, false.
     */
    public void deleteImage(ooAPObj partition, boolean deleteDBifLast)
        { persistor().deleteImage(partition.persistor(), deleteDBifLast) ; }

   /**
     * <i>(HA)</i> Creates an image of this database in the specified
     * autonomous partition with the given weight.
	 *
	 * <p>You cannot replicate this database if it contains any external containers.
	 * Call the {@link #numberOfExternalContainers <tt>numberOfExternalContainers</tt>}
	 * method to test for external containers.</p>
     *
     *
     * @param 	 partition  The partition in which this
     * database's image will be created.</p>
     *
     * @param 	 hostName    Data-server host on which to create the new
     * database image. The designated host machine must be running AMS.
     * The designated host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>hostName</i></tt> is null or an empty string, the
     * designated host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>pathName</i></tt> is a local path.
     * <li>The host implied by <tt><i>pathName</i></tt>, if <tt><i>pathName</i></tt> is an
     * NFS mount name.
     * <li>The host of the system-database file, if <tt><i>pathName</i></tt> is also null.
     * </ul></p>
	 *
     * <li>Otherwise, the host <tt><i>hostName</i></tt> is used.</ul></p>
	 *
     * @param 	 pathName    Pathname of the new database-image file on the
     * designated host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of the pathname must follow the naming conventions of
     * the designated host. Because the host must be running AMS,
	 * <tt><i>pathName</i></tt> must be understood locally by the host's file system;
	 * you may not specify a Windows UNC share name.
	 * If <tt><i>pathName</i></tt> is an NFS mount name, it is automatically converted
	 * to the corresponding local pathname on the implied host.
	 * </p>
     * <li>If the designated host is a remote system,
     * <tt><i>pathName</i></tt> must be fully qualified; otherwise,
     * <tt><i>pathName</i></tt> may be either relative or
     * fully qualified. </p>
     * <li><tt><i>pathName</i></tt> may optionally
     * include a filename for the database image; if
     * you omit the filename, it is generated automatically. </p>
     * <li>This parameter may be null only if <tt><i>hostName</i></tt> is also null or an
     * empty string; in this case, the directory of the controlling partition's system-database
     * file is used.
     * </ul></p>
     *
     * @param 	 weight  The weight of the new database image.
     * The default is 1; the weight must be greater than 0.</p>
     *
	 * @exception   ObjyRuntimeException    If
	 * <tt><i>partition</i></tt> already contains an
	 * image of this database.
     */
    public void replicate(ooAPObj partition, String hostName, String pathName, long weight)
        // use empty string to use default host and path
        { persistor().replicate(partition.persistor(), hostName, pathName, weight) ; }

    /**
     * <i>(HA)</i> Finds the autonomous partition that controls
     * this database.</p>
     *
     * </p> You can call {@link #containingImage <tt>containingImage</tt>}
     * instead of this method for a replicated database.</p>
     *
     * @return  The autonomous partition controlling the image.</p>
     *
     * @exception   ObjyRuntimeException    If this database is replicated.<p>
     */
    public ooAPObj getContainingPartition()
        { return persistor().getContainingPartition(); }

    /**
     * <i>(HA)</i> Initializes an object iterator to find all the autonomous
     * partitions in which this database has images.</p>
     *
     * @return      An object iterator that finds all the autonomous partitions
     * in which this database has images. When the object iterator finds an
     * autonomous partition, it does not open or lock the partition.
     */
    public Iterator containingImage()
        { return persistor().containingImage(); }

	/**
	 * <I>(HA)</I> Specifies whether this application can read this
	 * database even if the accessible images of the database
	 * do not constitute a quorum.</p>
     *
	 * <p><b>Warning: </b>If you enable nonquorum reading, your
	 * application may read stale data from this database.</p>
	 *
	 * <p>By default, nonquorum reading is disabled for all application-created
	 * databases. You must call this method explicitly to permit nonquorum reading for
	 * a particular database during a particular transaction.
	 *
	 * <p>If the session is not in a transaction when this method is called, nonquorum reading
	 * is enabled for this database in the next transaction.
	 * Nonquorum reading is automatically disabled at the end of the transaction in
	 * which this method is called.
	 *
	 * <p>When an application enables nonquorum reading for a database,
	 * the application reads the database using a quorum of images, if a quorum
	 * is accessible; otherwise, if a quorum cannot be established or is lost,
	 * reading may proceed without the quorum. Nonquorum reading is possible only
	 * if least one of the database's images is available for use as a read image.
	 * The application can explicitly set a read image for the database
	 * (see {@link #setReadImage <tt>setReadImage</tt>}).</p>
	 *
	 * @param   allowed True to allow this application to read this database
	 * even if a quorum cannot be accessed; false to prevent this
	 * application from reading this database when a quorum cannot be accessed.
	 *
     * @see #isNonQuorumReadAllowed
     * @see #isNonQuorumRead
     * @see Session#setAllowNonQuorumRead
	 */
    public void setNonQuorumReadAllowed(boolean allowed)
        { persistor().setNonQuorumReadAllowed(allowed); }

	/**
	 * <I>(HA)</I> Tests whether this application can read this database even
	 * when the accessible images of the database do not constitute a quorum.</p>
     *
	 * @return	    True if nonquorum reads are allowed; otherwise, false.</p>
     *
     * @see #setNonQuorumReadAllowed
     * @see #isNonQuorumRead
     * @see Session#setAllowNonQuorumRead
	 */
    public boolean isNonQuorumReadAllowed()
        { return persistor().isNonQuorumReadAllowed(); }

    /**
     * <I>(HA)</I> Forces recalculation of the quorum for this database.
	 *
	 * <p>This method ensures that the quorum for this database is as
	 * inclusive as possible. If the database has any nonquorum images that have recently
	 * become accessible, those images are restored into service�that is, they are added
	 * back into the quorum for the database and resynchronized (updated to be
	 * consistent) with the other quorum images.
	 *
	 *
	 * <p>If this database is not replicated, this method performs no action.
	 *
	 * <p>This method throws an exception and performs no action if the
     * application does not have access to a quorum of images for this
     * database.
     *
     * <p>You may not recalculate a quorum if the application is currently performing
	 * nonquorum reading in this database--that is, if
	 * {@link #isNonQuorumRead <tt>isNonQuorumRead</tt>} returns true
	 * and at least one container in the database is open. (Nonquorum reading prevents
	 * the quorum from being retested or updated for the rest of the transaction.)
	 * You can disable nonquorum reading by ending the current transaction; then call
	 * <tt>negotiateQuorum</tt> from within a new transaction.</p>
	 *
	 * <p>Recalculating a quorum for a database can momentarily reduce the
     * runtime performance of every application accessing the database,
     * whether or not recalculation actually changes the quorum. Consequently,
	 * before calling this method, you should test whether the database
	 * has any newly accessible images to add to the quorum.</p>
     *
	 * @param 	 lockMode	The type of lock to obtain for
	 * this database;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @see #availability
     * @see #ensureImageInQuorum
     * @see #isImageAccessible
     * @see #isImageAvailable
     */
    public void negotiateQuorum(int lockMode)
    { persistor().negotiateQuorum(lockMode); }


     /**
      * <I>(HA)</I> Tests whether the application is currently performing nonquorum reading
	  * in this database.
	  *
	  * <p>Nonquorum reading of a database is possible only after an
	  * application has called this database's
	  * {@link #setNonQuorumReadAllowed <tt>setNonQuorumReadAllowed</tt>}
	  * method during the current transaction.</p>
	  *
	  * @return	    True if the application is reading
	  * this database without having access to a quorum of images;
	  * otherwise, false.
	  *
	  * <p><b>Warning: </b>If this method returns true, your application
	  * may be reading stale data from this database.
      */
    public boolean isNonQuorumRead()
    { return persistor().isNonQuorumRead(); }


    /**
     * <i>(For backward compatibility only)</i> Adds the specified container with the
	 * specified properties to this database.
	 *
	 * <p> The added container has the specified system name, hash value,
	 * number of initial pages, and percent growth.</p>
	 *
     * <p>This method makes the specified container persistent and locks it
     * and this database in write mode.</p>
	 *
	 * <p>This method is appropriate if this
	 * database uses the pre-Release&nbsp;9.0 internal database format.
	 * Within such a database, the scope-naming mechanism is sensitive to whether
	 * a container is <i>hashed</i> or <i>nonhashed</i>. The <tt><i>hash</i></tt>
	 * parameter of this method specifies the hash value of the added container.
	 *
	 * <p>If this database uses the Release&nbsp;9.0 (or later) internal database format,
	 * its scope-naming mechanism does not use hashed containers,
	 * so the added container is nonhashed.
	 * <b>Note:</b> The preferred method
	 * for adding containers to a Release&nbsp;9.0 (or later) database is
	 * {@link #addContainer(ooContObj, int, String, long, long) <tt>addContainer(ooContObj, int, String, long, long)</tt>}.</p>
	 *
	 *
     * @param 	 container    The container to be added to
	 * this database.</p>
	 *
     * @param 	 name    The system name of the container.
     * A valid system name follows the same rules as for naming files within the operating system.
     * Specify an empty string or null to create an unnamed
	 * container.</p>
	 *
     * @param 	 hash    Specifies whether to add a hashed container:
	 * <ul type=disc>
	 * <li>If <tt><i>hash</i></tt> is 0, the container is nonhashed. Neither the added container
	 * or any basic object in it may be used as a scope object for naming a persistent object.
	 * <li>If <tt><i>hash</i></tt> is 1 or greater, the container is hashed.
	 * The added container and any of its basic objects may be used as a scope object for naming a persistent object.
	 * </ul></p>
	 * <p><b>Note:</b> The <tt><i>hash</i></tt> parameter applies only if
	 * this database uses the pre-Release&nbsp;9.0 internal database format. Otherwise,
	 * if the Release&nbsp;9.0&nbsp;(or later) internal database format is used,
	 * the value of this parameter is 0, regardless of the value you specify.</p>
	 *
     *
     * @param 	 initialPages  The initial number of pages
     * allocated for the container. Specify 0 to use obtain a value that is
	 * based on the value of the <tt><i>hash</i></tt> parameter:</p>
	 * <ul type=disc>
	 * <li>If <tt><i>hash</i></tt> is 0, the container is created with 2 pages.
	 * <li>If <tt><i>hash</i></tt> is 1, the container is created with 4 pages.
	 * </ul></p>
     *
	 * @param 	 growthFactor Amount by which the added container may grow when it needs to
	 * accommodate more basic objects, expressed as a percentage of its current
	 * number of storage pages.
	 * Specify 0 to use the system default value (10%).</p>
	 *
     * @exception   ObjyRuntimeException    If this database already has a container
	 * named <tt><i>name</i></tt>. You can call
	 * <a href="#hasContainer(java.lang.String)"><tt>hasContainer</tt></a> to test whether
	 * a container with the name <i><tt>name</tt></i> exists in this
	 * database.
	 *
     */
    public void addContainer(ooContObj container, String name,
            long hash, long initialPages, long growthFactor)
        { persistor().addContainer(container, name, hash, initialPages, growthFactor); }

    /**
     * Adds the specified container with the specified properties to this database; the container
	 * is embedded in this database's file.
	 *
	 * <p> The added container has the specified system name, identifier,
	 * number of initial pages, and percent growth.</p>
	 *
     * <p>This method makes the specified container persistent and locks it
     * and this database in write mode.
	 *
	 * <p><b>Note:</b>&nbsp;If this database uses the pre-Release&nbsp;9.0 internal database format,
	 * the container is added as a hashed container. If you want to
	 * add a nonhashed container to a pre-Release&nbsp;9.0 database, you must call
	 * {@link #addContainer(ooContObj, String, long, long, long) <tt>addContainer(ooContObj, String, long, long, long)</tt>}.</p>
     *
     * @param 	 container    The container to be added to
	 * this database.</p>
	 *
	 * @param 	 contId	Application-assigned container identifier,
	 * expressed as a single integer. You may not specify the identifiers 1 or 2,
	 * which are reserved by Objectivity/DB. Specify 0 to allow Objectivity/DB to
	 * assign the identifier.
	 * The maximum container identifier is 65535.
	 * <b>Note:</b>&nbsp;If this database uses the pre-Release&nbsp;9.0 internal database format,
	 * the maximum is 32766.</p>
	 *
     * @param 	 name    The system name of the container.
     * A valid system name follows the same rules as for naming files within the operating system.
     * Specify an empty string or null to create an unnamed
	 * container.</p>
     *
     * @param 	 initialPages  The initial number of pages
     * allocated for the container. Specify 0 to use the system default value (4).
	 * The minimum recommended value is 2. You should add 2 extra pages if you plan
	 * to use the container or any basic object in it as a scope object.
	 * <b>Note:</b>&nbsp;If this database uses the pre-Release&nbsp;9.0 internal database format,
	 * the minimum value is 4; any lower value is ignored.</p>
     *
	 * @param 	 growthFactor Amount by which the added container may grow when it needs to
	 * accommodate more basic objects, expressed as a percentage of its current
	 * number of storage pages.
	 * Specify 0 to use the system default value (10%).</p>
     *
     * @exception   ObjyRuntimeException    If this database already has a container
	 * with the specified name. You can call
	 * <a href="#hasContainer(java.lang.String)"><tt>hasContainer(String)</tt></a> to test whether
	 * a container with the name <i><tt>name</tt></i> exists in this
	 * database.</p>
	 *
     * @exception   ObjyRuntimeException    If this database already has a container
	 * with the specified container identifier.
	 * You can call
	 * <a href="#hasContainer(int)"><tt>hasContainer(int)</tt></a> to test whether
	 * a container with the identifier <i><tt>contId</tt></i> exists in this
	 * database.
	 *
     */
    public void addContainer(ooContObj container, int contId, String name, long initialPages, long growthFactor)
        { persistor().addContainer(container, contId, name, initialPages, growthFactor); }

	/**
	 * Adds the specified container with the specified properties to this database;
	 * the container is added as an external container stored in its own container file.
	 *
	 * <p> The added container has the specified system name, identifier,
	 * number of initial pages, percent growth, host and pathname for
	 * its container file, and storage-page size.</p>
	 *
	 * <p>This method makes the specified external container persistent and locks it
	 * and this database in write mode.
	 *
	 * <p><b>Note:</b>&nbsp;If this database uses the pre-Release&nbsp;9.0 internal database format,
	 * you may not add an external container to it. </p>
	 *
	 * @param 	 container    The container to be added to
	 * this database.</p>
	 *
	 * @param 	 contId	Application-assigned container identifier,
	 * expressed as a single integer. You may not specify the identifiers 1 or 2,
	 * which are reserved by Objectivity/DB. The maximum container identifier is 65535.
	 * Specify 0 to allow Objectivity/DB to assign the identifier.</p>
	 *
	 * @param 	 name    The system name of the container.
	 * A valid system name follows the same rules as for naming files within the operating system.
	 * Specify an empty string or null to create an unnamed
	 * container.</p>
	 *
	 * @param 	 initialPages  The initial number of pages
	 * allocated for the container. Specify 0 to use the system default value (4).</p>
	 *
	 * @param 	 growthFactor Amount by which the added container may grow when it needs to
	 * accommodate more basic objects, expressed as a percentage of its current
	 * number of storage pages. Specify 0 to use the system default value (10%).</p>
	 *
	 * @param 	 hostName	Data-server host on which to create
	 * the new container file. The designated host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>hostName</i></tt> is an empty string or null, the
     * designated host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>pathName</i></tt> is a local path.
     * <li>The host implied by <tt><i>pathName</i></tt>, if <tt><i>pathName</i></tt> is an
     * NFS mount name.
     * <li>The host of the parent database file, if <tt><i>pathName</i></tt> is also null.
     * </ul></p>
     *
     * <li>If <tt><i>pathName</i></tt> is a Windows UNC share name, <tt><i>hostName</i></tt> is
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>hostName</i></tt> is used.</ul></p>
	 *
	 * @param 	 pathName	Pathname of the new container file on the designated host.
     * Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of the pathname must follow the naming conventions of
     * the designated host.</p>
     * <li>If the designated host is a remote system,
     * <tt><i>pathName</i></tt> must be fully qualified; otherwise,
     * <tt><i>pathName</i></tt> may be either relative or
     * fully qualified. </p>
     * <li><tt><i>pathName</i></tt> may optionally include a filename for the container file;
	 * if you omit the filename, it is generated automatically.</p>
     * <li>This parameter may be null only if <tt><i>hostName</i></tt> is also null or an empty string;
     * in this case, the directory of the parent database's file is used.
     * </ul></p>
	 *
	 * @param 	 pageSize    Storage-page size in bytes. Allowable
	 * page sizes are integer multiples of 8 between 1024 and 65536 (inclusive).
	 * Specify 0 to use the storage-page size of this database.</p>
	 *
     * @exception   ObjyRuntimeException    If this database already has a container
	 * with the specified name. You can call
	 * <a href="#hasContainer(java.lang.String)"><tt>hasContainer(String)</tt></a> to test whether
	 * a container with the name <i><tt>name</tt></i> exists in this
	 * database.</p>
	 *
     * @exception   ObjyRuntimeException    If this database already has a container
	 * with the specified container identifier.
	 * You can call
	 * <a href="#hasContainer(int)"><tt>hasContainer(int)</tt></a> to test whether
	 * a container with the identifier <i><tt>contId</tt></i> exists in this
	 * database.</p>
	 *
	 * @exception   ObjyRuntimeException    If this database uses the
	 * pre-Release&nbsp;9.0 internal database format.  You can call
	 * {@link #addContainer(ooContObj, String, long, long, long) <tt>addContainer(ooContObj, String, long, long, long)</tt>}
	 * to add an embedded container instead.
	 *
	 *
	 */
    public void addExternalContainer(ooContObj container, int contId, String name, long initialPages, long growthFactor,
            String hostName, String pathName, int pageSize)
        { persistor().addExternalContainer(container, contId, name, initialPages, growthFactor, hostName, pathName, pageSize); }

	/**
	 * Gets the number of external containers belonging to this database.</p>
	 *
	 * @return      Number of containers stored in separate container files; returns 0
	 * if this database has no external containers.</p>
	 *
	 * @see		#getContainerCount
	 *
	 */
    public int numberOfExternalContainers()
        { return persistor().numberOfExternalContainers() ; }

    /**
     * Tests whether a container with the specified system name
     * exists in this database.</p>
     *
     * @param 	 name      The system name of the
	 * container.</p>
	 *
     * @return      True if the container with the system name <tt><i>name</i></tt>
     * exists in this database; otherwise false.
     *
     */
    public boolean hasContainer(String name)
        { return persistor().hasContainer(name) ; }

    /**
     * Tests whether a container with the specified integer identifier
     * exists in this database.</p>
     *
     * @param 	 contId      The integer identifier of the
	 * container.</p>
	 *
     * @return      True if the container with the integer identifier <tt><i>contId</i></tt>
     * exists in this database; otherwise false.
     *
     */
    public boolean hasContainer(int contId)
        { return persistor().hasContainer(contId) ; }

    /**
     * Finds the container with the specified system name in this database.</p>
     *
     * @param 	 name    The system name of the
     * container.</p>
	 *
     * @return      The specified container.</p>
     *
     * @exception    ObjectNotFoundException    If this database
	 * does not have a container with the specified system name.</p>
     *
     * @exception    LockNotGrantedException    If a lock for the
	 * container with the specified system name could not be obtained.
     *
     */
    public ooContObj lookupContainer(String name)
        { return persistor().lookupContainer(name) ; }

    /**
     * Finds the container with the specified system name in this database,
     * locking the found container as specified.</p>
     *
     * @param 	 name    The system name of the
     * container.</p>
     *
     * @param 	 lockMode	The type of lock to obtain for the container;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
     * </dl></dl></p>
     *
     * @return      The specified container; the container is locked as
     * specified by <tt><i>lockMode</i></tt>.</p>
     *
     * @exception   ObjectNotFoundException    If this database
	 * does not have a container with the specified system name.</p>
     *
     * @exception   LockNotGrantedException    If a lock for the
	 * container with the specified system name could not be obtained.
     *
     */
    public ooContObj lookupContainer(String name, int lockMode)
        { return persistor().lookupContainer(name, lockMode) ; }

    /**
     * Finds the container with the specified integer identifier in this database.</p>
     *
     * @param 	 contId    The integer identifier of the
     * container.</p>
	 *
     * @return      The specified container.</p>
     *
     * @exception   ObjectNotFoundException    If this database
	 * does not have a container with the specified integer identifier.</p>
     *
     * @exception   LockNotGrantedException    If a lock for the
	 * container with the specified integer identifier could not be obtained.
     *
     */
    public ooContObj lookupContainer(int contId)
        { return persistor().lookupContainer(contId) ; }

    /**
     * Finds the container with the specified integer identifier in this database,
     * locking the found container as specified.</p>
     *
     * @param 	 contId    The integer identifier of the
     * container.</p>
     *
     * @param 	 lockMode	The type of lock to obtain for the container;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
     * </dl></dl></p>
     *
     * @return      The specified container; the container is locked as
     * specified by <tt><i>lockMode</i></tt>.</p>
     *
     * @exception   ObjectNotFoundException    If this database
	 * does not have a container with the specified integer identifier.</p>
     *
     * @exception   LockNotGrantedException    If a lock for the
	 * container with the specified integer identifier could not be obtained.
     *
     */
    public ooContObj lookupContainer(int contId, int lockMode)
        { return persistor().lookupContainer(contId, lockMode) ; }

    /**
     * Initializes an object iterator to scan this database for objects
     * of the specified class.</p>
     *
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
     *
     * @return      An object iterator that finds the specified objects.
     */
    public Iterator scan(String className)
        { return persistor().scan(className) ; }

    /**
     * Initializes an object iterator to scan this database for objects
     * of the specified class that satisfy the specified predicate.
     *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan
     * policy.  See
     * <a href="../../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 *
     * @param 	 predicate       The condition that each
     * found object must satisfy, expressed in the Objectivity/DB
     * <a href="../../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
     *
     * @return      An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     *
     */
    public Iterator scan(String className, String predicate)
       { return persistor().scan(className, predicate) ; }
    
    /**
     * Initializes an object iterator to  scan
     * this database for objects qualified by an
	 * Object qualifier.
	 *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan
     * policy.  See
     * <a href="../../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
     * @param    className      The package-qualified name
     * of the class of the desired objects.</p>
     * 
     * @param 	 oq      The Object qualifier instance. </p>
     *
	 * @return		An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     */
    public Iterator scan(String className, ObjectQualifier oq) 
    {
        return persistor().scan(className, oq) ;    
    }

	/**
	 * Initializes an object iterator to use a parallel query to search this database for objects
	 * of the specified class that satisfy the specified predicate.</p>
	 *
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.
	 * See <a href="../../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 *
	 * The parallel query started by this method uses an internal default query splitter to define its subtasks,
	 * so every container in this database is scanned.</p>
	 *
	 * If the connection is using default task assignment, each container in this database
	 * will be scanned by the query server running on this database's data-server host.
	 * Consequently, before you start the parallel scan, you must ensure that a query server is running on that host.
	 * (If, however, an application-defined task assigner has been set for the connection,
	 * each container will be scanned by the query server chosen for it by the task assigner.)</p>
	 *
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 *
	 * @param 	 predicate    The condition that that each found object must satisfy,
	 * expressed in the Objectivity/DB <a href="../../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
	 * predicate query language</A>.</p>
	 *
	 * @return  An object iterator that finds the specified objects.</p>
	 *
	 * @see ooFDObj#parallelScan(String, String)
	 * @see Connection#checkQueryServer(String)
	 */
	public Iterator parallelScan(String className, String predicate)
        { return persistor().parallelScan(className, predicate) ; }

	/**
	 * Initializes an object iterator to use a custom parallel query to search this database for objects
	 * of the specified class that satisfy the specified predicate.</p>
	 *
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.
	 * See <a href="../../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 *
	 * This method starts a custom parallel query that uses the specified application-defined query splitter.
	 * Such a query splitter may select any number of individual containers for scanning.</p>
	 *
	 * If the connection is using default task assignment, each container selected by the query splitter
	 * will be scanned by the query server running on this database's data-server host.
	 * Consequently, before you start the parallel scan, you must ensure that a query server is running on that host.
	 * (If, however, an application-defined task assigner has been set for the connection,
	 * each container will be scanned by the query server chosen for it by the task assigner.)</p>
	 *
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 *
	 * @param 	 predicate        The condition that that each found object must satisfy,
	 * expressed in the Objectivity/DB <a href="../../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
	 * predicate query language</A>.</p>
	 *
	 * @param 	 qs           Query splitter for the custom parallel query.
	 * A query splitter is an instance of an application-defined class that implements the {@link QuerySplitter QuerySplitter} interface.</p>
	 *
	 * @return  An object iterator that finds the specified objects.</p>
	 *
	 *
	 * @see ooFDObj#parallelScan(String, String, QuerySplitter)
	 * @see Connection#checkQueryServer(String)
	 *
	 */
	public Iterator parallelScan(String className, String predicate, QuerySplitter qs)
        { return persistor().parallelScan(className, predicate, qs) ; }

	/**
	 * Initializes an object iterator to use a custom parallel query to search this database for objects
	 * of the specified class that are qualified by the ObjectQualifier.</p>
	 * 
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.  
	 * See <a href="../../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 * 
	 * This method starts a custom parallel query that uses the specified application-defined query splitter. 
	 * Such a query splitter may select any number of individual databases or even containers for scanning.</p>
	 * 
	 * If the connection is using default task assignment, each database or container selected by the query splitter
	 * will be scanned by the query server running on the relevant database's data-server host.
	 * Consequently, before you start the parallel scan, you must ensure that a query server is running on the data-server host
	 * of every database to be searched. 
	 * (If, however, an application-defined task assigner has been set for the connection,
	 * each database or container will be scanned by the query server chosen for it by the task assigner.)</p>
	 * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 * 
	 * @param 	 oq			Object qualifier instance.
	 * 
	 * @param 	 qs           Query splitter for the custom parallel query. 
	 * A query splitter is an instance of an application-defined class that implements the {@link QuerySplitter QuerySplitter} interface.</p>
	 * 
	 * @return  An object iterator that finds the specified objects.</p>
	 * 
	 * @see ooFDObj#parallelScan(String, ObjectQualifier, QuerySplitter)
	 * @see Connection#checkQueryServer(String)
	 * 
	 */
	public Iterator parallelScan(String className, ObjectQualifier oq, QuerySplitter qs)
    { return persistor().parallelScan(className, oq, qs) ; }
	
	/**
	 * Initializes an object iterator to use a custom parallel query to search this database for objects
	 * of the specified class that are qualified by the ObjectQualifier.</p>
	 * 
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.  
	 * See <a href="../../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 * 
	 * 
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 * 
	 * @param 	 oq			Object qualifier instance.
	 * 
	 * 
	 * @return  An object iterator that finds the specified objects.</p>
	 * 
	 * @see ooFDObj#parallelScan(String, ObjectQualifier, QuerySplitter)
	 * @see Connection#checkQueryServer(String)
	 * 
	 */
	public Iterator parallelScan(String className, ObjectQualifier oq)
    { return persistor().parallelScan(className, oq, null) ; }
	
    /**
	 * Initializes an object iterator to find all the containers in this database.</p>
	 *
	 * @return		An object iterator that finds all the containers in this database.
     *
     */
    public Iterator contains()
        { return persistor().contains(); }

    /**
     * Names the specified object with the specified root name in this database.
     *
     * <p>Giving an object a root name makes the object persistent. The named object
     * is made persistent immediately; all transient objects reachable from
     * the named object are made persistent on transaction commit.</p>
     *
     * @param 	 object  The object being named.</p>
     *
     * @param 	 name    The root name for the object.
     * This string must consist of only ASCII characters and must be unique
     * within the root dictionary of this database.</p>
     *
     * @exception   ObjectNameNotUniqueException If the name already exists in the root
     * dictionary.</p>
     *
     * @see #unbind(String)
     * @see #lookup(String)
     */
    public void bind(Object object, String name) throws ObjectNameNotUniqueException
        { persistor().bind(object, name) ; }

    /**
     * Finds the object with the specified root name in this
	 * database.</p>
     *
     * @param 	 name    The root name of the object.</p>
     *
     * @return      The object with the specified root name. If this object
     * is the root of a graph of objects, only the root object is
     * returned. The returned object is locked for read.</p>
     *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
     */
    public Object lookup(String name) throws ObjectNameNotFoundException
        { return persistor().lookup(name); }

    /**
     * Initializes an object iterator to find the root names maintained by this
     * database.</p>
     *
     * @return      An object iterator initialized to return all the root names
     * maintained by this database.
     *
     */
    public Iterator rootNames()
        { return persistor().rootNames(); }

    /**
     * Removes a root name from this database.</p>
     *
     * @param 	 name    The root name to be removed.</p>
     *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
     */
    public void unbind(String name) throws ObjectNameNotFoundException
        { persistor().unbind(name); }

    /**
     * Adds an index to this database.</p>
     *
     * @param 	 name   The name of the index to be added; must be different from
	 * the names of existing indexes in this database. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
	 *
     * @param 	 fieldList   The key fields for the index, separated by commas.
     * Each key field must be the name of a valid attribute
     * of <tt><i>className</i></tt> whose type is one of the Java
     * <a href="../../../../../../guide/jgdIndexes.html#Key Fields">
	 * types supported by indexes</A>.</p>
	 *
	 * @exception   ObjyRuntimeException    If Objectivity/DB is unable to
     * create the index.</p>
     *
     * @see #addUniqueIndex(String, String, String)
     * @see #dropIndex(String)
     */
    public void addIndex(String name, String className, String fieldList)
        { persistor().addIndex(name, className, fieldList); }

    /**
     * Adds a unique index to this database.
     *
     * <p>The application is responsible for ensuring that every object
     * indexed by a unique index has a
     * unique combination of values in its key fields. If two or more
	 * objects have a given combination of key values, the index contains
	 * only the first such object that is encountered when the index is
	 * created or updated.</p>
	 *
     * @param 	 name   The name of the index to be added; must be different from
	 * the names of existing indexes in this database. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
	 *
     * @param 	 className   The package-qualified
	 * name of the class whose instances are to be indexed.</p>
	 *
     * @param 	 fieldList   The key fields for the index, separated by commas.
     * Each key field must be the name of a valid attribute
     * of <tt><i>className</i></tt> whose type is one of the Java
     * <a href="../../../../../../guide/jgdIndexes.html#Key Fields">
	 * types supported by indexes</A>.</p>
	 *
	 * @exception   ObjyRuntimeException    If Objectivity/DB is unable to
     * create the index.</p>
	 *
	 * @see #addIndex(String, String, String)
     * @see #dropIndex(String)
     */
    public void addUniqueIndex(String name, String className, String fieldList)
        {
          persistor().flush();  //SPR 17691 flush object to index correct info
          persistor().addUniqueIndex(name, className, fieldList);
        }

    /**
     * Drops the specified index from this database.</p>
	 *
     * @param 	 name   The name of the index to be
     * dropped.</p>
     *
	 * @exception   ObjyRuntimeException    If this database does not have an index named
	 * <tt><i>name</i></tt>. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
     *
     * @see #addIndex(String, String, String)
     * @see #addUniqueIndex(String, String, String)
     * @see #hasIndex(String)
     */
    public void dropIndex(String name)
        { persistor().dropIndex(name); }

    /**
     * Tests whether this database has an index with the specified
	 * name.</p>
	 *
     * @param 	 name   The name of the index.</p>
	 *
     * @return      True if this database has an index named
     * <tt><i>name</i></tt>; otherwise, false.</p>
     *
     * @see #addIndex(String, String, String)
     * @see #addUniqueIndex(String, String, String)
     * @see #dropIndex(String)
     */
    public boolean hasIndex(String name)
        { return persistor().hasIndex(name); }

	/**
     * Tests whether the specified index in this database is
     * consistent with the definition of the indexed class.</p>
	 *
	 * <p>If you delete or change the data type of an attribute of the
     * indexed class and that attribute is used as a key field of an index,
     * the index becomes invalid because it is no longer consistent with the
     * updated definition of the indexed class. You should test for
     * consistency after modifying the definition of an indexed class and
     * should drop and recreate any invalid indexes.  See
     * <A HREF="../../../../../../guide/jgdIndexes.html#Reconstructing Indexes After Schema Evolution">
     * Reconstructing Indexes After Schema Evolution</A>.</p>
	 *
     * @param 	 name   The name of the index to be tested.</p>
	 *
     * @return      True if this database has an index named
	 * <tt><i>name</i></tt> and that index is consistent with the definition
     * of the indexed class; otherwise, false.
	 */
    public boolean indexConsistent(String name)
        { return persistor().indexConsistent(name); }

	/**
	 * Performs on-demand
     * <A HREF="../../../../../../guide/jgdSchemaEvolution.html#Object Conversion">
	 * object conversion</a> on any affected objects in this database.
	 *
	 * <p>Object conversion makes persistent objects in the federated database
	 * consistent with the current definitions of their
	 * Java classes.
	 *
	 * <p>You can call this method if the definitions of some Java classes are
	 * not consistent with the corresponding descriptions in the schema.
     * Certain changes to a class definition affect how instances of a class
     * should be laid out in storage. After you make such a change, existing
     * persistent objects of the changed classes are rendered out-of-date
     * until they are converted to their new representations.
     *
     * <p>You call this method in an update transaction to
     * convert the affected objects in this database on demand.
     * This method takes no action for affected objects in the database
     * that have already been converted.
     *
     * <p>If this database is read-only, you must call the
     * {@link #setReadOnly <tt>setReadOnly</tt>} method
     * to change it back to read/write before you can convert objects in
     * it.</p>
	 *
	 */
    public void convertObjects()
        { persistor().convertObjects() ; }

    /**
     * Tests whether this database is read only.
     *
     * <p> A read-only database can be opened only for read; any attempt to
     * open the database for write (implicitly or explicitly) will fail as if
     * there were a lock conflict. </p>
     *
     * @return  True if this database is a read-only database; otherwise,
     * false.</p>
     *
     * @see #setReadOnly
     */
    public boolean isReadOnly()
        { return persistor().isReadOnly() ; }

    /**
     * Set the access status of this database so that is is either read-only
     * or read/write.
     *
     * <p>A read-only database can be opened only for read; any attempt to
     * open the database for write (implicitly or explicitly) will fail as if
     * there were a lock conflict. Using a read-only database can improve
     * performance by allowing the application to grant read locks and deny
     * update locks without consulting the lock server.
     *
     * <p>You can change a read-only database back to read/write only if no
     * application or tool is currently reading either that database or any
     * other read-only database in the same federated database. You must
     * change the database back to read/write before you can perform any
     * update operation on it.
     *
     * <p>(<i>HA</i>) If one image of a database is made read-only, all
     * images are automatically made read-only. Similarly, if one image is
     * changed back to read/write, all images are changed back to
     * read/write.</p>
	 *
     * @param 	 value   True to mark this database as
     * read-only; false to change the database back to read/write.</p>
	 *
     * @see #isReadOnly
     */
    public void setReadOnly(boolean value)
        { persistor().setReadOnly(value) ; }

    /**
     * Gets the integer identifier of this database.</p>
     *
     * @return      The identifier of this database.
     */
    public long getNumber()
        { return persistor().getNumber() ; }

    /**
     * Gets the page size of this database.</p>
     *
     * @return      The page size of this database. 
	 * <br><b>Note:</b> If this database uses the pre-Release 9.0 internal database format, 
	 * this method returns the default page size for the federated database, 
	 * which may, but need not, be the same as the database's actual page size.
     */
    public int getPageSize()
        { return persistor().getPageSize() ; }
    
    /**
     * Changes the specified properties of the database.</p>
	 * 
	 * <p> Together, <tt><i>dbHostName</i></tt> and <tt><i>dbPathName</i></tt> 
	 * determine the network address of the database file. 
	 * These parameters physically relocate the file when <tt><i>catalogOnly</i></tt> is false;
	 * they also update the database's location properties in the global catalog. 
	 * If you want to update the location properties without affecting the file's location, 
	 * you can set <tt><i>catalogOnly</i></tt> to true. 
	 * Doing so assumes the file is to be physically moved by an operating-system command.</p>
	 * 
	 * <p>Changing the location of a database file has no effect on the files of any external containers 
	 * belonging to the database.</p>
	 * 
	 * <p>This method fails with an exception if any of the following cases:
	 * <ul type=disc>
	 * <li> If an exclusive update lock cannot be obtained on the database.
	 * <li> If the database is read-only.
	 * You must use the {@link #setReadOnly <tt>setReadOnly</tt>} method 
	 * to change the database back to read/write 
	 * before you can change its properties.
	 * <li>
	 * <i>(HA)</i> If this database is replicated (has more than one image).
	 * You must delete replicated databases before calling the <tt>change</tt> method.
	 * </ul></p> 
     * 
     * @param dbSystemName    New system name of the database. Specify null to retain the original system name.
	 *                        (You must always specify null if the database uses the pre-Release 9.0 internal database format.)<br> 			  
	 *                        <b>Note:</b> <i>This feature is not fully implemented.</i>
     *                        In particular, the changed system name is made permanent 
	 *                        during the transaction and cannot be rolled back 
	 *                        with a call to the session's abort method. 
     *                        To revert the change, you can call the change method 
	 *						  in a subsequent transaction and pass in the original system name.
	 * 
     * @param dbHostName      New data-server host for the database file. 
	 *                        You can specify null to leave the database file 
	 *                        on the same host.  
	 *                        (If the database uses the pre-Release 9.0 internal database format, 
	 *                        you must always specify the host name explicitly; null is not accepted.)
	 *  
     * @param dbPathName      New pathname (including the filename) for the database file on <tt><i>dbHostName</i></tt>. 
     *                        The format of the pathname must follow the naming conventions of that host. 
     *                        No specific filename extension is required, although <tt>.DB</tt> is commonly used.
	 * 
     * @param catalogOnly     Specifies whether to change the database file's host and pathname 
	 *                        only by updating its location properties in the global catalog.
	 *                        <ul type=disc>
	 *                        <li>Specify false to update properties in the global catalog 
	 *                             and also physically move or rename the database file in your file system.
	 *                        <li> Specify true to update properties in the global catalog, 
	 *                             without physically moving or renaming the database file.
	 *                        </ul></p>                 
	 * 
     * @param outputFileName  Name of the transcript file in which to report the original 
	 *                        and changed database properties. Specify null to write the report to standard output.
     *                        If the file cannot be created or updated,
	 *                        <tt>java.io.FileNotFoundException</tt> is thrown and the report is
	 *                        written to standard output.</p>
     * 
     * @return                True if the change succeeds; otherwise, false. </p>
     * 
     * @throws java.io.FileNotFoundException 
     */
    public boolean change(String dbSystemName, String dbHostName, String dbPathName, boolean catalogOnly, String outputFileName)
      throws java.io.FileNotFoundException
    {	
    	return persistor().change(dbSystemName, dbHostName, dbPathName, catalogOnly, outputFileName); 
    }

	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public synchronized void setPersistor(PooDBObj persistor)
        { this.persistor = persistor ; }

    /**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public synchronized PooDBObj persistor() {
        if (persistor == null)
            throw new ObjectIsDeadException("Attempted persistent operation on dead database") ;
        return persistor ;
    }

	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public long connectionId()
        { return persistor().connectionId() ; }
    
    
    /**
     * Adds the specified containers with the specified properties to this database; the containers
	 * are embedded in this database's file.
	 *
	 * <p> Each added container has the specified 
	 * number of initial pages and percent growth.</p>
	 *
     * <p>This method makes the specified containers persistent and locks them
     * and this database in write mode.</p>
     *
     * @param containers An array of containers.  All containers must be of the same type.
     * 
	 * @param 	 initialPages  The initial number of pages
	 * allocated for the containers. Specify 0 to use the system default value (4).</p>
	 *
	 * @param 	 percentGrowth Amount by which each added container may grow when it needs to
	 * accommodate more basic objects, expressed as a percentage of its current
	 * number of storage pages. Specify 0 to use the system default value (10%).</p>
     */
    public void createContainers(ooContObj[] containers, 
    		int initialPages, int percentGrowth)
    {
    	persistor().doNewConts(this.getOid().getStoreLong(), containers,
    			 initialPages, percentGrowth);
    }
}
