package com.objy.query.expression;
/**
 * Represents an ordered list literal value node.
 *
 */
public class OrderedListLiteralValueExpression extends LiteralValueExpression 
{
    /**
     * Constructs an ordered list literal value node with an element data type.
     */
    public OrderedListLiteralValueExpression(DataType type) 
    {
        this(Binding.create(type.getIntValue()));
    }
    
    /**
     * Constructs an ordered list literal value node with an ID.
     * @param id
     */
	OrderedListLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }

	/**
	 * Returns the element of the ordered list given an index.
	 * @param index Index in the ordered list
	 * @return Element as an instance of ooExpressionResult 
	 */
    /*public ExpressionResult getElement(int index) 
    {
        long elementId = Binding.getElement(getId(), index);
        return new ExpressionResult(elementId);
    }*/

    /** 
     * Returns the unsigned integer element of the ordered list at the given index.
     * @return Integer value of the element
     */
    // This is equivalent to getElement(index).getUIntResult(). 
    public int getUIntResultAt(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getUIntResultAt(mId, index);
    }
    
    /** 
     * Returns the integer element of the ordered list at the given index.
     * @return Integer value of the element
     */
    // This is equivalent to getElement(index).getIntResult(). 
    public int getIntResultAt(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getIntResultAt(mId, index);
    }
    
    /** 
     * Returns the string element of the ordered list at the given index.
     * @return String value of the element
     */
    // This is equivalent to getElement(index).getStringResult(). 
    public String getStringResultAt(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getStringResultAt(mId, index);
    }
    
    /** 
     * Returns the float32 element of the ordered list at the given index.
     * @return float32 value of the element
     */
    // This is equivalent to getElement(index).getFloat32Result(). 
    public float getFloat32ResultAt(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getFloat32ResultAt(mId, index);
    }
    
    /** 
     * Returns the float64 element of the ordered list at the given index.
     * @return float64 value of the element
     */
    // This is equivalent to getElement(index).getFloat64Result(). 
    public float getFloat64ResultAt(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getFloat64ResultAt(mId, index);
    }
    
    /**
     *  Returns the data type of the elements in the ordered list, indicating if the elements are strings or numeric values. 
     * @return An integer
     */
    public int getElementType()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getElementType(mId);
    }
    
    /**
     *  Returns the data type of the element at the given index.
     * @param index A specified index
     * @return An integer 
     */
    public int getElementTypeAt(int index)
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getElementTypeAt(mId, index);
    }
    
    /**
     * Returns the length of the ordered list.
     * @return An integer
     */
    public int getLength() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getLength(mId);
    }
    
    /**
     * Adds an element to the ordered list at the given index.
     * @param element An instance of a concrete literal value expression
     * @param index The index. If it is less than 0, the element is added to the end of the list. 
     */
    public void addElement(LiteralValueExpression element, int index)
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (element != null && element.getId() != 0)
        {
    	    Binding.addElement(mId, element.getId(), index);
        }
    }
    
    @Override
    public String toString()
    {
    	StringBuilder sb = new StringBuilder();
    	sb.append("(");
    	int len = getLength();
    	for (int i = 0; i < len; i++)
    	{
    		if (i > 0) sb.append(",");
    		int eleType = getElementTypeAt(i);
    		switch(eleType)
    		{
    		    case DataType.UINT:
    		        sb.append(getUIntResultAt(i));
    		        break;
    		    case DataType.INT:
    		        sb.append(getIntResultAt(i));
    		        break;
    		    case DataType.FLOAT32:
    		    	sb.append(getFloat32ResultAt(i));
    		        break;
    		    case DataType.FLOAT64:
    		        sb.append(getFloat64ResultAt(i));
    		        break;
    		    case DataType.BIT8STRING:
    		    	// The UTF string type in ordered list is not supported yet
    		        sb.append(getStringResultAt(i));
    		        break;
    		    default:
    		    	break;
    		}
    	}
    	sb.append(")");
    	return sb.toString();
    }
    
	@Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.OrderedListLiteralValueExpression; 
    }
	
	@Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitOrderedListLiteralValue(this);
    }
	
	static class Binding
	{
	    private static native long create(int value);
	    //private static native long getElement(long id, int index);
	    private static native int getIntResultAt(long id, int index);
	    private static native int getUIntResultAt(long id, int index);
	    private static native String getStringResultAt(long id, int index);
	    private static native float getFloat32ResultAt(long id, int index);
	    private static native float getFloat64ResultAt(long id, int index);
	    private static native int getElementType(long id);
	    private static native int getElementTypeAt(long id, int index);
	    private static native int getLength(long id);
	    private static native void addElement(long id, long element, int index);
	    
	}
}
