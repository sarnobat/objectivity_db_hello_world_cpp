/*
 * @(#)SessionData.java
 * 
 * Copyright (c) 2003 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Abstract superclass for session-data classes, which contain application-specific data that can 
 * be saved with a session.
 *
 * <p> An instance of a class derived from <tt>SessionData</tt> is called a <i>session-data object</i>. 
 * A session-data object 
 * can be used as the value of an application-defined property of a session, and 
 * can contain arbitrary application-specific data relevant to that session.
 * You set a session-data object as the value of a property by calling
 * a session's {@link Session#setSessionData <tt>setSessionData</tt>} method.</p>
 * 
 * <p>Because this class is abstract, you never instantiate it; instead,
 * you work with instances of its derived classes. </p>
 * 
 * For more information, 
 * see <a href="../../../../../guide/jgdSessions.html#Using Application-Defined Session Properties">
 * Using Application-Defined Session Properties</a>.</p>
 *
 */
abstract public class SessionData
{
    private boolean isSessionOwned ;

    /**
     * Reserved for internal use.
     */
    protected SessionData()
        { isSessionOwned = true ; }

    /**
     * Reserved for internal use.
     */
    protected SessionData(boolean _isSessionOwned)
        { isSessionOwned = _isSessionOwned ; }

    /**
     * Reserved for internal use.
     */
    protected boolean isSessionOwned() 
        { return isSessionOwned ; }
}
