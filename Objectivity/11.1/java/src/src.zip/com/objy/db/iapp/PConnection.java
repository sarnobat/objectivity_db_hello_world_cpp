/*
 * @(#)PConnection.java
 *
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.iapp ;

import java.util.HashMap ;
import java.util.Vector ;

import com.objy.db.app.Iterator ;
import com.objy.db.app.Session ;
import com.objy.db.app.Database ;
import com.objy.db.app.Connection ;
import com.objy.db.app.LogListener ;
import com.objy.db.app.SchemaPolicy ;
import java.io.PrintStream ;

import com.objy.db.app.TaskAssigner;

import com.objy.db.DatabaseOpenException ;
import com.objy.db.DatabaseClosedException ;
import com.objy.db.DatabaseNotFoundException ;
import com.objy.db.ObjectNameNotFoundException ;
import com.objy.db.ObjectNameNotUniqueException ;

/**
 * Reserved for internal use.
 */
public interface PConnection
       extends   PRoot
{
    void reopen() throws DatabaseOpenException, DatabaseNotFoundException ;

    void setOpenMode(int _openMode) ;

    Database getDatabase();

    Connection getConnection();

    boolean isOpen();

    String getBootFilePath();

    int getOpenMode();

    void close() throws DatabaseClosedException ;

    void update() ;

    void setThreadPolicy(int _threadPolicy);

    int getThreadPolicy();

    boolean startInternalLS();

    boolean stopInternalLS(int wait, boolean force);

    boolean checkLS(String host);

    boolean checkLS();

    Vector sessions();

    void useContextClassLoader(boolean useContextClassLoader);

    void addToMainLog(String label, String text);

    boolean getUniqueInternObjects();

    void setUniqueInternObjects(boolean internObjects);

    void setMainLogListener(LogListener listener) ;

    void createSessionPool(String sessionPoolName, int softLimit, int hardLimit) ;

    void createSessionPool(String sessionPoolName, int softLimit, int hardLimit, int sessionWait) ;

    void createSessionPool(String sessionPoolName, int softLimit, int hardLimit, int cacheInitialPages, int cacheMaxPages, int largeObjectMemoryLimit, boolean hotMode, int lockWait, int sessionWait) ;
    
    boolean haveSessionPool(String sessionPoolName);

    Session getSessionFromPool(String sessionPoolName, String tag) ;

    void returnSessionToPool(Session session) ;

    int getSchemaCacheMaximum() ;

    void setObjectCreationDiskFormat(int format) ;

    int getObjectCreationDiskFormat() ;

    int getClientHostArch() ;

    int diskFormatFromString(String installation) ;

    String stringFromDiskFormat(int format) ;

    int diskFormatAddressSize(int format) ;

    //
    // Federated wide operations
    //
    void setAMSUsage(int amsUsage);

    //
    // Root Names
    //
    void bind(Object object, String name) throws ObjectNameNotUniqueException ; // ODMG

    void unbind(String name) throws ObjectNameNotFoundException ;   // ODMG

    Object lookup(String name) throws ObjectNameNotFoundException  ;// ODMG

    Iterator rootNames() ;

    //
    // Schema
    //
    SchemaPolicy getSchemaPolicy() ;

    void setDeploymentMode(boolean deploymentMode) ;

    boolean isDeploymentMode() ;

    void registerClass(String className) ;

    void registerClass(String className, HashMap memberMap) ;

    void loadSchemaClasses(boolean verbose) ;


    void setSchemaClassName(String javaClassName, String schemaClassName) ;

    void dropClass(String className) ;

    void dropAllUserClasses() ;

    void dropAllUserClasses(boolean forceCacheRefresh) ;

    void dropAllUnregisterableClasses();

    TaskAssigner getTaskAssigner() ;

    void setTaskAssigner(TaskAssigner ta) ;

    boolean checkQueryServer(String hostname) ;

    boolean getLogSchemaModifications() ;

    void setLogSchemaModifications(boolean log) ;

    boolean isMemoryCheckPolicy() ;

    void setMemoryCheckPolicy(boolean policy) ;

    boolean isPermitSparseDbFiles() ;

    void setPermitSparseDbFiles(boolean sparse) ;

    void noLock() ;

    void setOutStream(PrintStream outputStream) ;

    void setErrStream(PrintStream outputStream) ;

    void setPredicateScanAutoFlush(boolean autoFlush) ;

    boolean isPredicateScanAutoFlush() ;

    void setUserClassLoader(ClassLoader userClassLoader) ;

    boolean isPermitReadAhead() ;

    void setPermitReadAhead(boolean useReadAhead) ;

    void join() ;

    void leave() ;

	//
	// OBJY-17572: set persistence policy
	//
	void setPersistencePolicy(int persistencePolicy);

	int getPersistencePolicy();

	boolean isPersistOnReachability();
}
