package com.objy.query.expression;

import java.util.HashMap;
import java.util.Map;
/**
 * Enumeration of the data types.
 *
 */
public enum DataType 
{
    NoDataType(DataType.NODATATYPE),
    UInt(DataType.UINT),
    Int(DataType.INT),
    WholeNumber(DataType.WHOLENUMBER),
    Float32(DataType.FLOAT32),
    Float64(DataType.FLOAT32),
    Float(DataType.FLOAT),
    Numeric(DataType.NUMERIC), 
    Bool(DataType.BOOL),
    Bit8String(DataType.BIT8STRING),
    Utf8String(DataType.UTF8STRING),
    Utf16String(DataType.UTF16STRING),
    Utf32String(DataType.UTF32STRING),
    UtfString(DataType.UTFSTRING), 
    String(DataType.STRING),
    Date(DataType.DATE),
    Time(DataType.TIME),
    DateTime(DataType.DATETIME),
    Interval(DataType.INTERVAL),
    Simple(DataType.SIMPLE),
    Class(DataType.CLASS),
    Reference(DataType.REFERENCE),
    Embedded(DataType.EMBEDDED),
    Object(DataType.OBJECT),
    OrderedArray(DataType.ORDEREDARRAY),
    OrderedList(DataType.ORDEREDLIST),
    OrderedSet(DataType.ORDEREDSET),
    OrderedMap(DataType.ORDEREDMAP),
    OldOrderedCollection(DataType.OLDORDEREDCOLLECTION),
    OrderedCollection(DataType.ORDEREDCOLLECTION),
    UnorderedArray(DataType.UNORDEREDARRAY),
    UnorderedSet(DataType.UNORDEREDSET),
    UnorderedMap(DataType.UNORDEREDMAP),
    OldUnorderedCollection(DataType.OLDUNORDEREDCOLLECTION),
    UnorderedCollection(DataType.UNORDEREDCOLLECTION),
    KeyedCollection(DataType.KEYEDCOLLECTION),
    ReferencedCollection(DataType.REFERENCEDCOLLECTION), 
    ReferenceAccessible(DataType.REFERENCEACCESSIBLE),
    Collection(DataType.COLLECTION),
    NonCollection(DataType.NONCOLLECTION),
    AllDataTypes(DataType.ALLDATATYPES);

    private final int queryDataType;

    DataType(int type)
    {
        queryDataType = type;
    }
    /**
     * Returns the integer code of the data type.
     * @return integer code.
     */
    public int getIntValue()
    {
        return queryDataType;
    }
    
    private static final Map<Integer, DataType> longToQDataTypeMap = new HashMap<Integer, DataType>(); 
    static { 
        for (DataType type : DataType.values()) { 
            longToQDataTypeMap.put(type.queryDataType, type); 
        }
    }
    /**
     * Returns the data type identified by an integer code.
     * @param val Integer code
     * @return Data type
     */
    public static DataType fromValue(int val)
    {
        return longToQDataTypeMap.get(val);
    }

    private static final int NODATATYPE = 0;
    static final int UINT = 1;
    static final int INT = 2;
    static final int WHOLENUMBER = UINT | INT;
    static final int FLOAT32 = 4;
    static final int FLOAT64 = 8;
    static final int FLOAT = FLOAT32 | FLOAT64;
    static final int NUMERIC = UINT | INT | FLOAT;
    static final int BOOL = 16;
    static final int BIT8STRING = 32;
    static final int UTF8STRING = 64;
    static final int UTF16STRING = 128;
    static final int UTF32STRING = 256;
    static final int UTFSTRING = UTF8STRING | UTF16STRING | UTF32STRING;
    static final int STRING = BIT8STRING | UTFSTRING;
    static final int DATE = 512;
    static final int TIME = 1024;
    static final int DATETIME = 2048;
    static final int INTERVAL = 4096;
    static final int SIMPLE = NUMERIC | BOOL | STRING | DATE | TIME | DATETIME | INTERVAL;
    static final int CLASS = 8192;
    static final int REFERENCE = 16384;
    static final int EMBEDDED = 32768;
    static final int OBJECT = REFERENCE | EMBEDDED;
    static final int ORDEREDARRAY = 65536;
    static final int ORDEREDLIST = 131072;
    static final int ORDEREDSET = 262144;
    static final int ORDEREDMAP = 524288;
    static final int OLDORDEREDCOLLECTION = 1048576;
    static final int ORDEREDCOLLECTION  = ORDEREDARRAY | ORDEREDLIST | ORDEREDSET | ORDEREDMAP | OLDORDEREDCOLLECTION;
    static final int UNORDEREDARRAY = 2097152;
    static final int UNORDEREDSET = 4194304;
    static final int UNORDEREDMAP = 8388608;
    static final int OLDUNORDEREDCOLLECTION = 16777216;
    static final int UNORDEREDCOLLECTION = UNORDEREDARRAY | UNORDEREDSET | UNORDEREDMAP | OLDUNORDEREDCOLLECTION;
    static final int KEYEDCOLLECTION = ORDEREDSET | UNORDEREDSET | ORDEREDMAP | UNORDEREDMAP;
    static final int REFERENCEDCOLLECTION = ORDEREDLIST | KEYEDCOLLECTION  | OLDORDEREDCOLLECTION | OLDUNORDEREDCOLLECTION; 
    static final int REFERENCEACCESSIBLE = REFERENCE | REFERENCEDCOLLECTION;
    static final int COLLECTION = ORDEREDCOLLECTION| UNORDEREDCOLLECTION;
    static final int NONCOLLECTION = SIMPLE | OBJECT | CLASS;
    static final int ALLDATATYPES = NONCOLLECTION | COLLECTION;
    
    static final int INVALID = -1;
}
