/*
 * @(#)Tuner.java
 * 
 * Copyright (c) 2005 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Abstract superclass for all performance-tuner classes.</p>
 * 
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>An instance of a class derived from <tt>Tuner</tt> is called a <i>performance tuner</i>. 
 * A performance tuner specifies values for various properties that control an
 * application's behavior.
 * 
 * <p>The Tuner class defines a method corresponding to each property
 * that a tuner can set. Each such method takes as a parameter the current property
 * value that was specified explicitly by the application or by default; the tuner
 * method can return that value unchanged or select and return a different value
 * for the property.
 * 
 * <p>To use a performance tuner, an application <i>registers</i> the tuner that is to determine
 * how to set property values. If a performance tuner is registered when a property
 * value is being set, Objectivity for Java calls the appropriate method of that
 * tuner and sets the property to the returned value. You register a performance
 * tuner by calling one of the {@link Connection#setTuner <tt>Connection.setTuner</tt>} static methods.
 * 
 * <p>Because this class is abstract, you never instantiate it; instead,
 * you work with instances of its derived classes.
 * 
 * For more information, 
 * see <a href="../../../../../guide/jgdTuner.html#_top_">
 * Performance Tuners</a>.</p>
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 * <TD><A HREF="#Tuner()">Tuner()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Logging&nbsp;Properties</B></TD>
 * <TD><A HREF="#logOptions(int)">logOptions(int)</A><BR>
 *     <A HREF="#appendLogs(boolean)">appendLogs(boolean)</A><BR>
 *     <A HREF="#logDirectory(java.lang.String)">logDirectory(String)</A>
 * </TD></TR>
 * 
 * <td VALIGN="top" WIDTH="1%"><B>Connection-Related&nbsp;Properties</B></TD>
 * <TD><A HREF="#numberOfFiles(int)">numberOfFiles(int)</A><BR>
 *     <A HREF="#amsUsage(int)">amsUsage(int)</A>
 * </TD></TR>
 * 
 * <td VALIGN="top" WIDTH="1%"><B>Initial&nbsp;Values&nbsp;for&nbsp;Session&nbsp;Properties</B></TD>
 * <TD><A HREF="#useIndex(boolean)">useIndex(boolean)</A><BR>
 *     <A HREF="#indexMode(int)">indexMode(int)</A>
 * </TD></TR>
 * 
 * <td VALIGN="top" WIDTH="1%"><B>Initial&nbsp;Values&nbsp;for&nbsp;Individual&nbsp;Sessions</B></TD>
 * <TD><A HREF="#cacheInitialPages(int)">cacheInitialPages(int)</A><BR>
 *     <A HREF="#cacheMaxPages(int)">cacheMaxPages(int)</A><BR>
 *     <A HREF="#largeObjectMemoryLimit(int)">largeObjectMemoryLimit(int)</A><BR>
 *     <A HREF="#hotMode(boolean)">hotMode(boolean)</A><BR>
 *     <A HREF="#lockWait(int)">lockWait(int)</A>
 * </TD></TR>
 *  
 * <td VALIGN="top" WIDTH="1%"><B>Initial&nbsp;Values&nbsp;for&nbsp;Pooled&nbsp;Sessions</B></TD>
 * <TD><A HREF="#poolSessionLargeObjectMemoryLimit(java.lang.String, int)">poolSessionLargeObjectMemoryLimit(String, int)</A><BR>
 *     <A HREF="#poolSessionHotMode(java.lang.String, boolean)">poolSessionHotMode(String, boolean)</A><BR>
 *     <A HREF="#poolSessionLockWait(java.lang.String, int)">poolSessionLockWait(String, int)</A><BR>
 * </TD></TR>
 * 
 * <td VALIGN="top" WIDTH="1%"><B>Properties&nbsp;of&nbsp;Session&nbsp;Pools</B></TD>
 * <TD><A HREF="#sessionPoolSoftLimit(java.lang.String, int)">sessionPoolSoftLimit(String, int)</A><BR>
 *     <A HREF="#sessionPoolHardLimit(java.lang.String, int)">sessionPoolHardLimit(String, int)</A><BR>
 *     <A HREF="#sessionPoolWait(java.lang.String, int)">sessionPoolWait(String, int)</A>
 * </TD></TR>
 * 
 * </TABLE>
 */
abstract public class Tuner
{
    /**
     * Reserved for internal use.
     */
    public Tuner() {}

    /**
     *Sets the number of file descriptors allowed in any session.</p>
     * 
	 * <p>The returned value supersedes the number of file descriptors specified by the
	 * {@link Connection#setFileCount <tt>Connection.setFileCount</tt>} static method.
	 * </p>
	 * 
	 * <p>For guidelines on selecting a value for the number of file descriptors, see
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Number of File Descriptors">
	 * Optimizing the Number of File Descriptors</a>.</p>
	 * 
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Number of file descriptors allowed in any session. The minimum value is 8. </p>
     */
    public int numberOfFiles(int current) { return current ; }

    /**
     *Specifies the application's policy for using the Advanced Multithreaded Server (AMS).</p>
     * 
	 * <p><b>Note:</b> If your application calls a connection's
	 * {@link Connection#setAMSUsage <tt>setAMSUsage</tt>} method,
	 * the value set by that call will supersede the
	 * value set by this performance tuner.
	 * </p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Policy for using AMS as data-server software on remote hosts. </p>
     */
    public int amsUsage(int current) { return current ; }

    /**
     *Sets the initial index-usage policy for all sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular session's
	 * {@link Session#setUseIndex <tt>setUseIndex</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * 
	 * 
	 * <p>For guidelines on selecting a value for the index-usage policy, see 
	 * <a href="../../../../../guide/jgdIndexes.html#Enabling and Disabling Indexes">
	 * Enabling and Disabling Indexes</a>.</p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		The initial index-usage policy for all sessions:
	 * <ul type=disc>
	 * <li>True�Newly created sessions are initialized to use indexes to
	 * optimize certain predicate scans.
	 * <li>False�Newly created sessions are initialized not to use
	 * indexes during predicate scans.
	 * </ul>
	 * 
	 * </p>
     */
    public boolean useIndex(boolean current) { return current ; }
      
    /**
     *Sets the initial index mode for all sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular session's
	 * {@link Session#setIndexMode <tt>setIndexMode</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * 
	 * <p>For guidelines on selecting a value for the index mode, see 
	 * <a href="../../../../../guide/jgdIndexes.html#Updating Indexes">
	 * Updating Indexes</a>.
	 * </p>
	 * 
	 * 
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		The initial property value for index mode, which specifies 
	 * whether and when a session updates indexes after objects of an 
	 * indexed class are created or deleted, or after key-field values are modified.
	 * </p>
     */
    public int indexMode(int current) { return current ; }

    /**
     *Sets the initial number of buffer pages for all individual sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular individual session's
	 * {@link Session#setBufferSpace <tt>setBufferSpace</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * </p>
	 * 
	 * <p>For guidelines on selecting a value for the initial size of a buffer pool,
	 * see 
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Objectivity/DB Cache Size">
	 * Optimizing the Objectivity/DB Cache Size</a>.</p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Factor for computing the initial sizes of the small- and large-object 
	 * buffer pools in an individual session's Objectivity/DB cache.
	 * 
     */
    public int cacheInitialPages(int current) { return current ; }

    /**
     *Sets the maximum number of buffer pages for all individual sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular individual session's
	 * {@link Session#setBufferSpace <tt>setBufferSpace</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * </p>
	 * 
	 * <p>For guidelines on selecting a value for the maximum size of a buffer pool,
	 * see 
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Objectivity/DB Cache Size">
	 * Optimizing the Objectivity/DB Cache Size</a>.</p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Factor for computing the maximum sizes of the small- and large-object 
	 * buffer pools in an individual session's Objectivity/DB cache.
     */
    public int cacheMaxPages(int current) { return current ; }

    /**
     *Sets the large-object memory limit for all individual sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular individual session's
	 * {@link Session#setLargeObjectMemoryLimit <tt>setLargeObjectMemoryLimit</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * </p>
	 * 
	 * <p>For guidelines on selecting a value for the large-object memory limit,
	 * see 
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Objectivity/DB Cache Size">
	 * Optimizing the Objectivity/DB Cache Size</a>.</p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		The suggested maximum number of bytes for the 
	 * large-object memory pool in the Objectivity/DB cache of an individual session.
	 * </p>
     */
    public int largeObjectMemoryLimit(int current) { return current ; }

    /**
     *Specifies whether to enable or disable hot mode for all individual sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular individual session's
	 * {@link Session#setHotMode <tt>setHotMode</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * </p>
	 * 
	 * <p>For guidelines on selecting a value for hot mode,
	 * see 
	 * <a href="../../../../../guide/jgdPerformance.html#Delaying Format Conversions in the Objectivity/DB Cache">
	 * Delaying Format Conversions in the Objectivity/DB Cache</a>.</p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		True to enable hot mode and false to disable it. 
     */
    public boolean hotMode(boolean current) { return current ; }

    /**
     *Sets the lock-waiting policy for all individual sessions.</p>
     * 
	 * <p><b>Note:</b> If your application calls a particular individual session's
	 * {@link Session#setWaitOption <tt>setWaitOption</tt>} method,
	 * the value set by that call will change the 
	 * value set for the session by this performance tuner.
	 * </p>
	 * 
	 * <p>For additional information, see
	 * <a href="../../../../../guide/jgdLocking.html#Lock Waiting">
	 * Lock Waiting</a>.</p>
	 * 
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		The lock-waiting policy, which specifies whether an individual session's 
	 * transactions are to wait to obtain locks, and if so, for how long. 
     */
    public int lockWait(int current) { return current ; }

    /**
     *Specifies whether to append new log items to the existing log file.</p>
     * 
	 * <p>The returned value supersedes the value of the <tt><i>appendLogFiles</i></tt> parameter of the
	 * {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method.
	 * </p>
	 * 
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		True to append new log items to the existing log file; 
	 * false to overwrite the existing log file with new log items.</p>
     */
    public boolean appendLogs(boolean current) { return current ; }

    /**
     *Specifies the directory in which log files should be written.</p>
     * 
	 * <p>The returned value supersedes the value of the <tt><i>logDirPath</i></tt> parameter of the
	 * {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method.
	 * </p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Path of the directory in which log files should be written, 
	 * or an empty string to use the current directory.</p>
     */
    public String logDirectory(String current) { return current ; }

    /**
     *Sets the soft limit for the specified session pool.</p>
     * 
	 * <p>The returned value supersedes the limit specified by the
	 * <tt><i>softLimit</i></tt> parameter of a connection's 
	 * {@link Connection#createSessionPool <tt>createSessionPool</tt>} method.
	 * 
	 * <p>For details about a session pool's soft limit, see 
	 * <a href="../../../../../guide/jgdSessions.html#Understanding Session Pools">
	 * Understanding Session Pools</a>.
	 * </p>
	 * 
     * @param 	 current	The current value for this property.</p>
	 * 
     *
     * @return		Maximum number of inactive sessions to be retained 
	 * when sessions are returned to the pool.</p>
     */
    public int sessionPoolSoftLimit(String sessionPoolName, int current) { return current ; }

    /**
     *Sets the large-object memory limit for sessions created by the specified session pool.</p>
     * 
	 * <p>The returned value supersedes the number of bytes specified by the
	 * <tt><i>largeObjectMemoryLimit</i></tt> parameter of a connection's 
	 * {@link Connection#createSessionPool(java.lang.String, int, int, int, int, int, boolean, int, int) <tt>createSessionPool</tt>} method.
	 * 
	 * <p>For guidelines on selecting a value for the large-object memory limit,
	 * see 
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Objectivity/DB Cache Size">
	 * Optimizing the Objectivity/DB Cache Size</a>.
	 * </p>
	 * 
     * @param 	 sessionPoolName	The name of the session pool that will have this property modified.</p>
     *
     * @param 	 current	The current value for this property.</p>
     *
     * @return		The suggested maximum number of bytes for the large-object memory pool 
	 * in the Objectivity/DB cache of a pooled session.</p>
     */
    public int poolSessionLargeObjectMemoryLimit(String sessionPoolName, int current) { return current ; }

    /**
     *Specifies whether to enable or disable hot mode for sessions created by the specified session pool.</p>
     * 
	 * <p>The returned value supersedes the value specified by the
	 * <tt><i>hotMode</i></tt> parameter of a connection's 
	 * {@link Connection#createSessionPool(java.lang.String, int, int, int, int, int, boolean, int, int) <tt>createSessionPool</tt>} method.
	 * 
	 * <p>For guidelines on selecting a value for hot mode,
	 * see 
	 * <a href="../../../../../guide/jgdPerformance.html#Delaying Format Conversions in the Objectivity/DB Cache">
	 * Delaying Format Conversions in the Objectivity/DB Cache</a>.</p>
	 * 
     * @param 	 sessionPoolName	The name of the session pool that will have this property modified.</p>
     *
     * @param 	 current	The current value for this property.</p>
     *
     * @return		True to enable hot mode and false to disable it.</p>
     */
    public boolean poolSessionHotMode(String sessionPoolName, boolean current) { return current ; }

    /**
     *Sets the lock-waiting policy for sessions created by the specified session pool.</p>
     * 
	 * <p>The returned value supersedes the value specified by the
	 * <tt><i>lockWait</i></tt> parameter of a connection's 
	 * {@link Connection#createSessionPool(java.lang.String, int, int, int, int, int, boolean, int, int) <tt>createSessionPool</tt>} method.
	 * 
	 * <p>For guidelines on selecting a value for the lock-waiting policy, see
	 * <a href="../../../../../guide/jgdLocking.html#Lock Waiting">
	 * Lock Waiting</a>.</p>
	 * 
     * @param 	 sessionPoolName	The name of the session pool that will have this property modified.</p>
     *
     * @param 	 current	The current value for this property.</p>
     *
     * @return		The lock-waiting policy, which specifies whether a pooled session's transactions 
	 * are to wait to obtain locks, and if so, for how long.</p>
     */
    public int poolSessionLockWait(String sessionPoolName, int current) { return current ; }

    /**
     *Sets the hard limit for the specified session pool.</p>
     * 
	 * <p>The returned value supersedes the limit specified by the
	 * <tt><i>hardLimit</i></tt> parameter of a connection's 
	 * {@link Connection#createSessionPool <tt>createSessionPool</tt>} method.
	 * 
	 * <p>For details about a session pool's hard limit, see 
	 * <a href="../../../../../guide/jgdSessions.html#Understanding Session Pools">
	 * Understanding Session Pools</a>.
	 * </p>
	 * 
	 * 
     * @param 	 sessionPoolName	The name of the session pool that will have this property modified.</p>
     *
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Maximum number of sessions to be created by the session pool.</p>
     */
    public int sessionPoolHardLimit(String sessionPoolName, int current) { return current ; }

    /**
     *Sets the session-waiting policy for the specified session pool.</p>
     * 
	 * <p>The returned value supersedes the policy specified by the
	 * <tt><i>sessionWait</i></tt> parameter of a connection's 
	 * {@link Connection#createSessionPool(java.lang.String, int, int, int) <tt>createSessionPool</tt>} method.
	 * 
	 * <p>For details about a session pool's session-waiting policy, see 
	 * <a href="../../../../../guide/jgdSessions.html#Understanding Session Pools">
	 * Understanding Session Pools</a>.
	 * </p>
	 * 
	 * 
     * @param 	 sessionPoolName	The name of the session pool that will have this property modified.</p>
     *
     * @param 	 current	The current value for this property.</p>
     *
     * @return		Value that specifies how the session pool behaves when the application 
	 * requests a session but no session is available and the pool has already created the maximum
	 * number of sessions (specified by the pool's hard limit).
	 * <ul type=disc>
	 * <li> 0�Do not wait for sessions to be returned.
	 * <li> -1�Wait indefinitely for a session to be returned.
	 * <li> <i>n</i>, where <i>n</i> is an integer greater than or equal to 1�Wait n seconds.
	 * </ul>
	 * </p>
     */
    public int sessionPoolWait(String sessionPoolName, int current) { return current ; }

    /**
     *Sets the logging options.</p>
     * 
	 * <p>The returned value supersedes the value of the <tt><i>options</i></tt> parameter of the
	 * {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method.
	 * </p>
	 * 
     * @param 	 current	The current value for this property.</p>
     *
	 * @return		Integer whose binary representation can be interpreted as a combination of
	 * logging options. See  <a href="../../../../../guide/jgdMonitoring.html#Selecting Logging Options">
	 * Selecting Logging Options</a>.</p>
     */
    public int logOptions(int current) { return current ; }
}
