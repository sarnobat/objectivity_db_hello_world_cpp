/*
 * @(#)ooCollectionIterator.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

/**
 * Defines behavior shared by all scalable-collection iterators.
 *
 * <p>A <i>scalable-collection iterator</i> is an object that iterates over 
 * objects in a particular scalable collection. For additional information,
 * see 
 * <a href="../../../../../guide/jgdIterators.html#Scalable-Collection Iterators">
 * Scalable-Collection Iterators</a>.</p>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER=1 CELLPADDING=3 CELLSPACING=0 WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#current()">current()</a><br>
 *     <a href="#currentValue()">currentValue()</a><br>
 *     <a href="#goToIndex(int)">goToIndex(int)</a><br>
 *     <a href="#goToLast()">goToLast()</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Indexes</b></td>
 *     <td>
 *     <a href="#currentIndex()">currentIndex()</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Repositioning&nbsp;the&nbsp;Iterator</b></td>
 *     <td>
 *     <a href="#goTo(java.lang.Object)">goTo(Object)</a><br>
 *     <a href="#goToIndex(int)">goToIndex(int)</a><br>
 *     <a href="#goToLast()">goToLast()</a><br>
 *     <a href="#reset()">reset()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Modifying&nbsp;the&nbsp;Collection</b></td>
 *     <td>
 *     <a href="#remove()">remove()</a><br>
 *     <a href="#set(java.lang.Object)">set(Object)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Moving&nbsp;an&nbsp;Element</b></td>
 *     <td>
 *     <a href="#moveCurrentTo(java.lang.Object)">moveCurrentTo(Object)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Related&nbsp;Objects</b></td>
 *     <td>
 *     <a href="#collection()">collection()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Cleanup</b></td>
 *     <td>
 *     <a href="#close()">close()</a>
 *     </td></tr>
 * </table>
 */
public interface ooCollectionIterator extends java.util.ListIterator
{
    /**
     * Throws UnsupportedOperationException.</p>
     *
     */
   public void add(Object obj);

	/**
     * Closes this scalable-collection iterator.
     *
     * <p>You can call this method to signal that you are finished using
     * this iterator, allowing its data structures to be garbage collected.
	 */
   public void close();

	/**
	 * Returns this scalable-collection iterator's corresponding collection.</p>
	 *
	 * @return		collection whose elements, keys, or values this scalable-collection iterator finds.
	 *
	 *
	 */
   public ooCollection collection();

	/**
	 * Finds this scalable-collection iterator's current element. </p>
	 * 
	 * <p>If the collection is a set or a list, 
	 * the found object is an element of that set or list. 
	 * If the collection is an object map, the found object is either a key or a value of that object map, 
	 * depending on how this scalable-collection iterator was initialized.
	 *
	 * @return	This scalable-collection iterator's current element or null if there is
	 * no current element (because the iterator is positioned before the
	 * first element or after the last element).</p>
	 *
	 * @see     #currentValue
	 */
   public Object current();

    /**
     * Gets the current index of this scalable-collection iterator.</p>
	 * 
	 * <p>Using indexes can be inefficient; 
	 * see
	 * <a href="../../../../../guide/jgdIterators.html#Performance of Object-Based and Index-Based Operations">
	 * Performance of Object-Based and Index-Based Operations</a>.</p>
     *
     * @return              The index at which this iterator is currently positioned in the collection.
     */
   public int currentIndex();

    /**
     * Finds the value object paired with the current (key) object in this 
     * scalable-collection iterator's iteration set. </p>
     *
     * <p>You typically use this method only if you are iterating over 
     * the keys of an object map and you 
     * want to find the value that is paired with the current key. This 
     * method is equivalent to the 
     * {@link #current <tt>current</tt>} method if you are 
     * iterating over a set or list, whose elements are not key-value 
     * pairs.</p>
     *
     * @return  The value of this scalable-collection iterator's current 
     * element, or null if there is no current element 
     * (because the iterator is positioned before the first element or after 
     * the last element). </p>
	 *
	 * @see     #current  
     */
   public Object currentValue();
   
	/**
	 * Positions this scalable-collection iterator at the first occurrence of the
	 * specified object.
	 *
	 * <p>You typically use this method only if you are iterating over the
	 * elements of a sorted set or the keys of a sorted object map. In those
	 * cases, you are assured that the iteration set contains at most one
	 * occurrence of the specified object; in addition, the position of that
	 * object is meaningful because the elements of the iteration set are sorted.
	 * For example, if a sorted set has a comparator that sorts objects by a
	 * <tt>name</tt> attribute, you might want to iterate starting with the objects whose names
	 * begin with the letter C. To do so, you could create an object with the name
	 * <tt>"C"</tt>, use that object as the parameter to <tt>goTo</tt>, then iterate
	 * from the new position. </p>
	 *
	 * 
	 * <p>If the specified object is found, this scalable-collection iterator is positioned
	 * at that object (as if the object had just been returned by <tt>next</tt>).
	 * To iterate starting with the specified object, you need to call 
	 * <a href="#current()"><tt>current</tt></a>
	 * followed by successive calls to <tt>next</tt>.
	 *
	 * <p>If the specified object is not found, this scalable-collection iterator is positioned
	 * at the index just past where that object belongs in the sorted collection. In
	 * the preceding example, if the set contained two successive elements 
     * with the names 
	 * <tt>"Byrnes"</tt> and <tt>"Cabbot"</tt>, the current index would be set to the index of the element
	 * named <tt>"Cabbot"</tt>. </p>
	 * 
	 * @param 	 obj	The object at which to position
	 * this scalable-collection iterator.
	 * 
	 * <p>Typically, <tt><i>obj</i></tt> is a persistent object, namely
	 * the element (or key) of interest.  If this scalable-collection iterator's
	 * collection has a custom comparator 
	 * that can identify a persistent object based on class-specific data, 
	 * <tt><i>obj</i></tt> can instead be a transient object
	 * that identifies the element (or key) of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
	 * Defining a Custom Comparator Class</a>.</p>
	 *
	 * @return		True if the iteration set contains the specified
	 * object; otherwise, false.</p>
	 *
	 *
	 * @see			#goToIndex
	 */
   public boolean goTo(Object obj);

	/**
	 * Positions this scalable-collection iterator at the specified index and returns
	 * the element at that position in the iteration set.
	 * 
	 * <p>If <tt><i>pos</i></tt> is a valid index, it becomes this iterator's new
	 * current index. If <tt><i>pos</i></tt> is less than -1, this iterator is positioned
	 * before the first element. If <tt><i>pos</i></tt> is too large, this iterator is
	 * positioned after the last element.
	 *
	 * <p>You normally use this method only if you are iterating over an ordered collection--for example,
	 *  so you can find a sequence of collection elements starting from a particular element. 
	 * However, even for an ordered collection, 
	 * this method can be inefficient because it requires traversing the collection
	 * to find the indicated index. Whenever possible,
	 * you should use {@link #goTo <tt>goTo</tt>} instead of this method.
	 * See
	 * <a href="../../../../../guide/jgdIterators.html#Performance of Object-Based and Index-Based Operations">
	 * Performance of Object-Based and Index-Based Operations</a>.
	 * </p>
	 *
	 * @param 	 pos	Zero-based index at which to position
	 * this scalable-collection iterator.</p>
	 *
	 * @return		The object at the index <tt><i>pos</i></tt> in the
	 * iteration set, or null if <tt><i>pos</i></tt> is out of bounds.
	 *
	 *
	 */
   public Object goToIndex(int pos);

    /**
     * Positions this scalable-collection iterator at the last element of the
     * iteration set and finds the object at that position.
     *
     * <p>If the collection is a set or a list, the found object is an element
     * of that set or list. If the collection is an object map, the found
     * object is either a key or a value of that object map, depending on how
     * this scalable-collection iterator was initialized.
     *
     * <p>If the collection is ordered (a list, a sorted set, or a sorted
     * object map), this method is more efficient than getting the last index
     * from the collection's size and then going to the last index.</p>
     *
     * @return	The object at the last position in the iteration set.
     */
   public Object goToLast();

	/**
	 * Moves the current element, clustering it with the specified object.
	 * 
	 * 
	 * <p>This method moves the element at this scalable-collection iterator's current index, 
	 * placing the object in a new location in the federated database. 
	 * The current element must be a basic object; you cannot use this method to move a container. 
	 * 
	 * <p>If this scalable-collection iterator is positioned before the first element 
	 * or after the last element of the iteration set, this method does nothing.
	 * If the current element is a key or a value in an object map, 
	 * this method moves just the individual key or value (not the key-value pair).
	 * 
	 * <p>This method changes the object identifier of the
	 * current element.  If the collection has a default comparator, this
	 * method first removes the current element from the collection; then it
	 * moves that object and adds it back to the collection.
	 * 
	 * <p>Do not call this method under any of the following conditions:
	 * <p><ul type=disc>
	 * <li>The current element is an element, key, or value of another
	 * persistent collection.</p>
	 *
	 * <li>The collection
	 * has an application-specific custom comparator that uses the object identifiers
	 * of the elements or keys.</p>
	 * 
	 * <li>(<i>In a non-placement-managed federated database.</i>) The collection 
	 * uses short object identifiers to link to its elements (or keys and values); 
	 * the objects of such a collection must all remain in the same container as the collection.
	 * </ul></p>
	 *
	 *
	 * <p><b>Warning: </b> Outside of the collection being visited, 
	 * any references containing the moved object's old identifier become invalid. 
	 * When you move an object you should, within the same transaction,
	 * update all attributes, name scopes, indexes, and unidirectional relationships
	 * that reference the object.  See
	 * <a href="../../../../../guide/jgdPersistence.html#Moving a Basic Object">
	 * Moving a Basic Object</a>
	 * for additional information.</p>
	 *
	 * @param 	 obj The object with which to cluster the
	 * current element; must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>obj</i></tt> is a database:<dd>The current element is moved to
	 * the default container of that database. 
	 * The element is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>obj</i></tt> is a persistent container:<dd>The current element is
	 * moved to that container.
	 * The element is put on an existing logical page, if there is one with enough space, 
	 * or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>obj</i></tt> is a persistent basic object:<dd>The current element is
	 * moved to the container in which <tt><i>obj</i></tt> is stored.
	 * The element is put on the same logical page as <tt><i>obj</i></tt>, if the page has enough space. 
	 * Otherwise, the element is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl>
	 *
     */
   public void moveCurrentTo(Object obj);

    /**
     * Removes the current element from this scalable-collection iterator's corresponding collection.
     *
     * <p> This method removes the element at this scalable-collection iterator's current position in the iteration set,
     * regardless of which method(s) were called to put the iterator in that position.</p>
	 * 
	 * </p><b>Warning: </b> Calling this method is the <i>only</i> acceptable way 
	 * to remove an element from a collection during iteration. 
	 * For example, do not attempt to remove the current element 
	 * by calling the collection's <tt>remove</tt> method.</p>
	 * 
     * <p>If this scalable-collection iterator is positioned
     * before the first element or after the last element of the collection,
     * this method does nothing.</p>
     *
     * <p>If this scalable-collection iterator is positioned
     * at an element of the collection,
     * the action taken by this method depends on the nature of that element:</p>
     *
     * <ul type=disc>
     * <li>If the current element is an element of a set or list,
     * or the key in an element of an object map,
     * this method removes the element from the collection
     * and positions this iterator at the previous element.
     * (If the first element is removed,
     * this iterator is positioned before the new first element.)
     *
     * <li>The current element is a value in an element of an object map,
     * this method replaces the value with <tt>null</tt> and leaves this iterator
     * positioned at the same element.
     * </ul></p>
     */
   public void remove();

   
   /**
    * Resets this scalable-collection iterator, repositioning it
    * before the first element of its iteration set.
    *
    * <p>You can call this method if you want to restart iterating from the 
    * beginning of the iteration set. After this method is executed, the 
    * current index is set to -1. A subsequent call to <tt>next</tt> returns 
    * the first element in the iteration set.   
    */
   public void reset();

    /**
     * Modifies this scalable-collection iterator's corresponding collection,
     * replacing the current element with the specified object.
     *
     * <p>If this scalable-collection iterator is positioned before the first
     * element or after the last element of the iteration set, this method does
     * nothing.
     * If this scalable-collection iterator is positioned at an element of
     * the iteration set, the action taken by the method depends on the nature
     * of that element:
     *
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *	<td VALIGN="top" WIDTH="1%"><b>Current&nbsp;Element</b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Action&nbsp;Taken<b></td></tr>
     * <tr><td>Element of a list</td>
     *		<td>Replaces the current element of the collection with the specified object.</td></tr>
     * <tr><td>Element of a set</td>
     *		<td><i>Throws an exception.</i></td></tr>
     * <tr><td>Key in a key-value pair of an object map</td>
     *		<td><i>Throws an exception.</i></td><tr>
     * <tr><td>Value in a key-value pair of an object map</td>
     *		<td>Sets the value to the specified object.</td><tr>
     * </table></p>
     *
     * <p><b>Note: </b> The set method cannot replace elements of a set or keys
     * of an object map because doing so would bypass the sorting criteria or
     * hashing function provided by the collection's comparator.</p>
	 * 
	 * <p>This method replaces the list element 
	 * or value object at this scalable-collection iterator's current position 
	 * in the iteration set,
     * regardless of which method(s) were called to put the iterator in that position.</p>
	 * 
     * @param 	 obj The object that is to replace the
     * current element.
     */
   public void set(Object obj);
}
