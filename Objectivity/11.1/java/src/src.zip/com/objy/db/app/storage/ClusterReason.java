/*
 * @(#)ClusterReason.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app.storage ;
/**
 * Defines constants that indicate the reason an object is being clustered,
 * as well as behavior shared by all clustering reasons.
 *
 * <p>A <i>clustering reason</i> indicates why an object is
 * being clustered.  
 * You can optionally use clustering reasons in a custom clustering strategy 
 * to place each object according to the reason for making it persistent;
 * see <a href="../../../../../../guide/jgdClustering.html#Controlling Clustering With Clustering Reasons">
 * Controlling Clustering With Clustering Reasons</a>.
 * A clustering reason is used as a parameter to the
 * <a href="ClusterStrategy.html#requestCluster(java.lang.Object, com.objy.db.app.storage.ClusterReason, java.lang.Object)"><tt>requestCluster</tt></a>
 * method of a clustering strategy or the
 * <a href="../Session.html#requestCluster(java.lang.Object, com.objy.db.app.storage.ClusterReason, java.lang.Object)"><tt>requestCluster</tt></a> method
 * of a session.
 *
 * <p>Objectivity for Java uses predefined clustering reasons to 
 * represent the various actions that can make objects persistent implicitly.
 * See <a href="../../../../../../guide/jgdClustering.html#Clustering for Predefined Reasons">
 * Clustering for Predefined Reasons</a>.
 *
 * <p>You should implement this interface in a class you define if you ever
 * make direct calls to a <tt>requestCluster</tt> method for an 
 * application-specific reason. You should pass an
 * object of your class as the <tt>reason</tt> parameter in direct calls
 * to <tt>requestCluster</tt>.
 * For additional information, see
 * <a href="../../../../../../guide/jgdClustering.html#Supporting Application-Specific Reasons for Clustering">
 * Supporting Application-Specific Reasons for Clustering</a>.
 *
 * <p>You can define as many clustering-reason classes as your application 
 * needs. 
 *
 * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr><td valign=top><a name="clusterReasons"><b>Clustering reasons</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify why an object is being made persistent.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#APPLICATION">APPLICATION</a><br>
 *     <a href="#BIND">BIND</a><br>
 *     <a href="#COLLECTION">COLLECTION</a><br>
 *     <a href="#NAMEOBJ">NAMEOBJ</a><br>
 * 	    <a href="#REFERENCE">REFERENCE</a><br>
 *     <a href="#RELATE_TO_PERSISTENT">RELATE_TO_PERSISTENT</a><br>
 *     <a href="#RELATE_TO_TRANSIENT">RELATE_TO_TRANSIENT</a>
 *     </td></tr>
 * </table>
 */
public interface ClusterReason
{
	/**
	 * Clustering reason: An object is being made persistent for some application-specific
	 * reason, that is, by a direct call to <tt>requestCluster</tt>.
	 */
    int APPLICATION  = 0 ;

	/**
	 * Clustering reason: An object is being made persistent because the requesting object
	 * references it in a reference attribute and the requesting object is
	 * being written to the database.
	 */
    int REFERENCE    = 1 ;

	/** Clustering reason: An object is being made persistent because it was 
     * given a root name in the roots dictionary of the requesting object.
	 */
    int BIND         = 2 ;

	/**
	 * Clustering reason: Included for backward compatibility only; use 
     * <tt>RELATE_TO_PERSISTENT</tt> instead.
	 */
    int RELATIONSHIP = 3 ;

	/**
	 * Clustering reason: An object is being made persistent because a relationship is 
     * being established between it and the requesting persistent object.
	 */
    int RELATE_TO_PERSISTENT = RELATIONSHIP ;

	/**
	 * Clustering reason: An object is being made persistent because it was given a scope name
	 * in the scope of the requesting object.
	 */
    int NAMEOBJ      = 4 ;

	/**
	 * Clustering reason: An object is being made persistent because it was added to a
	 * persistent collection (the requesting object). */
    int COLLECTION   = 5 ;
    
	/**
	 * Clustering reason: An object is being made persistent because a relationship is 
     * being established between it and a transient instance of a 
     * persistence-capable class.
	 */
    int RELATE_TO_TRANSIENT = 6 ;

	/**
	 * Gets the reason for making an object persistent.</p>
 	 *
 	 * @return		The reason represented by this object; one of the
	 * following constants defined in this interface:
     * <dl><dd><dl>
	 *  <dt><tt>BIND</tt><dd>The object was made a named root.</dd>
	 *  <dt><tt>NAMEOBJ</tt><dd>The object was given a scope name.</dd>
	 *  <dt><tt>COLLECTION</tt><dd>The object was added to a persistent
	 * collection.</dd>
	 *  <dt><tt>RELATE_TO_PERSISTENT</tt><dd>A relationship was established 
     * between the object and a persistent object.</dd>
	 *  <dt><tt>RELATE_TO_TRANSIENT</tt><dd>A relationship was established 
     * between the object and a transient instance of a persistence-capable 
     * class.</dd> 
	 *  <dt><tt>REFERENCE</tt><dd>The object is referenced by an object being 
	 * written to the session's Objectivity/DB cache.</dd>
	 *  <dt><tt>APPLICATION</tt><dd>The application made a direct call to <tt>requestCluster</tt>.</dd>
	 * </dd></dl></dl>
	 */
    int getReason() ;
}



