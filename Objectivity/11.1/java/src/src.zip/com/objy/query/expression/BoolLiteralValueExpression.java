package com.objy.query.expression;
/**
 * Represents a boolean literal value node.
 */
public class BoolLiteralValueExpression extends LiteralValueExpression 
{
    
    /**
     * Constructor.
     */
    BoolLiteralValueExpression() 
    {
        this(Binding.create());
    }
    
    /**
     * Constructor taking a boolean value.
     * @param value A boolean value
     */
    public BoolLiteralValueExpression(boolean value)
    {
        this(Binding.create(value));
    }

    /**
     * Constructor taking an ID.
     * @param id
     */
    BoolLiteralValueExpression(long id) 
    {
        setIdAfterNullCheck(id);
    }
    
    /**
     * Returns the type of this expression (oocBoolLiteralExpression).
     * @return ooExpressionType
     */
    @Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.BoolLiteralValueExpression; 
    }

    /**
     * Returns the boolean literal value.
     */
    public boolean getValue() 
    {
        throwExceptionIfInvalidOrClosed(getId());
        return Binding.getValue(getId());
    }

    /**
     * Sets the boolean literal value.
     */
    public void setValue(boolean val) 
    {
        throwExceptionIfInvalidOrClosed(getId());
        Binding.setValue(getId(), val);
    }

    @Override
    public String toString()
    {
    	return getValue() ? "true" : "false";
    }
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitBoolLiteralValue(this);
    }
    
    static class Binding
    {
        private static native long create();      
        private static native long create(boolean value);
        private static native boolean getValue(long id);
        private static native void setValue(long id, boolean val);
        
    }
}
