package com.objy.query.expression;
/**
 * Enumeration of expression types
 */
public enum ExpressionType 
{
    OperatorExpression(0),
    AttributeValueExpression(1),
    IntLiteralValueExpression(2),
    UIntLiteralValueExpression(3),
    FloatLiteralValueExpression(4),
    BoolLiteralValueExpression(5),
    StringLiteralValueExpression(6),
    DateLiteralValueExpression(7),
    TimeLiteralValueExpression(8),
    DateTimeLiteralValueExpression(9),
    IntervalLiteralValueExpression(10),
    OrderedListLiteralValueExpression(11),
    ClassTypeLiteralValueExpression(12),
    OidLiteralValueExpression(13),
    ObjectLiteralValueExpression(14),
    InvalidExpression(15);
    
    private int mIntValue; 
    
    ExpressionType(int val)
    {
        mIntValue = val;
    }
    
    /**
     * Returns the integer code of the expression type. 
     */
    
    public int getIntValue()
    {
        return mIntValue;
    }

}
