/*
 * @(#)ooId.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Defines the behavior of object identifiers.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You can obtain the object identifier for a basic object, container, 
 * or database by calling the object's <tt>getOid</tt> 
 * method. 
 *
 * <p>The object identifier for a basic object consists of four 
 * components that specify its storage location; these components identify
 * the database (<tt><i>D</i></tt>), container (<tt><i>C</i></tt>), logical 
 * page (<tt><i>P</i></tt>) within the container, and logical  
 * slot (<tt><i>S</i></tt>) within the page where the identified object 
 * resides.  For  
 * uniformity, the identifier of a container, database, or autonomous 
 * partition can be expressed as an object identifier (that is, in a 
 * four-part format).  For additional information, see
 * <a href="../../../../../guide/jgdOrganization.html#Object Identifiers">
 * Object Identifiers</a>.</p>
 *
 * <p>The object identifier may also specify the Objectivity/DB type number 
 * of the object's class. 
 *
 * <a name="Partial"></a><h2>Complete and Partial Object Identifiers</h2>
 *
 * <p>A <i>complete object identifier</i> specifies both 
 * the object's location in the federated database and the type number of
 * its class.  A <i>partial object identifier</i> specifies only the object's
 * location.  You can obtain a partial object identifier by calling the 
 * <a href="./ooObj.html#getOid(boolean)"><tt>getOid(boolean)</tt></A> method of a basic 
 * object, passing false as the parameter.  The <tt>getOid</tt> method 
 * must obtain a read lock on the basic object to look up the type number of 
 * its class; when you request a partial object identifier instead of a 
 * complete object identifier, you avoid the need to lock the object.
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 * 	<td>
 *     <a href="#getDB()">getDB()</a><br>
 *     <a href="#getOC()">getOC()</a><br>
 *     <a href="#getPage()">getPage()</a><br>
 *     <a href="#getSlot()">getSlot()</a><br>
 *     <a href="#getTypeN()">getTypeN()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	<td>
 *     <a href="#isNull()">isNull()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Converting&nbsp;to Other&nbsp;Representations</b></td>
 * 	<td>
 *     <a href="#getString()">getString()</a><br>
 *     <a href="#getStoreString()">getStoreString()</a><br>
 *     <a href="#getStoreLong()">getStoreLong()</a>
 * 	</td></tr>
 * </table>
 */
public interface ooId 
{
    /**
     * Gets the identifier of the database in which the object with this
     * object identifier is stored.</p>
     *
     * @return  The identifier of the database in which the object with this
     * object identifier is stored.
     */
    int getDB() ;
    /**
     * Gets the identifier of the container in which the object with this
     * object identifier is stored.</p>
     *
     * @return  The identifier of the container in which the object with this
     * object identifier is stored.
     */
    int getOC() ;
    /**
     * Gets the identifier of the page in which the object with this
     * object identifier is stored.</p>
     *
     * @return  The identifier of the page in which the object with this
     * object identifier is stored.
     */
    int getPage() ;
    /**
     * Gets the number of the slot in which the object with this
     * object identifier is stored.</p>
     *
     * @return  The number of the slot in which the object with this
     * object identifier is stored.
     */
    int getSlot() ;
    
    /**
     * Gets the Objectivity/DB type number of the class of the object with this
     * object identifier.
     *
     * <p>The type number uniquely identifies the object's class in the
     * federated database schema.</p>
     *
     * @return   The Objectivity/DB type number of the class of the object 
     * with this object identifier, or 0 if this is a partial object 
     * identifier. See <a href="#Partial">
     * Complete and Partial Object Identifiers</a>. 
     */
    long getTypeN() ;
    
    /**
     * Gets the string representation of this object identifier.
     *
     * <p>The string is of the form
     *<tt>"#<i>D</i>-<i>C</i>-<i>P</i>-<i>S</i>:<i>typeN</i>"</tt>.
     *
     * <p><b>Warning: </b>You must not modify the returned string if you 
     * intend to use it to look up the referenced object (by passing it as a 
     * parameter to the
     * {@link ooFDObj#objectFrom <tt>objectFrom</tt>} method of a
     * federated-database object.)</p>
     *
     * @return  The string representation of this object identifier.
     */
    String getStoreString() ;
    
    /**
     * Gets the short string representation of this object identifier.
     * <p>The string is of the form
     * <tt>"#<i>D</i>-<i>C</i>-<i>P</i>-<i>S</i>"</tt>.</p>
     *
     * @return  The short string representation of this object identifier.
     */
    String getString() ;

    /**
     * Gets the integer representation of this object identifier.
     * <p>The integer representation encodes the location of a persistent object but not its class.
     * You can find the referenced persistent object  by calling  the
     * <a href="./ooFDObj.html#objectFrom(long, long)"><tt>objectFrom</tt></a> method of a
     * federated-database object, specifying the
     * integer object identifier of the persistent object and the type number of its class.</p>
     *
     * @return  The long integer representation of this object identifier.
     */
    long getStoreLong() ;

    /**
     * Tests whether this object identifier is null.
     * <p>An object identifier is null if the value of each of its components except
     * the type number is 0.</p>
     *
     * @return  True if this object identifier is null; otherwise, false.
     */
    boolean isNull() ;

}


