/*
 * @(#)FetchErrorInfo.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

/**
 * Defines behavior shared by all fetch-error information objects.
 *
 * <p>When you fetch a source object and some or all of its reference 
 * attributes, the fetch operation may complete with errors. This situation 
 * arises when the session is able to fetch the source 
 * object, but is unable to find or access the destination 
 * objects of all relevant reference attributes.  For additional information,
 * see
 * <a href="../../../../../guide/jgdPersistence.html#FetchErrors">
 * Errors While Fetching Reference Attributes</a>.
 *
 * <p>A <i>fetch-error information object</i> contains descriptive information
 * about this kind of fetch error, including:
 * <ul>
 * <li>The name of the reference attribute at which the error occurred.
 * <li>The object identifier of the destination object that could not be 
 * found or accessed.
 * <li>If the destination object is an element of an array,
 * the index of the element.
 * <li>A description of the condition that caused the error.
 * </ul>
 *
 * <p>The <tt>FetchErrorInfo</tt> interface defines abstract methods for 
 * getting information from a fetch-error information object.
 *
 * <a name="Obtaining"><h2>Obtaining Fetch-Error Information Objects</h2>
 *
 * <p>By default, when a fetch operation completes with errors
 * Objectivity for Java traps those errors and
 * passes them in an
 * <a href="ActivateInfo.html">activate information object</a>
 * to the <a href="PersistentEvents.html#activate(com.objy.db.iapp.ActivateInfo)"><tt>activate</tt></a>
 * method, which is called at the end of fetch operation. The activate 
 * information object has a 
 * vector of fetch-error information objects, one for each destination object 
 * that could not be found or accessed.
 * The most likely cause of the error is that an object reference is invalid 
 * because the object has been deleted or moved.
 *
 * <p>You can obtain fetch-error information objects by calling the
 * <a href="ActivateInfo.html#getFetchErrors()"><tt>getFetchErrors</tt></a>
 * method of an activate information object.
 * Alternatively, you can call the 
 * <a href="../ObjyRuntimeException.html#errors()"<tt>errors</tt></a> method 
 * of a caught <a href="../FetchCompletedWithErrors.html"<tt>FetchCompletedWithErrors</tt></a>
 * exception.
 * You never create an object of this interface directly.
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 *
 */
public interface FetchErrorInfo 
{
   /**
    * Gets the name of the reference attribute at which the fetch error occurred.
    */
   String getFieldName() ;
   
   /**
    * Gets the index of the element at which the fetch error occurred.
    *
    * <p>This method is relevant when the object for which the fetch error
    * occurred is an element of an array.
    * The index is specified by an array of integers;
    * each element of the returned array specifies one dimension of the index.
    * For example, if an error occurred at the object
    * referenced by <i>arrayField</i>[3][5], the array of integers would 
	* contain two elements; the first element would be 3, and the second, 
    * 5.</p>
    *
    * @return   An array of integers that specify the index of the
    * element at which a fetch error occurred.
    */
   int[ ] getIndex() ;

   /**
    * Gets a description of the fetch error.
    */
   String getErrorMessage() ;

   /**
    * Gets the object identifier of the destination object referenced
    * by the reference attribute at which the fetch error occurred.
    */
   com.objy.db.app.ooId getOid() ;
}



