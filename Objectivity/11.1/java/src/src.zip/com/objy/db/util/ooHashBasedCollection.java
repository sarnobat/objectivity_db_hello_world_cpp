/*
 * @(#)ooHashBasedCollection.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.Comparator;
import java.util.Iterator;

import com.objy.db.ObjectIsDeadException;
import com.objy.db.ObjectNotPersistentException;
import com.objy.pm.ooHashBasedCollectionsPersistor;

/**
 * Abstract superclass for persistence-capable classes that represent 
 * scalable unordered collections containing persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>  Scalable unordered collections  can
 * increase in size with minimal performance degradation. They are
 * implemented using an extendible hashing mechanism so that elements can be added, deleted, 
 * and found efficiently. 
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Properties of Scalable Unordered Collections">
 * Properties of Scalable Unordered Collections</a>.
 * 
 * 
 * <p>Concrete subclasses of <tt>ooHashBasedCollection</tt> represent more specific kinds of
 * unordered collections:
 * <a href="ooHashSetX.html">unordered sets</a> of persistent objects, and
 * <a href="ooHashMapX.html">unordered object maps</a>.
 *
 * <p>Because this class is abstract, you never instantiate it; instead, you
 * work with instances of its concrete derived classes. You should not create
 * your own subclasses of this class.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#add(java.lang.Object)">add(Object)</a><br>
 *     <a href="#ooAddAll(com.objy.db.util.ooCollection)">ooAddAll(ooCollection)</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#ooRemoveAll(com.objy.db.util.ooCollection)">ooRemoveAll(ooCollection)</a><br>
 *     <a href="#ooRetainAll(com.objy.db.util.ooCollection)">ooRetainAll(ooCollection)</a><br>
 *     <a href="#removeAllDeleted()">removeAllDeleted()</a><br>
 *     <a href="#clear()">clear()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#ooIterator()">ooIterator()</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 *     <td>
 *     <a href="#size()">size()</a><br>
 *     <a href="#comparator()">comparator()</a><br>
 *     <a href="#directorySize()">directorySize()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 *     <td>
 *     <a href="#isEmpty()">isEmpty()</a><br>
 *     <a href="#contains(java.lang.Object)">contains(Object)</a><br>
 *     <a href="#ooContainsAll(com.objy.db.util.ooCollection)">ooContainsAll(ooCollection)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Viewing in an MROW&nbsp;Transaction</b></td>
 *     <td VALIGN="top">
 *     <a href="#refresh(int)">refresh(int)</a>
 *     </td></tr>
 * </table>
 */
abstract public class ooHashBasedCollection extends ooCollection {
    ooHashBasedCollection() {}

    /**
     * Gets the comparator for this unordered collection. </p>
     *
     * @return		The comparator for this unordered collection, or null if this
     * collection has a default comparator.
     */
    public Comparator comparator() {
        return getHashBasedCollectionPersistor().comparator();
    }

    /**
     * Tests whether this unordered collection contains the specified
     * object. </p>
     *
     * @param 	 object  The object to be tested for
     * containment in this unordered collection.
     *
     * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
     * the element (or key) of interest.  If this is a sorted collection
     * with a custom
     * comparator that can identify a persistent object based on class-specific
     * data, <tt><i>object</i></tt> can instead be a transient object
     * that identifies the element (or key) of interest. See
     * <a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
     * Custom Comparator Class for Sorted Collections</a>.</p>
     *
     * @return      True if this unordered collection contains an element equal to
     * the specified element; otherwise, false.</p>
     */
    public boolean contains(Object object) {
        return getHashBasedCollectionPersistor().contains(object);
    }

    /**
     * Adds the specified object to this unordered collection. </p>
     *
     * @param 	 object	The element to be added;
     * must be an instance of a persistence-capable class.
     * If <tt><i>object</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @return		True if an element was added; otherwise, false.</p>
     *
     * @see #ooAddAll(ooCollection)
     * @see #ooRemove(Object)
     */
    public boolean add(Object object) {
        return getHashBasedCollectionPersistor().add(object);
    }

    /**
     * Removes from this unordered collection all persistent objects that have been
     * deleted from the federated database.
     *
     * <p>If the elements of this unordered collection are persistent objects, this
     * method removes any element that has been deleted.  If the elements are
     * key-value pairs, this method removes any element in which either the
     * key or the value has been
     * deleted.
     *
     * <p>You can call this method to restore this unordered collection's referential
     * integrity.
     */
    public void removeAllDeleted()
    {
        getHashBasedCollectionPersistor().removeAllDeleted();
    }

    /**
     * Removes all elements (or keys) of the specified collection from this unordered collection.
     *
     * <p>Which elements are removed depends on whether the elements of the two collections
     * are persistent objects or key-value pairs.
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of This&nbsp;Collection</b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of <tt><i>collection</i></tt><b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Removes From This Collection</td></b></tr>
     * <tr><td>persistent objects</td>
     *		<td>persistent objects</td>
     *		<td>All elements that are also elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>persistent objects</td>
     *		<td>key-value pairs</td>
     *		<td>All elements that are keys of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>persistent objects</td>
     *		<td>All elements whose keys are elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>key-value pairs</td>
     *		<td>All elements whose keys are also keys of
     * <tt><i>collection</i></tt></td></tr>
     * </table></p>
     *
     * @param 	 collection	The collection whose elements are to be
     * removed from this unordered collection.</p>
     *
     * @return		True if any elements were removed; otherwise, false.</p>
     *
     * @see #clear
     * @see #ooRemove(Object)
     * @see #ooRetainAll(ooCollection)
     */
    public boolean ooRemoveAll(ooCollection collection) {
        if (collection == this) {
            if (isEmpty())
                return false;
            else
                return getHashBasedCollectionPersistor().removeAll(collection);
        }
        boolean changed = false;
        Iterator itr = collection.keyIterator();
        while (itr.hasNext())
            if (ooRemove(itr.next()))
                changed = true;
        return changed;
    }

    /**
     * Removes the first occurrence of the specified object from this unordered collection.
     *
     * <p>If the elements of this unordered collection are persistent objects, this method removes the
     * first element (if any) that is
     * equal to <tt><i>object</i></tt>.
     * If the elements are key-value pairs, this method removes the
     * element (if any) whose key is <tt><i>object</i></tt>. </p>
     *
     * @param 	 object  The object to be removed.</p>
     *
     * @return      True if an element was removed; otherwise, false.</p>
     *
     * @see #clear
     * @see #ooRemoveAll(ooCollection)
     * @see #ooRetainAll(ooCollection)
     */
    public boolean ooRemove(Object object) {
        return getHashBasedCollectionPersistor().remove(object);
    }

    /**
     * Tests whether this unordered collection is empty. </p>
     *
     * @return		True if this unordered collection has no elements; otherwise,
     * false.
     */
    public boolean isEmpty() {
        return getHashBasedCollectionPersistor().isEmpty();
    }

    /**
     * Adds all elements (or keys) in the specified collection to this
     * collection. </p>
     *
     * @param 	 collection	The collection whose elements are to
     * be added to this unordered collection.  If the elements of <tt><i>collection</i></tt> are
     * key-value pairs and the elements of this unordered collection are persistent objects,
     * only the keys of <tt><i>collection</i></tt> are added to this
     * collection.</p>
     *
     * @return		True if any elements were added; otherwise, false.</p>
     *
     * @see #add(Object)
     * @see #ooRemoveAll(ooCollection)
     */
    public boolean ooAddAll(ooCollection collection)
    {
        Iterator itr = collection.keyIterator();
        boolean mod = false;
        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

    /**
     * Tests whether this unordered collection contains all elements (or keys) in the specified
     * collection.
     *
     * <p>The meaning of this method depends on whether the elements of the collections being
     * compared are persistent objects or  key-value pairs.
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of This&nbsp;Collection</b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of <tt><i>collection</i></tt><b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Tests Whether</td></b></tr>
     * <tr><td>persistent objects</td>
     *		<td>persistent objects</td>
     *		<td>This collection contains all elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>persistent objects</td>
     *		<td>key-value pairs</td>
     *		<td>This collection contains all keys of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>persistent objects</td>
     *		<td>All elements of <tt><i>collection</i></tt>
     * are keys of this collection</td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>key-value pairs</td>
     *		<td>All keys of <tt><i>collection</i></tt>
     * are also keys of this collection</td></tr>
     * </table></p>
     *
     * @param 	 collection	The collection whose elements
     * (or keys) are
     * to be tested for containment in this unordered collection.</p>
     *
     * @return		True if this unordered collection contains an element (or key) equal to
     * each element (or key) of <tt><i>collection</i></tt>; otherwise, false. 
     * </p> 
     *
     * @see #contains(Object)
     */
    public boolean ooContainsAll(ooCollection collection) {
        if (comparator() == null)
            return getHashBasedCollectionPersistor().containsAll(collection);
        else {
            Iterator itr = collection.keyIterator();
            while (itr.hasNext())
                if (!contains(itr.next()))
                    return false;
            return true;
        }
    }

    /**
     * Sets this unordered collection to an empty collection, removing any elements it
     * contains. </p>
     *
     * @see #ooRemove(Object)
     * @see #ooRemoveAll(ooCollection)
     * @see #ooRetainAll(ooCollection)
     */
    public void clear()
    {
        getHashBasedCollectionPersistor().clear();
    }
    

    /**
     * Retains all elements of this unordered collection that are also in the specified
     * collection, removing all other elements.
     *
     * <p>Which elements are removed depends on whether the elements of the two collections
     * are persistent objects or key-value pairs.
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of This&nbsp;Collection</b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of <tt><i>collection</i></tt><b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Removes From This Collection</td></b></tr>
     * <tr><td>persistent objects</td>
     *		<td>persistent objects</td>
     *		<td>All elements that are not also elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>persistent objects</td>
     *		<td>key-value pairs</td>
     *		<td>All elements that are not keys of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>persistent objects</td>
     *		<td>All elements whose keys are not elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>key-value pairs</td>
     *		<td>All elements whose keys are not also keys of
     * <tt><i>collection</i></tt></td></tr>
     * </table></p>
     *
     * @param 	 collection	The collection whose elements
     * (or keys) are to be retained in this unordered collection.</p>
     *
     * @return		True if any elements were removed; otherwise, false.</p>
     *
     * @see #clear
     * @see #ooRemove(Object)
     * @see #ooRemoveAll(ooCollection)
     */
    public boolean ooRetainAll(ooCollection collection) {
        if (collection.comparator() == null)
            return getHashBasedCollectionPersistor().retainAll(collection);
        else {
            boolean changed = false;
            Iterator itr = keyIterator();
            while (itr.hasNext())
                if (!collection.contains(itr.next())) {
                    itr.remove();
                    changed = true;
                }
            return changed;
        }
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this unordered collection. </p>
     *
     * @return		A scalable-collection iterator for finding the elements of this unordered collection. 
	 * The iterator finds the
     * elements in an undefined order.
     */
    public ooCollectionIterator ooIterator() {
        return getHashBasedCollectionPersistor().iterator();
    }

    /**
     * Refreshes each container used internally by this unordered collection, except 
     * for the container in which the collection itself is stored.  
     *
     * <p>You typically call this method when you need to refresh 
     * your view of a collection that you are reading in an MROW 
     * transaction.  This method calls 
     * {@link com.objy.db.app.storage.ooContObj#refresh <tt>refresh</tt>}
     * on each container that is used internally by the collection--that is, 
     * on the node  
     * containers maintained by an ordered scalable collection, 
     * or the hash-bucket containers maintained by an 
     * unordered scalable
     * collection. This method does not refresh the container in which the 
     * collection itself is stored, nor does it necessarily refresh the 
     * containers that store the collection's elements.</p>        
     *
     * @param 	 mode    The type of lock to obtain for 
     * each refreshed container; one of the following constants defined in 
     * the <tt>com.objy.db.app.oo</tt> interface: 
     * <dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
     * </dl>
     */
    public void refresh(int mode) {
        getHashBasedCollectionPersistor().refresh(mode);
    }

    /**
     * Gets the size of this unordered collection. </p>
     *
     * @return		The number of elements in this unordered collection.
     */
    public int size() {
        return getHashBasedCollectionPersistor().size();
    }

	/**
	 * Gets the directory size of this unordered collection. </p>
	 * 
	 * The number of entries in an unordered collection�s top-level directory is 2**<tt><i>N</tt></i>,
	 * where <tt><i>N</tt></i> is the number of high-order bits of an element�s hash value that are used
	 * to select a hash bucket for that element. A top-level directory is considered very
	 * large if it has 2**14 (or more) entries; such a collection would use 14 (or more)
	 * high-order bits of the hash values to select a hash bucket for its elements.</p>
	 * 
	 * You can use this method to monitor the growth of the top-level directory as a
	 * diagnostic for evaluating the effectiveness of various properties of this collection:
	 * <ul>
	 * <li>
	 * A very large top-level directory may indicate that the hash values produced
	 * by your hashing algorithm are not distributed evenly over the range of 32-bit
	 * integers. For optimal performance, the elements� hash values should vary in
	 * their high-order bits. Otherwise, the top-level directory of the collection
	 * grows until it uses a number of high-order bits that do vary.
	 * <li>
	 * If the hash values are fairly well distributed, a very large top-level directory
	 * may indicate that the capacity of the collection�s hash buckets is too small. In
	 * this case, you should consider re-creating the collection with a larger number
	 * of pages per hash bucket, or re-creating the collection in a container with a
	 * larger storage-page size, or both.
	 * </ul>
	 * </p>
	 * 
	 * Of course, a collection�s top-level directory may be very large simply because the
	 * collection itself has a very large number of elements.</p>
	 * 
	 * For more information, see
	 * <a href="../../../../../guide/jgdCollections.html#Properties of Scalable Unordered Collections">
	 * Properties of Scalable Unordered Collections</a>.</p>
	 * 
	 *
	 * @return		The number of entries in this unordered collection�s top-level directory.
	 * 
	 */
	public int directorySize() {
        return getHashBasedCollectionPersistor().directorySize();
    }


    /**
     * Reserved for internal use; you should not call this method. </p>
     */
    protected ooHashBasedCollectionsPersistor getHashBasedCollectionPersistor() {
        if (getPersistor() == null)
            throw new ObjectNotPersistentException(
                    "Attempted persistence operation on transient object");
        if (getPersistor().isDead())
            throw new ObjectIsDeadException("Attempted persistence operation on dead object");
        return (ooHashBasedCollectionsPersistor) getPersistor();
    }
}
