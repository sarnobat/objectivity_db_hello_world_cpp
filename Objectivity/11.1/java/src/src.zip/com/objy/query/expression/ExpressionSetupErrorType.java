package com.objy.query.expression;
/**
 * Enumeration of expression setup error types
 */
public enum ExpressionSetupErrorType 
{
    ooQPQLSyntaxError(0),
    ooQInvalidPredicateTypeError(1),
    ooQUnknownTypeError(2),
    ooQUnknownAttributeError(3),
    ooQUnknownTokenError(4),
    ooQOperandMismatchError(5),
    ooQTooFewOperandsError(6),
    ooQTooManyOperandsError(7),
    ooQIncompatibleOperandError(8),
    ooQInvalidRegularExpressionError(9),
    ooQOperandCrossIncompatibleError(10),
    ooQElementCrossIncompatibleError(11),
    ooQOperatorImplementationError(12),
    ooQObjectLitValueIncompatibleError(13),
    ooQUnknownVariableTypeError(14),
    ooQUndefinedVariableError(15),
    ooQVariableValueNotSetError(16),
    ooQCreateLookupFieldError(17);
    
    private int mIntValue; 
    
    ExpressionSetupErrorType(int val)
    {
        mIntValue = val;
    }
  
    /**
     * Returns the integer code of the setup error type. 
     */
    public int getIntValue()
    {
        return mIntValue;
    }
}
