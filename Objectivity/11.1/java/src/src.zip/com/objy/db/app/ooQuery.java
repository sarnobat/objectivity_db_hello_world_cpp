/*
 * @(#)ooQuery.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.db.ObjyRuntimeException ;

import com.objy.db.iapp.PooQuery ;
import com.objy.db.iapp.Persistent ;

import com.objy.pm.Access ;

/**
 * @deprecated
 *
 * See {@link com.objy.query.ObjectQualifier <tt>ObjectQualifier</tt>}.</p>
 *
 * Represents a query object, which evaluates whether a persistent object
 * matches a given predicate string.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You use a query object to filter arbitrary groups of objects that
 * cannot be scanned directly with a predicate string. For example, you can
 * use a query object to perform a predicate query over the elements
 * in a persistent collection.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 * <TD><A HREF="#ooQuery()">ooQuery()</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information</B></TD>
 * <TD><A HREF="#setup(java.lang.String, long)">setup(String, long)</A><BR>
 *     <A HREF="#evaluate(com.objy.db.iapp.Persistent)">evaluate(Persistent)</A>
 * </TD></TR>
 * </TABLE>
 */
public class ooQuery
{
    private transient PooQuery persistor ;

	/**
	 * Constructs a query object.
	 */
    public ooQuery()
        { persistor = Access.new_ooQueryPersistor() ; }

	/**
	 * Sets up this query object for evaluating the specified type of objects
     * against the specified predicate string.</p>
	 *
	 * @param 	 predicate	Condition that this
     * query object will test,  expressed in the Objectivity/DB
     * <a href="../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
	 *
	 * @param 	 typeNumber	Objectivity/DB type number of the
     * class whose instances are to be evaluated.</p>
	 */
    public void setup(String predicate, long typeNumber)
        { persistor().setup(predicate, typeNumber) ; }

	/**
	 * Evaluates whether the specified persistent object matches this query
     * object's predicate string.</p>
	 *
	 * @param 	 obj	The persistent object for which the
     * predicate is to be evaluated.</p>
	 *
	 * @return		True if the object matches the predicate string
     * specified by <tt>setup</tt>; otherwise, false.</p>
     *
     * @see #setup(String,  long)
	 */
    public boolean evaluate(Persistent obj)
        { return persistor().evaluate(obj) ; }

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized PooQuery persistor() {
        if (persistor == null)
            throw new ObjyRuntimeException("Attempted persistent operation on a terminated session") ;
        return persistor ;
    }

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized void setPersistor(PooQuery persistor)
        { this.persistor = persistor ; }
}


