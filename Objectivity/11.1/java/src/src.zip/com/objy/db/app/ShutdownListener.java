

package com.objy.db.app ;

/**
 * Abstract superclass for all Objectivity/DB shutdown-listener classes.</p>
 * 
 * 
 * An instance of a class derived from <tt>ShutdownListener</tt> is called a <i>shutdown listener</i>.
 * An application-defined shutdown listener can be registered with
 * the Objectivity/DB shutdown hook to perform application-specific actions
 * before and after the application's interaction is terminated with Objectivity/DB.
 * The Objectivity/DB shutdown hook automatically calls the 
 * <A HREF="#beforeObjyShutdown()"><tt>beforeObjyShutdown()</tt></a> 
 * and <A HREF="#afterObjyShutdown()"><tt>afterObjyShutdown()</tt></a> 
 * methods of the registered shutdown listener. </p>
 * 
 * By default, the Objectivity/DB shutdown hook aborts any active transactions in all threads,
 * deletes any sessions that still exist, deletes all connection objects,
 * and leaves Objectivity/DB in a safe state for process termination.
 * An application can define one or more shutdown listeners to perform additional custom cleanup 
 * beyond the default shutdown behavior.
 * For example, an application-defined shutdown listener 
 * could check whether transactions are complete and commit them as appropriate, 
 * add final entries to an application-specific log, 
 * or release Objectivity/DB-related resources.</p>
 * 
 * You register a shutdown listener by calling the connection's
 * <A HREF="Connection.html#addShutdownHook(com.objy.db.app.ShutdownListener)"><tt>addShutdownHook</tt></a>
 * static method.
 * If you register multiple shutdown listeners, 
 * their pre-shutdown methods and post-shutdown methods are called 
 * in the order in which the listeners are registered.</p>
 * 
 * Because this class is abstract, you never instantiate it; 
 * instead, you work with instances of its derived classes. </p>
 *
 */
abstract public class ShutdownListener
{
	/**
	 * Constructs a new shutdown listener.
	 */
    public ShutdownListener() {}
    
	/**
	 * Provides custom preprocessing before 
	 * the application's interaction with Objectivity/DB is terminated.</p>
	 * 
	 * An application can override this method to perform application-specific preparation
	 * for terminating its interaction with Objectivity/DB.
	 * This method is called automatically by the Objectivity/DB shutdown hook;
	 * an application never calls this method directly.</p>
	 * 
	 * An application typically overrides this method 
     * to ensure the completion of tasks that use or reference Objectivity/DB resources,
     * while those resources still exist.
	 * 
	 * 
	 */
    public void beforeObjyShutdown() {}


	/**
	 * Provides custom postprocessing 
	 * after the application's interaction with Objectivity/DB is terminated.</p>
	 * 
	 * An application can override this method to perform further application-specific cleanup
	 * after its interaction with Objectivity/DB is terminated.
	 * This method is called automatically by the Objectivity/DB shutdown hook;
	 * an application never calls this method directly.</p>
	 * 
	 */
    public void afterObjyShutdown() {}
}
