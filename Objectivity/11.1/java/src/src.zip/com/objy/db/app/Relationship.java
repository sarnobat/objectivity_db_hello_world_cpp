/*
 * @(#)Relationship.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

import com.objy.db.ObjySchemaException ;

import com.objy.pm.tmi.TMIConstants ;
import com.objy.pm.Access;

/**
 * Abstract superclass for classes that represent 
 * <a href="../../../../../guide/jgdOrganization.html#Relationships">
 * relationships</a> of source classes.
 * 
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>Because this class is abstract, you never instantiate it; instead,
 * you work with instances of its derived classes. You should not create
 * your own subclasses of this class.
 *
 * <p>The source class of a relationship must declare a relationship field
 * and define a public static <i>relationship-definition method</i> that 
 * returns a properly initialized instance of the appropriate subclass of 
 * <tt>Relationship</tt>. See
 * <a href="../../../../../guide/jgdDefiningClasses.html#Defining Relationships">
 * Defining Relationships</a>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2"><a name = "ConstantTypes">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr><td valign=top><a name = "copyBehavior"><b>Copy modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how the association links for a 
 * relationship are handled when a source object is copied.</td> 
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#COPY_COPY">COPY_COPY</a><br>
 *     <a href="#COPY_DELETE">COPY_DELETE</a><br>
 *     <a href="#COPY_MOVE">COPY_MOVE</a>
 * 	</td></tr>
 * <tr><td valign=top><a name = "versionBehavior"><b>Versioning modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how the association links for a 
 * relationship are handled when a new version of a source object is 
 * created.</td> 
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#VERSION_COPY">VERSION_COPY</a><br>
 *     <a href="#VERSION_DELETE">VERSION_DELETE</a><br>
 *     <a href="#VERSION_MOVE">VERSION_MOVE</a>
 *     </td></tr>
 * <tr><td valign=top><a name = "accessControl"><b>Access control modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how a relationship may be accessed.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#PRIVATE">PRIVATE</a><br>
 *     <a href="#PROTECTED">PROTECTED</a><br>
 *     <a href="#PUBLIC">PUBLIC</a>
 *     </td></tr>
 * <tr><td valign=top><a name = "inlineMode"><b>Storage modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how the association links for a 
 * relationship are stored.</td> 
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#INLINE_NONE">INLINE_NONE</a><br>
 *     <a href="#INLINE_LONG">INLINE_LONG</a><br>
 *     <a href="#INLINE_SHORT">INLINE_SHORT</a>
 *     </td></tr>
 * </TABLE></p>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information</B></TD>
 * <TD><A HREF="#getMemberName()">getMemberName()</A><BR>
 * 	<A HREF="#getOtherClass()">getOtherClass()</A><BR>
 * 	<A HREF="#getOtherMember()">getOtherMember()</A><BR>
 * 	<A HREF="#getCopyMode()">getCopyMode()</A><BR>
 * 	<A HREF="#getVersionMode()">getVersionMode()</A><br>
 * 	<A HREF="#getAccessControl()">getAccessControl()</A><br>
 *  <A HREF="#getInlineMode()">getInlineMode()</a>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 * <TD><A HREF="#isBidirectional()">isBidirectional()<BR>
 * </A><A HREF="#isDeletePropagated()">isDeletePropagated()<BR>
 * </A><A HREF="#isLockPropagated()">isLockPropagated()<BR>
 * </A><A HREF="#isToMany()">isToMany()<BR>
 * </A><A HREF="#isOtherToMany()">isOtherToMany()</A><BR>
 * </A><A HREF="#isInline()">isInline()</A></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Setting&nbsp;Properties</B></TD>
 * <TD><A HREF="#setAccessControl(int)">setAccessControl(int)</A>
 * </TD></TR>
 * </TABLE>
 */
abstract public class Relationship
{
    private String  memberName;
    private String  otherClassName ;    // Package Qualified Class Name
    private String  otherMemberName;
    private byte    copyMode ; 
    private byte    versionMode ;
    private boolean deletePropagate ;
    private boolean lockPropagate ;
    private long    memberID = 0 ;      // filled in at runtime by the SchemaManager
    private long    assocNum = 0 ;      // filled in at runtime by the SchemaManager
    private int     accessControl = 0 ; // filled in at runtime by the SchemaManager
    private byte    inlineMode ;
    private boolean defined = false ;
    private int     direction = TMIConstants.otiAssocUnknown ; // filled in at runtime by the SchemaManager
        
    /**
     * Copy mode: Delete the association links for the relationship
     * from the copy of the source object and leave them in the 
	 * original source object
     */
    public static final byte COPY_DELETE    = TMIConstants.OTI_COPY_DROP ; 

    /**
     * Copy mode: Move the association links for the relationship from
	 * the original source object to the copy of the source object.
     */
    public static final byte COPY_MOVE      = TMIConstants.OTI_COPY_MOVE ;
    
    /**
     * Copy mode: Copy the association links for the relationship from
	 * the original source object to the copy of the source object.
     */
    public static final byte COPY_COPY      = TMIConstants.OTI_COPY_COPY ; 

    /**
     * Versioning mode: Delete the association links for the relationship 
     * from the new version of the source object and leave them in the 
	 * original source object.
	 *
     * <p><b>Note: </b>Creating new versions of basic objects is not 
     * supported in this release. 
     * These constants are defined so that relationships can be defined
     * to interoperate with other programming interfaces that do support the
     * versioning operation.
     */
    public static final byte VERSION_DELETE = TMIConstants.OTI_VERSION_DROP ; 

    /**
     * Versioning mode: Move the association links for the relationship from
	 * the original source object to the new version of the object.
	 *
     * <p><b>Note: </b>Creating new versions of basic objects is not 
     * supported in this release. 
     * These constants are defined so that relationships can be defined
     * to interoperate with other programming interfaces that do support the
     * versioning operation.
     */
    public static final byte VERSION_MOVE   = TMIConstants.OTI_VERSION_MOVE ; 

    /**
     * Versioning mode: Copy the association links for the relationship from
	 * the original source object to the new version of the object.
	 *
     * <p><b>Note: </b>Creating new versions of basic objects is not 
     * supported in this release. 
     * These constants are defined so that relationships can be defined
     * to interoperate with other programming interfaces that do support the
     * versioning operation.
     */
    public static final byte VERSION_COPY   = TMIConstants.OTI_VERSION_COPY ; 

	/**
	 * Access-control mode: Allow public access to the relationship field.
	 */
    public static final int  PUBLIC         = TMIConstants.otiVisPublic ; 

	/**
	 * Access-control mode: Allow private access to the relationship field.
	 */
    public static final int  PRIVATE        = TMIConstants.otiVisPrivate ; 

	/**
	 * Access-control mode: Allow protected access to the relationship field.
	 */
    public static final int  PROTECTED      = TMIConstants.otiVisProtected ; 

	/**
	 * Storage mode: Store the relationship's association links in the source 
     * object's system default association array. 
	 */
    public static final byte INLINE_NONE    = TMIConstants.OTI_INLINE_NONE ;

	/**
	 * Storage mode: Store the relationship's association links inline in 
     * the data for the source object as standard  
     * object identifiers for the destination objects. 
	 */
    public static final byte INLINE_LONG    = TMIConstants.OTI_INLINE_LONG ;

	/**
	 * Storage mode: (<i>For advanced users only.</i>)  
	 *  Store the relationship's association links inline in
     * the data for the source object as short object 
     * identifiers for the destination objects.
     * Short object identifiers are safe to use only with appropriate object placement. 
     * Specify this constant only after obtaining technical consultation from Objectivity.
	 */
    public static final byte INLINE_SHORT   = TMIConstants.OTI_INLINE_SHORT ;
    
    /**
     * Constructor for the shared part of subclasses of <tt>Relationship</tt>.
     *<p>Because this class is abstract, you never instantiate it;
     * instead, you work with instances of its derived classes:
	 * <ul type=disc>
     * <li><a href="OneToOne.html"><tt>OneToOne</tt></a>
     * <li><a href="OneToMany.html"><tt>OneToMany</tt></a>
     * <li><a href="ManyToOne.html"><tt>ManyToOne</tt></a>
     * <li><a href="ManyToMany.html"><tt>ManyToMany</tt></a>
     * </ul>
     *
     */
    Relationship(String memberName, String otherClassName, String otherMemberName, 
        byte copyMode, byte versionMode, 
        boolean deletePropagate, boolean lockPropagate,
        byte inlineMode)
    {
        this.memberName      = memberName ;
        this.otherClassName  = otherClassName ;
        this.otherMemberName = otherMemberName ;
        this.copyMode        = copyMode ;
        this.versionMode     = versionMode ;
        this.deletePropagate = deletePropagate ;
        this.lockPropagate   = lockPropagate ;
        this.inlineMode      = inlineMode ;
    }


    /**
     * Gets the name of the relationship field for this relationship.</p>
     *
     * @return  The name of the relationship field.
     */
    public String getMemberName()
        { return memberName ; }
        
    /**
     * Gets the name of the destination class for this relationship.</p>
     *
     * @return  The name of the destination class.
     */
    public String getOtherClass()
        { return otherClassName ; }
    
    /**
     * Tests whether this relationship is bidirectional.</p>
     *
     * @return  True if the relationship is bidirectional; otherwise, false.
     */
    public boolean isBidirectional()
        { return (otherMemberName != null) ; }
        
    /**
     * Gets the name of the relationship field for the inverse relationship 
     * in the destination class.</p>
     *
     * @return  The name of the relationship field for the inverse 
     * relationship. 
     */
    public String getOtherMember()
        { return otherMemberName; }
        
    /**
     * Gets the copy mode for this relationship.</p>
     *
     * @return  The copy mode, which specifies how the 
     * association links for this relationship  
     * are handled when a source object is copied; one of the following 
     * constants defined in this class:
	 * <dl><dd><dl>
	 * <dt><tt>COPY_DELETE</tt><dd>Delete the association links from
	 * the copy of the source object and leave them in the 
	 * original source object.</dd>
	 *
	 * <dt><tt>COPY_MOVE</tt><dd>Move the association links from
	 * the original source object to the copy.</dd>
	 *
	 * <dt><tt>COPY_COPY</tt><dd>Copy the association links from
	 * the original source object to the copy of the source object.</dd>
     * </dd></dl></dl></p>
     */
    public byte getCopyMode()
        { return copyMode; }
        
    /**
     * Gets the versioning mode for this relationship.</p>
     *
     * @return  The versioning mode, which specifies how the association 
     * links for this relationship are handled when a new version of a 
     * source object is created; one of the following constants
	 * defined in this class:
	 * <dl><dd><dl>
	 * <dt><tt>VERSION_DELETE</tt><dd>Delete the association links from
	 * the new version of the source object and leave them in the 
	 * original source object.</dd>
	 *
	 * <dt><tt>VERSION_MOVE</tt><dd>Move the association links from
	 * the original source object to the new version of the object.</dd>
	 *
	 * <dt><tt>VERSION_COPY</tt><dd>Copy the association links from
	 * the original source object to the new version of the object.</dd>
     * </dd></dl></dl></p>
     */
    public byte getVersionMode()
        { return versionMode; }
        
    /**
     * Tests whether delete operations are propagated along 
     * association links for this relationship.</p>
     *
     * @return  True if delete operations on source objects are propagated to 
     * destination objects; otherwise, false.
     */
    public boolean isDeletePropagated()
        { return deletePropagate ; }
        
    /**
     * Tests whether explicit locking is propagated along 
     * association links for this relationship.</p>
     *
     * @return  True if an explicit lock obtained for a source object is  
     * propagated to destination objects; otherwise, false.
     */
    public boolean isLockPropagated()
        { return lockPropagate ; }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public long getMemberID()
        { return memberID ; }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public long getAssocNum()
        { return assocNum ; }
        
   	/**
     * Gets the access control for this relationship in the schema.</p>
     *
     * @return		The access control for this relationship; one of the
	 * following constants defined in this class:
     * <dl><dd><dl>
	 *  <dt><tt>PUBLIC</tt><dd>Allow public access to the relationship field.</dd>
	 *  <dt><tt>PROTECTED</tt><dd>Allow protected access to the relationship field.</dd>
	 *  <dt><tt>PRIVATE</tt><dd>Allow private access to the relationship field.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @see #setAccessControl
	 */
    public int getAccessControl()
        { return accessControl ; }
        
   	/**
     * Sets the access control for this relationship in the schema.
     *
     * <p>If this method is never called, the default access control in the
	 * schema is the access control of the static method that returns
	 * this relationship.  For example, if the relationship field for this 
     * relationship is the 
	 * <tt>fleet</tt> field of a <tt>Vehicle</tt> object, its default access
	 * control is the access control of the
	 * <tt>Vehicle.fleet_Relationship</tt> static method.</p>
     *
     * @param 	 accessControl	The access control for this
     * relationship; one of the following constants defined in this class:
     * <dl><dd><dl>
	 *  <dt><tt>PUBLIC</tt><dd>Allow public access to the relationship field.</dd>
	 *  <dt><tt>PROTECTED</tt><dd>Allow protected access to the relationship field.</dd>
	 *  <dt><tt>PRIVATE</tt><dd>Allow private access to the relationship field.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @see #getAccessControl
	 */
    public void setAccessControl(int accessControl)
        { this.accessControl = accessControl ; }
        
   	/**
     * Gets the storage mode for this relationship.</p>
     *
     * @return		The mode in which this relationship's association links 
     * are stored; one of the
	 * following constants defined in this class:
     * <dl><dd><dl>
	 *  <dt><tt>INLINE_NONE</tt><dd>The association links are stored in the 
     * source object's system default association array.</dd> 
	 *  <dt><tt>INLINE_LONG</tt><dd>The association links are stored inline 
     * in the data for the source object as standard object  
     * identifiers for the destination objects.</dd>
	 *  <dt><tt>INLINE_SHORT</tt><dd>(<i>For advanced users only.</i>)  
	 *  The association 
     * links are stored inline in the data for the source object as short object 
     * identifiers for the destination objects.
     * Short object identifiers are safe to use only with appropriate object placement. 
     * Specify this constant only after obtaining technical consultation from Objectivity.
     * </dd>
	 * </dd></dl></dl></p>
	 *
	 * @see #setAccessControl
	 * @see #isInline
	 */
    public byte getInlineMode() 
        { return inlineMode ; }
        
    /**
     * Tests whether this relationship's association links are stored 
     * inline.</p>
     *  @return True if the association links are stored 
     * inline in the source object's data (as either standard or short object 
     * identifiers); false if the association links are stored in the source 
     * object's system default association array.
     */
    public boolean isInline() 
        { return getInlineMode() != INLINE_NONE ; }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public boolean isDefined() 
        { return defined ; }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void setDefined(boolean flag) 
        { defined = flag ; }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void setDirection(int _direction) 
        { direction = _direction ; }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public int getDirection() 
        { return direction ; }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void setMemberIDAndAssocNum(long memberID, long assocNum) {
        this.memberID = memberID ;
        this.assocNum = assocNum ;
        this.defined = true ;
    }
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void setAssocNum(long assocNum)
        { this.assocNum = assocNum ; }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void setMemberID(long memberID)
        { this.memberID = memberID ; }
    
    /**
     * Tests whether this relationship is a to-many relationship.
     *
	 * <p>This method is abstract, so it can be called only on a subclass
	 * of <tt>Relationship</tt>.</p>
	 *
	 * @return  True if this relationship is a to-many relationship;
	 * otherwise, false.
     */
    public abstract boolean isToMany() ;
    
    /**
     * Tests whether this relationship's destination class 
     * defines an inverse to-many relationship.
     *
	 * <p>This method is abstract, so it can be called only on a subclass
	 * of <tt>Relationship</tt>.</p>
	 *
	 * @return  True if the inverse of this relationship is a to-many relationship;
	 * otherwise, false.
     */
    public abstract boolean isOtherToMany() ;
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void assertValidMember(String className, Class memberClass, String actualMemberName) {
        if (getMemberName() == null)
            throw new ObjySchemaException("Malformed Relationship Definition for class " + className + ": "
                + "member name is null") ;
        if (getMemberName().equals(""))
            throw new ObjySchemaException("Malformed Relationship Definition for class " + className + ": "
                + "member name is empty string") ;
        if (!getMemberName().equals(actualMemberName))
            throw new ObjySchemaException("Malformed Relationship Definition for class " + className + ": "
                + "definition specifies member name \""+ getMemberName() 
                + "\" but the actual member name is \""+ actualMemberName+"\"") ;
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void assertOtherRelMatches(String className, Relationship otherRel) {
        if (otherRel.getOtherMember() == null)
            throw new ObjySchemaException("Malformed Relationship Definition for \"" 
                + getOtherClass() + "." + otherRel.getMemberName() 
                + "\" -- definition specifies other member name as null") ;
        if (otherRel.getOtherMember() == "")
            throw new ObjySchemaException("Malformed Relationship Definition for \"" 
                + getOtherClass() + "." + otherRel.getMemberName() 
                + "\" -- definition specifies other member name as empty string") ;
        if (!otherRel.getOtherClass().equals(className))
            throw new ObjySchemaException("Malformed Relationship Definition --  \"" 
                + className + "." + getMemberName() + "\" specifies inverse class \""
                + getOtherClass() + "\""
                + ", but \""+ getOtherClass() + "." + otherRel.getMemberName()
                + "\" specifies inverse class \""+ otherRel.getOtherClass() + "\"");
        if (!otherRel.isBidirectional())
            throw new ObjySchemaException("Malformed Relationship Definition for \"" + className + "."
                + getMemberName() + "\" -- relationship is bidirectional, but inverse definition \""
                + getOtherClass() + "." + getOtherMember() + "\" has no other member name") ;
        if (getOtherMember() != otherRel.getMemberName())
            throw new ObjySchemaException("Malformed Relationship Definition for class \"" + className + "."
                + getMemberName() + "\" -- definition specifies other member name \""+ getOtherMember() 
                + "\" but inverse definition specifies member name as \""
                + otherRel.getMemberName() + "\"") ;
        if (getMemberName() != otherRel.getOtherMember())
            throw new ObjySchemaException("Malformed Relationship Definition for \"" 
                + getOtherClass() + "." + otherRel.getMemberName() 
                + "\" -- definition specifies inverse member name as \""+ otherRel.getOtherMember() 
                + "\" but member name specified in class \"" + className + "\" is \""+ getMemberName()+"\"") ;
        if (isToMany() != otherRel.isOtherToMany())
            throw new ObjySchemaException("Malformed Relationship Definition for \"" + className + "."
                + getMemberName() + "\" -- cardinality does not agree with the inverse definition in \""
                + getOtherClass() + "." + otherRel.getMemberName() + "\"") ;
        if (getInlineMode() != otherRel.getInlineMode())
            throw new ObjySchemaException("Malformed Relationship Definition for class " + className + ": \""
                + getMemberName() + "\" -- the inverse definition association type (Inline Mode) in \"" 
                + getOtherClass() + "." + otherRel.getMemberName() + "\" does not match") ;
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void dumpRelInfo() {
        Access.connectionOut().println("  Relationship Name  :  " + getMemberName());
        Access.connectionOut().println("    Is BiDirectional :  " + isBidirectional());
        Access.connectionOut().println("    Other Class Name :  " + getOtherClass());
        Access.connectionOut().println("    Other Member Name:  " + getOtherMember());
        Access.connectionOut().println("    Member ID :         " + getMemberID());
        Access.connectionOut().println("    Assoc Number :      " + getAssocNum());
        //Access.connectionOut().println("Version Mode :      " + getVersionMode());
        //Access.connectionOut().println("Delete Propagate :  " + isDeletePropagated());
        //Access.connectionOut().println("Lock Propagate :    " + isLockPropagated());
        //Access.connectionOut().println("Inline Mode :       " + getInlineMode());
    }
}


