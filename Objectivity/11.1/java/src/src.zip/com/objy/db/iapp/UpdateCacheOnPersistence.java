/*
 * @(#)UpdateCacheOnPersistence.java
 * 
 * Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

/**
 * Defines behavior shared by all objects that are written to the
 * Objectivity/DB cache immediately after being made persistent.</p>
 *
 * When an object is made persistent, its object identifier
 * in the federated database is assigned immediately.  However, the object's
 * attributes are not processed until the object is written
 * into the Objectivity/DB cache, typically as a result of 
 * committing or checkpointing the transaction, calling the <tt>flush</tt> method on a storage object containing the object, 
 * or calling the object's {@link com.objy.db.app.ooObj#write() <tt>write</tt>} method.</p>
 *
 * Objects that implement this interface are written to the cache
 * immediately upon being made persistent, which causes Objectivity/DB to reserve
 * object identifiers for any
 * attributes that represent internal persistent objects. This allows a persistent object to be clustered near any
 * internal persistent objects it references. Reference
 * attributes are ignored during this write operation, and the object remains marked as modified.</p>
 * 
 * See <a href="../../../../../guide/jgdPersistence.html#Clustering Internal Persistent Objects">Clustering Internal Persistent Objects</a>
 * and <a href="../../../../../guide/jgdCache.html#Interaction With an Objectivity/DB Cache">Interaction With an Objectivity/DB Cache</a>.
 */

public interface UpdateCacheOnPersistence {}
