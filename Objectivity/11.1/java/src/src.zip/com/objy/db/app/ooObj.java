/*
 * @(#)ooObj.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.db.ObjectIsDeadException ;
import com.objy.db.ObjectNotPersistentException ;
import com.objy.db.FetchCompletedWithErrors ;

import com.objy.db.app.storage.ClusterStrategy;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.iapp.IooObj ;
import com.objy.db.iapp.PooObj ;
import com.objy.db.iapp.PersistentEvents ;
import com.objy.db.iapp.ActivateInfo ;
import com.objy.db.iapp.DeactivateInfo ;
import com.objy.db.iapp.PreWriteInfo ;

import com.objy.pm.Access ;
import com.objy.pm.SessionPersistor ;


/**
 * Superclass for persistence-capable classes with the ability to respond to
 * persistent events, a public API that supports all persistence behavior,
 * and default implementation for Objectivity/DB operations.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>Classes that are derived from <tt>ooObj</tt> are called
 * <i>persistence-capable classes</i> because their
 * instances can be made persistent and saved with their
 * application-specific data in a federated database.
 * Two general kinds of objects can be saved persistently: basic
 * objects and containers.
 *
 * <ul type=disc>
 * <li>A <i>basic object</i> is the fundamental unit of
 * storage in an Objectivity/DB federated database.  You can subclass
 * <tt>ooObj</tt> to
 * define classes for the basic objects that you want to save persistently; see
 * <a href="../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>.</p>
 *
 * <li>A <i>container</i> is a physical grouping of basic objects. Within physical storage,
 * basic objects are clustered into containers.  Containers themselves
 * are stored in databases, which, in turn, are grouped into
 * federated databases.  The classes
 * <a href="storage/ooContObj.html"><tt>ooContObj</tt></a> and
 * <a href="storage/ooGCContObj.html"><tt>ooGCContObj</tt></a> represent
 * containers.
 * </ul>
 *
 * <p>You never create an instance of this
 * class; instead, you create instances of its subclasses.
 *
 * <p>When you instantiate a class derived from <tt>ooObj</tt>, the
 * newly created object is transient. If you want to save the object,
 * you must make it <i>persistent</i>.
 * Every persistent object belongs to the
 * <a href="Session.html">session</a> that is in a
 * transaction when the object is made persistent or retrieved.
 * Objectivity for Java does not allow a persistent
 * object to interact
 * with objects that belong to different sessions;  see
 * <A HREF="../../../../../guide/jgdSessions.html#Isolation">
 * Object Isolation</A>.
 *
 * <p>Most methods defined on <tt>ooObj</tt> can be called only after the object
 * has been made persistent and only while the session that owns the object is in a
 * transaction.  See
 * <a href="../../../../../guide/jgdPersistence.html#_top_">
 * Persistent Objects</a>
 * for details on how to make an object persistent and how to work with
 * persistent objects.
 *
 * <h2>Related Interfaces</h2>
 *
 * <p>Alternative ways to define a persistence-capable class are:
 * <ul type=disc>
 * <li>Implement the
 * <a href="../iapp/IooObj.html"><tt>IooObj</tt></a> interface,
 * which provides public methods to get and set an object's
 * persistor, to perform Objectivity/DB operations explicitly, and to handle
 * persistent events. You must implement all these methods.</p>
 *
 * <li>Implement the
 * <a href="../iapp/PersistentEvents.html"><tt>PersistentEvents</tt></a>
 * interface, which has public methods to get and set the persistor and
 * to handle persistent events; you need to implement those methods. If you
 * desire, you can also implement public or private methods to perform
 * Objectivity/DB operations explicitly.</p>
 *
 * <li>Implement the
 * <a href="../iapp/Persistent.html"><tt>Persistent</tt></a>
 * interface, which
 * has public methods to get and set the persistor; you
 * need to implement those methods. If you desire, you can also implement
 * public or private methods to perform Objectivity/DB operations
 * explicitly.</p>
 * </ul>
 *
 * <p>For additional information, see
 * <a href="../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Locking</b></td><td>
 * 	<a href="#lock(int)">lock(int)</a><br>
 * 	<a href="#lockNoProp(int)">lockNoProp(int)</a><br>
 *  <a href="#refreshOpenContainer(int)">refreshOpenContainer(int)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Fetching&nbsp;Persistent&nbsp;Data</b></td><td>
 * 	<a href="#fetch()">fetch()</a><br>
 * 	<a href="#fetch(java.lang.String)">fetch(String)</a><br>
 * 	<a href="#fetch(java.lang.String, boolean)">fetch(String, boolean)</a><br>
 * 	<a href="#fetch(int)">fetch(int)</a><br>
 * 	<a href="#fetch(java.lang.String, int)">fetch(String, int)</a><br>
 * 	<a href="#fetch(java.lang.String, int, boolean)">fetch(String, int, boolean)</a><br>
 * 	<a href="#markModified()">markModified()</a><br>
 * 	<a href="#clearModified()">clearModified()</a><br>
 * 	<a href="#markFetchRequired()">markFetchRequired()</a><br>
 * 	<a href="#isFetchRequired()">isFetchRequired()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Modifying</b></td><td>
 * 	<a href="#markModified()">markModified()</a><br>
 * 	<a href="#move(java.lang.Object)">move(Object)</A><br>
 * 	<a href="#delete()">delete()</A><br>
 * 	<a href="#deleteNoProp()">deleteNoProp()</A><br>
 * 	<a href="#clearModified()">clearModified()</a><br>
 * 	<a href="#write()">write()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td><td>
 * 	<a href="#getSession()">getSession()</a><br>
 * 	<a href="#getPersistor()">getPersistor()</a><br>
 * 	<a href="#getTypeNumber()">getTypeNumber()</A><br>
 *  <a href="#getOid()">getOid()</A><br>
 * 	<a href="#getOid(boolean)">getOid(boolean)</A><br>
 * 	<a href="#getReferenceOids()">getReferenceOids()</A><br>
 * 	<a href="#getReferenceData()">getReferenceData()</A>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td><td>
 * 	<a href="#isPersistent()">isPersistent()</a><br>
 * 	<a href="#isModified()">isModified()</a><br>
 * 	<a href="#isFetchRequired()">isFetchRequired()</a><br>
 * 	<a href="#isValid()">isValid()</a><br>
 *  <a href="#isContainerUpdated()">isContainerUpdated()</a><br>
 * 	<a href="#isDead()">isDead()</a>
 * 	</td></tr>
  * <tr><td VALIGN="top" WIDTH="1%"><B>Making Persistent</b></td><td>
 * 	<a href="#persist()">persist()</a><br>
 * 	<a href="#persist(com.objy.db.app.PlacementConditions)">persist(PlacementConditions)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With Scope-Named&nbsp;Objects</b></td><td>
 * 	<a href="#nameObj(java.lang.Object, java.lang.String)">nameObj(Object, String)</a><br>
 * 	<a href="#unnameObj(java.lang.Object)">unnameObj(Object)</a><br>
 * 	<a href="#lookupObj(java.lang.String)">lookupObj(String)</a><br>
 * 	<a href="#lookupObj(java.lang.String, int)">lookupObj(String, int)</a><br>
 * 	<a href="#lookupObjName(java.lang.Object)">lookupObjName(Object)</a><br>
 * 	<a href="#scopedObjects()">scopedObjects()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Handling&nbsp;Persistent&nbsp;Events</b></td><td>
 * 	<a href="#activate(com.objy.db.iapp.ActivateInfo)">activate(ActivateInfo)</a><br>
 * 	<a href="#deactivate(com.objy.db.iapp.DeactivateInfo)">deactivate(DeactivateInfo)</a><br>
 * 	<a href="#preWrite(com.objy.db.iapp.PreWriteInfo)">preWrite(PreWriteInfo)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Scope&nbsp;Objects</b></td><td>
 * 	<a href="#scopedBy()">scopedBy()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Indexes</b></td><td>
 * 	<a href="#updateIndexes()">updateIndexes()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Managing&nbsp;Default&nbsp;Association&nbsp;Arrays</b></td><td>
 * 	<a href="#size()">size()</a><br>
 * 	<a href="#trimToSize()">trimToSize()</a><br>
 * 	<a href="#ensureCapacity(int)">ensureCapacity(int)</a>
 * 	</td></tr>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Internal Persistent&nbsp;Objects</B></TD>
 * <TD>
 *   	<A HREF="#deleteReference(java.lang.Object)">deleteReference(Object)</A><BR>
 *   	<A HREF="#dropCachedReference(java.lang.Object)">dropCachedReference(Object)</A><br>
 *   	<a href="#getReferenceOids()">getReferenceOids()</A>
 * </TD></TR>
 *
 * <TR>
 * <TD><B>Static Utilities</B></TD><TD>
 * <a href="#getTypeNumberFor(java.lang.String)">getTypeNumberFor(String)</A><br>
 * <a href="#getQualifiedClassNameFor(long)">getQualifiedClassNameFor(long)</A><br>
 * <A HREF="#create_ooObj(com.objy.db.app.ooId)">create_ooObj(ooId)</A>
 * </TD></TR>
 * 
  * <tr><td VALIGN="top" WIDTH="1%"><b>Backward Compatibility</b></td><td>
 * 	<a href="#getContainer()">getContainer()</a><br>
 * 	<a href="#move(java.lang.Object)">move(Object)</A><br>
 *  <a href="#copy(java.lang.Object)">copy(Object)</a><br>
 *  <a href="#cluster(java.lang.Object)">cluster(Object)</a><br>
 * 	<a href="#cluster(java.lang.Object, com.objy.db.app.storage.ClusterStrategy)">cluster(Object, ClusterStrategy)</a>
 * 	</td></tr>
 *
 * </table>
 */
public class ooObj
    extends ooAbstractObj
    implements IooObj
{
    
    /** The persistor. */
    private transient PooObj persistor ;

	/**
	 * Reserved for internal use; you create instances of subclasses of <tt>ooObj</tt>, not
	 * instances of <tt>ooObj</tt> itself.
	 *
	 * <p>You should not use this constructor directly.</p>
	 */
    public ooObj()
        { Access.createRelationshipField(this) ; }

    /**
     * Instantiates a new oo obj.
     *
     * @param oid the oid
     */
    private ooObj(ooId oid) {
	Access.createRelationshipField(this) ;
	Access.createOoObj(this, oid) ;
    }

    /**
     * Constructs an instance of <tt>ooObj</tt> that represents a persistent object.
     *
     * <p>The newly created local representation, while representing an
     * existing persistent object, is treated by Objectivity/DB as an instance of <tt>ooObj</tt>.
     * Consequently, methods such as <tt>fetch</tt> and <tt>write</tt> will not work as expected,
	 * because they require access to class-specific persistent data.  This
     * constructor will generally not be useful outside an 
	 * <a href="../../as/app/package-summary.html">Active Schema</a>
     * application.
     *
     * <p>This constructor can only be used with object identifiers that
     * are assigned in the federated database to existing persistent
     * objects.</p>
     *
     * @param 	 oid	The object identifier of the existing persistent object 
	 * to be represented.
     */
    public static final ooObj create_ooObj(ooId oid) {
	return new ooObj(oid) ;
    }

	/**
	 * Finds the container in which this object is stored.
	 * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * <p>If this object was retrieved from a federated database, the return
	 * value is the
	 * container in which the object is stored.  If this object was created
	 * programmatically, the return value is the container in which
	 * this object will be stored when the transaction is committed.</p>
	 *
	 * @return The container in which this object is stored.</p>
	 *
     * @exception   com.objy.db.ObjectNotPersistentException    If the object is transient.
 	 */
    public ooContObj getContainer()
        { return persistor().getContainer() ; }

	/**
	 * Gets the session in which this object was made persistent or
	 * retrieved.</p>
	 *
	 * @return The session to which this object belongs.</p>
     * @exception   com.objy.db.ObjectNotPersistentException    If the object is transient.
  	 */
    public Session getSession()
        { return persistor().getSession() ; }

	/**
	 * Gets the object identifier of this object.</p>
	 *
	 * @return 	The object identifier of this persistent object.</p>
	 * @exception   com.objy.db.ObjectNotPersistentException    If the object is transient.
	 */
    public ooId getOid()
        { return persistor().getOid() ; }

	/**
	 * Gets the object identifier of this object, optionally looking up the type
     * number for the object's class.</p>
	 *
	 * <p>The <tt><i>getTypeNumber</i></tt> parameter controls whether this method
	 * gets just this object's location in the federated database or both its
     * location and the type number of its class.
     *
	 * <p><ul type=disc>
     * <li>Pass true as the parameter to get
     * a complete object identifier, which specifies both the object's
     * location and the type number of its class.
     * (This is equivalent to the default <a href="#getOid()">
     * <tt>getOid</tt></a> method.) The session must
     * obtain a read lock on this object to look up the type number. </p>
     *
     * <li>Pass false as the parameter to avoid locking this object.
     * In that case, this method does not look up the type number.
     * It returns a partial object identifier, which specifies the object's
     * location, but not the type number of its class.
     *</ul></p>
     *
	 * @param 	 getTypeNumber	True to get both this object's
     * location and the type number of its class; false to get just its
     * location.</p>
     *
	 * @return		The object identifier of this persistent object.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this
     * object is transient.
	 */
    public ooId getOid(boolean getTypeNumber)
        { return persistor().getOid(getTypeNumber) ; }
    
	/**
	 * Gets the Objectivity/DB type number of this object's class.</p>
	 * 
	 * <p>The type number uniquely identifies the class of this object in the federated database schema.</p>
	 *
	 * @return		The Objectivity/DB type number of the class of this object.</p>
	 */
    public long getTypeNumber()
    {
    	return persistor().getTypeNumber();
    }
    
	/**
	 * Gets the package-qualified class name corresponding to the specified Objectivity/DB type number.</p>
	 *
     * @param 	 typeNumber The Objectivity/DB type number.
	 * @return 	The package-qualified name of the class 
	 * corresponding to the specified Objectivity/DB type number.</p>
	 */
    public static String getQualifiedClassNameFor(long typeNumber)
    {
		return Access.getQualifiedClassNameFor(typeNumber);
    }

	/**
	 * Gets the Objectivity/DB type number corresponding to the specified class.</p>
	 * 
	 * <p>Every class in the federated database schema has a unique Objectivity/DB type number.</p>
	 *
	 * @param  qualifiedClassName The fully qualified class name.
	 * @return 	The Objectivity/DB type number corresponding to the specified class.</p>
	 */
    public static long getTypeNumberFor(String qualifiedClassName)
    {
    	return Access.getTypeNumberFor(qualifiedClassName);
    }

	/**
	 * Tests whether this object is
     * <a href="../../../../../guide/jgdPersistence.html#Dead Persistent Objects">
	 * dead</a>.
	 *
	 * @return	    True if this object is dead; otherwise, false.
	 */
    public boolean isDead()
        { return (persistor == null) ? false : persistor.isDead() ; }

	/**
	 * Tests whether this object has been marked as modified.
	 *
	 * <p>A persistent object that is marked as modified will be written to the
	 * federated database when the transaction is committed.</p>
	 * 
	 * <p>You should call this method while the session owning this object is in a transaction;
	 * otherwise, this method returns false, regardless of the actual state of the object.</p>
	 *
	 *
	 * @return	    True if this object is persistent and marked as modified;
	 * otherwise, false.
	 * False is the only return value while the session is not in a transaction.
	 * </p>
	 *
	 * @see     #markModified
	 */
    public boolean isModified()
        { return (persistor == null) ? false : notDeadPersistor().isModified() ; }

	/**
	 * Tests whether this object's persistent data needs to be fetched.
	 * 
     * <p>You can call this method if you want to explicitly test 
	 * whether this object contains its most recent persistent data. 
	 * In most situations, however, it is more efficient 
	 * to simply call the <a href="#fetch()"><tt>fetch</tt></a> method,
	 * which implicitly tests this object's persistent data
	 * and then transfers the current persistent data as necessary.</p>
	 * 
	 * <p>The <tt>isFetchRequired</tt> method checks whether any updates 
	 * have occurred in this object's container 
	 * since the last transaction in which this object's data was fetched. 
	 * If so, this method returns true, and a subsequent fetch operation 
	 * will actually transfer the object's data.
	 * If no objects in the container have been modified since the 
	 * last time this object's data was fetched, this method will
	 * return false.</p>
	 *
	 * <p>You should call this method while the session owning this object is in a transaction;
	 * otherwise, this method returns true, regardless of the actual state of the object.</p>
	 *
	 * @return		True if this object's persistent data must be fetched; false
	 * if this object already contains its most recent persistent data.
	 * True is the only return value while the session is not in a transaction.
	 */
    public boolean isFetchRequired()
        { return (persistor == null) ? false : notDeadPersistor().isFetchRequired() ; }

	/**
	 * Tests whether this object is persistent.</p>
	 *
	 * @return	    True if this object is persistent and false if it is
	 * transient.
	 */
     /* Used to return notDeadPersistor().isPersistent() but notDeadPersistor calls
     * ooObjPersistor.isDead and thrown exception if true.  ooObjPersistor.isPersistent
     * also ends up calling ooObjPersistor.isDead so we were calling the same thing twice.
     * 
     * Note the following (An object is persistent if it is neither dead nor transient;
     * however, transient objects do not have persistors, so this method
     * cannot be called for a transient object.)*/       
    public boolean isPersistent()
    {
        //if persistor == null it's transient 
        if(persistor == null)
            return false;        
        //notDeadPersistor will throw ObjectIsDeadException
        //so really all we are checking for in terms of returning
        //a bool value is if the persistor == null
        notDeadPersistor();
        return true;
     }

	/**
	 * Tests whether this object represents a valid persistent object.
	 *
	 * <p>An object is a valid persistent object if it is
	 * neither dead nor transient. When you retrieve a persistent object,
	 * the retrieved object is
	 * guaranteed to reference a valid persistent object.  However, if some
	 * other session then deletes the object from the federated
	 * database or moves it, the retrieved object becomes invalid.
	 *
	 * <p><b>Note:</b>  If, for some reason, the session cannot access this object for read, this
	 * method returns false.</p>
	 *
	 * @return		True if this object represents a valid persistent object;
	 * otherwise, false.
	 */
    public boolean isValid()
        { return (!testablePersistor()) ? false : notDeadPersistor().isValid() ; }

	/**
	 * Marks this object as needing to have its persistent data <a href="#fetch()">fetched</a>.
	 * 
	 * 
	 * <p>Applications typically do not need to call this method explicitly.
	 * 
	 * <p>If you modify an object and then want to force
	 * its definition to be reread from the federated database (overwriting your
	 * modifications), you should first call
	 * the <a href="#clearModified()"><tt>clearModified</tt></a> method, then call
	 * this method.</p>
	 *
	 * @see #clearModified
	 */
    public void markFetchRequired()
        { persistor().markFetchRequired() ; }

	/**
	 * Locks this object for write, fetches its persistent data if it is not
	 * already fetched, and marks it as modified.
	 *
	 * <p>If this object is not currently locked for write,
	 * this method locks it for write.  The
	 * write lock is not propagated along association links to destination objects.
	 * If this object does not contain its most recent persistent data, this method
	 * fetches that data.  There is no overhead for calling this method if
	 * this object is already locked for write and its data has already been fetched during the
	 * current transaction.
	 *
	 * <p>You must call this method whenever you make
     * changes to this object's attributes; typically, you call this
	 * method from every attribute-access method that sets the value of an
     * attribute of your
	 * subclass of <tt>ooObj</tt>.  Only objects that are marked as modified
	 * are written to the federated database when the transaction is committed.
	 *
 	 * <p> The modified mark is removed at the end of
     * the current transaction or by an explicit call to the
     * <a href="#write()"><tt>write</tt></a> method.
	 *
	 * <p>This method does nothing if this object is transient.</p>
     *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this
     * object is transient.</p>
     *
	 * @exception   com.objy.db.ObjyRuntimeException        If this object is
	 * already marked modified.</p>
	 * 
	 * @see     #isModified
	 */
    public void markModified() // no-op if not persistent
        { if (persistor != null) notDeadPersistor().markModified() ; }

    /**
     * Removes the modified mark from this object.
     * 
     * <p>The modified mark indicates that this object needs to be written to
     * the federated database.  You can call this method if you want to prevent your
     * changes to this object from being written to the federated database.
     * 
     * <p>If you want to prevent a newly persistent object from being written to the
     * federated database, you should either abort the transaction, or call the object's
     * <a href="#delete()"><tt>delete</tt></a> method.</p>
     * 
     * @exception   com.objy.db.ObjyRuntimeException    If this object has
     * never been written to the federated database
	 * since it was made persistent.
     *
     */
    public void clearModified() // no-op if not persistent
        { if (persistor != null) notDeadPersistor().clearModified() ; }

	/**
	 * Locks this object for read and fetches its persistent data.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If this object is not currently locked,
	 * this method locks it for read
	 * before fetching its data. 
	 * This method fetches all the persistent data and marks this object as
     * not needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current,
	 * this method has no effect, other than locking the object as appropriate. 
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.
	 * 
	 * <p>If this object has reference attributes,
	 * this method also locks every destination object for read.
	 * However, the data for these objects is not fetched.
	 * 
	 * <p>This method does nothing if this object is transient.</p>
	 * 
	 */
    public void fetch()  // no-op if not persistent
        { if (persistor != null) notDeadPersistor().fetch() ; }

	/**
	 * Locks this object for read and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the named reference attributes.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked,
	 * this method locks it for read
	 * before fetching its data.
	 * This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current,
	 * this method has no effect, other than locking the object as appropriate.
	 * 
	 * 
	 * <p>The destination object of each fetched reference attribute
	 * is locked for read, but the data of the destination object is not fetched.
	 * 
	 * <p>This method does nothing if this object is transient.</p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names. Any reference attributes named in the string are
     * fetched; other reference attributes are not fetched.  
     * If you specify null, no reference attributes are fetched. If you specify 
     * an empty string, all reference attributes are fetched.
	 */
    public void fetch(String references)
        { if (persistor != null) notDeadPersistor().fetch(references) ; }

	/**
	 * Locks this object for read and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the reference attributes
	 * specified by name or regular expression.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked,
	 * this method locks it for read
	 * before fetching its data. This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current,
	 * this method has no effect, other than locking the object as appropriate.
	 * 
	 * <p>The destination object of each fetched reference attribute
	 * is locked for read, but the data of the destination object is not fetched.
	 * 
	 * <p>This method does nothing if this object is transient.</p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names or regular expressions (as indicated by the
     * <tt><i>regexp</i></tt> parameter). Any reference attributes named in
     * the string (or whose names match a regular expression in the string)
     * are fetched; other reference attributes are not fetched.  
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
	 *
	 * @param 	 regexp  True if the
     * <tt><i>references</i></tt> string may contain regular expressions;
     * false if it must contain attribute names.
	 */
    public void fetch(String references, boolean regexp)
        { if (persistor != null) notDeadPersistor().fetch(references, regexp) ; }

	/**
	 * Fetches this object's persistent data after obtaining the specified lock.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching this object's data.
	 * This method fetches all the persistent data and marks this object as
	 * not needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current,
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.
	 * 
	 * <p>If this object has reference attributes,
	 * this method also locks every destination object for read.
	 * However, the data for these objects is not fetched.
	 * 
	 * <p>This method does nothing if this object is transient.</p>
	 *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 */
    public void fetch(int mode) // no-op if not persistent
        { if (persistor != null) notDeadPersistor().fetch(mode) ; }

	/**
	 * Obtains the specified lock on this object and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the named reference attributes.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching this object's data. This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current,
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.
	 * 
	 * <p>The destination object of each fetched reference attribute
	 * is locked for read, but the data of the destination object is not fetched.
	 * 
	 * <p>This method does nothing if this object is transient.</p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names. Any reference attributes named in the string are
     * fetched; other reference attributes are not fetched.  
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
     *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 */
    public void fetch(String references, int mode) // no-op if not persistent
        { if (persistor != null) notDeadPersistor().fetch(references, mode) ; }

	/**
	 * Obtains the specified lock on this object and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the reference attributes
	 * specified by name or regular expression.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching this object's data. This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current,
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.
	 * 
	 * <p>The destination object of each fetched reference attribute
	 * is locked for read, but the data of the destination object is not fetched.
	 * 
	 * <p>This method does nothing if this object is transient.</p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names or regular expressions (as indicated by the
     * <tt><i>regexp</i></tt> parameter). Any reference attributes named in
     * the string (or whose names match a regular expression in the string)
     * are fetched; other reference attributes are not fetched. 
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
     *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @param 	 regexp  True if the
     * <tt><i>references</i></tt> string may contain regular expressions;
     * false if it must contain attribute names.
	 */
    public void fetch(String references, int mode, boolean regexp) // no-op if not persistent
        { if (persistor != null) notDeadPersistor().fetch(references, mode, regexp) ; }

	/**
	 * Transfers this object's data to the session's Objectivity/DB cache.
	 * 
	 * <p>This method writes the object's data to its session's
	 * Objectivity/DB cache.  Each session has its own Objectivity/DB cache,
	 * so the written data will not be visible to
	 * other sessions or processes. The changes will be transferred to the
	 * federated database when you commit or checkpoint the current
	 * transaction.  If the transaction is aborted, the changes are never
	 * transferred to the federated database.
	 * 
	 * <p>Only this object's data is written to the cache.  If this object
	 * references destination objects, those destination objects are
	 * <i>not</i> written.
	 * 
	 * <p>This method removes any modified mark from this object. If you make
	 * additional changes after calling this method, you must call
	 * <a href="#markModified()"><tt>markModified</tt></a>
	 * or <tt>write</tt> again; otherwise, your changes will be lost.
	 * 
	 * <p>You typically do not call this method.  Instead, you call either the
	 * session's <a href="Session.html#commit()"><tt>commit</tt></a> method or its
	 * <a href="Session.html#checkpoint()"><tt>checkpoint</tt></a>
	 * method, which writes all changes to the federated database.  The
	 * <tt>commit</tt> and <tt>checkpoint</tt> methods make changes accessible
	 * to <i>all</i> other clients, not just to other transactions of your process.</p>
	 *
     * @exception   ObjectNotPersistentException    If this object is transient.
	 *
	 */
    public void write()
        { persistor().write() ; }

	/**
	 * Explicitly locks this object and propagates the
	 * lock to related destination objects.
	 * 
	 * <p>This method locks this object for the specified access and
	 * propagates the lock
	 * to any destination objects linked to
	 * this object through relationships for which lock
	 * propagation is enabled.
	 * 
	 * <p>Locking a basic object implicitly locks the object's container. Locking
	 * a container implicitly  locks all basic objects in the container.</p>
	 *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
     * <p>The lock mode is limited by the open mode of this object's
     * session</a>.
     * If you try to set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>,
	 * this method throws a runtime exception.
	 *
	 * <p>If this object is already locked, you can call this method to upgrade a
	 * read lock to a write lock, but not to downgrade a write lock to a read
	 * lock.</p>
     *
     * @exception   ObjectNotPersistentException    If this object is
     * transient.</P>
     *
     * @exception   com.objy.db.ObjyRuntimeException    If you try to set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>.</p>
	 *
	 * @see      #lockNoProp
	 */
    public void lock(int mode)
        { persistor().lock(mode) ; }

	/**
	 * Explicitly locks this object for the specified access.
	 * 
	 * <p>Unlike the <a href="#lock(int)"><tt>lock</tt></a>
	 * method, this method does not propagate the lock to related destination objects.
	 * 
	 * <p>Locking a basic object implicitly locks the object's container. Locking
	 * a container implicitly  locks all basic objects in the container.</p>
	 *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
     * <p>The lock mode is limited by the open mode of this object's
     * session</a>.
     * If you try to set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>,
	 * this method throws a runtime exception.</p>
     *
     * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 *
	 * @see #lock
	 *
	 */
    public void lockNoProp(int mode)
        { persistor().lockNoProp(mode) ; }

	/**
	 * Deletes this object from the federated database and propagates the deletion
	 * operation to related destination objects.
	 * 
	 * <p>This method propagates the deletion operation to any destination objects
	 * linked to this object through relationships for which deletion
	 * propagation is enabled.
	 * 
	 * <p>Until the current transaction is committed, this object
	 * continues to exist in your application's memory, but it is
	 * marked dead.  However, any related destination objects are not
	 * marked dead in memory, and should not be modified.
	 * 
	 * <p>Each deleted object is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
	 * write a persistent object that references a dead object.</p>
     *
	 * @exception   ObjectNotPersistentException    If this object is
     * transient. </P>
     *
	 * @exception   ObjectIsDeadException   If you attempt to perform this operation on a
	 * dead object.</p>
	 *
     * @see     #deleteNoProp
     * @see     #isDead
	 */
    public void delete()
        { persistor().delete() ; }

	/**
	 * Deletes this object from the federated database.
	 * 
	 * <p>Until the current transaction is committed, this object continues to
	 * exist in your application's memory, but it is marked dead.
	 * 
	 * <p>The deleted object is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
	 * write a persistent object that references a dead object.
	 * 
	 * <p>Unlike the <a href="#delete()"><tt>delete</tt></a>
	 * method, this method does not propagate the deletion operation
	 * to related destination objects.</p>
	 *
	 * @exception   ObjectNotPersistentException    If this object is
     * transient.</P>
     *
	 * @exception   ObjectIsDeadException   If you attempt to perform this operation on
	 * a dead object.</p>
	 *
     * @see     #isDead
     * @see     #delete
	 */
    public void deleteNoProp()
        { persistor().deleteNoProp() ; }

	/**
	 * Makes the specified object persistent, clustering it with this
	 * object, subject to the session's clustering strategy.</p>
	 *
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.
	 * The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The session's
	 * clustering strategy determines where to locate the object relative
	 * to this object. See
     * <a href="../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
     *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this object's database, adding it to that database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
	 * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 * 
	 *
	 * @see     <a href="./storage/ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>ooDBObj.addContainer(ooContObj, int, String, long, long)</tt></a>
	 */
    public void cluster(Object object)
        { persistor().cluster(object, getPersistor().getSession().getClusterStrategy()); }

	/**
	 * Makes the specified object persistent, clustering it with this
	 * object, subject to the specified clustering strategy.</p>
	 * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.
	 * The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The specified
	 * clustering strategy determines where to locate the object relative
	 * to this object. See
     * <a href="../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
     *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this object's database, adding it to that database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
     * @param 	 strategy    Clustering strategy to determine 
     * the location of a basic object.
     * This parameter is ignored if
     * <tt><i>object</i></tt> is a container.</p>
     *
	 * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 *
	 * @see     <a href="./storage/ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>ooDBObj.addContainer(ooContObj, int, String, long, long)</tt></a>
	 */
    public void cluster(Object object, ClusterStrategy strategy)
        { persistor().cluster(object, strategy); }
    
    
    /* (non-Javadoc)
     * @see com.objy.db.iapp.IooObj#persist()
     */
    @Override
    public void persist()
    {
	SessionPersistor sp = (SessionPersistor)Session.getCurrent().persistor();
	sp.persist(this);
    }         
    
	/* (non-Javadoc)
	 * @see com.objy.db.iapp.IooObj#persist(com.objy.db.app.PlacementConditions)
	 */
	@Override
	public void persist(PlacementConditions placementConditions) {
		boolean hasId = (placementConditions.relatedObjectId !=null);
		boolean hasType = (placementConditions.relatedObjectTypeNumber !=0);
		boolean hasPurpose = (placementConditions.getPurpose()!=null);
		boolean hasRelatedObject = (placementConditions.relatedObject != null);
		
		SessionPersistor sp = (SessionPersistor)Session.getCurrent().persistor();
		if(hasRelatedObject)
		{
			sp.persist(this, placementConditions.relatedObject, 
					placementConditions.getPurpose());
		}
		else if(hasId && hasType)
		{
			sp.persist(this, (com.objy.pm.ooId)placementConditions.getRelatedObjectId(), 
					placementConditions.getRelatedObjectTypeNumber(), 
					placementConditions.getPurpose());	
		}
		else if(hasPurpose)
		{
			sp.persist(this, placementConditions.getPurpose());
		}
		else
		{
			persist();
		}
	}

	/**
	 * <a href="../../../../../guide/jgdPersistence.html#Copying a Basic Object">
	 * Copies</a> this basic object, clustering
	 * the new object with the specified object.
	 * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
	 * <p>You should call this method for persistent objects only.  If this
	 * object is not locked, this method locks its container for read-only
	 * access.</p>
	 *
	 * @param 	 near The object with which to cluster the
	 * new copy.  The <tt><i>near</i></tt> object must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>near</i></tt> is a database:<dd>The new copy is stored in
	 * the default container of that database.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent container:<dd>The new copy is
	 * stored in that container.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent basic object:<dd>The new copy is
	 * stored in the same container as <tt><i>near</i></tt>.
	 * The object is put on the same logical page as <tt><i>near</i></tt>, if the page has enough space. 
	 * Otherwise, the object is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @return		The new copy of this object.
	 * The returned object is persistent. If the transaction is aborted, the new
     * object becomes a dead object and is not stored persistently.
	 */
    public Object copy(Object near)
        { return persistor().copy(near) ; }

	/**
	 * Moves this basic object, clustering it with the specified object.
	 * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * <p>You should call this method for persistent basic objects only.  If this
	 * object is not locked, this method locks its container and the container
	 * to which it will be moved, for read/write access.
	 * 
	 * <p><b>Warning: </b>This method changes the object identifier of this object.
	 * When you move an object you should, within the same transaction, update references to the object within all relevant
	 * relationships, collections (including root-name maps), scope names, and
	 * indexes. In the case of a reference within a name map or root name,
	 * corruption of the federated database could result if the reference is
	 * not updated. See
	 * <a href="../../../../../guide/jgdPersistence.html#Moving a Basic Object">
	 * Moving a Basic Object</a>
	 * for additional information.</p>
	 *
	 * @param 	 near The object with which to cluster this
	 * object; must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>near</i></tt> is a database:<dd>This object is moved to
	 * the default container of that database.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent container:<dd>This object is
	 * moved to that container.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent basic object:<dd>This object is
	 * moved to the container in which <tt><i>near</i></tt> is stored.
	 * The object is put on the same logical page as <tt><i>near</i></tt>, if the page has enough space. 
	 * Otherwise, the object is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl>
	 */
    public void move(Object near)
        { persistor().move(near) ; }

	/**
	 * Names the specified scope object in the scope of this object.
	 * 
	 * <p>If the specified object is transient, this method makes it persistent.
	 * If the specified object is already persistent, this method locks its
	 * container for write.
	 * 
	 * <p>This method obtains a write lock on the name map in which this
	 * object stores its scope names.</p>
	 *
	 * @param 	 object	The object to be named.</p>
	 *
	 * @param 	 scopeName	The name for the specified
	 * object in the scope of this object.
     * This name can be any valid Java string and must be unique
	 * within this object's name scope.  </p>
     *
     * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
     *
     * @see     #lookupObj(String)
     * @see     #unnameObj(Object)
	 */
    public void nameObj(Object object, String scopeName)
        { persistor().nameObj(object, scopeName) ; }

	/**
	 * Removes the specified object's name from this object's
	 * name scope.
	 * 
	 * <p>This method locks both this object and  <tt><i>object</i></tt> for
	 * write.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * removed.</p>
     *
     * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 *
	 * @exception   com.objy.db.ObjyRuntimeException    If
	 * <tt><i>object</i></tt> has no name in this object's name scope.</p>
	 *
     * @see     #lookupObj(String)
     * @see     #nameObj(Object, String)
	 */
    public void unnameObj(Object object)
        { persistor().unnameObj(object) ; }

	/**
	 * Finds the object with the specified scope name in the scope defined
	 * by this object.</p>
	 *
	 * @param 	 scopeName	The scope name to look
     * up.</p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this object. The returned object is locked for read.</p>
     *
	 * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 *
	 * @exception   com.objy.db.ObjyRuntimeException    If there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this
     * object.</p>
	 *
	 * @see     #lookupObjName(Object)
	 * @see     #nameObj(Object, String)
	 */
    public Object lookupObj(String scopeName)
        { return persistor().lookupObj(scopeName) ; }

	/**
	 * Finds the object with the specified scope name in the scope defined
	 * by this object, locking the
	 * found object as specified.</p>
	 *
	 * @param 	 scopeName	The scope name to look up.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this object; the returned object
	 * is locked as specified by <tt><i>lockMode</i></tt>.</p>
     *
	 * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 *
	 * @exception   com.objy.db.ObjyRuntimeException    If there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this
     * object.</p>
	 *
	 * @see     #lookupObjName(Object)
	 * @see     #nameObj(Object, String)
	 */
    public Object lookupObj(String scopeName, int lockMode)
        { return persistor().lookupObj(scopeName, lockMode) ; }

	/**
	 * Looks up the name of the specified object in the scope defined
	 * by this persistent object.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * looked up.</p>
     *
	 * @return		The scope name of the specified object in this object's
	 * name scope.</p>
	 *
	 * @exception   ObjectNotPersistentException    If this object
	 * is transient.</p>
	 *
	 * @exception   com.objy.db.ObjyRuntimeException    If <tt><i>object</i></tt> has
	 * no name in this object's name scope.</p>
	 *
	 * @see     #lookupObj(String)
	 */
    public String lookupObjName(Object object)
        { return persistor().lookupObjName(object) ; }

	/**
	 * Initializes an object iterator to find all objects named in the
	 * name scope of this object.</p>
	 *
	 * @return 	An object iterator that finds the named objects.</p>
	 * 
  	 * @exception   ObjectNotPersistentException   If this object
	 * is transient.
	 *
	 */
    public Iterator scopedObjects() // Objects that I provide a scope for
        { return persistor().scopedObjects() ; }

	/**
	 * Initializes an object iterator to find all scope objects that define
	 * scope names for this object.</p>
	 *
	 * @return 	An object iterator that finds the scope objects.</p>
	 * 
	 * @exception   ObjectNotPersistentException    If this object
	 * is transient.
	 *
	 */
    public Iterator scopedBy() // Objects that provide a scope for me
        { return persistor().scopedBy() ; }

	/**
	 * Removes this persistent object's reference to the specified internal
	 * persistent object and deletes that object.</p>
	 * 
	 * <p>
	 * <b>Note:</b> You should delete an internal persistent object
	 * <i>only</i>
	 * if you also plan to delete the persistent object that referenced it.
	 * </p>
	 *
	 * @param 	 object	The
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> to be deleted.</p>
	 *
	 * @exception       com.objy.db.ObjyRuntimeException    If
	 * <tt><i>object</i></tt> is not referenced by this persistent object
	 * or is not an array, a string element of an
	 * array, or a date or time type that is stored in the
	 * federated database as an internal persistent object
	 * (<tt>java.util.Date</tt>, <tt>java.sql.Date</tt>, or
     * <tt>java.sql.Time</tt>,
	 * <tt>java.sql.Timestamp</tt>).
	 */
    public void deleteReference(Object object) {
        persistor().deleteReference(object) ;
    }

	/**
	 * Drops the specified internal persistent object from the
	 * internal session cache.</p>
	 * 
	 * <p>The object to be released is an
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> that is referenced by some persistent
	 * object.
	 * 
	 * <p><b>Note: </b> You should call this method only if the memory
	 * consumed by Objectivity for Java prevents your application from
	 * running to completion. In that situation, you
	 * should call this method only when the persistent object
	 * that references <tt><i>object</i></tt> has
	 * itself been released and is waiting to be garbage collected.</p>
	 *
	 * @param 	 object	The
	 * internal persistent object to be deleted; must be an instance of
	 * <tt>java.util.Date</tt>, <tt>java.sql.Date</tt>,
     * <tt>java.sql.Time</tt>, or <tt>java.sql.Timestamp</tt>.
	 *
	 */
    public void dropCachedReference(Object object) {
        persistor().dropCachedReference(object) ;
    }

    /**
     * Updates the indexes that include this object.
     * 
     * <p>If a session's index mode is <tt>EXPLICIT_UPDATE</tt>,
     * indexes are not updated automatically to reflect changes to indexed
     * attributes.
     * You must call this method after creating an object and initializing
     * its indexed attributes, and after modifying the indexed attributes of an
     * existing object.
     * 
     * <p>When this method is called, the object's <a href="#write()"><tt>write</tt></a>
     * is implicitly called first.</p>
     *
     * @exception   ObjectNotPersistentException    If this object
     * is transient.
     *
     * @see     #markModified
     * @see     #write
     */
    public void updateIndexes()
        { persistor().updateIndexes() ; }

    /**
     * Gets the object providing persistence behavior for this object.</p>
     *
     * @return This object's persistor.
     *
     */
    public synchronized PooObj getPersistor()
        { return persistor ; }

	/**
	 * Reserved for internal use; you should not call this method.</p>
	 *
	 * @param   persistor   Ignore
	 */
    public synchronized void setPersistor(PooObj persistor) // Not for general use
        { this.persistor = persistor ; }

	/**
	 * Default implementation for handling an activate event.
	 * 
	 * <p>Objectivity for Java calls this method <i>after</i> this object's
	 * data is fetched from the federated database.  It is called after
	 * execution of this object's
	 * <tt>fetch</tt> or <tt>markModified</tt></a> method if the object has
	 * not yet been fetched.
	 * 
	 * <p>If <tt><i>info</i></tt> indicates that errors occurred
	 * during the fetch operation, this method throws a
	 * <a href="../FetchCompletedWithErrors.html">
	 * <tt>FetchCompletedWithErrors</tt></a>
	 * exception.
	 * 
	 * <p>You should not call this method directly; however, you may override
	 * its behavior. For example, your implementation might initialize
	 * the persistent object's transient fields or perform
	 * application-specific registration of the object.</p>
	 *
	 * @param 	 info    An
 	 * <a href="../iapp/ActivateInfo.html">activate information object</a>
	 * containing information about any exceptions that occurred
	 * during the fetch operation.
     *
	 */
    public void activate(ActivateInfo info) {
        if (info.hasFetchErrors())
            throw new FetchCompletedWithErrors(
                "Fetch completed but errors occurred", this, info.getFetchErrors()) ;
    }

	/**
	 * Default implementation for handling a deactivate event.
	 * 
	 * <p>Objectivity for Java calls this method <i>after</i> the current
	 * transaction of this object's session is committed or
	 * aborted.
	 * 
	 * <p>The default implementation is empty and will never be called.
	 * 
	 * <p>You should not call this
	 * method directly; however, you may override
	 * its behavior. In a work-flow application, for example, your
	 * implementation might check the reason for deactivation to see whether
	 * changes were accepted (commit) or not (abort).  Overriding this
	 * method will cause the object to be removed from eligibility for
	 * garbage collection.
	 * 
	 * <p>If an error occurs during the execution of this method, it does not
	 * affect the state of commit or abort operations.  The Objectivity/DB operation
	 * completes normally.
	 * <p>If an exception is thrown during an abort, there are two special
	 * cases to consider:
	 * <ul type=disc>
	 * <li>If this object was made persistent during this transaction, it
	 * reverts to being transient.
	 * <li>If this object was created by a copy operation, it is made a dead
	 * object.
	 * </ul>
	 * 
	 * <p>In either case, this object's <tt>deactivate</tt> method is executed.
	 * <p>If this object has been deleted, it has been removed from its
	 * session, so this method is not called when the
	 * transaction commits or aborts.</p>
	 *
	 * @param 	 info    A
 	 * <a href="../iapp/DeactivateInfo.html">deactivate information object</a>
     * specifying the reason why deactivation occurred.
	 *
	 */
    public void deactivate(DeactivateInfo info)
        { }

	/**
	 * Default implementation for handling a pre-write event.
	 * 
	 * <p>Objectivity for Java calls this method <i>before</i> this object is
	 * written to the session's Objectivity/DB cache.   See
	 * <a href="../../../../../guide/jgdCache.html#Updating the Objectivity/DB Cache">
	 * Updating the Objectivity/DB Cache</a>.
	 * 
	 * <p>The default implementation is empty.
	 * 
	 * <p>If an error occurs during the execution of this method, the encompassing
	 * operation does not complete.  The state of this object is not changed;
	 * that is, it is still marked as modified.
	 * 
	 * <p>You should not call this
	 * method directly; however, you may override
	 * its behavior. For example, your implementation might encrypt some
	 * attributess and make other attributes null.  Your
	 * implementation could throw an exception to prevent this object from
	 * being written (and terminate the encompassing operation with that
	 * exception).</p>
	 *
     * @param 	 info    A
 	 * <a href="../iapp/PreWriteInfo.html">pre-write information object</a>
     * specifying the reason why the object is being written.
	 */
    public void preWrite(PreWriteInfo info)
        { }

	/**
	 * Resizes the default association array for this object to be
	 * able to hold the indicated number of relationships.</p>
	 *
	 * @param minCapacity the number of relationships 
	 */
    public void ensureCapacity(int minCapacity)
        { persistor().ensureCapacity(minCapacity) ; }

	/**
	 * Returns the number of relationships for this object currently
	 * in the default association array.</p>
	 *
	 * @return	The size of the default association array for this object.</p>
	 */
    public int size()
        { return persistor().size() ; }

	/**
	 * Resizes the default association array for this object to the 
	 * defined number of relationships.</p>
	 */
    public void trimToSize()
        { persistor().trimToSize() ; }

    /**
     * Gets the object identifiers of 
     * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
     * internal persistent objects</a> referenced by this object.</p>
     *
     * @return		An array of object identifiers of
     * internal persistent objects referenced by this object.</p>
     */
    public ooId[] getReferenceOids()
	{ return persistor().getReferenceOids() ; }

	/**
	 * Gets the information used to create a garbage-collectible reference object for
	 * this object.</p>
	 *
	 * This method must be overridden in a persistence-capable class that defines
	 * one or more garbage-collectible reference fields,
	 * where each such field holds a weak or soft reference to some other persistent object.</p>
	 * 
	 * 
	 * Your overriding definition of this method 
	 * must create and return a <a href="ooReferenceData.html">reference-data object</a>
     * appropriate for each of the garbage-collectible reference fields in the class.
     * When the data of a persistent object of the class 
	 * is  fetched, the fetch operation checks each of the object's 
	 * garbage-collectible reference fields to determine whether the field 
	 * currently holds a reference object. 
	 * If it does not (for example, because its referent has been garbage collected), 
	 * the fetch operation calls this method
     * to obtain the reference data needed for
     * constructing an appropriate garbage-collectible reference object for the field.</p>
	 * 
	 * Although you can define this method to return different reference data
	 * for different fields, you normally use either all soft references or all weak references
	 * within the same persistent object.
	 * Furthermore, if a reference queue is to be used, all reference objects 
	 * in the same persistent object normally use the same one.</p>
	 *
	 * @return	The information used to create a garbage-collectible reference object
	 * for this object.</p>
	 */
    public ooReferenceData getReferenceData()
        { return null ; }

    /**
     * Reopens this object's container, refreshing the session's view of 
     * the container in the MROW transaction reading it. 
     * 
     * <p>You should call this method only during an MROW session and
     * only if you locked this object's container for read, and another session
     * subsequently updated some object in the container.  You can
     * call the <a href="#isContainerUpdated()"><tt>isContainerUpdated</tt></a> method to
     * check whether another session has made updates in this container since you
     * locked it.
     *
     * <p>Note that this method does not automatically refetch any existing
     * fetched object in the container.</p>
     *
     * <p> This method throws an exception if the container being refreshed
     * no longer exists. </p>
     * 
     * @param mode The intended level of access to the reopened container;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock on the container.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock on the container.
     * </dl></dl></p>
     */
    @Override
    public void refreshOpenContainer(int mode)
    { persistor().refreshOpenContainer(mode) ; }
    
    /**
     * Tests whether this object's container has already been 
     * updated and committed or checkpointed by another session.
     * 
     * <p>You should call this method only during an MROW session in
     * which you locked this object (and its container) for read. If this method
     * returns true, your application's copies of the container and its
     * objects are out of date, because an MROW update session has concurrently accessed an object in the same container and then committed.  
     * You can call the
     * <a href="#refreshOpenContainer(int)"><tt>refreshOpenContainer</tt></a> method to
     * update the session's copy of this container and its objects.</p>
     * 
     * @return      True if the container has been updated and committed by another 
     * session since being locked for read by the current MROW session; 
     * otherwise, false. </p>
     */
    @Override
    public boolean isContainerUpdated()
    { return persistor().isContainerUpdated() ; }
    
    public boolean equals(Object obj)
    {
        //other object is null or not an instance of ooObj can't be equal
        if(obj == null || !(obj instanceof ooObj))
            return false;
        
        ooObj otherObj = (ooObj)obj;
        //one of the objects is transient so can't compare oids
        //use base class equals
        if(otherObj.getPersistor() == null || getPersistor() == null )
            return super.equals(obj);
        //if oids (via connectionId) are equal...
        if(otherObj.getPersistor().connectionId() == getPersistor().connectionId())
            return true;
        
        return false;        
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 *
	 */
	protected synchronized PooObj persistor() {
        if (persistor == null)
            throw new ObjectNotPersistentException("Attempted persistent operation on transient object") ;

        if (persistor.isDead())
            throw new ObjectIsDeadException("Attempted persistent operation on dead object") ;

        return persistor ;
    }


	private synchronized PooObj notDeadPersistor() {
        if (persistor.isDead())
            throw new ObjectIsDeadException("Attempted persistent operation on dead object") ;

        return persistor ;
    }

	/**
	 * Reserved for internal use; you should not call this method.
	 */
	protected synchronized boolean testablePersistor() {
	return (persistor == null || persistor.isDead()) ? false : true ;
    }
}


