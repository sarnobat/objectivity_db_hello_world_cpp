/*
 * @(#)ooTreeSetX.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.SortedSet;

import com.objy.db.ObjectNotPersistentException;
import com.objy.db.iapp.Persistent;
import com.objy.db.iapp.PooObj;
import com.objy.pm.ooCollectionIterator;
import com.objy.pm.ooTreeBasedCollectionsPersistor;
import com.objy.pm.ooTreeSetXPersistor;

/**
 * Persistence-capable class for sorted sets of persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Sorted Sets</h2>
 *
 * <p>A <i>sorted set</i> is a scalable ordered collection of persistent 
 * objects with no duplicate elements.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Properties of Scalable Ordered Collections">
 * Properties of Scalable Ordered Collections</a>.
 *
 * <p><h2>Working With a Sorted Set</h2>
 *
 * <P>A sorted set is transient when it is created; you can make it
 * persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created a sorted set, you can:
 * <ul type=disc>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a Set">
 * Building a Set</a></p>
 *
 * <li>Look up particular elements in the sorted set as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Sets">
 * Individual Lookup in Sets</a></p> 
 *
 * <li>Iterate over the sorted set as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Elements of a List or Set">
 * Finding the Elements of a List or Set</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make a sorted set persistent before you call
 * any methods defined by the <tt>ooTreeSetX</tt>, <tt>ooTreeBasedCollection</tt>, or
 * <tt>ooCollection</tt>
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.</p>
 * 
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of persistent objects:
 * <ul type=disc>
 * <li><a href="ooHashSetX.html"><tt>ooHashSetX</tt></a> represents
 * an <i>unordered</i> collection of persistent objects with no duplicate 
 * elements. </p>
 *
 * <li><a href="ooTreeListX.html"><tt>ooTreeListX</tt></a> represents an
 * <i>ordered</i> collection of persistent objects that <i>can contain 
 * duplicate elements</i>.</p> 
 * </ul></p>
 * 
 * The related class <a href="ooCompare.html"><tt>ooCompare</tt></a> is the abstract base class for custom comparators for
 * sorted sets.</p>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr> <td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 *      <td>
 *      <a href="#ooTreeSetX()">ooTreeSetX()</a><br>
 *      <a href="#ooTreeSetX(int, boolean)">ooTreeSetX(int, boolean)</a><br>
 *      <a href="#ooTreeSetX(com.objy.db.util.ooCompare)">ooTreeSetX(ooCompare)</a><br>
 *      <a href="#ooTreeSetX(com.objy.db.util.ooCompare, int, boolean)">ooTreeSetX(ooCompare, int, boolean)</a><br>
 *      <a href="#ooTreeSetX(com.objy.db.util.ooCompare, int, boolean, boolean)">ooTreeSetX(ooCompare, int, boolean, boolean)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#add(java.lang.Object)">add(Object)</a><br>
 *     <a href="#add(java.lang.Object, int[])">add(Object, int[])</a><br>
 *     <a href="#addAll(java.util.Collection)">addAll(Collection)</a><br>
 *     <a href="#remove(java.lang.Object)">remove(Object)</a><br>
 *     <a href="#remove(java.lang.Object, int[])">remove(Object, int[])</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#ooRemove(java.lang.Object, int[])">ooRemove(Object, int[])</a><br>
 *     <a href="#removeAll(java.util.Collection)">removeAll(Collection)</a><br>
 *     <a href="#retainAll(java.util.Collection)">retainAll(Collection)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#get(java.lang.Object)">get(Object)</a><br>
 *     <a href="#iterator()">iterator()</a><br>
 *      <a href="#toArray()">toArray()</a><br>
 *      <a href="#toArray(java.lang.Object[])">toArray(Object[])</a>
 *      </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 *     <td>
 *     <a href="#contains(java.lang.Object, int[])">contains(Object, int[])</a><br>
 *     <a href="#containsAll(java.util.Collection)">containsAll(Collection)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting Views of the Object Set</b></td>
 *     <td>
 *     <a href="#headSet(java.lang.Object)">headSet(Object)</a><br>
 *     <a href="#subSet(java.lang.Object, java.lang.Object)">subSet(Object, Object)</a><br>
 *     <a href="#tailSet(java.lang.Object)">tailSet(Object)</a>
 *  </td></tr>
 * </table>
 *
 */
final public class ooTreeSetX extends ooTreeBasedCollection implements SortedSet
{
    /**
     * Reserved for internal use.
     */
    public transient int _numberOfElements;
    /**
     * Reserved for internal use.
     */
    public transient boolean _useShortRefs;

    /**
     * Reserved for internal use.
     */
    public transient boolean _comparisonArrayIsCompleteKey;

	/**
	 * Constructs an empty sorted set with a default comparator 
	 * and with default storage characteristics. </p>
	 */
	public ooTreeSetX()
    {
        _numberOfElements = 5;
        _useShortRefs = false;
		_comparisonArrayIsCompleteKey = false;
    }

	/**
	 * Constructs an empty sorted set with a default comparator, with the specified storage characteristics. </p>
	 *
	 * @param 	 numElements Expected number of elements to be accommodated by
	 * the new sorted set. The specified value serves as a hint to help Objectivity/DB optimize the
	 * amount of space it reserves for the array associated with the root node in the
	 * sorted set�s B-tree. 
	 * 
	 * You can specify 0 to request the maximum amount space be reserved. 
	 * The maximum is equal to the size of one storage page in the container in which
	 * the new sorted set is clustered.</p>
	 * 
	 * @param 	 useShortRefs Specifies how the new sorted set will be linked 
	 * to its elements:
	 * <ul type=disc>
	 * <li> Specify false to create a sorted set that is linked to its
	 * elements by standard object identifiers.
	 * <li> (<i>For advanced users only.</i>) Specify true to to create a sorted set that is linked to its
	 * elements by short object identifiers, which are safe to use only with appropriate object placement. 
	 * Specify true only after obtaining technical consultation from Objectivity.
	 * </ul>
	 */
	public ooTreeSetX(int numElements, boolean useShortRefs)
    {
         _numberOfElements = numElements;
         _useShortRefs = useShortRefs;
		_comparisonArrayIsCompleteKey = false;
    }

	/**
	 * Constructs an empty sorted set with the specified custom comparator and 
	 * with default storage characteristics.</p>
	 * 
	 * <p>If the specified custom comparator supports 
	 * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">comparison arrays</a>,
	 * the new sorted set can validly store duplicate arrays for two or more different elements.</p>
	 *
	 * @param 	 compare	<a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
     * Custom comparator</a>
	 * for the new sorted set. 
	 * The comparator must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>. 
	 */
	public ooTreeSetX(ooCompare compare)
    {
        _comparator = compare;
        _numberOfElements = 5;
        _useShortRefs = false;
		_comparisonArrayIsCompleteKey = false;
    }

	/**
	 * Constructs an empty sorted set with the specified custom comparator, with the specified storage characteristics. </p>
	 * 
	 * <p>If the specified custom comparator supports 
	 * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">comparison arrays</a>,
	 * the new sorted set can validly store duplicate arrays for two or more different elements.</p>
	 * 
	 * @param 	 compare	<a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
     * Custom comparator</a>
	 * for the new sorted set. 
	 * The comparator must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>. </p>
	 *
	 * @param 	 numberOfElements Expected number of elements to be accommodated by
	 * the new sorted set. The specified value serves as a hint to help Objectivity/DB optimize the
	 * amount of space it reserves for the array associated with the root node in the
	 * sorted set�s B-tree.
	 * 
	 * You can specify 0 to request the maximum amount space be reserved. 
	 * The maximum is equal to the size of one storage page in the container in which
	 * the new sorted set is clustered.</p>
	 * 
	 * @param 	 useShortRefs Specifies how the new sorted set will be linked 
	 * to its elements:
	 * <ul type=disc>
	 * <li> Specify false to create a sorted set that is linked to its
	 * elements by standard object identifiers.
	 * <li> (<i>For advanced users only.</i>) Specify true to to create a sorted set that is linked to its
	 * elements by short object identifiers, which are safe to use only with appropriate object placement. 
	 * Specify true only after obtaining technical consultation from Objectivity.
	 * </ul>
	 */
	public ooTreeSetX(ooCompare compare, int numberOfElements, boolean useShortRefs)
    {
      _comparator = compare;
      _numberOfElements = numberOfElements;
      _useShortRefs = useShortRefs;
      _comparisonArrayIsCompleteKey = false;
    }

	/**
	 * Constructs an empty sorted set with the specified custom comparator, with the specified storage characteristics, and
	 * with the specified way of using 
	 * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">comparison arrays</a>. 
	 * </p>
	 * 
	 * <p>Comparison arrays are a performance optimization 
	 * that can be supported by custom comparators. 
	 * If you can guarantee that each element of this sorted set 
	 * will have a unique comparison array,
	 * you can maximize the performance benefit of comparison arrays 
	 * by setting the <tt><i>comparisonArrayIsCompleteKey</tt></i> parameter to true.
	 * Then, if the sorted set encounters two identical comparison arrays, 
	 * it will consider the corresponding persistent objects to be equal 
	 * without opening those objects to obtain further comparison data 
	 * for the comparator to evaluate. 
	 * This behavior minimizes the I/O during sorting and lookup operations, 
	 * but will incorrectly match up different persistent objects 
	 * if they have duplicate comparison arrays.</p>
	 * 
	 * @param 	 compare	<a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
	 * Custom comparator</a>
	 * for the new sorted set. 
	 * The comparator must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>. </p>
	 *
	 * @param 	 numberOfElements Expected number of elements to be accommodated by
	 * the new sorted set. The specified value serves as a hint to help Objectivity/DB optimize the
	 * amount of space it reserves for the array associated with the root node in the
	 * sorted set�s B-tree.
	 * 
	 * You can specify 0 to request the maximum amount space be reserved. 
	 * The maximum is equal to the size of one storage page in the container in which
	 * the new sorted set is clustered.</p>
	 * 
	 * @param 	 useShortRefs Specifies how the new sorted set will be linked 
	 * to its elements:
	 * <ul type=disc>
	 * <li> Specify false to create a sorted set that is linked to its
	 * elements by standard object identifiers.
	 * <li> (<i>For advanced users only.</i>) Specify true to to create a sorted set that is linked to its
	 * elements by short object identifiers, which are safe to use only with appropriate object placement. 
	 * Specify true only after obtaining technical consultation from Objectivity.
	 * </ul></p>
	 * 
	 * @param 	 comparisonArrayIsCompleteKey Specifies whether 
	 * the new sorted set can use comparison arrays
	 * <i>alone</i> to obtain a valid total ordering for all of its elements:
	 * <ul type=disc>
	 * <li> False (the default) if the custom comparator does not support comparison arrays, 
	 * or if comparison arrays are supported, but should not be used alone 
	 * to determine the ordering of elements 
	 * (because duplicate arrays could be stored for two or more elements). 
	 * 
	 * <li> True if comparison arrays can appropriately be used alone 
	 * to determine the ordering of elements--that is, if the custom comparator 
	 * supports comparison arrays <i>and</i> you can guarantee that every element 
	 * in the new sorted set will have a unique comparison array. 
	 * </ul>
	 */

	public ooTreeSetX(ooCompare compare, int numberOfElements, boolean useShortRefs, boolean comparisonArrayIsCompleteKey)
    {
      _comparator = compare;
      _numberOfElements = numberOfElements;
      _useShortRefs = useShortRefs;
      _comparisonArrayIsCompleteKey = comparisonArrayIsCompleteKey;
    }
    /**
     * Adds all elements in the specified collection to this sorted set. </p>
     *
     * @param 	 collection  The collection
     * whose elements are to be added to this sorted set. Every element
     * of <tt><i>collection</i></tt> must be an instance of a
     * persistence-capable class. If any element is transient, this
     * method makes it persistent.</p>
     *
     * @return      True if any elements were added; otherwise, false.
     *
     * <p>This method returns false if this sorted set already contains
     * all the elements of <tt><i>collection</i></tt>.
     */
    public boolean addAll(Collection collection)
    {
        Iterator itr;
        if (collection instanceof ooCollection)
            itr = ((ooCollection)collection).keyIterator();
        else
            itr = collection.iterator();
        boolean mod = false;
    
        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

    /**
     * Adds the specified object to this sorted set. </p>
     *
     * @param 	 object  The element to be added;
     * must be an instance of a persistence-capable class.
     * If <tt><i>object</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @return      True if an element was added; otherwise, false.</p>
     *
     * @see #ooAddAll(ooCollection)
     * @see #ooRemove(Object)
     */
    public boolean add(Object object)
    {
        int[] comparisonArray = null;
        ooCompare comp = (ooCompare)comparator();
        if (comp != null && comp.comparisonArraySize() > 0)
        {
            comparisonArray = new int[comp.comparisonArraySize()];
            comp.setComparisonArrayFromObject(object, comparisonArray);
        }
        return getTreeBasedCollectionPersistor().add(object, comparisonArray);
    }

	/**
	 * Reserved for future use.
	 */
	public boolean add(Object object, int[] comparisonArray)
    {
        return getTreeBasedCollectionPersistor().add(object, comparisonArray);
    }


	/**
	 * Reserved for future use.
	 */
	public boolean contains(Object object, int[] comparisonArray)
	{
		return getTreeBasedCollectionPersistor().contains(object, comparisonArray);
	}

    /**
     * Tests whether this sorted set contains all elements in the
     * specified collection. </p>
     *
     * @param 	 collection  The collection whose elements are
     * to be tested for containment in this sorted set.</p>
     *
     * @return      True if this sorted set contains elements equal to
     * each element of <tt><i>collection</i></tt>; otherwise, false.
     */
    public boolean containsAll(Collection collection) {
        if (comparator() == null)
            return getTreeBasedCollectionPersistor().containsAll((ooCollection) collection);
        else
        {
            Iterator itr;
            if (collection instanceof ooCollection)
                itr = ((ooCollection)collection).keyIterator();
            else
                itr = collection.iterator();
            while (itr.hasNext())
                if (!contains(itr.next()))
                    return false;
            return true;
        }
    }

    /**
     * Finds the element of this sorted set with the specified
     * lookup value. </p>
     *
     * @param 	 lookupValue   The lookup value of the 
     * element to find.</p> 
     *
     * @return      The element whose lookup value equals <tt><i>lookupValue</i></tt>.</p>
     *
     * @see #first
     * @see #last
     */
    public Object get(Object lookupValue)
    {
        int[] comparisonArray = null;
        ooCompare comp = (ooCompare)comparator();
        if (comp != null && comp.comparisonArraySize() > 0)
        {
            comparisonArray = new int[comp.comparisonArraySize()];
            comp.setComparisonArrayFromObject(lookupValue, comparisonArray);
        }
       return ((ooTreeSetXPersistor)getTreeBasedCollectionPersistor()).get(lookupValue, comparisonArray);
    }

    /**
     * Gets a view of the beginning of this sorted set up to, 
     * but not including, the specified element.
     *
     * <p>The returned sorted set contains all elements of this object set
     * whose elements sort before the specified element, 
     * according to this object set's comparator. If you want a view that 
     * includes a particular element, specify as your parameter 
     * an element that sorts after the desired element. 
     *
     * <p>The returned sorted set is backed by this object set, so changes 
     * in the returned sorted set are reflected in this object set, and 
     * vice-versa. 
     *
     * <p>The returned sorted set throws an 
     * <tt>IllegalArgumentException</tt> if an attempt is made to
     * insert a new element that is equal to, or sorts after,
     * <tt><i>toElement</i></tt>.</p>
     *
     * @param 	 toElement   An object specifying the 
     * (exclusive) upper limit for elements in the returned set.</p>
     *
     * @return  A view of the specified initial range of this sorted set. </p>
     *
     * @see #subSet(Object, Object)
     * @see #tailSet(Object)
     */
    public SortedSet headSet(Object toElement) {
    return new SubSet(getTreeBasedCollectionPersistor(), toElement, true);
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this
     * sorted set. </p>
     *
     * @return      A scalable-collection iterator for finding the elements of this
     * sorted set. The iterator finds the
     * elements in their sorted order.
     *
     * <p>If you want to call any methods that are specific to Objectivity
     * for Java scalable-collection iterators, you should cast the returned iterator
     * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
     */
    public Iterator iterator()
    {
        return getTreeBasedCollectionPersistor().iterator();
    }

	/**
	 * Removes the specified object from this sorted set.
	 *
	 * <p>This method is equivalent to {@link #remove <tt>remove</tt>}.</p>
	 *
	 * @param 	 object  The object to be removed.
	 *
	 * Typically, <tt><i>object</i></tt> is a persistent object, namely, the element to be removed. 
	 * If this sorted set has a 
	 * <a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
	 * custom comparator</a> that can identify an element based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the element to be removed. 
	 * (Such a custom comparator may, but need not, support the implicit use of
     * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">
	 * comparison arrays</a> to optimize comparison.)</p>
	 * 
	 *
	 * @return      True if an element was removed; otherwise, false.</p>
	 */
	public boolean ooRemove(Object object)
   {
        return remove(object);
   }

   /**
	* Reserved for future use.
	*/
   public boolean ooRemove(Object object, int[] comparisonArray)
   {
	   return getTreeBasedCollectionPersistor().remove(object, comparisonArray);
   }



   /**
	* Removes the specified object from this sorted set. </p>
	*
	* @param 	 object  The object to be removed.
	*
	* Typically, <tt><i>object</i></tt> is a persistent object, namely, the element to be removed. 
	* If this sorted set has a 
	* <a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
	* custom comparator</a> that can identify an element based on class-specific
	* data, <tt><i>object</i></tt> can instead be a transient object
	* that identifies the element to be removed. 
	 * (Such a custom comparator may, but need not, support the implicit use of
     * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">
	 * comparison arrays</a> to optimize comparison.)</p>
	*
	* @return      True if an element was removed; otherwise, false.</p>
	*
	* @see #removeAll(Collection)
	* @see #retainAll(Collection)
	*/
   public boolean remove(Object object) {
        int[] comparisonArray = null;
        ooCompare comp = (ooCompare)comparator();
        if (comp != null && comp.comparisonArraySize() > 0)
        {
            comparisonArray = new int[comp.comparisonArraySize()];
            comp.setComparisonArrayFromObject(object, comparisonArray);
        }
        return getTreeBasedCollectionPersistor().remove(object, comparisonArray);
    }

	/**
	 * Reserved for future use.
	 */
	public boolean remove(Object object, int[] comparisonArray) {
        return getTreeBasedCollectionPersistor().remove(object, comparisonArray);
    }
    
    /**
     * Removes all elements of the specified collection from this
     * sorted set. </p>
     *
     * @param 	 collection  The collection whose elements are to be
     * removed from this sorted set.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #remove(Object)
     * @see #retainAll(Collection)
     */
    public boolean removeAll(Collection collection)
    {
        if (collection == this)
        {
            if (isEmpty())
                return false;
            return getTreeBasedCollectionPersistor().removeAll((ooCollection) collection);
        }
        if (collection == null)
            throw new NullPointerException("The specified collection is null.");        
        boolean changed = false;
        Iterator itr = collection.iterator();
        while (itr.hasNext())
        {
            if (remove(itr.next()))
                changed = true;
        }
        return changed;
   }

	/**
	 * Creates an array containing all the elements in this
	 * sorted set. </p>
	 *
	 * @return		A new array containing all of the elements in
	 * this sorted set.
	 * The returned array contains the
	 * elements in their order in this sorted set.
	 */
    public Object[] toArray() 
	{
        Object answer[] = (Object[])Array.newInstance(java.lang.Object.class, size()) ;
        Iterator itr = iterator();
        int i = 0;
        while (itr.hasNext())
            answer[i++] = itr.next();
        return answer ;
    }
    
	/**
	 * Returns an array that contains all elements in this sorted set and whose
	 * runtime type is that of the specified array.
	 *
	 * <p>If the specified array is large enough to hold all elements of this
	 * sorted set, this method replaces the elements of that array with the
	 * elements of this sorted set and returns the updated array.
	 * If the array has more elements than this sorted set, the element in the array
	 * immediately following the end of the sorted set is set to null. 
	 * The caller can use the null element to
	 * determine the length of this sorted set. 
	 *
	 * <p>If the specified array is smaller than this sorted set, this method
	 * allocates a new array with the runtime type of
	 * the specified array and the size of this sorted set. It then
	 * sets the elements of the new array to the elements of this
	 * sorted set and returns the new array. </p>
	 *
	 * @param 	 a	The array giving the runtime type of the
	 * returned array.</p>
	 *
	 * @return		An array containing the elements of this sorted set.
	 * The returned array contains the
	 * elements in their order in this sorted set.
	 */
    public Object[] toArray(Object[] a) 
	{
        int size = size();
        if (a.length < size)
            a = (Object[])Array.newInstance(a.getClass().getComponentType(), size);
        Iterator itr = iterator();
        for (int i=0; i<size; i++)
            a[i] = itr.next();
    
        if (a.length > size)
            a[size] = null;
        return a;
    }
    
    /**
     * Retains all elements of this sorted set that are also in the
     * specified collection, removing all other elements. </p>
     *
     * @param 	 collection  The collection whose elements
     * are to be retained in this sorted set.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #remove(Object)
     * @see #removeAll(Collection)
     */
    public boolean retainAll(Collection collection) {
        if (collection instanceof ooCollection && ((ooCollection) collection).comparator() == null)
            return getTreeBasedCollectionPersistor().retainAll((ooCollection) collection);
        else
        {
            if (collection == null)
                throw new NullPointerException("The specified collection is null.");
            boolean changed = false;
            Iterator itr = iterator();
            while (itr.hasNext())
                if (!collection.contains(itr.next()))
                {
                    itr.remove();
                    changed = true;
                }
            return changed;
        }
    }

    /**
     * Gets a view of the portion of this sorted set
     * whose elements are in the specified range.
     *
     * <p>The returned sorted set contains all elements of this object set
     * that are equal to, or sort after, <tt><i>fromElement</i></tt>
     * and sort before <tt><i>toElement</i></tt>, 
     * according to this object set's comparator. 
     *
     * <p>The returned sorted set is backed by this object set, so changes 
     * in the returned sorted set are reflected in this object set, and 
     * vice-versa. 
     *
     * <p>The returned sorted set throws an 
     * <tt>IllegalArgumentException</tt> if an attempt is made to
     * insert an element that sorts before 
     * <tt><i>fromElement</i></tt> or is equal to, or sorts after,
     * <tt><i>toElement</i></tt>.</p>
     *
     * @param 	 fromElement   An object specifying the 
     * (inclusive) lower limit for elements in the returned set.</p> 
     *
     * @param 	 toElement   An object specifying the 
     * (exclusive) upper limit for elements in the returned set.</p>  
     *
     * @return  A view of the specified range of this sorted set.</p> 
     *
     * @see #headSet(Object)
     * @see #tailSet(Object)
     */
    public SortedSet subSet(Object fromElement, Object toElement) {
        return new SubSet(getTreeBasedCollectionPersistor(), fromElement, toElement);
    }

    /**
     * Gets a view of the end of this sorted set, starting with
     * the specified set.
     *
     * <p>The returned sorted set contains all elements of this object set
     * that are equal to, or sort after, <tt><i>fromElement</i></tt>
     * according to this object set's comparator. 
     *
     * <p>The returned sorted set is backed by this object set, so changes 
     * in the returned sorted set are reflected in this object set, and 
     * vice-versa. 
     *
     * <p>The returned sorted set throws an 
     * <tt>IllegalArgumentException</tt> if an attempt is made to
     * insert a new element that sorts before 
     * <tt><i>fromElement</i></tt>.</p>
     *
     * @param 	 fromElement   An object specifying the 
     * (inclusive) lower limit for elements in the returned set.</p>  
     *
     * @return  A view of the specified final range of this sorted 
     * set.</p> 
     *
     * @see #subSet(Object, Object)
     * @see #headSet(Object)
     */
    public SortedSet tailSet(Object fromElement) {
        return new SubSet(getTreeBasedCollectionPersistor(), fromElement, false);
    }

    private class SubSet implements SortedSet {

        private transient PooObj superPersistor;
        private transient Object lowRange;
        private transient Object highRange;
    
        protected SubSet(PooObj persistor, Object fromElement, Object toElement)
        {
            superPersistor = persistor;
            if (fromElement != null && toElement != null && compare(fromElement, toElement) > 0)
                throw new IllegalArgumentException("fromElement > toElement");
            lowRange = fromElement;
            highRange = toElement;
        }
    
        protected SubSet(PooObj persistor, Object element, boolean headSet)
        {
            superPersistor = persistor;
            if (headSet) {
                lowRange = null;
                highRange = element;
            }
            else {
                lowRange = element;
                highRange = null;
            }
        }
        
        public boolean addAll(Collection collection) {
            return ooTreeSetX.this.addAll(collection);
        }
    
        public boolean containsAll(Collection collection) {
            Iterator itr;
            if (collection instanceof ooCollection)
                itr = ((ooCollection)collection).keyIterator();
            else
                itr = collection.iterator();
            while (itr.hasNext())
                if (!contains(itr.next()))
                    return false;
            return true;
        }
    
        public SortedSet headSet(Object toElement) {
            if (!inRange2(toElement))
                throw new IllegalArgumentException("toElement out of range");
            return new SubSet(getSuperPersistor(), lowRange, toElement);
        }
    
        public Iterator iterator() {
            ooCollectionIterator itr = (ooCollectionIterator)getTreeBasedCollectionPersistor().iterator();
            return new SubSetIterator(itr, lowRange, highRange, inTreeRange(lowRange));
        }
    
        public boolean remove(Object element) {
            if (contains(element))
                return ooTreeSetX.this.remove(element);
            else 
                return false;
        }
    
        public boolean removeAll(Collection collection) {
            Object obj;
            boolean changed = false;
            Iterator itr;
    
            if (collection instanceof ooCollection)
                itr = ((ooCollection)collection).keyIterator();
            else
                itr = collection.iterator();
            while ((obj = itr.next()) != null) {
                if (remove(obj))
                    changed = true;
            }
            return changed;
        }
    
        public boolean retainAll(Collection collection) {
            if (collection == null)
                throw new NullPointerException("The specified collection is null.");
            boolean changed = false;
            Iterator itr = iterator();
            while (itr.hasNext())
            if (!collection.contains(itr.next())) {
                itr.remove();
                changed = true;
            }
            return changed;
        }
    
        public SortedSet subSet(Object fromElement, Object toElement) {
                if (!inRange(fromElement))
            throw new IllegalArgumentException("fromElement out of range");
                if (!inRange2(toElement))
                    throw new IllegalArgumentException("toElement out of range");
            return new SubSet(getSuperPersistor(), fromElement, toElement);
        }
    
        public SortedSet tailSet(Object fromElement) {
            if (!inRange(fromElement))
                throw new IllegalArgumentException("fromElement out of range");
            return new SubSet(getSuperPersistor(), fromElement, highRange);
        }
    
        public boolean add(Object element) {
            if (!inRange(element))
                throw new IllegalArgumentException("element out of range");
            return ooTreeSetX.this.add(element);
        }
    
        public void clear() {
            Iterator itr = iterator();
            while (itr.hasNext()) {
                itr.next();
                itr.remove();
            }
        }
    
        public Comparator comparator() {
            return ooTreeSetX.this.comparator();
        }
    
        public boolean contains(Object element) {
            if (!inRange(element))
                return false;
            ooCollectionIterator itr = (ooCollectionIterator)getTreeBasedCollectionPersistor().iterator();
            return itr.goTo(element);
        }
    
        public Object first() {
            Iterator itr = iterator();
            if (itr.hasNext())
                return itr.next();
            else
                throw new NoSuchElementException("SubSet is empty.");
        }
    
        public boolean isEmpty() {
            if (ooTreeSetX.this.isEmpty())
                return true;
            Iterator itr = iterator();
            return !itr.hasNext();
        }
    
        public Object last() {
            Iterator itr = iterator();
            Object current = null;
            while (itr.hasNext())
                current = itr.next();
            if (current == null)
                throw new NoSuchElementException("SubSet is empty.");
            return current;
        }
    
        public int size() {
            Iterator itr = iterator();
            int i = 0;
            while (itr.hasNext()) {
                i++;
                itr.next();
            }
            return i;
        }
    
        public Object[] toArray() {
            Object answer[] ;
            answer = (Object[])Array.newInstance(java.lang.Object.class, size()) ;
            Iterator itr = iterator();
            int i = 0;
            while (itr.hasNext())
                answer[i++] = itr.next();
            return answer ;
        }
    
        public Object[] toArray(Object[] a) {
            int size = size();
            if (a.length < size)
                a = (Object[])Array.newInstance(a.getClass().getComponentType(), size);
            Iterator itr = iterator();
            for (int i=0; i<size; i++)
                a[i] = itr.next();
    
            if (a.length > size)
                a[size] = null;
            return a;
        }
    
        // Compares two keys using the correct comparison method
        protected int compare(Object k1, Object k2) {
            int returnVal = 0;
            //firstExcluded can be null to include the last element of ooTreeSetX in the SubSet
            if (k2 == null) 
                return -1;
            if (comparator() == null) {
                returnVal = ((Persistent) k1).getPersistor().compareOoId(((Persistent) k2).getPersistor());
            } else {
                returnVal = comparator().compare(k1, k2);
            }
            return returnVal;
        }
    
        private boolean inRange(Object element) {
            return (lowRange == null ? true : compare(element, lowRange) >= 0) && (highRange == null ? true : compare(element, highRange) < 0);
        }
    
        // This form allows the high endpoint (as well as all legit elements)
        private boolean inRange2(Object element) {
            return (lowRange == null ? true : compare(element, lowRange) >= 0) && (highRange == null ? true : compare(element, highRange) <= 0);
        }
        
        // This form checks if the element is in the Tree, excepting null elements
        // returns 0, if the element is within the tree's range. 
        private int inTreeRange(Object element) {
            if (element == null)
                return 0;
            if (compare(element, ooTreeSetX.this.first()) < 0)
                return -1;
            if (compare(element, ooTreeSetX.this.last()) > 0)
                return 1;
            return 0;
        }

        protected PooObj getSuperPersistor()
            { return superPersistor ; }
    
        protected ooTreeBasedCollectionsPersistor getTreeBasedCollectionPersistor() {
            if (getSuperPersistor() != null)
                return (ooTreeBasedCollectionsPersistor) getSuperPersistor() ;
            else
                throw new ObjectNotPersistentException("Attempted persistence operation on transient object") ;
        }
    
        private class SubSetIterator implements Iterator {
            private ooCollectionIterator itr;
            private Object firstExcluded;
            private Object firstVal = null;
            
            SubSetIterator(ooCollectionIterator _itr, Object _first, Object _firstExcluded, int inRangeFirst) {
                itr = _itr;
                firstExcluded = _firstExcluded;
                if (inRangeFirst <= 0)
                {
                    if (_first != null && (itr.goTo(_first) || (ooTreeSetX.this.comparator().compare(itr.current(),firstExcluded) < 0)))
                        firstVal = itr.current();
                    else
                    {
                        try {itr.previous();}
                        catch(NoSuchElementException ex) {}
                    }
		    if (_first == firstExcluded)
			firstVal = null;
                    if (firstExcluded != null) {
                        Object restore = itr.current();
                        itr.goTo(firstExcluded);
                        firstExcluded = itr.current();
                        if (restore != null)
                            itr.goTo(restore);
                        else
                            itr.reset();
                    }
                }
                else
                    itr.goTo(_first);
            }
            
            public boolean hasNext() {
                if (firstVal != null) 
                    return true ;
                return (itr.hasNext() && (compare(get(itr.nextIndex()), firstExcluded) < 0));
            }
            
            public Object next() {
                Object value;
                if (firstVal != null) {
                    value = firstVal;
                    firstVal = null;
                }
                else {
                    if (!hasNext())
                        return null;
                    value = itr.next();
                }
                return value;
            }
            
            public void remove() {
                itr.remove();
            }
        } // End class SubSetIterator
    } // End class SubSet
}
