/*
 * @(#)ooContObj.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app.storage ;

import java.util.Vector ;

import com.objy.db.ObjyRuntimeException ;

import com.objy.db.iapp.PooContObj;
import com.objy.db.app.Connection;
import com.objy.db.app.Iterator;
import com.objy.db.app.ooId;
import com.objy.db.app.ooObj;
import com.objy.query.ObjectQualifier;
/**
 * Represents a physical grouping of basic objects in a database.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>A container is the third highest level in the Objectivity/DB logical storage 
 * hierarchy. Within this hierarchy, each container belongs to exactly one database, 
 * and can contain one or more basic objects. 
 * The <tt>ooContObj</tt> class defines the behavior shared by all
 * containers; it is the superclass for all container classes.
 *
 * <p>Containers of class <tt>ooContObj</tt> are
 * <a href="../../../../../../guide/jgdStorage.html#nonGcContainers">
 * non-garbage-collectible</a>. The basic objects they contain
 * must be explicitly deleted when they are no longer needed by
 * an application. Such containers are used primarily by applications
 * written in a non-garbage-collected language, such as C++.
 * Java applications more commonly use
 * <a href="../../../../../../guide/jgdStorage.html#gcContainers">
 * garbage-collectible</a> containers of the
 * <a href="ooGCContObj.html"><tt>ooGCContObj</tt></a> class.
 *
 * <p><b>Note:</b> You must make a container
 * <a href="../../../../../../guide/jgdStorage.html#Making a Container Persistent">
 * persistent</a> before you call any
 * methods defined by the <tt>ooContObj</tt> class; for similar restrictions
 * on inherited methods, see the <tt>ooObj</tt> method descriptions.
 *
 * <p>If your application needs persistent container-specific data, you can
 * define your own non-garbage-collectible container class, by
 * subclassing ooContObj and defining attributes to represent the
 * container-specific information. See
 * <a href="../../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>.
 * 
 * <p>A container of any class may be either:
 * <ul type=disc>
 * <li> An <i>embedded container</i>, which means it is
 * physically stored within the file of its containing database.</p>
 * <li>An <i>external container</i>, which means it is stored 
 * in its own <i>container file</i> and therefore external to the 
 * database that logically contains it. 
 * A container file normally resides in the same directory as the file of the 
 * containing database; however, like database files, container files can 
 * be distributed among different machines.
 * </ul></p>
 *
 * <p>For additional information about containers and a discussion of how
 * an application can create and work with containers,
 * see <A HREF="../../../../../../guide/jgdStorage.html#Containers">
 * Containers</A>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 	<td>
 *     <a href="#ooContObj()">ooContObj()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Refreshing&nbsp;Persistent&nbsp;Data</b></td><td>
 *     <a href="#refresh(int)">refresh(int)</a>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Locking</b></td><td>
 *     <a href="#lockNoProp(int)">lockNoProp(int)</a><br>
 *     <a href="#releaseReadLock()">releaseReadLock()</a>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Modifying</b></td><td>
 *     <a href="#delete()">delete()</a><br>
 * 	   <a href="#deleteNoProp()">deleteNoProp()</A><br>
 *     <a href="#changeExternalContainerLocation(java.lang.String, java.lang.String, boolean)">changeExternalContainerLocation(String, String, boolean)</A>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting Information</b></td><td>
 *     <a href="#getDB()">getDB()</a><br>
 *     <a href="#getName()">getName()</a><br>
 *     <a href="#getNumLogicalPages()">getNumLogicalPages()</a><br>
 *     <a href="#getCountLogicalPages()">getCountLogicalPages()</a><br>
 *     <a href="#getMaxPagesForSmallPageMap()">getMaxPagesForSmallPageMap()</a><br>
 *     <a href="#getPageCount()">getPageCount()</a><br>
 *     <a href="#getGrowthFactor()">getGrowthFactor()</a><br>
 *     <a href="#getOid()">getOid()</a><br>
 *     <a href="#getNumber()">getNumber()</A><br>
 *     <a href="#getFileName()">getFileName()</A><br>
 *     <a href="#getHostName()">getHostName()</A><br>
 *     <a href="#getPathName()">getPathName()</A><br>
 *     <a href="#getPageSize()">getPageSize()</A><br>
 *     <a href="#getHash()">getHash()</A>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td><td>
 *     <a href="#isUpdated()">isUpdated()</a><br>
 *     <a href="#hasIndex(java.lang.String)">hasIndex(String)</a><br>
 *     <a href="#indexConsistent(java.lang.String)">indexConsistent(String)</a><br>
 *     <a href="#isExternal()">isExternal()</A>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Clustering</b></td><td>
 * 	<a href="#cluster(java.lang.Object)">cluster(Object)</a><br>
 * 	<a href="#cluster(java.lang.Object, com.objy.db.app.storage.ClusterStrategy)">cluster(Object, ClusterStrategy)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Contained&nbsp;Objects</b></td><td>
 *     <a href="#contains()">contains()</a><br>
 *     <a href="#scan(java.lang.String)">scan(String)</a><br>
 *     <a href="#scan(java.lang.String, java.lang.String)">scan(String, String)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Indexes</b></td>
 * 	<td>
 *     <a href="#addIndex(java.lang.String, java.lang.String, java.lang.String)">addIndex(String, String, String)</a><br>
 *     <a href="#addUniqueIndex(java.lang.String, java.lang.String, java.lang.String)">addUniqueIndex(String, String, String)</a><br>
 *     <a href="#dropIndex(java.lang.String)">dropIndex(String)</a><br>
 *     <a href="#hasIndex(java.lang.String)">hasIndex(String)</a><br>
 *     <a href="#indexConsistent(java.lang.String)">indexConsistent(String)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Converting&nbsp;Objects</b></td><td>
 * 	<a href="#convertObjects()">convertObjects()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Writing&nbsp;Objects</b></td><td>
 * 	<a href="#flush()">flush()</a>
 * 	</td></tr>
 * </table>
 */
public class ooContObj
    extends ooObj
{
	/**
	 * Constructs a non-garbage-collectible container.
	 *
	 * <p>The newly created container object is transient; you must make it
	 * persistent before calling any of the public methods of
	 * <tt>ooContObj</tt>.  For example, you can explicitly add it to a database by calling the
	 * <a href="ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)"><tt>addContainer</tt></a>
	 * method of the database.
	 */
    public ooContObj()
        { }

	/**
     * Reserved for internal use.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ooContObj(PooContObj persistor) {
        if (persistor == null)
            throw new ObjyRuntimeException("Constructor not for general use");
        setPersistor(persistor) ;
    }

	/**
	 * Finds the database in which this container is stored.</p>
	 *
	 * @return	The database in which this container is stored.
	 */
    public ooDBObj getDB()
        { return contPersistor().getDB() ; }

	/**
	 * Overrides the inherited method; disallows getting the container for
     * containers.</p>
	 *
	 * @exception   ObjyRuntimeException    This method always throws an exception, since
	 * only basic objects can be stored in containers.</p>
	 *
	 */
    public ooContObj getContainer()
        { throw new ObjyRuntimeException("getContainer() not valid for containers");}

	/**
	 * <i>(For backward compatibility only)</i> Gets the hash value of this container.
	 * 
	 * <p>This method returns a useful value only if this container belongs to a database that
	 * uses the pre-Release&nbsp;9.0 internal database format.</p>
	 * 
	 * @return		1 if this container is hashed, or 0 if this container is nonhashed. 
	 * <b>Note:</b> The return value is always 0 if this container belongs to a database that uses the 
	 * Release&nbsp;9.0 (or later) internal database format.</p>
	 * 
	 * @see		<a href="ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, java.lang.String, long, long, long)"><tt>addContainer(ooContObj, String, long, long, long)</tt></a>
	 * 
	 */ 
    public int getHash()
        { return contPersistor().getHash() ; }

	/**
	 * Gets the system name of this container.
	 *
	 * <p>When a container is added to a database, its system name is
	 * specified as a parameter to the
	 * <a href="ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)"><tt>addContainer</tt></a>
	 * method.</p>
	 *
	 * @return		The system name of this container, or an empty string if this
	 * container has no system name.
	 */
    public String getName()
        { return contPersistor().getName(); }

	/**
	 * Gets the fully qualified filename of this external container.
	 *
	 * <p>The returned filename includes the directory pathname as well as 
	 * the simple name  of the container file. Use <a href="#getPathName()"><tt>getPathName</tt></a> 
	 * to obtain just the directory pathname.</p>
	 *
	 * @return		The filename of this external container, or an empty string if this
	 * container is an embedded container.
	 */
    public String getFileName()
        { return contPersistor().getFileName(); }

	/**
	 * Gets the network name of the data-server host of this external container.</p>
	 *
	 *
	 * @return		The network name of the data-server host, or an empty string if this
	 * container is an embedded container.
	 */
    public String getHostName()
        { return contPersistor().getHostName(); }

	/**
	 * Gets the pathname of the container-file directory for this external container.
	 *
	 * <p>The returned pathname does not include the simple name of the container file.
	 * Use <a href="#getFileName()"><tt>getFileName</tt></a> 
	 * to obtain a path name that includes the filename.</p>
	 *
	 * @return		The path to the directory of this external container, or an empty string if this
	 * container is an embedded container.
	 */
    public String getPathName()
        { return contPersistor().getPathName(); }

	/**
	 * Gets the storage-page size of this external container.
	 *
	 * <p>This method is primarily used for getting the storage-page size of an 
	 * external container. If this container is embedded in a database file, the 
	 * database's storage-page size is returned.</p>
	 *
	 * @return	  The size (in bytes) of the storage pages managed by this container.
	 */
    public int getPageSize()
        { return contPersistor().getPageSize() ; }

	/**
	 * Tests whether this container is an external container.</p>
	 *
	 *
	 * @return	  True if this container is an external container; false if it is embedded
	 * in the file of its containing database.
	 */
    public boolean isExternal()
        { return contPersistor().isExternal() ; }

	/**
	 * Moves or renames the container file of this external container.</p>
	 *
	 * @param 	 hostName	New data-server host for the container file.
     * The designated host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>hostName</i></tt> is an empty string or null, the 
     * designated host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>pathName</i></tt> is a local path.
     * <li>The host implied by <tt><i>pathName</i></tt>, if <tt><i>pathName</i></tt> is an 
     * NFS mount name.
     * <li>The host on which the container file already resides, if <tt><i>pathName</i></tt> is also null.
     * </ul></p>
     *
     * <li>If <tt><i>pathName</i></tt> is a Windows UNC share name, <tt><i>hostName</i></tt> is 
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>hostName</i></tt> is used.</ul></p>
	 *
	 * @param 	 pathName	New pathname (including the filename) for the container file.
     * Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of the pathname must follow the naming conventions of 
     * the designated host.</p>
     * <li>If the designated host is a remote system, 
     * <tt><i>pathName</i></tt> must be fully qualified; otherwise, 
     * <tt><i>pathName</i></tt> may be either relative or fully qualified. </p> 
     * <li>This parameter may be null only if <tt><i>hostName</i></tt> is also null or an empty string; 
     * in this case, the file location is unchanged.
     * </ul></p>
	 * 
	 * @param 	 catalogOnly	Specifies whether to change the container file's host and path only by 
	 * updating its location properties in the relevant database-level catalog.
	 * <p><ul type=disc>
	 * <li>Specify true to update properties in the relevant database-level catalog, 
	 * without physically affecting the container file.</p>
	 * <li>Specify false to update properties in the relevant database-level catalog, 
	 * and also physically move or rename the container file in your file system.
	 * </ul></p>
	 * 
	 */
    public void changeExternalContainerLocation(String hostName, String pathName, boolean catalogOnly)
        {  contPersistor().changeExternalContainerLocation(hostName, pathName, catalogOnly); }

	/**
	 * Gets the largest logical page number in this container.</p>
	 *
	 * <p>You can use this method to monitor when the container will reach 
	 * its maximum logical page limit (65534). </p>
	 * 
	 * <p>
	 * This method returns the largest logical-page identifier assigned 
	 * to a storage page within the container. 
	 * (A logical-page identifier is assigned to a storage page 
	 * only if at least one basic object is clustered on that page.) 
	 * </p>
	 * 
	 * <p>
	 * If all the basic objects in the container are stored on consecutive logical pages, 
	 * the largest logical-page identifier is the same as the total number of 
	 * used logical pages in the container. 
	 * You can therefore call this method to monitor when such a container 
	 * will reach its maximum logical-page limit (65534). 
	 * For example, you typically call this method to determine 
	 * how full the container is before attempting to cluster new basic objects in it.
	 * </p>
	 * 
	 * <p>
	 * This method is not appropriate for monitoring the capacity of a container 
	 * if any logical pages have been deleted from it or 
	 * if any basic objects have been explicitly clustered on nonconsecutive logical pages 
	 * throughout the container. 
	 * For example, if a container stores basic objects 
	 * only on logical pages 1, 2, 5, and 9, this method returns 9 
	 * (the highest logical-page identifier), 
	 * not 4 (the number of logical pages in use). 
	 * You should call 
	 * the <a href="#getCountLogicalPages()"><tt>getCountLogicalPages</tt></a> method 
	 * to accurately monitor 
	 * the capacity of a container that stores objects on nonconsecutive logical pages.
	 * </p>
	 * 
	 *
	 * @return		Largest logical-page identifier currently 
	 * assigned to a storage page in the container.</p>
	 *
	 * @exception   ObjyRuntimeException    If this container cannot be locked for
	 * read.</p>
	 * 
	 * @see		<a href="#getCountLogicalPages()"><tt>getCountLogicalPages</tt></a>
	 * @see		<a href="#getPageCount()"><tt>getPageCount</tt></a>
	 *
	 */
    public long getNumLogicalPages()
        { return contPersistor().getNumLogicalPages(); }

	/**
	 * Gets the current number of logical pages in this container.</p>
	 *
	 * <p>
	 * This method returns the number of storage pages in the container 
	 * that are managed as logical pages, 
	 * where each such page has at least one basic object clustered on it. 
	 * </p>
	 * <p>
	 * You can use this method to monitor when a container will reach 
	 * its maximum logical-page limit (65534). 
	 * For example, you typically call this method to determine 
	 * how full the container is before attempting to cluster new basic objects in it.
	 * </p>
	 * <p>
	 * This method is especially appropriate for monitoring the capacity of containers 
	 * that have logical pages with nonconsecutive identifiers, including:
	 * </p>
	 * <ul type=disc>
	 * <li>
	 * Containers from which logical pages have been deleted 
	 * (because all the basic objects on those pages have been deleted).
	 * </li>
	 * <li>
	 * Containers in which basic objects have been explicitly clustered 
	 * on nonconsecutive logical pages. 
	 * </li>
	 * </ul>
	 * <p>
	 * For example, if a container stores basic objects only on logical pages 1, 2, 5, and 9, 
	 * this method returns 4 (the number of logical pages in use).
	 * </p>
	 * <p>
	 * If, however, all the basic objects in a container are clustered on consecutive logical pages, 
	 * it is more efficient to monitor the container�s capacity by calling the 
	 * <a href="#getNumLogicalPages()"><tt>getNumLogicalPages</tt></a> method, 
	 * which returns the largest logical-page identifier currently in use.
	 * </p>
	 *
	 * @return		Current number of logical pages
	 * in this container.</p>
	 *
	 * @exception   ObjyRuntimeException    If this container cannot be locked for
	 * read.</p>
	 * 
	 * @see		<a href="#getNumLogicalPages()"><tt>getNumLogicalPages</tt></a>
	 * @see		<a href="#getPageCount()"><tt>getPageCount</tt></a>
	 *
	 */
    public long getCountLogicalPages()
        { return contPersistor().getCountLogicalPages(); }


	/**
	 * Gets the current number of storage pages in this container.</p>
	 *
	 * <p>You can use this method to help you calculate the size (in bytes) 
     * of this container. You can get the size of this container's 
	 * storage pages by calling its <a href="#getPageSize()">
     * <tt>getPageSize</tt></a> method.</p>    
	 * 
	 * <p><b>Note: </b> The returned number may, but need not, include any storage pages 
	 * that were added to the container during the current transaction. 
	 * If you want to ensure that added, but uncommitted, 
	 * pages are included in the returned number, 
	 * you should checkpoint the transaction before calling this method.</p>
     *     
	 * @return		The total number of used and free physical storage pages
	 * in this container.</p>
	 *
	 * @exception   ObjyRuntimeException    If this container cannot be locked for
	 * read.</p>
	 * 
	 * @see		<a href="#getNumLogicalPages()"><tt>getNumLogicalPages</tt></a>
     *
	 */
    public long getPageCount()
        { return contPersistor().getPageCount() ; }

	/**
	 * Gets the object identifier of this container.</p>
	 *
	 * @return		The object identifier of this container.</p>
	 */
    public ooId getOid()
        { return contPersistor().getOid() ; }

	/**
	 * Gets the growth factor for this container.
	 *
	 * <p>Each time additional disk space must be allocated for a container,
	 * the container grows by a percentage of its current size. The growth
	 * factor is the percentage by which the container grows; it is set when
	 * the container is created.</p>
	 *
	 * @return		This container's growth factor.</p>
	 *
	 * @exception   ObjyRuntimeException    If this container cannot be locked for
	 * read.
	 *
	 */
    public long getGrowthFactor()
        { return contPersistor().getGrowthFactor() ; }

	/**
	 * Tests whether this container has been updated and committed or checkpointed
	 * by another session.
	 *
	 * <p>You should call this method only during an MROW session in
	 * which you locked this container for read. If this method
	 * returns true, your application's copies of the container and its
 	 * objects are out of date.  You can call the
	 * <a href="#refresh(int)"><tt>refresh</tt></a> method to
	 * update the session's copy of this container and its objects.</p>
	 *
	 * @return		True if all of the following conditions are true:
	 * <dl>
	 * <dt><dd>This method is called during an MROW session.
	 * <dt><dd>This container is locked for read.
	 * <dt><dd>Another session has updated this container or some object it
	 * contains since the current session locked the container.
	 * </dl>
	 * Otherwise, false.
	 */
    public boolean isUpdated()
        { return contPersistor().isUpdated() ; }

	/**
	 * Explicitly locks this container for the specified access.
	 *
	 * <p>Unlike the <a href="ooObj.html#lock(int)"><tt>lock</tt></a>
	 * method, this method does not propagate the lock to related objects.
	 *
	 * <p>This method implicitly locks all basic objects in this
     * container.</p>
	 *
	 * @param 	 mode	The type of lock to obtain for this
	 * container and its objects; one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
     * <p>The lock mode is limited by the open mode of this container's
     * session</a>.
	 *
	 * <p>If this container is already locked, you can call this method to upgrade a
	 * read lock to a write lock, but not to downgrade a write lock to a read
     * lock.</p>
	 *
	 * @exception   ObjyRuntimeException    If you try to set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>.</p>
	 *
	 */
    public void lockNoProp(int mode)
        { contPersistor().lockNoProp(mode) ; }

	/**
	 * Releases this container's read lock.
	 *
	 * <p>This method is useful in a non-MROW session when your application has
	 * finished reading objects in this container, but will continue working with
	 * objects in other containers.  Releasing the read lock allows another
	 * session to obtain a write lock on this container.
	 *
	 * <p>This implicitly releases the read
	 * locks on all basic objects in this container.</p>
	 *
	 * @exception   ObjyRuntimeException    If this container is locked for
	 * write; it takes no action if this container is not locked.
	 *
	 */
    public void releaseReadLock()
        { contPersistor().releaseReadLock(); }

	/**
	 * Updates the session's copy of this container and its objects.
	 *
	 * <p>You should call this method only during an MROW session and
	 * only if you locked this container for read and another session
	 * subsequently updated the container.  You can
	 * call the <a href="#isUpdated()"><tt>isUpdated</tt></a> method to
	 * check whether another session has updated this container since you
	 * locked it.
	 *
	 * <p>Note that this method does not automatically refetch any existing
	 * fetched object in the container.</p>
	 *
	 * <p> This method throws an exception if the container being refreshed
	 * no longer exists. </p>
	 *
	 * @param 	 mode	The type of lock to obtain for this container; one
     * of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl>
	 */
    public void refresh(int mode)
        { contPersistor().refresh(mode) ; }

    /**
     * Transfers the data of all modified persistent objects in this
     * container to the session's Objectivity/DB cache.
     *
     * <p>After the successful execution of this method, the objects
     * are no longer marked as modified.
     *
     * <P>This method makes the data of modified objects available to the
     * process that calls the method, but does not make the changes
     * permanent and available to other processes. When you checkpoint or
     * commit the transaction, the changes become permanent in the federated
     * database.</p>
     */
    public void flush()
        { contPersistor().flush() ; }

	/**
	 * Deletes this container and all its objects from the federated database
     * and propagates
	 * the deletion operation to related destination objects.
	 *
	 * <p>This method propagates the deletion operation to any destination objects
	 * linked to this container through relationships for which delete
	 * propagation is enabled.
	 *
     * <p>If your application has objects in memory that represent any of the
	 * objects in this container, this method deletes each
	 * such object and propagates the deletion operation to that object's related objects.
	 *
	 * <p>Until the current transaction is committed, the deleted container and
	 * basic objects continue to
     * exist in your application's memory, but they are marked dead.
     *
     * <p>Each deleted object (including this container) is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
     * write a persistent object that references a dead object.
	 * 
	 * <p>If this container is an external container, its file is removed
	 * from the file system. Aborting the transaction restores the deleted file.</p>
     *
	 * @exception   com.objy.db.ObjectIsDeadException   If you attempt
     * to perform this operation on a dead object.</p>
     *
     * @see #deleteNoProp
     * @see ooObj#isDead
	 */
    public void delete()
        { contPersistor().delete() ; }

	/**
	 * Deletes this container and all its objects from the federated database.
	 *
     * <p>If your application has objects in memory that represent any of the
	 * objects in this container, this method calls the
	 * <a href="ooObj.html#deleteNoProp()"><tt>deleteNoProp</tt></a> method of each
	 * such object.
	 *
	 * <p>Until the current transaction is committed, the deleted container and
	 * basic objects continue to
     * exist in your application's memory, but they are marked dead.
     *
     * <p>Each deleted object (including this container) is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
     * write a persistent object that references a dead object.</p>
     *
 	 * <p>Unlike the <a href="#delete()"><tt>delete</tt></a>
	 * method, this method does not propagate the deletion operation
	 * to related destination objects.</p>
	 * 
	 * <p>If this container is an external container, its file is removed
	 * from the file system. Aborting the transaction restores the deleted file.</p>
	 *
	 * @exception com.objy.db.ObjectIsDeadException     If you attempt
     * to perform this operation on a dead object.</p>
	 *
     * @see ooObj#isDead
	 */
    public void deleteNoProp()
        { contPersistor().deleteNoProp() ; }

	/**
	 * Makes the specified object persistent, clustering it with this
	 * container, subject to the session's clustering strategy.</p>
	 *
	 * <p>The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The session's
	 * clustering strategy determines where to locate the object relative
	 * to this container. See
     * <a href="../../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this container's database, adding it to that database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this
     * container is transient.</p>
	 *
	 */
    public void cluster(Object object)
    { contPersistor().cluster(object, getPersistor().getSession().getClusterStrategy()); }

	/**
	 * Makes the specified object persistent, clustering it with this
	 * container, subject to the specified clustering strategy.</p>
	 *
	 * <p>The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The specified
	 * clustering strategy determines where to locate the object relative
	 * to this container. See
     * <a href="../../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this container's database, adding it to that database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.</p>
	 *
     * @param 	 strategy    Clustering strategy to determine 
     * the location of a basic object.
     * This parameter is ignored if
     * <tt><i>object</i></tt> is a container.</p>
     *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this
     * container is transient.</p>
	 */
    public void cluster(Object object, ClusterStrategy strategy)
        { contPersistor().cluster(object, strategy); }

    /**
     * Overrides the inherited behavior; disallows copying objects for
     * this container.</p>
     *
     * @exception   ObjyRuntimeException    This method always throws an
     * exception.</p>
     *
     */
    public Object copy(Object near)
        { throw new ObjyRuntimeException("copy(Object) not valid for containers");}

    /**
     * Overrides the inherited behavior; disallows moving objects for
     * this container.</p>
     *
     * @exception   ObjyRuntimeException    This method always throws an
     * exception.</p>
     *
     */
    public void move(Object near)
        { throw new ObjyRuntimeException("move(Object) not valid for containers");}

	/**
     * Initializes an object iterator to scan
     * this container for objects of the specified class.</p>
	 *
     * @param 	 className      The package-qualified name of the
     * class of the desired objects.</p>
     *
	 * @return		An object iterator that finds the specified objects.
	 */
    public Iterator scan(String className)
        { return contPersistor().scan(className) ; }

	/**
     * Initializes an object iterator to  scan
     * this container for objects of the specified class that satisfy the
	 * specified predicate.
	 *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan
     * policy.  See
     * <a href="../../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
     * @param 	 className      The package-qualified name of the
     * class of the desired objects. </p>
     *
	 * @param 	 predicate	The condition that the objects must
	 * satisfy, expressed in the Objectivity/DB
     * <a href="../../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
     *
	 * @return		An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     */
    public Iterator scan(String className, String predicate)
        { return contPersistor().scan(className,predicate); }
    
    /**
     * Initializes an object iterator to  scan
     * this container for objects qualified by an
	 * ObjectQualifier.
	 *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan
     * policy.  See
     * <a href="../../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
     * @param    className      The package-qualified name of the
     * class of the desired objects. </p>
     *
     * @param 	 objectQualifier      The ObjectQualifier instance. </p>
     *
	 * @return		An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     */
    public Iterator scan(String className, ObjectQualifier objectQualifier) 
    {
        return contPersistor().scan(className, objectQualifier) ;    
    }

	/**
     * Adds an index to this container.</p>
   	 *
     * @param 	 name   The name of the index to be added;
	 * must be different from
	 * the names of existing indexes in this container's database. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
     *
     * @param 	 className   The package-qualified name of
	 * the class whose instances are to be indexed.</p>
	 *
     * @param 	 fieldList   The key fields for the index,
	 * separated by commas.
     * Each key field must be the name of a valid attribute
     * of <tt><i>className</i></tt> whose type is one of the Java
     * <a href = "../../../../../../guide/jgdIndexes.html#Key Fields">
     * types supported by indexes</a>.</p>
     *
	 * @exception   ObjyRuntimeException    If Objectivity/DB is unable to
     * create the index.</p>
     *
	 * @see #addUniqueIndex(String, String, String)
	 * @see #dropIndex(String)
	 */
    public void addIndex(String name, String className, String fieldList)
        { contPersistor().addIndex(name, className, fieldList); }

	/**
     * Adds a unique index to this container.
     *
     * <p>The application is responsible for ensuring that every object
	 * indexed by a unique index has a
     * unique combination of values in its key fields. If two or more
	 * objects have a given combination of key values, the index contains
	 * only the first such object that is encountered when the index is
	 * created or updated.</p>
	 *
     * @param 	 name   The name of the index to be added;
	 * must be different from
	 * the names of existing indexes in this container's database. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
     *
     * @param 	 className   The package-qualified name of
	 * the class whose instances are to be indexed.</p>
	 *
     * @param 	 fieldList   The key fields for the index,
	 * separated by commas.
     * Each key field must be the name of a valid attribute
     * of <tt><i>className</i></tt> whose type is one of the Java
     * <a href = "../../../../../../guide/jgdIndexes.html#Key Fields">
     * types supported by indexes</a>.</p>
     *
	 * @exception   ObjyRuntimeException    If Objectivity/DB is unable to
     * create the index.</p>
     *
	 * @see #addIndex(String, String, String)
	 * @see #dropIndex(String)
	 */
    public void addUniqueIndex(String name, String className, String fieldList)
        { 
          contPersistor().flush(); //SPR 17691 flush object to index correct info
          contPersistor().addUniqueIndex(name, className, fieldList); 
        }

	/**
     * Drops the specified index from this container.</p>
	 *
     * @param 	 name   The name of the index to be dropped.
     *
	 * @exception   ObjyRuntimeException    If this container does not have an index named
	 * <tt><i>name</i></tt>. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether the
     * specified index exists.</p>
     *
     * @see #addIndex(String, String, String)
     * @see #addUniqueIndex(String, String, String)
	 */
    public void dropIndex(String name)
        { contPersistor().dropIndex(name) ; }

	/**
	 * Tests whether this container has an index with the specified name.</p>
	 *
	 * @param 	 name	The name of the index.</p>
	 *
     * @return		True if this container has an index named
     * <tt><i>name</i></tt>; otherwise, false.
	 */
    public boolean hasIndex(String name)
        { return contPersistor().hasIndex(name) ; }

	/**
     * Tests whether the specified index in this container is
     * consistent with the definition of the indexed class.</p>
	 *
	 * <p>If you delete or change the data type of an attribute of the
     * indexed class and that attribute is used as a key field of an index,
     * the index becomes invalid because it is no longer consistent with the
     * updated definition of the indexed class. You should test for
     * consistency after modifying the definition of an indexed class and
     * should drop and recreate any invalid indexes.  See
     * <A HREF="../../../../../../guide/jgdIndexes.html#Reconstructing Indexes After Schema Evolution">
     * Reconstructing Indexes After Schema Evolution</A>.</p>
	 *
     * @param 	 name   The name of the index to be tested.</p>
	 *
     * @return      True if this container has an index named
	 * <tt><i>name</i></tt> and that index is consistent with the definition
     * of the indexed class; otherwise, false.
	 */
    public boolean indexConsistent(String name)
        { return contPersistor().indexConsistent(name) ; }

	/**
     * Initializes an object iterator to find all basic objects in this
     * container.</p>
	 *
	 * @return		An object iterator that finds the basic objects stored in this container.
	 */
    public Iterator contains() // returns all objects in container
        { return contPersistor().contains(); }

	/**
	 * Performs on-demand
     * <A HREF="../../../../../../guide/jgdSchemaEvolution.html#Object Conversion">
	 * object conversion</a> on any affected objects in this container.
	 *
	 * <p>Object conversion makes persistent objects in the federated database
	 * consistent with their current definitions of their
	 * Java classes.
	 *
	 * <p>You can call this method if the definitions of some Java classes are
	 * not consistent with the corresponding descriptions in the schema.
     * Certain changes to a class definition affect how instances of a class
     * should be laid out in storage. After you make such a change, existing
     * persistent objects of the changed classes are rendered out-of-date
     * until they are converted to their new representations.
	 *
     * <p>You call this method in an update transaction to
     * convert the affected objects in this container on demand.
     * This method takes no action if the affected objects in the container have
     * already been converted.
     *
     * <p>This method automatically drops any index
     * that is invalidated by a schema evolution change. Specifically, if you
     * changed the type or deleted an attribute that is a key field of an
     * index, that index is dropped.
	 */
    public void convertObjects()
        { contPersistor().convertObjects(); }

    /**
     * Gets the integer identifier of this container.</p>
     *
     * @return      The integer identifier of this container.
     */
    public long getNumber()
        { return contPersistor().getNumber() ; }

	/**
	 * Gets the maximum number of logical pages that this container can have 
	 * and still maintain its page map as a small object.</p>
	 * 
	 * <p>This method calculates the maximum number of logical-page entries 
	 * that can be recorded in the container's page map before the page map becomes a large object. 
	 * When a page map is a large object, it spans multiple storage pages, 
	 * causing certain internal housekeeping operations to require more memory than they would 
	 * if the page map could fit entirely within a single page. 
	 * Limiting the container's size to the returned number of logical pages 
	 * avoids this extra memory usage and 
	 * can therefore optimize the performance of operations that update basic objects in the container. </p>
	 * 
	 * <p>You typically call this method in code that explicitly monitors 
	 * how full the container is before attempting to cluster new basic objects in it. 
	 * (As an alternative to such code, however, you can set the container-fill policy 
	 * of the session's clustering strategy to 
	 * {@link ClusterStrategy#fastAccess <tt>ClusterStrategy.fastAccess</tt>}, 
	 * which uses this calculation in its implementation.)
	 * 
	 * @return	Integer number of logical pages that can be managed 
	 * by a page map that occupies a single storage page in this container. 
	 * A different number is returned for containers that have different storage-page sizes.
	 * 
	 * 
	 */
    public int getMaxPagesForSmallPageMap()
        { return contPersistor().getMaxPagesForSmallPageMap() ; }

    synchronized PooContObj contPersistor()
        { return (PooContObj)persistor() ; }
}
