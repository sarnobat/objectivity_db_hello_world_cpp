package com.objy.db;

import com.objy.query.expression.ExpressionSetupError;


@SuppressWarnings("serial")
public class ExpressionSetupException extends ObjyRuntimeException
{
    private ExpressionSetupError mExpressionSetupError;
    
    /**
     * Constructs an expression setup exception with a message.
     * @param message
     */
    public ExpressionSetupException(String message) 
    {
        super(message);
    }
    
    /**
     * Constructs an expression setup exception with a message and an expression setup error.
     * @param message
     * @param error
     */
    public ExpressionSetupException(String message, ExpressionSetupError error) 
    {
        super(message);
        mExpressionSetupError = error; 
    }
    /**
     * Returns the expression setup error.
     * @return An instance of ooExpressionSetupError
     */
    public ExpressionSetupError getError()
    {
        return mExpressionSetupError;
    }
}
