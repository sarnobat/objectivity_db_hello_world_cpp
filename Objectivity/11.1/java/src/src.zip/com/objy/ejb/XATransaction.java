/*
 * @(#)XATransaction.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.ejb ;

import javax.transaction.xa.XAException ;
import javax.transaction.xa.XAResource ;
import javax.transaction.xa.Xid ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.app.Database ;
import com.objy.db.app.Session ;
import com.objy.db.iapp.PXATransaction ;

import com.objy.pm.Access ;

/**
 * Represents an Objectivity/DB transaction resource manager.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <h2>Understanding Transaction Resource Managers</h2>
 *
 * <p>An Objectivity/DB transaction <i>resource manager</i> provides transaction 
 * services for performing a transaction with the connected Objectivity/DB 
 * federated database as a separate  transaction branch within  a global 
 * transaction. Your application interacts with a <i>transaction manager</i> 
 * to perform an Objectivity/DB transaction as part of a global transaction.
 * The transaction manager controls the global transaction; it calls methods 
 * of the resource manager to start and end work in the transaction branch, 
 * to prepare the work to be committed, and to commit or roll back the work 
 * at the end of the global transaction.
 *
 * <p>Typically, an application that accesses a federated database as part of a
 * global transactions does so through a <a href="UserConnection.html">
 * user connection</a>.
 *
 * <p><b>Note:</b> You do not work directly with instances of this class unless 
 * you implement your own transaction manager.
 *
 * <p>An Objectivity/DB transaction resource manager is associated with a
 * particular <a href="../db/app/Session.html">session</a>.  
 * At any given time, the session may be involved in either a 
 * local transaction or a global transaction, but not both:
 * <ul>
 * <li> While a session is open, that is, in a 
 * local transaction, its resource manager may not start work in 
 * a branch of a global transaction.</p>  
 *
 * <li>If a resource manager is
 * performing work in a transcation branch, its session cannot begin
 * a local transaction.
 * </ul>
 *
 * <p>Between when the resource manager starts work in a transaction 
 * branch and when it ends work in the branch, you can perform Objectivity/DB 
 * operations just as you would do during a local transaction.  For example, 
 * you can create, find, modify, and delete persistent objects and storage 
 * objects in the connected federated database.
 * 
 * <p>The resource-manager object <i>belongs to</i> its session.
 * While the resource manager is performing work in a branch of a global 
 * transaction, the local representation of every persistent 
 * object and storage object that you retrieve or create also belongs to the 
 * session. 
 * Objectivity for Java does not allow these objects 
 * to interact with any object that belongs to a different session; see
 * <A HREF="../../../../guide/jgdApplication.html#Isolation">
 * Object Isolation</A>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * 
 * <TABLE BORDER=1 CELLPADDING=3 CELLSPACING=0 WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Controlling a Transaction&nbsp;Branch</b></td>
 *     <td>
 *     <a href="#start(javax.transaction.xa.Xid, int)">start(Xid, int)</a><br>
 *     <a href="#end(javax.transaction.xa.Xid, int)">end(Xid, int)</a><br>
 *     <a href="#prepare(javax.transaction.xa.Xid)">prepare(Xid)</a><br>
 *     <a href="#commit(javax.transaction.xa.Xid, boolean)">commit(Xid, boolean)</a><br>
 *     <a href="#rollback(javax.transaction.xa.Xid)">rollback(Xid)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 *     <td>
 *     <a href="#recover(int)">recover(int)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 *     <td>
 *     <a href="#isSameRM(javax.transaction.xa.XAResource)">isSameRM(XAResource)</a><br>
 *     </td></tr>
 * </table>
 */
@Deprecated
final public class XATransaction implements javax.transaction.xa.XAResource {

    private transient PXATransaction persistor ;
    private transient Database database ;  // for isSameRM()

    /** 
     * Reserved for internal use; to obtain an Objectivity/DB transaction 
     * resource manager, call the
     * <a href="../db/app/Session.html#getXAResource()">
     * <tt>getXAResource</tt></a> method of a session.
     */
    public XATransaction(PXATransaction _persistor, Database _database) {
        persistor = _persistor ; 
        database = _database ;
    }
    
    /** 
     * Commits the Objectivity/DB transaction being performed in the specified 
     * transaction branch.
     *
     * <p>The transaction manager calls this method after all branchs of the 
     * global transaction have been successfully prepared.  The transaction 
     * manager commits the global transaction by directing the resource 
     * manager for each transaction branch to commit that branch.</p>
	 *
	 * @param 	 xid	The transaction-branch identifier.</p>
	 *
	 * @param 	 onePhase	True to use a one-phase 
     * commit protocol; false to use two-phase commit.
     *
     * <P>A one-phase commit can be performed only if this resource manager
     * started work in the specified transaction branch, beginning the 
     * Objectivity/DB transaction.  A two-phase commit can be performed only 
     * if the specified transaction branch has already been prepared.</p>
	 *
	 * @exception	XAException 	If the Objectivity/DB transaction cannot 
     * be committed. The error code may be one  of the following constants 
     * defined in the <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>A catastrophic error occurred in 
     * committing;  this resource manager can never commit the Objectivity/DB 
     * transaction branch and cannot hold the Objectivity/DB 
     * transaction in a prepared state.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable.</dd>
     *  <dt><tt>XAER_NOTA</tt></dt> <dd>The specified transaction branch is 
     * not know to this resource manager.</dd>
     *  <dt><tt>XAER_INVAL</tt></dt> <dd>Invalid parameters were specified.</dd>
     *  <dt><tt>XAER_PROTO</tt></dt> <dd>This method was called in an improper 
     * context.</dd>
     *  <dt><tt>XA_RB<i>error</i></tt></dt> <dd>One-phase commit failed. This 
     * resource manager has rolled back the branch's work, that is, it 
     * has aborted the Objectivity/DB transaction.</dd>
     * </dd></dl></dl></p>
     *
     * @see     #prepare(Xid)
     * @see     #rollback(Xid)
	 */
    public void commit(Xid xid, boolean onePhase) throws XAException {
    /* Only commit Xid's that have come back from a prepare() */
        debugLevel1("<< Objectivity >> CALLING " + this + ".commit().") ;
        getPersistor().commit(xid, onePhase) ;
    }

	/**
	 * Ends work in the specified transaction branch. 
	 *
     * <p>The transaction manager calls this method when the 
     * application has completed its work in the transaction branch, or needs 
     * to suspend the branch.</p>
	 *
	 * <p>After this method has been called, no more Objectivity/DB 
     * operations may be performed in the current Objectivity/DB 
     * transaction.</p> 
     *
	 * @param 	 xid	The transaction-branch identifier.</p>
	 *
	 * @param 	 flags	Flag that indicates what action 
     * to take; one of the following constants defined in the
	 * <tt>javax.transaction.xa.XAResource</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>TMSUCCESS</tt></dt> <dd>End work in the transaction branch 
     * successfully. Disassociate this resource 
     * manager from the specified transaction branch.</dd>
     *  <dt><tt>TMFAIL</tt></dt> <dd>End work in the transaction branch  
     * unsuccessfully. Abort the Objectivity/DB transaction  and disassociate 
     * this resource manager from the specified transaction branch.</dd>
     *  <dt><tt>TMSUSPEND</tt></dt> <dd>Temporarily suspend the specified 
     * transaction branch in an incomplete state. The branch can be resumed 
     * with a call to {@link #start <tt>start</tt>} that specifies the
     * <tt>TMRESUME</tt> flag.</dd>
     * </dd></dl></dl></p>
	 *
	 * @exception	XAException 	If an error occurred.
     * The error code may be one  of the following constants defined in the
	 * <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>An error occurred in disassociating 
     * this resource manager from the transaction branch.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable.</dd>
     *  <dt><tt>XAER_NOTA</tt></dt> <dd>The specified transaction branch is 
     * not know to this resource manager.</dd>
     *  <dt><tt>XAER_INVAL</tt></dt> <dd>Invalid parameters were specified.</dd>
     *  <dt><tt>XAER_PROTO</tt></dt> <dd>This method was called in an improper 
     * context.</dd>
     *  <dt><tt>XA_RB<i>error</i></tt></dt> <dd>This resource manager is 
     * dissociated from the transaction branch and has marked the branch as 
     * roll-back only.</dd>
     * </dd></dl></dl></p>
     *
     * @see     #start(Xid, int)
     * @see     #prepare(Xid)
	 */
    public void end(Xid xid, int flags) throws XAException {
        debugLevel1("<< Objectivity >> CALLING " + this + ".end(), " + getXAFlags(flags)) ;
        getPersistor().end(xid, flags) ;
    }

	/**
	 * Reserved for future use; you should not call this method.</p>
	 *
	 * @exception	XAException 	Always, indicating that this method is 
     * not supported.
	 */
    public void forget(Xid xid) throws XAException {
        debugLevel3("<< Objectivity >> CALLING " + this + ".forget().") ;
        getPersistor().forget(xid) ;
    }

	/**
	 * Reserved for future use; you should not call this method.</p>
	 */
    public int getTransactionTimeout() {
        return getPersistor().getTransactionTimeout() ;
    }

	/**
	 * Tests whether this resource manager is the same as the specified
	 * resource manager.</p>
	 *
	 * @param 	 xares	The resource manager to be 
     * compared.</p>
	 *
	 * @return		True if <tt><i>xares</i></tt> is the same as this 
     * resource manager; otherwise, false.</p>
	 *
	 * @exception	XAException 	If an error occurred.
     * The error code may be one  of the following constants defined in the
	 * <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>An error occurred comparing the two 
     * resource managers.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable.</dd>
     * </dd></dl></dl></p>
	 */
    public boolean isSameRM(XAResource xares) throws XAException {  // ?????
        // should not go through persistor
        boolean temp = false ;
        if (xares instanceof XATransaction) {
            //temp = (database == ((XAResource)xares).getDatabase()) ;
            temp = true ;
        }
        debugLevel3("<< Objectivity >> CALLING " + this + ".isSameRM(): returning " + temp) ;
        return temp ;
    }

	/**
	 * Prepares the specified transaction branch for commit.
	 *
     * <p>The transaction manager calls this method after all branchs of the 
     * global transaction have ended work.  The transaction 
     * manager prepares the global transaction by directing the resource 
     * manager for each transaction branch to prepare that branch.
     * If all branches are successfully 
     * prepared, each branch can be committed, thus committing the global 
     * transaction.  If preparation of any branch fails, all branches must be 
     * rolled back.</p>
	 *
	 * @param 	 xid	The transaction-branch identifier.</p>
	 *
	 * @return		A return code indicating the outcome;
	 * one of the following constants defined in the
	 * <tt>javax.transaction.xa.XAResource</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>XA_OK</tt></dt> <dd>The Objectivity/DB transaction has been 
     * prepared.</dd> 
     *
     *  <dt><tt>XA_RDONLY</tt></dt> <dd>The Objectivity/DB transaction was 
     * read-only and has been committed.</dd>
     * </dd></dl></dl></p>
     *
	 * @exception	XAException 	If an error occurred.
     * The error code may be one of the following constants defined in the
	 * <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>An error occurred in preparing; the 
     * transaction branch may or may not be prepared.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable; the 
     * transaction branch may or may not be prepared.</dd>
     *  <dt><tt>XAER_NOTA</tt></dt> <dd>The specified transaction branch is 
     * not know to this resource manager.</dd>
     *  <dt><tt>XAER_INVAL</tt></dt> <dd>Invalid parameters were specified.</dd>
     *  <dt><tt>XAER_PROTO</tt></dt> <dd>This method was called in an improper 
     * context.</dd>
     *  <dt><tt>XA_RB<i>error</i></tt></dt> <dd>This resource manager 
     * has rolled back the branch's work, that is, it 
     * has aborted the Objectivity/DB transaction.  This resource manager is 
     * dissociated from the transaction branch and has marked the branch as 
     * roll-back only.</dd>
     * </dd></dl></dl></p>
     *
     * @see     #end(Xid, int)
     * @see     #commit(Xid, boolean)
     * @see     #rollback(Xid)
	 */
    public int prepare(Xid xid) throws XAException {
        debugLevel1("<< Objectivity >> CALLING " + this + ".prepare().") ;
        return getPersistor().prepare(xid) ;
    }

	/**
	 * Gets identifiers for the transaction branches that this resource 
     * manager has prepared.
	 *
	 * <p>During the recovery process, the transaction manager obtains 
     * identifiers for prepared branches from this resource manager in a 
     * <i>recovery scan</i> that consists of one or more calls to this 
     * method. At the start of the scan, the resource manager returns 
     * transaction-branch identifiers starting with the first one on its 
     * internal list of identifiers.  If the resource manager does not return 
     * all identifiers in its list, it keeps track of the last identifier it 
     * returned so that it can continue the scan starting with the next 
     * identifier in its list.  The <tt><i>flags</i></tt> parameter
     * indicates whether this methods should perform the entire scan, 
     * start the scan, continue the scan, or finish the scan.</p>
	 *
	 * @param 	 flag	Flag that indicates what portion 
     * of the scan to perform in this method call; one of the following values,
     * using constants defined in the
	 * <tt>javax.transaction.xa.XAResource</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>TMSTARTRSCAN | TMENDRSCAN</tt></dt> 
     * <dd>Perform the entire scan;  
     * that is, return all transaction-branch identifiers.</dd>
     *  <dt><tt>TMSTARTRSCAN</tt></dt>
     * <dd>Begin the scan, but do not necessarily 
     * return all transaction-branch identifiers.</dd>
     *  <dt><tt>TMNOFLAGS</tt></dt>
     * <dd>Continue the scan, but do not necessarily 
     * return all remaining transaction-branch identifiers.</dd>
     *  <dt><tt>TMENDRSCAN</tt></dt>
     * <dd>Finish the scan; return all remaining 
     * transaction-branch identifiers.</dd>
     * </dd></dl></dl></p>
	 *
	 * @return  An array containing the transaction-branch identifiers in the 
     * specified portion of this resource manager's list of prepared 
     * branches.</p>
	 *
	 * @exception	XAException 	If an error occurred.
     * The error code may be one  of the following constants defined in the
	 * <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>An error occurred in identifying the 
     * prepared transaction branches.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable.</dd>
     *  <dt><tt>XAER_INVAL</tt></dt> <dd>Invalid parameters were specified.</dd>
     *  <dt><tt>XAER_PROTO</tt></dt> <dd>This method was called in an improper 
     * context.</dd>
     * </dd></dl></dl></p>
     *
     * @see     #prepare(Xid)
	 */
    public Xid[] recover(int flag) throws XAException {
        debugLevel3("<< Objectivity >> CALLING " + this + ".recover(), " + getXAFlags(flag)) ;
        return getPersistor().recover(flag) ;
    }

	/**
	 * Rolls back work performed in the specified transaction branch.
	 *
	 * <p>The transaction manager calls this method when the global 
     * transaction cannot be completed successfully, typically because 
     * at least one  
     * resource manager failed to prepare its transaction branch. This 
     * method aborts the  
     * Objectivity/DB transaction that was performed in the specified 
     * transaction branch.</p>
	 *
	 * @param 	 xid	The transaction-branch identifier.</p>
	 *
	 * @exception	XAException 	If an error occurred.
     * The error code may be one  of the following constants defined in the
	 * <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>An error occurred in aborting 
     * the Objectivity/DB transaction.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable.</dd>
     *  <dt><tt>XAER_NOTA</tt></dt> <dd>The specified transaction branch is 
     * not know to this resource manager.</dd>
     *  <dt><tt>XAER_INVAL</tt></dt> <dd>Invalid parameters were specified.</dd>
     *  <dt><tt>XAER_PROTO</tt></dt> <dd>This method was called in an improper 
     * context.</dd>
     *  <dt><tt>XA_RB<i>error</i></tt></dt> <dd>This resource manager had 
     * previously aborted the Objectivity/DB transaction and  marked the 
     * branch as roll-back only.</dd>
     * </dd></dl></dl></p>
     *
     * @see     #prepare(Xid)
     * @see     #commit(Xid, boolean)
	 */
    public void rollback(Xid xid) throws XAException {
        debugLevel1("<< Objectivity >> CALLING " + this + ".rollback().") ;
        getPersistor().rollback(xid) ;
    }

	/**
	 * Reserved for future use; you should not call this method.</p>
	 */
    public boolean setTransactionTimeout(int seconds) {
        return getPersistor().setTransactionTimeout(seconds) ;
    }

	/**
	 * Starts work in the specified transaction branch.
	 *
	 * <p>The transaction manager calls this method to start or resume a 
     * transaction branch that consists of an Objectivity/DB transaction with 
     * the connected federated database. </p>
	 *
	 * @param 	 xid	The transaction-branch identifier.</p>
	 *
	 * @param 	 flags	Flag that indicates what action 
     * to take; one of the following constants defined in the
	 * <tt>javax.transaction.xa.XAResource</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>TMNOFLAGS</tt></dt> <dd>Start a new transaction branch; begin 
     * the Objectivity/DB transaction. </dd>
     *  <dt><tt>TMRESUME</tt></dt> <dd>Resume a transaction banch that was 
     * suspended by a call to  the {@link #end <tt>end</tt>} method that 
     * specified the <tt>TMSUSPEND</tt> flag.</dd>
     * </dd></dl></dl></p>
	 *
	 * @exception	XAException 	If an error occurred.
     * The error code may be one  of the following constants defined in the
	 * <tt>javax.transaction.xa.XAException</tt> class:
     * <dl><dd><dl>
     *  <dt><tt>XAER_RMERR</tt></dt> <dd>An error occurred in starting or 
     * resuming the Objectivity/DB transaction or associating 
     * this resource manager with the transaction branch.</dd> 
     *  <dt><tt>XAER_RMFAIL</tt></dt> <dd>An error occurred that makes this 
     * resource manager unavailable.</dd>
     *  <dt><tt>XAER_DUPID</tt></dt> <dd>Attempt to start a transaction 
     * branch with a transaction-branch identifier that is already in 
     * use.</dd> 
     *  <dt><tt>XAER_NOTA</tt></dt> <dd>Attempt to resume a transaction 
     * branch that is not know to this resource manager.</dd>
     *  <dt><tt>XAER_INVAL</tt></dt> <dd>Invalid parameters were specified.</dd>
     *  <dt><tt>XAER_PROTO</tt></dt> <dd>This method was called in an improper 
     * context.</dd>
     * </dd></dl></dl></p>
     *
     * @see     #end(Xid, int)
	 */
    public void start(Xid xid, int flags) throws XAException {
        debugLevel1("<< Objectivity >> CALLING " + this + ".start(), " + getXAFlags(flags)) ;
        //new RuntimeException("<< Objectivity >> CALLING " + this + ".start().").printStackTrace() ;
        getPersistor().start(xid, flags) ;
    }

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public boolean isOpen() {
        return getPersistor().isOpen() ;
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public String getXAFlags(int flags) {
        String returnString = "UNASSIGNED" ;
        
        if (flags == 0x00800000){
            returnString = new String("TMENDRSCAN, " + Thread.currentThread());
        }
        else if (flags == 0x20000000){
            returnString = new String("TMFAIL, " + Thread.currentThread());
        }
        else if (flags == 0x00200000){
            returnString = new String("TMJOIN, " + Thread.currentThread());
        }
        else if (flags == 0x00000000){
            returnString = new String("TMNOFLAGS, " + Thread.currentThread());
        }
        else if (flags == 0x40000000){
            returnString = new String("TMONEPHASE, " + Thread.currentThread());
        }
        else if (flags == 0x08000000){
            returnString = new String("TMRESUME, " + Thread.currentThread());
        }
        else if (flags == 0x01000000){
            returnString = new String("TMSTARTRSCAN, " + Thread.currentThread());
        }
        else if (flags == 0x04000000){
            returnString = new String("TMSUCCESS, " + Thread.currentThread());
        }
        else if (flags == 0x02000000){
            returnString = new String("TMSUSPEND, " + Thread.currentThread());
        }
        else if (flags == 0x00000003){
            returnString = new String("XA_RDONLY, " + Thread.currentThread());
        }
        else if (flags == 0){
            returnString = new String("XA_OK, " + Thread.currentThread());
        }
        return returnString ;
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized void setPersistor(PXATransaction persistor)
        { this.persistor = persistor ; }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized PXATransaction getPersistor() { 
        if (persistor == null)
            throw new ObjyRuntimeException("Can not access this object.  It's session was previously terminated.") ;
        return persistor ; 
    }
    
    //public Session getSession() {
    //    return getPersistor().getSession() ; 
    //}
    
    Database getDatabase() {
        return database ;  // for isSameRM()
    }
    
    void info(String message) {
        XADataSource.info(message) ;
    }

    void debugLevel1(String message) {
        XADataSource.debugLevel1(message) ;
    }

    void debugLevel2(String message) {
        XADataSource.debugLevel2(message) ;
    }

    void debugLevel3(String message) {
        XADataSource.debugLevel3(message) ;
    }


	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void end(int flags) throws XAException {
        getPersistor().end(flags) ;
    }
}