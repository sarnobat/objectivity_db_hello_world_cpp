package com.objy.query.expression;
/**
 * Represents an unsigned integer literal value node.
 *
 */
public class UIntLiteralValueExpression extends LiteralValueExpression 
{
    /**
     * Constructs an unsigned integer literal value node.
     */
    public UIntLiteralValueExpression() 
    {
        this(Binding.create());
    }

    /**
     * Constructs an unsigned integer literal value node with a long value.
     */
    public UIntLiteralValueExpression(long value) 
    {
        setIdAfterNullCheck(Binding.create(value));
    }

    UIntLiteralValueExpression(long id, boolean dummyArg) 
    {
        setId(id);
    }
    
    /**
     * Returns the expression type (oocUIntLiteralValueExpression).
     */
    @Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.UIntLiteralValueExpression; 
    }

    /**
     * Returns the value.
     */
    public long getValue() 
    {
        throwExceptionIfInvalidOrClosed(getId());
        return Binding.getValue(getId());
    }

    /**
     * Sets the value.
     */
    public void setValue(long val) 
    {
        throwExceptionIfInvalidOrClosed(getId());
        Binding.setValue(getId(), val);
    }

    @Override
    public String toString()
    {
    	return Long.toString(getValue());
    }
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitUIntLiteralValue(this);
    }
    
    static class Binding
    {
        private static native long create();
        private static native long create(long val);
        private static native long getValue(long id);
        private static native void setValue(long id, long value);
    }
}
