/*
 * @(#)PersistentEventInfo.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

/**
 * <p>Defines constants that indicate why a persistent event occurred.</p>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr><td valign=top><a name="PersistentEventReason"><b>Persistent-event reasons</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify why a persistent event occurred.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#EVENT_COMMIT">EVENT_COMMIT</a><br>
 *     <a href="#EVENT_ABORT">EVENT_ABORT</a><br>
 *     <a href="#EVENT_CHECKPOINT">EVENT_CHECKPOINT</a><br>
 *     <a href="#EVENT_CHECKPOINT_DOWNGRADE">EVENT_CHECKPOINT_DOWNGRADE</a><br>
 *     <a href="#EVENT_WRITE">EVENT_WRITE</a><br>
 *     <a href="#EVENT_WRITE_BEFORE_COPY_OBJ">EVENT_WRITE_BEFORE_COPY_OBJ</a><br>
 *     <a href="#EVENT_FLUSH_FD">EVENT_FLUSH_FD</a><br>
 *     <a href="#EVENT_FLUSH_DB">EVENT_FLUSH_DB</a><br>
 *     <a href="#EVENT_FLUSH_CONTAINER">EVENT_FLUSH_CONTAINER</a><br>
 *     <a href="#EVENT_XAEND">EVENT_XAEND</a><br>
 *     <a href="#EVENT_XAPREPARE">EVENT_XAPREPARE</a><br>
 *     <a href="#EVENT_XACOMMIT">EVENT_XACOMMIT</a><br>
 *     <a href="#EVENT_XAABORT">EVENT_XAABORT</a>
 * </td>
 * </table>
 */
public interface PersistentEventInfo
{
	/**
	 * Persistent-event reason: The deactivate or pre-write event occurred 
     * because the current transaction was committed.
	 */
    int EVENT_COMMIT                       = 0 ;

	/**
	 * Persistent-event reason: The deactivate event occurred because the 
     * current transaction was aborted.
	 */
    int EVENT_ABORT                        = 1 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * checkpoint operation with no downgrade of locks.
	 */
    int EVENT_CHECKPOINT                   = 2 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * checkpoint operation with write locks downgraded to read locks.
	 */
    int EVENT_CHECKPOINT_DOWNGRADE         = 3 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * call to a persistent object's <tt>write</tt> method
	 */
    int EVENT_WRITE                        = 4 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because a 
     * persistent object had to be written before being copied.
	 */
    int EVENT_WRITE_BEFORE_COPY_OBJ        = 5 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * flush operation on the federated database. 
	 */
    int EVENT_FLUSH_FD                     = 6 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * flush operation on a database.
	 */
    int EVENT_FLUSH_DB                     = 7 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * flush operation on a container.
	 */
    int EVENT_FLUSH_CONTAINER              = 8 ;

	/**
	 * Persistent-event reason: The deactivate or pre-write event occurred 
     * because the current global transaction was ended.
	 */
    int EVENT_XAEND                         = 9 ;
    
	/**
	 * Persistent-event reason: The deactivate or pre-write event occurred 
     * because the current global transaction was prepared.
	 */
    int EVENT_XAPREPARE                    = 10 ;
    
	/**
	 * Persistent-event reason: The deactivate or pre-write event occurred 
     * because the current global transaction was committed.
	 */
    int EVENT_XACOMMIT                     = 11 ;
    
	/**
	 * Persistent-event reason: The deactivate event occurred because the 
     * current global transaction was aborted.
	 */
    int EVENT_XAABORT                      = 12 ;
    
	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * flush at object creation.
	 */
    int EVENT_FLUSH_ON_CREATION            = 13 ;

	/**
	 * Persistent-event reason: The pre-write event occurred because of a 
     * automatic flush operation by a session.
	 */
    int EVENT_AUTO_FLUSH                   = 14 ;

	/**
	 * Reserved for internal use.
	 */
    int EVENT_MAX                          = 15 ;

}
