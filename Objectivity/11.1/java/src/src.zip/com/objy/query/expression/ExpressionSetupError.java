package com.objy.query.expression;
/**
 * Represents an expression setup error.
 *
 */
public class ExpressionSetupError extends AbstractExpression
{
    /**
     * Constructs an expression setup error with the ID. Reserved for internal use.
     */
    protected ExpressionSetupError(long id) 
    {
        setId(id);
    }

    /**
     * Returns the type of the error.
     * @return The type of expression setup error
     */
    public ExpressionSetupErrorType getErrorType() 
    {
        return ExpressionSetupErrorType.values()[Binding.getErrorType(mId)];
    }

    /**
     * Returns a description of the error.
     * @return The description
     */
    public String getDescription()
    {
        return Binding.getErrorDescription(mId);
    }

    /**
     * Returns the expression node that has the error or null if there is
     * no associated expression node.
     * @return The expression node
     */
    public Expression getExpression()
    {
        return Expression.getExpression(Binding.getExpression(mId));
    }

    /**
     * Returns the operand that has the error if applicable;
     * null otherwise.
     * @return The operand
     */
    public Expression getOperand()
    {
        return Expression.getExpression(Binding.getOperand(mId));
    }

    /**
     * Returns the next error or null if there are no more errors.
     * @return The expression setup error
     */
    public ExpressionSetupError getNextError()
    {
        long id = Binding.getNextError(mId);
        if (id == 0)
        {
            return null;
        }
        return (new ExpressionSetupError(id));
    }

    static class Binding
    {
        // Returns the error's type.
        private static native int getErrorType(long id);
        
        // Returns a description of the error.
        private static native String getErrorDescription(long id);
        
        // Returns the expression node that has the error or null if there is
        // no associated expression node.
        private static native long getExpression(long id);
        
        // Returns the operand that has the error if applicable;
        // null otherwise.
        private static native long getOperand(long id);
        
        // Get the next error or null if there are no more errors.
        private static native long getNextError(long id);
       
    }
}

