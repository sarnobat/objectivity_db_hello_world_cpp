/*
 * @(#)ooFDObj.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.ObjectNameNotUniqueException ;
import com.objy.db.ObjectNameNotFoundException ;

import com.objy.db.app.storage.ooAPObj;
import com.objy.db.app.storage.ooDBObj;
import com.objy.db.iapp.PooFDObj ;
import com.objy.db.iapp.PooObj ;
import com.objy.query.ObjectQualifier;



/**
 * Represents an Objectivity/DB federated database.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>A <i>federated database</i> is the highest level in the Objectivity/DB
 * logical storage hierarchy; within this hierarchy, each federated database logically contains one or more 
 * databases.   
 *
 * <p>A federated database always contains one database, called its system 
 * database, which is physically maintained in a <i>system-database file</i>,
 * The system database stores the schema for the federated database, a 
 * catalog of all the databases, any indexes created for the entire federated database
 * and any scope names of persistent objects 
 * named in the scope of the federated database. 
 * Configuration information for the federated database is maintained in a 
 * second file (the <i>boot file</i>), along with various other attributes. 
 * The simple name of the boot file serves as the federated database's system 
 * name. A federated database also has an integer identifier that 
 * distinguishes it from all other federated databases using the same the 
 * lock server.  It may contain a default database and
 * one or more application-specific databases.
 *
 * <p>For additional information about using federated databases,
 * see <A HREF="../../../../../guide/jgdStorage.html#Federated Databases">
 * Federated Databases</A>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 * <TD><A HREF="#getSession()">getSession()</A><BR>
 * 	<A HREF="#getName()">getName()</A><BR>
 * 	<A HREF="#getDefaultDB()">getDefaultDB()</A> <BR>
 * 	<A HREF="#getLockServerName()">getLockServerName()</A><BR>
 * 	<A HREF="#getNumber()">getNumber()</A><BR>
 * 	<A HREF="#getPageSize()">getPageSize()</A><br>
 * 	<A HREF="#dumpCatalog()">dumpCatalog()</A>
 * </td></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Locking</B></TD>
 * <TD><A HREF="#lock(int)">lock(int)</A><BR>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Updating&nbsp;the Objectivity/DB&nbsp;cache</B></TD>
 * <TD><A HREF="#flush()">flush()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Working&nbsp;With&nbsp;Named&nbsp;Roots</B></TD>
 * <TD><A HREF="#bind(java.lang.Object, java.lang.String)">bind(Object, String)<BR>
 * </A><A HREF="#unbind(java.lang.String)">unbind(String)<BR>
 * </A><A HREF="#lookup(java.lang.String)">lookup(String)<BR>
 * </A><A HREF="#rootNames()">rootNames()</A> </TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Working&nbsp;With Scope-Named&nbsp;Objects</B></TD>
 * <TD><a href="#nameObj(java.lang.Object, java.lang.String)">nameObj(Object, String)</a><br>
 * 	<a href="#unnameObj(java.lang.Object)">unnameObj(Object)</a><br>
 * 	<A HREF="#lookupObj(java.lang.String)">lookupObj(String)</A><br>
 * 	<A HREF="#lookupObj(java.lang.String, int)">lookupObj(String, int)</A><br>
 * 	<a href="#lookupObjName(java.lang.Object)">lookupObjName(Object)</a>
 * 	</TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Contained&nbsp;Objects</B></TD>
 *
 * <TD><A HREF="#scan(java.lang.String)">scan(String)</A><BR>
 * 	<A HREF="#scan(java.lang.String, java.lang.String)">scan(String, String)</A><br>
 *  <A HREF="#scan(java.lang.String, com.objy.query.ObjectQualifier)">scan(String, ObjectQualifier)</A><br>
 * 	<A HREF="#containedDBs()">containedDBs()</A><br>
 *  <A HREF="#parallelScan(java.lang.String, java.lang.String)">parallelScan(String, String)</A><br>
 *  <A HREF="#parallelScan(java.lang.String, com.objy.query.ObjectQualifier)">parallelScan(String, ObjectQualifier)</A><br>  
 *  <A HREF="#parallelScan(java.lang.String, java.lang.String, com.objy.db.app.QuerySplitter)">parallelScan(String, String, QuerySplitter)</A><br>
 *  <A HREF="#parallelScan(java.lang.String, com.objy.query.ObjectQualifier, com.objy.db.app.QuerySplitter)">parallelScan(String, ObjectQualifier, QuerySplitter)</A>  
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Objects by Object&nbsp;Identifier</B></TD>
 *
 * <TD>
 *  <A HREF="#objectFrom(com.objy.db.app.ooId)">objectFrom(ooId)</A><br>
 *  <A HREF="#objectFrom(com.objy.db.app.ooId, int)">objectFrom(ooId, int)</A><br>
 *  <A HREF="#objectFrom(java.lang.String)">objectFrom(String)</A><br>
 *  <A HREF="#objectFrom(java.lang.String, int)">objectFrom(String, int)</A><br>
 *  <A HREF="#objectFrom(long, long)">objectFrom(long, long)</A><br>
 *  <A HREF="#objectFrom(long, long, int)">objectFrom(long, long, int)</A>
 * </TD></TR>
 *
 * <tr><td VALIGN="top" WIDTH="1%"><B>Converting&nbsp;Objects</b></td><td>
 * 	<a href="#convertObjects()">convertObjects()</a><br>
 * 	<a href="#convertObjects(boolean)">convertObjects(boolean)</a><br>
 * 	<a href="#upgradeObjects()">upgradeObjects()</a><br>
 * 	<a href="#upgradeObjects(boolean)">upgradeObjects(boolean)</a>
 * </td></tr>
 *
 * 
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Internal Persistent&nbsp;Objects</B></TD>
 * <TD>
 *   	<A HREF="#deleteReference(java.lang.Object)">deleteReference(Object)</A><BR>
 *   	<A HREF="#moveReference(java.lang.Object, java.lang.Object)">moveReference(Object, Object)</A>
 * </TD></TR>
 *
 * 
  * <TR><td VALIGN="top" WIDTH="1%"><B>Testing<br><i>(Backward compatibility)</i></B></TD>
 * <TD><A HREF="#hasDB(java.lang.String)">hasDB(String)</A><BR>
 *     <A HREF="#hasDB(int)">hasDB(int)</A><BR>
 *     <a href="#hasIndex(java.lang.String)">hasIndex(String)</a><br>
 *     <a href="#indexConsistent(java.lang.String)">indexConsistent(String)</a><br>
 *  	<A HREF="#hasAP(java.lang.String)">hasAP(String)</A>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><A NAME="ooDBObj"></A><B>Working&nbsp;With&nbsp;Databases<br><i>(Backward compatibility)</i></B></TD>
 *
 * <TD><A HREF="#getDefaultDB()">getDefaultDB()</A> <BR>
 * 	<A HREF="#newDB(java.lang.String)">newDB(String)</A><BR>
 * 	<A HREF="#newDB(java.lang.String, long, long, java.lang.String, java.lang.String, long)">newDB(String, long, long, String, String, long)</A><BR>
 * 	<A HREF="#newDB(java.lang.String, long, long, java.lang.String, java.lang.String, long, long)">newDB(String, long, long, String, String, long, long)</A><BR>
 * 	<A HREF="#newDB(java.lang.String, long, long, java.lang.String, java.lang.String, long, long, int)">newDB(String, long, long, String, String, long, long, int)</A><BR>
 * 	<A HREF="#lookupDB(java.lang.String)">lookupDB(String)</A><BR>
 * 	<A HREF="#lookupDB(int)">lookupDB(int)</A><BR>
 * 	<A HREF="#hasDB(java.lang.String)">hasDB(String)</A><BR>
 * 	<A HREF="#hasDB(int)">hasDB(int)</A><BR>
 * 	<A HREF="#containedDBs()">containedDBs()</A>
 * </TD></TR>
 * 
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Indexes<br><i>(Backward compatibility)</i></b></td>
 * 	<td>
 *     <a href="#addIndex(java.lang.String, java.lang.String, java.lang.String)">addIndex(String, String, String)</a><br>
 *     <a href="#addUniqueIndex(java.lang.String, java.lang.String, java.lang.String)">addUniqueIndex(String, String, String)</a><br>
 *     <a href="#dropIndex(java.lang.String)">dropIndex(String)</a><br>
 *     <a href="#hasIndex(java.lang.String)">hasIndex(String)</a><br>
 *     <a href="#indexConsistent(java.lang.String)">indexConsistent(String)</a>
 * 	</td></tr>
 *
*  <TR><td VALIGN="top" WIDTH="1%"><A NAME="ooAPObj"></A><B>Working&nbsp;With Autonomous&nbsp;Partitions<BR><I>(HA)</I><br><i>(Backward compatibility)</i></B>
 *  </TD>
 *  <TD><A HREF="#newAP(java.lang.String, java.lang.String, java.lang.String, java.lang.String)">newAP(String, String, String, String)</A><BR>
 *  	<A HREF="#newAP(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String)">newAP(String, String, String, String, String, String, String, String)</A><BR>
 *  	<A HREF="#newAP(java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, java.lang.String, int)">newAP(String, String, String, String, String, String, String, String, int)</A><BR>
 *  	<A HREF="#lookupAP(java.lang.String)">lookupAP(String)</A> <BR>
 *  	<A HREF="#containedAPs()">containedAPs()</A> <BR>
 *  	<A HREF="#hasAP(java.lang.String)">hasAP(String)</A> <BR>
 *  	<A HREF="#getBootAP()">getBootAP()</A>
 *  </TD></TR>
 *
 * </TABLE>
 *
 */

final public class ooFDObj
    extends ooAbstractObj
{
    private PooFDObj persistor ;

    private ooFDObj()
        { }

	/**
	 * Reserved for internal use; to obtain a federated-database object, call the
	 * <a href="Session.html#getFD()"><tt>getFD</tt></a> method of a
	 * session.
	 *
	 * <p>You should not use this constructor directly.</p>
	 */
    public ooFDObj(PooFDObj persistor)
        { this.persistor = persistor ; }

	/**
	 * Gets the session that created this federated-database object.</p>
	 *
	 * @return		The session that created this federated-database object.
	 */
    public Session getSession()
        { return persistor().getSession() ; }

	/**
     * Gets the identifier of this federated database.</p>
	 *
     * @return      The identifier of this federated database.
	 */
    public long getNumber()
        { return persistor().getNumber() ; }

	/**
     * Gets the name of the host running the lock-server process
     * for this federated database.</p>
	 *
     * @return     The name of the host running the lock-server process.
	 */
    public String getLockServerName()
        { return persistor().getLockServerName() ; }

	/**
     * Gets the system name of this federated database.</p>
	 *
     * @return     The system name of this federated database.
	 */
    public String getName()
        { return persistor().getName() ; }

	/**
     * Gets the page size of this federated database's system database.</p>
	 *
     * @return      The system database's page size.
	 */
    public long getPageSize()
        { return persistor().getPageSize() ; }

	/**
     * Explicitly places the specified kind of lock on this federated database.
	 *
	 * <p>A read lock prevents other transactions from concurrently getting 
     * read/write access to the federated database (or its contents). 
     * An exclusive lock prevents all concurrent access to the federated 
     * database; no other application connected to the same federated 
     * database can concurrently begin a transaction.
     *
     * <p>The lock mode is limited by the open mode of the
     * this federated database object's session.
     * A session open mode of <tt>openReadWrite</tt> permits lock modes of
     * <tt>WRITE</tt> or <tt>READ</tt>; a session open mode of <tt>openReadOnly</tt>
     * only permits the lock mode <tt>READ</tt>.
	 *
	 * <p>If this federated database is already locked, you can call this method to upgrade a
	 * read lock to an exclusive lock, but not to downgrade an exclusive lock to a
	 * read lock.</p>
     *
     * @param 	 mode	The kind of lock to place on
     * this federated
     * database; one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Place a read lock on the federated database.</dd>
	 *  <dt><tt>WRITE</tt><dd>Place an exclusive lock on the federated database.</dd>
	 * </dd></dl></dl></p>
     *
     * @exception   com.objy.db.ObjyRuntimeException
     * If you try to specify the lock mode <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>.
	 *
	 */
    public void lock(int mode)
        { persistor().lock(mode) ; }

	/**
     * Names the specified object with the specified root name in this
     * federated database.
     *
     * <p>Giving an object a root name makes the object persistent. The named object
     * is made persistent immediately; all transient objects reachable from
     * the named object are made persistent on transaction commit.</p>
	 *
     * @param 	 object  The object being named.</p>
	 *
     * @param 	 name    The root name for the object.
     * This name can be any valid Java string and must be unique
     * within the root dictionary of this federated database.</p>
	 *
     * @exception   ObjectNameNotUniqueException    If the name already exists in the root
     * dictionary.</p>
     *
     * @see #unbind(String)
     * @see #lookup(String)
	 */
    public void bind(Object object, String name) throws ObjectNameNotUniqueException
        { persistor().bind(object, name) ; }

	/**
     * Removes a root name from this federated database.</p>
	 *
     * @param 	 name    The root name to be removed.</p>
	 *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
	 */
    public void unbind(String name) throws ObjectNameNotFoundException
        { persistor().unbind(name) ; }

	/**
     * Finds the object with the specified root name in this
	 * federated database.</p>
	 *
     * @param 	 name    The root name of the object.</p>
	 *
     * @return      The object with the specified root name. If this object
     * is the root of a graph of objects, only the root object is retrieved.
	 * The returned object is locked for read.</p>
	 *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
	 */
    public Object lookup(String name) throws ObjectNameNotFoundException
        { return persistor().lookup(name) ; }

	/**
     * Initializes an object iterator to find the root names maintained by this
	 * federated database.</p>
	 *
     * @return      An object iterator that finds all the root names
     * maintained by this federated database.
	 */
    public Iterator rootNames()
        { return persistor().rootNames() ; }

	/**
     * Finds the database with the specified system name in this
     * federated database.</p>
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 name    The system name of the 
     * database.</p> 
	 *
     * @return      The specified database.</p>
     *
     * @exception   ObjyRuntimeException    If this federated database
	 * does not have a database with the specified system name. You can call 
	 * <a href="#hasDB(java.lang.String)"><tt>hasDB(String)</tt></a>
	 * to test whether the specified database exists.</p>
	 * 
	 * 
	 */
    public ooDBObj lookupDB(String name)
        { return persistor().lookupDB(name) ; }

	/**
     * Finds the database with the specified integer identifier in this
     * federated database.</p>
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 dbId    The integer identifier of the 
     * database.</p> 
	 *
     * @return      The specified database.</p>
     *
     * @exception   ObjyRuntimeException    If this federated database
	 * does not have a database with the specified integer identifier. You can call 
	 * <a href="#hasDB(int)"><tt>hasDB(int)</tt></a>
	 * to test whether the specified database exists.</p>
	 */
    public ooDBObj lookupDB(int dbId)
        { return persistor().lookupDB(dbId) ; }

	/**
     * Creates a database in this federated database with the specified 
     * system name.
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>This method creates a new database with the following properties
	 * (in addition to the specified system name):
	 * 
	 * <ul type=disc>
     * <li> The database's default container initially has 4 pages and grows by 10% when required.
	 * 
	 * <li> The database file is in the same directory as the system-database file for this
     * federated database.
	 * 
     * <li>If Objectivity/DB High Availability (HA) is being used,
     * the weight of the first database image is 1.
	 * 
     * <li>The new database has a unique integer identifier assigned by Objectivity/DB.
	 * 
	 * <li> The database file uses the same storage-page size as this federated database's system database.
	 * </ul></p>
     *
     * <p>The new database is locked in write mode.</p>
	 * 
	 * 
	 * <p><b>Note:</b> The internal database format of the new database matches the
	 * internal database format of this federated database. 
	 * In particular, if this federated database was created prior to Objectivity/DB Release&nbsp;9.0,
	 * the new database is created with the pre-Release&nbsp;9.0 internal database format.</p>
	 *
     * @param 	 name    The system name of the database.
	 * The specified name:
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of all databases in the federated database.
     * </ul></p>
	 *
     * @return      A database object that represents the new
     * database. When the transaction is committed, the new database is
     * created in the federated database. If the transaction is aborted, the
     * returned object becomes a dead object and the database is not created
	 * in the federated database.</p>
	 *
     * @exception       ObjyRuntimeException    If this federated
	 * database already has a database
	 * with the specified name. You can call 
	 * <a href="#hasDB(java.lang.String)"><tt>hasDB(String)</tt></a>
	 * to test whether the specified database exists.</p>
	 *
	 */
    public ooDBObj newDB(String name)
        { return persistor().newDB(name) ; }

	/**
     * Creates a database in this federated database with the specified 
     * system name, properties for its default container, host and pathname 
     * for its database file, and image weight.
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *  
     * <p>This method creates a new database with the following properties
	 * (in addition to the properties specified by parameters):
	 * 
	 * <ul type=disc>
     * <li>The new database has a unique integer identifier assigned by Objectivity/DB.
	 * 
	 * <li> The database file uses the same storage-page size as this federated database's system database.
	 * </ul></p>
	 * 
     *
     * <p>The new database is locked in write mode.</p>
	 * 
	 * <p><b>Note:</b> The internal database format of the new database matches the
	 * internal database format of this federated database. 
	 * In particular, if this federated database was created prior to Objectivity/DB Release&nbsp;9.0,
	 * the new database is created with the pre-Release&nbsp;9.0 internal database format.</p>
	 * 
     * @param 	 name    The system name of the database.
	 * The specified name:
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of all databases in the federated database.
     * </ul></p>
	 *
     * @param 	 defaultContainerInitialPages    The initial number of storage pages
     * to allocate for the default container. The minimum recommended value is 2. The maximum value is 65534. 
	 * Specify 0 to use the system default value (4).</p>
	 *
     * @param 	 defaultContainerGrowth   The percentage by which the
     * default container
     * should grow when needed to accommodate more basic objects, expressed as a percentage
	 * of its current number of storage pages.
     * Specify 0 to use the system default value (10%).</p>
	 *
     * @param 	 hostName Data-server host on which to 
     * create the new database.  The designated host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>hostName</i></tt> is an empty string or null, the 
     * designated host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>pathName</i></tt> is a local path.
     * <li>The host implied by <tt><i>pathName</i></tt>, if <tt><i>pathName</i></tt> is an 
     * NFS mount name.
     * <li>The host of the system-database file, if <tt><i>pathName</i></tt> is also null.
     * </ul></p>
     *
     * <li>If <tt><i>pathName</i></tt> is a Windows UNC share name, <tt><i>hostName</i></tt> is 
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>hostName</i></tt> is used.</ul></p>
	 *
     * @param 	 pathName Pathname of the new database file on the designated host.
     * Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of the pathname must follow the naming conventions of 
     * the designated host.</p>
     * <li>If the designated host is a remote system, 
     * <tt><i>pathName</i></tt> must be fully qualified; otherwise, 
     * <tt><i>pathName</i></tt> may be either relative or  
     * fully qualified. </p> 
     * <li><tt><i>pathName</i></tt> may optionally include a filename for the database; if you omit the 
     * filename, it is generated automatically from the system names of the database and 
	 * the federated database.</p>
     * <li>This parameter may be null only if <tt><i>hostName</i></tt> is also null or an empty string; 
     * in this case, the directory of the system-database file is used.
     * </ul></p>
	 *
     * @param 	 weight  The weight of the first database image
     * if Objectivity/DB High Availability is being used. If HA is not
     * being used, you must specify 1.</p>
	 *
     * @return      A database object that represents the new
     * database. When the transaction is committed, the new database is
     * created in the federated database. If the transaction is aborted, the
     * returned object becomes a dead object and the database is not created
	 * in the federated database.</p>
     *
     * @exception       ObjyRuntimeException    If this federated
	 * database already has a database
	 * with the specified name. You can call 
	 * <a href="#hasDB(java.lang.String)"><tt>hasDB(String)</tt></a>
	 * to test whether the specified database exists.</p>
	 */
    public ooDBObj  newDB(
            String  name,
            long    defaultContainerInitialPages,
            long    defaultContainerGrowth,
            String  hostName,
            String  pathName,
            long    weight ) {
        return persistor().newDB(
            name, defaultContainerInitialPages, defaultContainerGrowth,
            hostName, pathName, weight) ;
    }
    
    /**
     * Creates a database in this federated database with the specified 
     * system name, properties for its default container, host and pathname 
     * for its database file, image weight, and database identifier.
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
	 * <p>The new database uses the same storage-page size as this federated database's system database.
	 * 	 
     * <p>The new database is locked in write mode.</p>
	 * 
	 * <p><b>Note:</b> The internal database format of the new database matches the
	 * internal database format of this federated database. 
	 * In particular, if this federated database was created prior to Objectivity/DB Release&nbsp;9.0,
	 * the new database is created with the pre-Release&nbsp;9.0 internal database format.</p>
	 * 
     * @param 	 name    The system name of the database.
	 * The specified name:
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of all databases in the federated database.
     * </ul></p>
	 *
     * @param 	 defaultContainerInitialPages    The initial number of storage pages
     * to allocate for the default container. The minimum recommended value is 2. The maximum value is 65534. 
	 * Specify 0 to use the system default value (4).</p>
	 *
     * @param 	 defaultContainerGrowth   The percentage by which the
     * default container
     * should grow when needed to accommodate more basic objects, expressed as
	 * a percentage of its current number of storage pages.
     * Specify 0 to use the system default value (10%).</p>
	 *
     * @param 	 hostName Data-server host on which to 
     * create the new database.  The designated host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>hostName</i></tt> is an empty string or null, the 
     * designated host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>pathName</i></tt> is a local path.
     * <li>The host implied by <tt><i>pathName</i></tt>, if <tt><i>pathName</i></tt> is an 
     * NFS mount name.
     * <li>The host of the system-database file, if <tt><i>pathName</i></tt> is also null.
     * </ul></p>
     *
     * <li>If <tt><i>pathName</i></tt> is a Windows UNC share name, <tt><i>hostName</i></tt> is 
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>hostName</i></tt> is used.</ul></p>
	 *
     * @param 	 pathName Pathname of the new database file on the designated host.
     * Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of the pathname must follow the naming conventions of 
     * the designated host.</p>
     * <li>If the designated host is a remote system, 
     * <tt><i>pathName</i></tt> must be fully qualified; otherwise, 
     * <tt><i>pathName</i></tt> may be either relative or  
     * fully qualified. </p> 
     * <li><tt><i>pathName</i></tt> may optionally include a filename for the database; if you omit the 
     * filename, it is generated automatically.</p>
     * <li>This parameter may be null only if <tt><i>hostName</i></tt> is also null or an empty string; 
     * in this case, the directory of the system-database file is used.
     * </ul></p>
	 *
     * @param 	 weight  The weight of the first database image
     * if Objectivity/DB High Availability is being used. If HA is not
     * being used, you must specify 1.</p>
     *
     * @param 	 userDBID    The application-assigned database 
     * identifier, expressed as a single integer. If you specify 0, the identifier is 
     * assigned by Objectivity/DB. You may not specify the identifier 1
     * or the identifier 65535, which are reserved by Objectivity/DB. The
     * maximum database identifier is 65534.</p>
     *
     * @return      A database object that represents the new
     * database. When the transaction is committed, the new database is
     * created in the federated database. If the transaction is aborted, the
     * returned object becomes a dead object and the database is not created
	 * in the federated database.</p>
     *
     * @exception       ObjyRuntimeException    If this federated
	 * database already has a database
	 * with the specified name. You can call 
	 * <a href="#hasDB(java.lang.String)"><tt>hasDB(String)</tt></a>
	 * to test whether the specified database exists.</p>
	 * 
     * @exception       ObjyRuntimeException    If this federated
	 * database already has a database
	 * with the specified database identifier. You can call 
	 * <a href="#hasDB(int)"><tt>hasDB(int)</tt></a>
	 * to test whether the specified database exists.</p>
	 * 
	 */
    public ooDBObj  newDB(
            String  name,
            long    defaultContainerInitialPages,
            long    defaultContainerGrowth,
            String  hostName,
            String  pathName,
            long    weight,
            long    userDBID ) {
        return persistor().newDB(
            name, defaultContainerInitialPages, defaultContainerGrowth,
            hostName, pathName, weight, userDBID) ;
    }

    /**
     * Creates a database in this federated database with the specified 
     * system name, properties for its default container, host and pathname 
     * for its database file, image weight, database identifier, and page
     * size.
     * 
	 * <p>
     * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>The new database is locked in write mode.</p>
	 * 
	 * <p><b>Note:</b> The internal database format of the new database matches the
	 * internal database format of this federated database. 
	 * In particular, if this federated database was created prior to Objectivity/DB Release&nbsp;9.0,
	 * the new database is created with the pre-Release&nbsp;9.0 internal database format.</p>
	 *
     * @param 	 name    The system name of the database.
	 * The specified name:
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of all databases in the federated database.
     * </ul></p>
	 *
     * @param 	 defaultContainerInitialPages    The initial number of 
	 * storage pages
     * to allocate for the default container. The minimum recommended value is 2. The maximum value is 65534. 
	 * Specify 0 to use the system default value (4).</p>
	 *
     * @param 	 defaultContainerGrowth   The percentage by which the
     * default container
     * should grow when needed to accommodate more basic objects,
	 * expressed as a percentage of its current number of storage pages.
     * Specify 0 to use the system default value (10%).</p>
	 *
     * @param 	 hostName Data-server host on which to 
     * create the new database.  The designated host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>hostName</i></tt> is an empty string or null, the 
     * designated host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>pathName</i></tt> is a local path.
     * <li>The host implied by <tt><i>pathName</i></tt>, if <tt><i>pathName</i></tt> is an 
     * NFS mount name.
     * <li>The host of the system-database file, if <tt><i>pathName</i></tt> is also null.
     * </ul></p>
     *
     * <li>If <tt><i>pathName</i></tt> is a Windows UNC share name, <tt><i>hostName</i></tt> is 
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>hostName</i></tt> is used.</ul></p>
	 *
     * @param 	 pathName Pathname of the new database file on the designated host.
     * Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of the pathname must follow the naming conventions of 
     * the designated host.</p>
     * <li>If the designated host is a remote system, 
     * <tt><i>pathName</i></tt> must be fully qualified; otherwise, 
     * <tt><i>pathName</i></tt> may be either relative or  
     * fully qualified. </p> 
     * <li><tt><i>pathName</i></tt> may optionally include a filename for the database; if you omit the 
     * filename, it is generated automatically.</p>
     * <li>This parameter may be null only if <tt><i>hostName</i></tt> is also null or an empty string; 
     * in this case, the directory of the system-database file is used.
     * </ul></p>
	 *
     * @param 	 weight  The weight of the first database image
    * if Objectivity/DB High Availability is being used. If HA is not
     * being used, you must specify 1.</p>
     *
     * @param 	 userDBID    The application-assigned database 
     * identifier, expressed as a single integer. If you specify 0, the identifier is 
     * assigned by Objectivity/DB. You may not specify the identifier 1
     * or the identifier 65535, which are reserved by Objectivity/DB. The
     * maximum database identifier is 65534.</p>
     * 
     * @param 	 pageSize    Storage-page size in bytes. Allowable 
	 * page sizes are integer multiples of 8 between 1024 and 65536 (inclusive). 
	 * If you specify 0, the system database's storage-page size is used.
	 * <b>Warning:</b>&nbsp;You must specify 0 if this federated database was created
	 * prior to Objectivity/DB Release&nbsp;9.0 <i>and</i> if the new
	 * database is to be accessed by unrebuilt pre-Release&nbsp;9.0 applications.
	 * </p>
	 * 
	 * 
     *
     * @return      A database object that represents the new
     * database. When the transaction is committed, the new database is
     * created in the federated database. If the transaction is aborted, the
     * returned object becomes a dead object and the database is not created
	 * in the federated database.</p>
     *
     * @exception       ObjyRuntimeException    If this federated
	 * database already has a database
	 * with the specified name. You can call 
	 * <a href="#hasDB(java.lang.String)"><tt>hasDB(String)</tt></a>
	 * to test whether the specified database exists.</p>
	 * 
     * @exception       ObjyRuntimeException    If this federated
	 * database already has a database
	 * with the specified database identifier. You can call 
	 * <a href="#hasDB(int)"><tt>hasDB(int)</tt></a>
	 * to test whether the specified database exists.</p>
	 */
    public ooDBObj  newDB(
            String  name,
            long    defaultContainerInitialPages,
            long    defaultContainerGrowth,
            String  hostName,
            String  pathName,
            long    weight,
	    long    userDBID,
            int     pageSize ) {
        return persistor().newDB(
            name, defaultContainerInitialPages, defaultContainerGrowth,
            hostName, pathName, weight, userDBID, pageSize) ;
    }

	/**
     * Initializes an object iterator to find the databases
     * contained by this federated database.</p>
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @return      An object iterator that finds the databases.
	 */
    public Iterator containedDBs()
        { return persistor().containedDBs() ; }

	/**
     * Tests whether the database with the specified system name
     * exists in this federated database.</p>
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 name      The system name of the database.</p>
	 *
     * @return      True if the database with the system name <tt><i>name</i></tt>
     * exists in this federated database; otherwise, false.
	 */
    public boolean hasDB(String name)
        { return persistor().hasDB(name) ; }

	/**
     * Tests whether the database with the specified integer identifier
     * exists in this federated database.</p>
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 dbId      The integer identifier of the database.</p>
	 *
     * @return      True if the database with the integer identifier <tt><i>dbNum</i></tt>
     * exists in this federated database; otherwise, false.
	 */
    public boolean hasDB(int dbId)
        { return persistor().hasDB(dbId); }
	/**
     * Finds the default database for this federated database.</p>
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @return      The default database.
	 */
    public ooDBObj getDefaultDB()
        { return persistor().getDefaultDB() ; }

	/**
     * Initializes an object iterator to scan this federated database for objects
     * of the specified class.</p>
	 *
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 *
     * @return      An object iterator that finds the specified objects.
	 */
    public Iterator scan(String className)
         { return persistor().scan(className) ; }

	/**
     * Initializes an object iterator to scan this federated database for objects
     * of the specified class that satisfy the specified predicate.
	 *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus 
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan 
     * policy.  See  
     * <a href="../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
     * @param 	 className      The package-qualified name
	 * of the class of the desired objects.</p>
	 *
     * @param 	 predicate     The condition that each 
     * found object must satisfy, expressed in the Objectivity/DB
     * <a href="../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
	 *
     * @return      An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
	 */
    public Iterator scan(String className, String predicate)
          { return persistor().scan(className, predicate) ; }

    /**
     * Initializes an object iterator to  scan
     * this federated database for objects of the specified class that satisfy the
	 * specified predicate represented in the ObjectQualifier instance.
	 *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan
     * policy.  See
     * <a href="../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
	 * @param      className      The package-qualified name
     * of the class of the desired objects.</p>
     *
     * @param 	 oq      The ObjectQualifier instance. </p>
     *
	 * @return		An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     */
    public Iterator scan(String className, ObjectQualifier oq) 
    {
        return persistor().scan(className, oq) ;    
    }


	/**
	 * Initializes an object iterator to use a parallel query to search this federated database for objects
	 * of the specified class that satisfy the specified predicate.</p>
	 * 
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.  
	 * See <a href="../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 * 
	 * The parallel query started by this method uses an internal default query splitter to define its subtasks.
	 * If the application uses managed placement, only the databases containing objects of the specified class are scanned.
	 * If the application uses explicit placement, every database in this federated database is scanned.
	 * </p>
	 * 
	 * If the connection is using default task assignment, each database being searched
	 * will be scanned by the query server running on that database's data-server host.
	 * Before you start the parallel scan, you should ensure that a query server is running on the data-server host
	 * of every database in this federated database. 
	 * (If, however, an application-defined <a href="TaskAssigner.html">task assigner</a> has been set for the connection,
	 * each database will be scanned by the query server chosen for it by the task assigner.)</p>
	 * 
     * @param 	 className      The package-qualified name
	 * of the class of the objects to be found.</p>
	 * 
	 * @param 	 predicate        The condition that that each found object must satisfy,
	 * expressed in the Objectivity/DB <a href="../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
	 * 
	 * @return  An object iterator that finds the specified objects.</p>
	 * 
	 * @see Connection#checkQueryServer(String)
	 * 
	 * 
	 */

	public Iterator parallelScan(String className, String predicate)
        { return persistor().parallelScan(className, predicate) ; }



	/**
	 * Initializes an object iterator to use a custom parallel query to search this federated database for objects
	 * of the specified class that satisfy the specified predicate.</p>
	 * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.  
	 * See <a href="../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 * 
	 * This method starts a custom parallel query that uses the specified application-defined <a href="QuerySplitter.html">query splitter</a>. 
	 * Such a query splitter may select any number of individual databases or even containers for scanning.</p>
	 * 
	 * If the connection is using default task assignment, each database or container selected by the query splitter
	 * will be scanned by the query server running on the relevant database's data-server host.
	 * Consequently, before you start the parallel scan, you must ensure that a query server is running on the data-server host
	 * of every database to be searched. 
	 * (If, however, an application-defined <a href="TaskAssigner.html">task assigner</a> has been set for the connection,
	 * each database or container will be scanned by the query server chosen for it by the task assigner.)</p>
	 * 
     * @param 	 className      The package-qualified name
	 * of the class of the objects to be found.</p>
	 * 
	 * @param 	 predicate        The condition that that each found object must satisfy,
	 * expressed in the Objectivity/DB <a href="../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
	 * 
	 * @param 	 qs           Query splitter for the custom parallel query. 
	 * A query splitter is an instance of an application-defined class that implements the {@link QuerySplitter QuerySplitter} interface.</p>
	 * 
	 * @return  An object iterator that finds the specified objects.</p>
	 * 
	 * @see Connection#checkQueryServer(String)
	 * 
	 */

	public Iterator parallelScan(String className, String predicate, QuerySplitter qs)
        { return persistor().parallelScan(className, predicate, qs) ; }
	
	/**
	 * Initializes an object iterator to use a custom parallel query to search this federated database for objects
	 * of the specified class that are qualified by the ObjectQualifier.</p>
	 * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
	 * 
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.  
	 * See <a href="../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 * 
	 * This method starts a custom parallel query that uses the specified application-defined <a href="QuerySplitter.html">query splitter</a>. 
	 * Such a query splitter may select any number of individual databases or even containers for scanning.</p>
	 * 
	 * If the connection is using default task assignment, each database or container selected by the query splitter
	 * will be scanned by the query server running on the relevant database's data-server host.
	 * Consequently, before you start the parallel scan, you must ensure that a query server is running on the data-server host
	 * of every database to be searched. 
	 * (If, however, an application-defined <a href="TaskAssigner.html">task assigner</a> has been set for the connection,
	 * each database or container will be scanned by the query server chosen for it by the task assigner.)</p>
	 * 
	 * 
     * @param 	 className      The package-qualified name
	 * of the class of the objects to be found.</p>
	 * 
	 * @param 	 oq      The ObjectQualifier instance. </p>
	 * 
	 * @param 	 qs           Query splitter for the custom parallel query. 
	 * A query splitter is an instance of an application-defined class that implements the {@link QuerySplitter QuerySplitter} interface.</p>
	 * 
	 * @return  An object iterator that finds the specified objects.</p>
	 * 
	 * @see Connection#checkQueryServer(String)
	 * 
	 */
	public Iterator parallelScan(String className, ObjectQualifier oq, QuerySplitter qs)
    { return persistor().parallelScan(className, oq, qs) ; }
	
	/**
	 * Initializes an object iterator to use a custom parallel query to search this federated database for objects
	 * of the specified class that are qualified by the ObjectQualifier.</p>
	 * 
	 * This method starts a <i>parallel query</i> to initialize the returned object iterator.
	 * A parallel query splits its search into individual subtasks
	 * that are performed in parallel by the threads of one or more query server processes running on separate hosts.  
	 * See <a href="../../../../../guide/jgdPQE.html">Parallel Queries</A>.</p>
	 * 
	 * The parallel query started by this method uses an internal default query splitter to define its subtasks.
	 * If the application uses managed placement, only the databases containing objects of the specified class are scanned.
	 * If the application uses explicit placement, every database in this federated database is scanned.
	 * </p>
	 * 
	 * If the connection is using default task assignment, each database being searched
	 * will be scanned by the query server running on that database's data-server host.
	 * Before you start the parallel scan, you should ensure that a query server is running on the data-server host
	 * of every database in this federated database. 
	 * (If, however, an application-defined <a href="TaskAssigner.html">task assigner</a> has been set for the connection,
	 * each database will be scanned by the query server chosen for it by the task assigner.)</p>
	 * 
	 * 
     * @param 	 className      The package-qualified name
	 * of the class of the objects to be found.</p>
	 * 
	 * @param 	 oq      The ObjectQualifier instance. </p>
	 * 
	 * @return  An object iterator that finds the specified objects.</p>
	 * 
	 * @see Connection#checkQueryServer(String)
	 * 
	 */
	public Iterator parallelScan(String className, ObjectQualifier oq)
    { return persistor().parallelScan(className, oq, null) ; }

	/**
   	 * Adds an index to this federated database.</p>
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
     * @param 	 name   The name of the index to be added; must be different from
	 * the names of existing indexes in this federated database. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
	 *
   	 * @param 	 className   The package-qualified name of
	 * the class whose instances are to be indexed.</p>
	 *
  	 * @param 	 fieldList   The key fields for the index, separated by commas.
  	 * Each key field must be the name of a valid attribute
     * of <tt><i>className</i></tt> whose type is one of the Java
     * <a href = "../../../../../guide/jgdIndexes.html#Key Fields">
     * types supported by indexes</a>.</p>
  	 *
	 * @exception   ObjyRuntimeException    If Objectivity/DB is unable to 
     * create the index.</p> 
     *
  	 * @see #addUniqueIndex(String, String, String)
 	 * @see #dropIndex(String)
	 */
    public void addIndex(String name, String className, String fieldList)
        { persistor().addIndex(name, className, fieldList) ; }

	/**
     * Adds a unique index to this federated database.
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
     * <p>The application is responsible for ensuring that every object
  	 * indexed by a unique index has a
     * unique combination of values in its key fields. If two or more
	 * objects have a given combination of key values, the index contains
	 * only the first such object that is encountered when the index is
	 * created or updated.</p>
	 *
     * @param 	 name   The name of the index to be added; must be different from
	 * the names of existing indexes in this federated database. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
	 *
     * @param 	 className   The package-qualified name of
	 * the class whose instances are to be indexed.</p>
	 *
     * @param 	 fieldList   The key fields for the index, separated by commas.
     * Each key field must be the name of a valid attribute
     * of <tt><i>className</i></tt> whose type is one of the Java
     * <a href = "../../../../../guide/jgdIndexes.html#Key Fields">
     * types supported by indexes</a>.</p>
     *
	 * @exception   ObjyRuntimeException    If Objectivity/DB is unable to 
     * create the index.</p> 
     *
     * @see #addIndex(String, String, String)
     * @see #dropIndex(String)
	 */
    public void addUniqueIndex(String name, String className, String fieldList)
        { 
          persistor().flush(); //SPR 17691 flush object to index correct info
          persistor().addUniqueIndex(name, className, fieldList) ; 
        }

	/**
     * Drops the specified index from this federated database.</p>
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 name   The name of the index to be 
     * dropped.</p> 
	 *
	 * @exception   ObjyRuntimeException    If this federated database does not have an index named
	 * <tt><i>name</i></tt>. You can call
	 * <a href="#hasIndex(java.lang.String)"><tt>hasIndex</tt></a> to test whether an index with the
     * specified name exists.</p>
     *
     * @see #addIndex(String, String, String)
     * @see #addUniqueIndex(String, String, String)
	 */
    public void dropIndex(String name)
        { persistor().dropIndex(name) ; }

	/**
     * Tests whether this federated database has an index with the
	 * specified name.</p>
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 name   The name of the index.</p>
	 *
     * @return      True if this federated database has an index named
	 * <tt><i>name</i></tt>; otherwise, false.
	 */
    public boolean hasIndex(String name)
        { return persistor().hasIndex(name) ; }

	/**
     * Tests whether the specified index in this federated database is
     * consistent with the definition of the indexed class.</p>
     * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
	 * <p>If you delete or change the data type of an attribute of the 
     * indexed class and that attribute is used as a key field of an index, 
     * the index becomes invalid because it is no longer consistent with the 
     * updated definition of the indexed class. You should test for 
     * consistency after modifying the definition of an indexed class and 
     * should drop and recreate any invalid indexes.  See
     * <A HREF="../../../../../guide/jgdIndexes.html#Reconstructing Indexes After Schema Evolution">
     * Reconstructing Indexes After Schema Evolution</A>.</p>
	 *
     * @param 	 name   The name of the index to be tested.</p>
	 *
     * @return      True if this federated database has an index named
	 * <tt><i>name</i></tt> and that index is consistent with the definition 
     * of the indexed class; otherwise, false.
	 */
    public boolean indexConsistent(String name)
        { return persistor().indexConsistent(name) ; }

	/**
	 * Names the specified object in the scope of this federated database.
     *
     * <p>If the specified object is transient, this method makes it persistent.
     * If the specified object is already persistent, this method locks it
	 * for write.
	 *
	 * <p>This method locks this federated database for write.</p>
	 *
	 * @param 	 object	The object to be named.</p>
	 *
	 * @param 	 scopeName	The name for the specified
	 * object in the scope of this federated database.
     * This name can be any valid Java string and must be unique
	 * within  the name scope of this federated database.</p>
     *
     * @see #lookupObj(String)
     * @see #unnameObj(Object)
	 */
    public void nameObj(Object object, String scopeName)
        { persistor().nameObj(object, scopeName) ; }

	/**
	 * Removes the specified object's name from the
	 * name scope of this federated database.
	 *
	 * <p>This method locks both this federated database and
	 * <tt><i>object</i></tt> for write.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * removed.</p>
	 *
	 * @exception   ObjyRuntimeException    If <tt><i>object</i></tt> has no name
	 * in the scope of this federated database.</p>
	 *
     * @see #lookupObj(String)
     * @see #nameObj(Object, String)
	 */
    public void unnameObj(Object object)
        { persistor().unnameObj(object) ; }

	/**
	 * Finds the object with the specified scope name in the scope defined
     * by this federated database.</p>
	 *
	 * @param 	 scopeName	The scope name to look 
     * up.</p> 
	 *
	 * @return		The object with the specified scope name in the scope of
     * this federated database. The returned object is locked for read.</p>
     *
     * @exception   ObjyRuntimeException    If there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this federated
	 * database.</p>
     *
     * @see #lookupObjName(Object)
	 */
    public Object lookupObj(String scopeName)
        { return persistor().lookupObj(scopeName) ; }

	/**
	 * Finds the object with the specified scope name in the scope defined
     * by this federated database, locking the
	 * found object as specified.</p>
	 *
	 * @param 	 scopeName	The scope name to look 
     * up.</p> 
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this federated database; the returned object
	 * is locked as specified by <tt><i>lockMode</i></tt>.</p>
     *
     * @exception   ObjyRuntimeException    If there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this federated
	 * database.</p>
     *
     * @see #lookupObjName(Object)
	 */
    public Object lookupObj(String scopeName, int lockMode)
        { return persistor().lookupObj(scopeName, lockMode) ; }

	/**
	 * Looks up the name of the specified object in the scope defined
     * by this federated database.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * looked up.</p>
	 *
	 * @return		The scope name of the specified object in the name scope
	 * of this federated database.</p>
	 *
	 * @exception   ObjyRuntimeException    If <tt><i>object</i></tt> has
	 * no name in the scope of this federated database.</p>
	 *
	 * @see #lookupObj(String)
	 */
    public String lookupObjName(Object object)
        { return persistor().lookupObjName(object) ; }

    /**
     * Prints federated database catalog information
     * to the standard output device.
     *
     * <p>Performs the same function as the tool
     * <tt>oodumpcatalog</tt>.</p>
     */
    public void dumpCatalog()
        { persistor().dumpCatalog() ; }

    /**
     * Transfers the data of all modified persistent objects in this 
     * federated database to the session's Objectivity/DB cache.
     *
     * <p>After the successful execution of this method, the objects are
     * no longer marked as modified.
	 *
     * <P>This method makes the data of modified objects available to the
     * process that calls the method, but does not make the changes
     * permanent and available to other processes. When you checkpoint or
     * commit the transaction, the changes become permanent in the federated 
     * database.</p>
     */
    public void flush()
        { persistor().flush() ; }

	/**
	 * Performs on-demand 
     * <A HREF="../../../../../guide/jgdSchemaEvolution.html#Object Conversion"> 
	 * object conversion</a> on any affected objects in this federated database.
	 *
	 * <p>Object conversion makes persistent objects in the federated database
	 * consistent with the current definitions of their
	 * Java classes.
	 *
	 * <p>You can call this method if the definitions of some Java classes are
	 * not consistent with the corresponding descriptions in the schema.  
     * Certain changes to a class definition affect how instances of a class 
     * should be laid out in storage. After you make such a change, existing 
     * persistent objects of the changed classes are rendered out-of-date 
     * until they are converted to their new representations. 
     *
     * <p>You call this method in an update transaction to 
     * convert the affected objects in this federated database on demand. 
     * This method takes no action for affected objects that have 
     * already been converted.  
	 */
    public void convertObjects()
        { persistor().convertObjects(); }

	/**
	 * Performs on-demand 
     * <A HREF="../../../../../guide/jgdSchemaEvolution.html#Object Conversion"> 
	 * object conversion</a> on any affected objects in this federated 
     * database, optionally purging the schema-evolution history.
	 *
	 * <p>Object conversion makes persistent objects in the federated database
	 * consistent with the current definitions of their
	 * Java classes.
	 *
	 * <p>You can call this method if the definitions of some Java classes are
	 * not consistent with the corresponding descriptions in the schema.  
     * Certain changes to a class definition affect how instances of a class 
     * should be laid out in storage. After you make such a change, existing 
     * persistent objects of the changed classes are rendered out-of-date 
     * until they are converted to their new representations. 
     *
     * <p>You call this method in an update transaction to 
     * convert the affected objects in this federated database on demand. 
     * This method takes no action for affected objects that have 
     * already been converted.</p>  
     *
	 * @param 	 purge_schema	True to 
     * remove schema-evolution history after all objects are converted; false
     * to leave the schema-evolution history unchanged. You must specify false in an application that accesses a placement-managed federated database.
     * <p><b>Warning:</b> 
     * Purging the schema may delete information that is required for 
     * distributing schema changes to deployed federated databases; see 
     * <A HREF="../../../../../guide/jgdSchemaEvolution.html#Purging the Schema-Evolution History">
     * Purging the Schema-Evolution History</a>.
     * You should make a backup of the federated database before purging its 
     * schema.
	 */
    public void convertObjects(boolean purge_schema)
        { persistor().convertObjects(purge_schema); }
    
    /**
	 * Performs object conversion on this federated database; used only in a 
     * special-purpose upgrade application.
     *
     * <p>This method is included for interoperability.  Changes to Java 
     * class definitions never leave the federated database schema in a state 
     * that requires an upgrade application. However, changes to the schema 
     * made by the Objectivity/C++ DDL processor can require an 
     * upgrade application to convert objects of the modified class before 
     * any of those objects can be accessed. Typically, a C++ developer who 
     * makes such modifications to the schema also runs an Objectivity/C++ 
     * upgrade application.  This method makes it possible to run an
     * Objectivity for Java upgrade application instead.
     *
     * <p>To run an upgrade application, you open a read/write connection 
     * to the federated database.  You create a session and call its
     * {@link Session#upgrade <tt>upgrade</tt>} method before 
     * beginning the first and only 
     * transaction.  That transaction must consist of a call to this method, 
     * which initiates the upgrade process.  Objectivity/DB
     * signals an error if the federated database schema does not
     * include any pending changes that require an upgrade
     * application.
     *
     *
     * <p>For additional information about upgrade applications, refer to the 
     * Objectivity/C++ product documentation.</p>     
     */
    public void upgradeObjects()
        { persistor().upgradeObjects(); }

    /**
	 * Performs object conversion on this federated database, optionally 
     * purging the schema-evolution history; used only in a  
     * special-purpose upgrade application.
     *
     * <p>This method is included for interoperability.  Changes to Java 
     * class definitions never leave the federated database schema in a state 
     * that requires an upgrade application. However, changes to the schema 
     * made by the Objectivity/C++ DDL processor can require an 
     * upgrade application to convert objects of the modified class before 
     * any of those objects can be accessed. Typically, a C++ developer who 
     * makes such modifications to the schema also runs an Objectivity/C++ 
     * upgrade application.  This method makes it possible to run an
     * Objectivity for Java upgrade application instead.
     *
     * <p>To run an upgrade application, you open a read/write connection 
     * to the federated database.  You create a session and call its
     * {@link Session#upgrade <tt>upgrade</tt>} method before 
     * beginning the first and only 
     * transaction.  That transaction must consist of a call to this method, 
     * which initiates the upgrade process.  Objectivity/DB
     * signals an error if the federated database schema does not
     * include any pending changes that require an upgrade
     * application.
     *
     * <p>For additional information about upgrade applications, refer to the 
     * Objectivity/C++ product documentation.</p> 
     *
	 * @param 	 purge_schema	True to 
     * remove schema-evolution history after all objects are converted; false
     * to leave the schema-evolution history unchanged. You must specify false in an application that accesses a placement-managed federated database.
     * <p><b>Warning:</b> 
     * Purging the schema may delete information that is required for 
     * distributing schema changes to deployed federated databases; see 
     * <A HREF="../../../../../guide/jgdSchemaEvolution.html#Purging the Schema-Evolution History">
     * Purging the Schema-Evolution History</a>.
     * You should make a backup of the federated database before purging its 
     * schema.
     */
	public void upgradeObjects(boolean purge_schema)
        { persistor().upgradeObjects(purge_schema); }

    /**
     * Finds the object with the specified object identifier in this federated
	 * database.</p>
	 *
     * @param 	 oid The object identifier of the object to be found.</p>
	 *
     * @return	The object with the specified object identifier; the returned object is locked for read.
	 */
    public Object objectFrom(ooId oid) {
        if (oid == null)
            throw new com.objy.db.ObjyRuntimeException("oid parameter must not be a null reference");
        return persistor().objectFrom(oid);
    }

	/**
     * Finds the object with the specified object identifier in this federated
	 * database, locking the found object as 
     * specified.</p>
	 *
     * @param 	 oid The object identifier of the object to be found.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
     *
     * @return	The object with the specified object identifier; the returned object is 
     * locked as specified by <tt><i>lockMode</i></tt>.
	 */
    public Object objectFrom(ooId oid, int lockMode) {
        if (oid == null)
            throw new com.objy.db.ObjyRuntimeException("oid parameter must not be a null reference");
        return persistor().objectFrom(oid, lockMode);
    }

	/**
	 * Finds the object in this federated database whose identifier has the 
     * specified string representation.
	 *
	 * <p>This method translates the string representation of the
	 * object identifier to an
     * object of class {@link ooId <tt>ooId</tt>} before looking up the 
     * object.</p> 
	 *
	 * @param 	 oidString	The string representation of the
     * object's identifier.
     * <p>The string must be of one of the following forms: 
     * <tt>"#<i>D</i>-<i>C</i>-<i>P</i>-<i>S</i>"</tt> or
     * <tt>"#<i>D</i>-<i>C</i>-<i>P</i>-<i>S</i>:<i>typeNumber</i>"</tt> 
     * (the form returned by the {@link ooId#getStoreString <tt>getStoreString</tt>}
     * method of an object identifier).
     *
     * <p><b>Warning:</b> If you obtain an object identifier string from 
     * <tt>getStoreString</tt>, you must not  
     * modify it before passing it as a parameter to this method. If you do 
     * modify the string, this method may not find the correct object.</p>
	 *
     * @return	The object with the specified object identifier.
	 */
    public Object objectFrom(String oidString)
        { return persistor().objectFrom(oidString) ; }

	/**
	 * Finds the object in this federated database whose identifier has the 
     * specified string representation, locking the found object as 
     * specified.
	 *
	 * <p>This method translates the string representation of the object identifier to an
     * object of class {@link ooId <tt>ooId</tt>} before looking up the 
     * object.</p> 
	 *
	 * @param 	 oidString	The string representation of the
     * object's identifier. The string must be of the form returned by the
     * {@link ooId#getStoreString <tt>getStoreString</tt>}
     * method of an object identifier.
	 *
     * <p><b>Warning:</b> If you obtain an object identifier string from 
     * <tt>getStoreString</tt>, you must not  
     * modify it before passing it as a parameter to this method. If you do 
     * modify the string, this method may not find the correct object.</p>
     *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
     *
     * @return	The object with the specified object identifier; the returned object is 
     * locked as specified by <tt><i>lockMode</i></tt>.
	 */
    public Object objectFrom(String oidString, int lockMode)
        { return persistor().objectFrom(oidString, lockMode) ; }


	/**
	 * Finds the object in this federated database whose identifier has the 
     * specified integer representation.</p>
	 *
	 * @param 	 oidLong	The long-integer representation of the
     * object's identifier. The integer must be of the form returned by the
     * {@link ooId#getStoreLong <tt>getStoreLong</tt>}
     * method of an object identifier.</p>
	 *
	 * @param 	 typeNumber	The type number that uniquely identifies the 
	 * desired object's class in the federated database schema.  You can obtain the type
	 * number by calling <a href="./ooId.html#getTypeN()">
	 * <tt>getTypeN</tt></a> method of an object identifier.</p>
     *
     * @return	The object with the specified object identifier.
	 */
    public Object objectFrom(long oidLong, long typeNumber)
        { return persistor().objectFrom(oidLong, typeNumber) ; }

	/**
	 * Finds the object in this federated database whose identifier has the 
     * specified integer representation, locking the found object as 
     * specified.</p>
	 *
	 * @param 	 oidLong	The long-integer representation of the
     * object's identifier. The integer must be of the form returned by the
     * {@link ooId#getStoreLong <tt>getStoreLong</tt>}
     * method of an object identifier.</p>
	 *
	 * @param 	 typeNumber	The type number that uniquely identifies the 
	 * desired object's class in the federated database schema.  You can obtain the type
	 * number by calling {@link ooId#getTypeN <tt>getTypeN</tt>} method of an object identifier.</p>
     *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
     *
     * @return	The object with the specified object identifier; the returned object is 
     * locked as specified by <tt><i>lockMode</i></tt>.
	 */
    public Object objectFrom(long oidLong, long typeNumber, int lockMode)
        { return persistor().objectFrom(oidLong, typeNumber, lockMode) ; }

	/**
	 * Deletes the specified internal persistent object from this
	 * federated database.
	 *
	 * <p><b>Note: </b>It is better to call the 
	 * {@link ooObj#deleteReference <tt>deleteReference</tt>} method
	 * on the persistent object that references the internal 
     * persistent object than to call this method on a federated database 
     * object. Deadlocks can occur when you call this method in a 
     * multithreaded application.</p>
         *
	 * <p>
	 * <b>Note:</b> You should delete an internal persistent object
	 * <i>only</i> 
	 * if you also plan to delete the persistent object that referenced it.
	 * </p>
	 *
	 * @param 	 object	The
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> to be deleted.</p>
	 *
	 * @exception       com.objy.db.ObjyRuntimeException    If
	 * <tt><i>object</i></tt> is not an array, a string element of an
	 * array, or a date or time type that is stored in the
	 * federated database as an internal persistent object 
	 * (<tt>java.util.Date</tt>, <tt>java.sql.Date</tt>, <tt>java.sql.Time</tt>,
	 * <tt>java.sql.Timestamp</tt>).
	 *
	 */
    public void deleteReference(Object object)
        { persistor().deleteReference(object) ; }

    /**
	 * Moves the specified internal persistent object from its current
	 * location and clusters it with the specified object.</p>
	 *
	 * @param 	 object  The
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> to be moved.</p>
	 *
	 * @param 	 nearObj	The object with which to
	 * cluster <tt><i>object</i></tt>; must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>nearObj</i></tt> is a database:<dd>The internal
	 * persistent object is moved to
	 * the default container of that database.</dd>
	 * <dt>If <tt><i>nearObj</i></tt> is a persistent container:<dd>The
	 * internal persistent object is
	 * moved to that container.</dd>
	 * <dt>If <tt><i>nearObj</i></tt> is a persistent basic
	 * object:<dd>The internal persistent object is
	 * moved to the container in which <tt><i>nearObj</i></tt> is stored.
	 * If possible, it will be stored on the same page as <tt><i>nearObj</i></tt> or
	 * on a page close to <tt><i>nearObj</i></tt>.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @exception       com.objy.db.ObjyRuntimeException    If
	 * <tt><i>object</i></tt> is not an array, a string element of an
	 * array, or a date or time type that is stored in the
	 * federated database as an internal persistent object (
	 * <tt>java.util.Date</tt>, <tt>java.sql.Date</tt>, <tt>java.sql.Time</tt>,
	 * <tt>java.sql.Timestamp</tt>).
	 */
    public void moveReference(Object object, Object nearObj)
        { persistor().moveReference(object, nearObj) ; }

    /**
     * <i>(HA)</i> Tests whether an autonomous partition with the
     * specified system name exists in this federated database.</p>
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 name      The system name of the autonomous 
     * partition.</p> 
     *
     * @return          True if the autonomous partition with the system
     * name <tt><i>name</i></tt> exists in this federated database; otherwise
     * false.
     *
     */
    public boolean hasAP(String name)
        { return persistor().hasAP(name) ; }

    /**
     * <i>(HA)</i> Finds the autonomous partition with the
     * specified system name in this federated database.</p>
     * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * @param 	 name      The system name of the 
     * autonomous partition.</p> 
     *
     * @return      The specified autonomous partition.</p>
     *
     * @exception   ObjyRuntimeException        If this federated database
     * does not have an autonomous partition with the specified system name.
     * You can call <a href="#hasAP(java.lang.String)"><tt>hasAP</tt></a> 
     * to test whether the specified partition exists.
     */
    public ooAPObj lookupAP(String name)
        { return persistor().lookupAP(name) ; }

    /**
     * <i>(HA)</i> Creates an autonomous partition in this federated 
     * database with the specified system name,
     * lock-server host, and location for its
     * system-database file.
     * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>The boot file (named <tt>name.boot</tt>) and journal file are
     * created in the same directory as the system-database file
     * and on the host <tt><i>systemDBFileHost</i></tt>.
     * <p>When you create a partition, Objectivity/DB needs access to all of the
     * partitions in the federated database so that it can update
     * the global catalog data.
     * <p>The new autonomous partition is locked in write mode.</p>
     *
     * @param 	 name   System name of the new autonomous 
     * partition. The system name implicitly specifies the name of the 
     * autonomous-partition boot file (<tt><i>name</i>.boot</tt>). The 
     * specified name: 
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of autonomous
     * partitions in the federated database.</p>
	 * <li>Must be between 1 and 127 characters long, inclusive.
     * </ul></p>
     *
     * @param 	 lockServerHost  Host of the lock server servicing 
     * the new autonomous partition.</p>
     *
     * @param 	 systemDBFileHost   Data-server host on which to 
     * create the new autonomous partition's system-database file. 
     * The designated system-database host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>systemDBFileHost</i></tt> is an
     * empty string or null, the system-database host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>systemDBFilePath</i></tt> is a local path.
     * <li>The host implied by <tt><i>systemDBFilePath</i></tt>, if <tt><i>systemDBFilePath</i></tt> 
     * is an NFS mount name. 
     * </ul></p>
     *
     * <li>Otherwise, the host <tt><i>systemDBFileHost</i></tt> is used.</ul></p>
     *
     * @param 	 systemDBFilePath   Pathname 
     * of the new autonomous partition's system-database file 
     * on the designated system-database host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of 
     * the pathname must follow the naming conventions of the designated 
     * system-database host.
	 * Because the host must be running AMS, 
	 * <tt><i>systemDBFilePath</i></tt> must be understood locally by the host's file system; 
	 * you may not specify a Windows UNC share name. 
	 * If <tt><i>systemDBFilePath</i></tt> is an NFS mount name, 
	 * it is automatically converted to the corresponding local pathname on the implied host. 
	 * </p>
     * <li>If the designated system-database host is a remote system, the 
     * pathname must be fully qualified; otherwise, the pathname may be 
     * either relative or fully qualified.</p> 
     *
     * <li>By convention, you compose the filename from the system name with 
     * the extension <tt>.AP</tt>.</p>
	 * 
     * <li>If the pathname does not include a filename, it will be generated
     * automatically.</ul></p> 
	 * 
     * @return      An autonomous partition object that represents the
     * newly created autonomous partition.</p>
     *
     * @exception ObjyRuntimeException      If this federated database already has an
	 * autonomous partition named <tt><i>name</i></tt>. You can call
	 * <a href="#hasAP(java.lang.String)"><tt>hasAP</tt></a> to test whether the specified
     * partition exists.
     *
     */
    public ooAPObj newAP(
            String name,
            String lockServerHost,
            String systemDBFileHost,
            String systemDBFilePath) {
        return persistor().newAP(name, lockServerHost, systemDBFileHost, systemDBFilePath) ;
    }

    /**
     * <i>(HA)</i> Creates an autonomous partition in this federated 
     * database with the specified system name,
     * lock-server host, and file locations.
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>The new autonomous partition is locked in write mode.
     *
     * <p>When you create a partition, Objectivity/DB needs access to all of the
     * partitions in the federated database so that it can update
     * the global catalog data.</p>
     *
     * @param 	 name   System name of the new autonomous 
     * partition. The system name implicitly specifies the name of the 
     * autonomous-partition boot file (<tt><i>name</i>.boot</tt>). The 
     * specified name: 
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of autonomous
     * partitions in the federated database.</p>
	 * <li>Must be between 1 and 127 characters long, inclusive.
     * </ul></p>
     *
     * @param 	 lockServerHost  Host of the lock server servicing 
     * the new autonomous partition.</p>
     *
     * @param 	 systemDBFileHost   Data-server host on which to 
     * create the new autonomous partition's system-database file. 
     * The designated system-database host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>systemDBFileHost</i></tt> is an
     * empty string or null, the system-database host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>systemDBFilePath</i></tt> is a local path.
     * <li>The host implied by <tt><i>systemDBFilePath</i></tt>, if <tt><i>systemDBFilePath</i></tt> 
     * is an NFS mount name. 
     * </ul></p>
     *
     * <li>Otherwise, the host <tt><i>systemDBFileHost</i></tt> is used.</ul></p>
     *
     * @param 	 systemDBFilePath   Pathname 
     * of the new autonomous partition's system-database file 
     * on the designated system-database host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of 
     * the pathname must follow the naming conventions of the designated 
     * system-database host.
	 * Because the host must be running AMS, 
	 * <tt><i>systemDBFilePath</i></tt> must be understood locally by the host's file system; 
	 * you may not specify a Windows UNC share name. 
	 * If <tt><i>systemDBFilePath</i></tt> is an NFS mount name, 
	 * it is automatically converted to the corresponding local pathname on the implied host. 
	 * </p>
     * <li>If the designated system-database host is a remote system, the 
     * pathname must be fully qualified; otherwise, the pathname may be 
     * either relative or fully qualified.</p> 
     *
     * <li>By convention, you compose the filename from the system name with 
     * the extension <tt>.AP</tt>.</p>
     *
     * <li>If the pathname does not include a filename, it will be generated
     * automatically.</ul></p>
     *
     * @param 	 bootFileHost    Data-server host on which 
     * to create the autonomous partition's boot file.
     * The designated boot-file  host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>bootFileHost</i></tt> is an empty string or null, the  
     * boot-file host is:
     * <ul type=circle>
	 * <li>The current host, if <tt><i>bootFilePath</i></tt> is a local path.
	 * <li>The host implied by <tt><i>bootFilePath</i></tt>, if <tt><i>bootFilePath</i></tt> is an 
	 * NFS mount name.
	 * <li>The same as the designated system-database host, if <tt><i>bootFilePath</i></tt> is also 
	 * an empty string or null.
     * </ul></p>
     *
     * <li>If <tt><i>bootFilePath</i></tt> is a Windows UNC share name, <tt><i>bootFileHost</i></tt> is 
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>bootFileHost</i></tt> is used.</ul></p>
     *
     * @param 	 bootFilePath    Pathname of the 
     * directory in which to create the autonomous partition's boot file on  
     * the designated boot-file host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>If the designated boot-file host is a remote system, the pathname 
     * must be fully qualified; otherwise, the pathname may be either 
     * relative or fully qualified.</p>
     * 
     * <li>This parameter may be null  only if <tt><i>bootFileHost</i></tt> 
     * is also null or an empty string;  
     * in this case, the boot-file directory is the same as the 
     * system-database directory (on the designated system-database 
     * host).</ul></p> 
     *
     * @param 	 journalDirHost      Host of the new 
     * autonomous partition's journal directory. 
     * The designated journal-directory host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>journalDirHost</i></tt> is an
     * empty string or null, the journal-directory host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>journalDirPath</i></tt> is a local path.
     * <li>The host implied by <tt><i>journalDirPath</i></tt>, if 
     * <tt><i>journalDirPath</i></tt> is an NFS mount name.
     * <li>The same as the designated system-database host, if 
     * <tt><i>journalDirPath</i></tt> is also null. 
     * </ul></p>
     * <li>If <tt><i>journalDirPath</i></tt> is a Windows UNC share name, <tt><i>journalDirHost</i></tt> 
     * is automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>journalDirHost</i></tt> is used.</ul></p>
     *
     * @param 	 journalDirPath      Pathname of the new 
     * autonomous partition's journal directory on the designated 
     * journal-directory host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>If the designated journal-directory host is a remote system, the 
     * pathname must be fully qualified; otherwise,  
     * the pathname may be either relative or fully qualified.</p>
     * <li>This parameter may be null only if <tt><i>journalDirHost</i></tt> 
     * is also null or an empty string;  
     * in this case, the journal directory is the same as the 
     * system-database directory (on the designated system-database 
     * host).</ul></p> 
     *
     * @return      An autonomous partition object that represents the
     * newly created autonomous partition.</p>
     *
     * @exception       com.objy.db.ObjyRuntimeException    If this federated database already has an
	 * autonomous partition named <tt><i>name</i></tt>. You can call
	 * <a href="#hasAP(java.lang.String)"><tt>hasAP</tt></a> to test whether the specified
     * partition exists.
     *
     */
    public ooAPObj newAP(
            String name,
            String lockServerHost,
            String systemDBFileHost,
            String systemDBFilePath,
            String bootFileHost,
            String bootFilePath,
            String journalDirHost,
            String journalDirPath) {
        return persistor().newAP(
            name, lockServerHost,
            systemDBFileHost, systemDBFilePath,
            bootFileHost, bootFilePath,
            journalDirHost, journalDirPath) ;
    }
    /**
     * <i>(HA)</i> Creates an autonomous partition in this federated 
     * database with the specified system name,
     * lock-server host, file locations, and weight.
     * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>The new autonomous partition is locked in write mode.
     *
     * <p>When you create a partition, Objectivity/DB needs access to all of the
     * partitions in the federated database so that it can update
     * the global catalog data.</p>
     *
     * @param 	 name   System name of the new autonomous 
     * partition. The system name implicitly specifies the name of the 
     * autonomous-partition boot file (<tt><i>name</i>.boot</tt>). The 
     * specified name: 
     * <p><ul type=disc>
     * <li>Must follow the same naming rules as files of your operating 
     * system.</p> 
     * <li>Must be unique among all the system names of autonomous
     * partitions in the federated database.</p>
	 * <li>Must be between 1 and 127 characters long, inclusive.
     * </ul></p>
     *
     * @param 	 lockServerHost  Host of the lock server servicing 
     * the new autonomous partition.</p>
     *
     * @param 	 systemDBFileHost   Data-server host on which to 
     * create the new autonomous partition's system-database file. 
     * The designated system-database host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>systemDBFileHost</i></tt> is an
     * empty string or null, the system-database host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>systemDBFilePath</i></tt> is a local path.
     * <li>The host implied by <tt><i>systemDBFilePath</i></tt>, if <tt><i>systemDBFilePath</i></tt> 
     * is an NFS mount name. 
     * </ul></p>
     *
     * <li>Otherwise, the host <tt><i>systemDBFileHost</i></tt> is used.</ul></p>
     *
     * @param 	 systemDBFilePath   Pathname 
     * of the new autonomous partition's system-database file 
     * on the designated system-database host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>The format of 
     * the pathname must follow the naming conventions of the designated 
     * system-database host.
	 * Because the host must be running AMS, 
	 * <tt><i>systemDBFilePath</i></tt> must be understood locally by the host's file system; 
	 * you may not specify a Windows UNC share name. 
	 * If <tt><i>systemDBFilePath</i></tt> is an NFS mount name, 
	 * it is automatically converted to the corresponding local pathname on the implied host. 
	 * </p>
     * <li>If the designated system-database host is a remote system, the 
     * pathname must be fully qualified; otherwise, the pathname may be 
     * either relative or fully qualified.</p> 
     *
     * <li>By convention, you compose the filename from the system name with 
     * the extension <tt>.AP</tt>.</p>
     *
     * <li>If the pathname does not include a filename, it will be generated
     * automatically.</ul></p>
     *
     * @param 	 bootFileHost    Data-server host on which 
     * to create the autonomous partition's boot file.
     * The designated boot-file  host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>bootFileHost</i></tt> is an empty string or null, the  
     * boot-file host is:
     * <ul type=circle>
	 * <li>The current host, if <tt><i>bootFilePath</i></tt> is a local path.
	 * <li>The host implied by <tt><i>bootFilePath</i></tt>, if <tt><i>bootFilePath</i></tt> is an 
	 * NFS mount name.
	 * <li>The same as the designated system-database host, if <tt><i>bootFilePath</i></tt> is also 
	 * an empty string or null.
     * </ul></p>
     *
     * <li>If <tt><i>bootFilePath</i></tt> is a Windows UNC share name, <tt><i>bootFileHost</i></tt> is 
     * automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>bootFileHost</i></tt> is used.</ul></p>
     *
     * @param 	 bootFilePath    Pathname of the 
     * directory in which to create the autonomous partition's boot file on  
     * the designated boot-file host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>If the designated boot-file host is a remote system, the pathname 
     * must be fully qualified; otherwise, the pathname may be either 
     * relative or fully qualified.</p>
     * 
     * <li>This parameter may be null  only if <tt><i>bootFileHost</i></tt> 
     * is also null or an empty string;  
     * in this case, the boot-file directory is the same as the 
     * system-database directory (on the designated system-database 
     * host).</ul></p> 
     *
     * @param 	 journalDirHost      Host of the new 
     * autonomous partition's journal directory. 
     * The designated journal-directory host is set as follows:
     * <p><ul type=disc>
     * <li>If <tt><i>journalDirHost</i></tt> is an
     * empty string or null, the journal-directory host is:
     * <ul type=circle>
     * <li>The current host, if <tt><i>journalDirPath</i></tt> is a local path.
     * <li>The host implied by <tt><i>journalDirPath</i></tt>, if 
     * <tt><i>journalDirPath</i></tt> is an NFS mount name.
     * <li>The same as the designated system-database host, if 
     * <tt><i>journalDirPath</i></tt> is also null. 
     * </ul></p>
     * <li>If <tt><i>journalDirPath</i></tt> is a Windows UNC share name, <tt><i>journalDirHost</i></tt> 
     * is automatically set to the literal string <tt>oo_local_host</tt>; any value you specify is 
     * ignored.</p>
     *
     * <li>Otherwise, the host <tt><i>journalDirHost</i></tt> is used.</ul></p>
     *
     * @param 	 journalDirPath      Pathname of the new 
     * autonomous partition's journal directory on the designated 
     * journal-directory host. Guidelines for this parameter:
     * <p><ul type=disc>
     * <li>If the designated journal-directory host is a remote system, the 
     * pathname must be fully qualified; otherwise,  
     * the pathname may be either relative or fully qualified.</p>
     * <li>This parameter may be null only if <tt><i>journalDirHost</i></tt> 
     * is also null or an empty string;  
     * in this case, the journal directory is the same as the 
     * system-database directory (on the designated system-database 
     * host).</ul></p> 
     *
     * @param 	 weight      Weight of the new 
	 * autonomous partition; an integer greater than zero. 
	 * </p>
     *
     * @return      An autonomous partition object that represents the
     * newly created autonomous partition.</p>
     *
     * @exception       com.objy.db.ObjyRuntimeException    If this federated database already has an
	 * autonomous partition named <tt><i>name</i></tt>. You can call
	 * <a href="#hasAP(java.lang.String)"><tt>hasAP</tt></a> to test whether the specified
     * partition exists.
     *
     */
    public ooAPObj newAP(
            String name,
            String lockServerHost,
            String systemDBFileHost,
            String systemDBFilePath,
            String bootFileHost,
            String bootFilePath,
            String journalDirHost,
            String journalDirPath,
	    int weight) {
        return persistor().newAP(
            name, lockServerHost,
            systemDBFileHost, systemDBFilePath,
            bootFileHost, bootFilePath,
            journalDirHost, journalDirPath, weight) ;
    }

    /**
     * <i>(HA)</i> Initializes an object iterator to find the autonomous partitions
     * contained by this federated database.</p>
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
     * @return  An object iterator that finds the autonomous partitions.
     */
    public Iterator containedAPs()
        { return persistor().containedAPs() ; }

    /**
     * <i>(HA)</i>
     * Finds the autonomous partition whose boot file was used by the current 
     * application to open this federated database.
     * 
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
	 * <p> If the application can no longer access the original boot autonomous partition,
	 * this method finds the partition controlling the system database from
	 * which the application is currently obtaining schema and global catalog
	 * information.
     *
     * <p>No single autonomous partition is statically
     * defined as a boot autonomous partition.
     * Instead, each process determines its boot autonomous
     * partition based on the boot file it uses. If a process requests an
     * object that is outside the control of its boot autonomous
     * partition, the partition transparently locates the object through
     * the global catalog and accesses the object through the
     * controlling autonomous partition.</p>
     *
     * @return      The boot autonomous partition.
     *
     */
    public ooAPObj getBootAP()
        { return persistor().getBootAP() ; }

    synchronized PooFDObj persistor() {
        if (persistor == null)
            throw new ObjyRuntimeException("Can not access this object.  It's session was previously terminated.") ;

        return persistor ;
    }

	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public synchronized void setPersistor(PooFDObj persistor)
        { this.persistor = persistor ; }
}
