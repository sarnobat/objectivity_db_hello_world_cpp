package com.objy.query.expression;

/**
 * Represents the operator group registry, which contains one or more operator groups.
 */
public class OperatorGroupRegistry
{

    /**
     * Creates an operator group with the specified name and adds it to the registry.
     * @param name The name of the operator group
     * @return The created operator group
     */
    /*static OperatorGroup registerNewOperatorGroup(String name)
    {
        OperatorGroup opGroup = null;
        long opGroupId = Binding.registerNewOperatorGroup(name); // same as createAddOperatorGroup(). 
        if (opGroupId != 0)
            opGroup = new OperatorGroup(name, opGroupId);
        return opGroup;
    }*/

    /**
     * Removes an operator group from the registry.
     */
    /*static void removeOperatorGroup(OperatorGroup group)
    {
        Binding.removeOperatorGroup(group.getId());
    }*/

    /**
     * Returns the total number of operator groups.
     */
    public static int getNumberOfOperatorGroups()
    {
        return Binding.getNumberOfOperatorGroups();
    }

    /**
     * Returns the operator group at the specified index.
     */
    public static OperatorGroup getOperatorGroup(int index)  
    {
        OperatorGroup opGroup = null;
        long conn = Binding.getOperatorGroup(index);
        if (conn != 0)
            opGroup = new OperatorGroup(conn);
        return opGroup;
    }

    /**
     * Returns the operator group with the specified name, 
     * or null if no such group exists.
     */
    public static OperatorGroup getOperatorGroup(String name)
    {
        OperatorGroup opGroup = null;
        long conn = Binding.getOperatorGroup(name);
        if (conn != 0)
            opGroup = new OperatorGroup(conn);
        return opGroup;
    }

   /**
     * Returns all operators that have a result type compatible with that 
     * specified.
     */
    /*static OperatorGroup getCompatibleOperators(ExpressionResultSpec resultType)
    {
        OperatorGroup opGroup = null;
        long id = Binding.getCompatibleOperators(resultType.getId());
        if (id != 0)
            opGroup = new OperatorGroup(id);
        return opGroup;
    }*/

    /**
     * Returns all operators having a token name that matches the specified 
     * tokenName. The operator groups in the registry are iterated in reverse
     * order, so the later overloaded operators are looked up first. 
     * This method is called from ooOperatorExpression::completSetup() to get
     * all matching operators by token in order to perform the operator lookup.
     * The caller is responsible for deleting the returned group.
     */
    static OperatorGroup getMatchingOperators(String tokenName)
    {
        OperatorGroup opGroup = null;
        long id = Binding.getMatchingOperators(tokenName);
        if (id != 0)
        {
            opGroup = new OperatorGroup(id);
        }
        return opGroup;
    }

    static class Binding
    {
        private native static long registerNewOperatorGroup(String name);
        
        // Returns the total number of operator groups.
        private native static int getNumberOfOperatorGroups();
        
        // Returns the operator group for the specified index.
        private native static long getOperatorGroup(int index);
        
        // Returns the operator group with the specified name, 
        // or null if no such group exists.
        private native static long getOperatorGroup(String name);
        
        // Returns all operators that have a result type compatible with that 
        // specified.
        // The caller is responsible for deleting the returned group.
        private native static long getCompatibleOperators(long id);
        
        // Returns all operators having a token name that matches the specified 
        // tokenName. The operator groups in the registry are iterated in reverse
        // order, so the later overloaded operators are looked up first. 
        // This method is called from ooOperatorExpression::completSetup() to get
        // all matching operators by token in order to perform the operator lookup.
        // The caller is responsible for deleting the returned group.
        private native static long getMatchingOperators(String token);
        
    }
}
