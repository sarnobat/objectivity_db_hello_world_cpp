/*
 * @(#)LockNotGrantedException.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

import com.objy.db.app.TransactionInfo;
import com.objy.db.app.oo;
import com.objy.db.app.ooId;
import com.objy.pm.Access;

/**
 * Signals a failure to obtain a requested lock.
 *
 * <p>A lock request fails because of a <i>lock conflict</i>; namely, one or  
 * more other clients already hold locks that are inconsistent with a 
 * simultaneous lock of the kind that was requested.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information About 
 * Conflicting&nbsp;Locks</B></TD>
 *
 * <TD><A HREF="#getOID()">getOID()</A><BR>
 * 	<A HREF="#getLockMode()">getLockMode()</A><BR>
 * 	<A HREF="#getTransactions()">getTransactions()</A><BR>
 * </TD></TR>
 * </TABLE>
 *
 *
 */
public class   LockNotGrantedException
       extends ODMGRuntimeException
{
	private TransactionInfo[] transInfo;
	private ooId OID;
	private int lockMode;
	
	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public LockNotGrantedException() {
        super();
	Access.fillException(this);
    }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public LockNotGrantedException(String msg) {
        super(msg);
	Access.fillException(this);
    }
    
    /**
     * Gets information about the conflicting locks.</p>
     *
     * <p>You can obtain information about conflicting locks only if the
     * collection of lock-conflict information was enabled  
     * <i>before</i> this exception was thrown. 
     * To enable the collection of lock-conflict information,  
     * call the session's 
     * <a href="./app/Session.html#setLockConflictInfo(boolean)">
     * <tt>setLockConflictInfo</tt></a> method.</p>  
     *
     * @return  An array of <a href="./app/TransactionInfo.html">
     * transaction-information objects</a> describing the transactions that 
     * hold conflicting locks. The returned array is empty if the session has 
     * not enabled collection of lock-conflict information or if the lock 
     * server being used is an older version that does not support
     * lock-conflict information.</p>
     */
    public TransactionInfo[] getTransactions()
        { return transInfo; }

    /**
     * Gets the object identifier of the object for which a lock was 
     * requested.</p>
     *
     * @return      The object identifier of the object for which a lock was 
     * requested, or null if the lock failure occurred in some other context.
     */
    public ooId getOID()
        { return OID; }
        
    /**
     * Gets the type of lock that was requested.</p>
     *
     * @return      The type of lock that was requested; one of the following
	 *  constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Write lock.
     *
         *  <dt><tt>EXCLUSIVE_WRITE</tt><dd>Exclusive Write lock.
	 * </dl></dl>
     */
    public int getLockMode() {
        if (lockMode == oo.openReadOnly) return oo.READ;
        if (lockMode == oo.openReadWrite) return oo.WRITE;
	/*SPR 15900 -- support for exclusive update lock on database*/
        if (lockMode == oo.openExclusive) return oo.EXCLUSIVE_WRITE;
        else return oo.NONE;
    }

	/**
	 * Reserved for internal use.
	 */
    public void fillException(TransactionInfo[] _transInfo, ooId _OID, int _lockMode) {
        transInfo = _transInfo;
	OID = _OID;
	lockMode = _lockMode;
    }
}


