package com.objy.query.expression;
/**
 * Represents an OID literal value node.
 *
 */
public class OidLiteralValueExpression extends LiteralValueExpression 
{
	
	/**
	 * Constructs an OID literal value node.
	 */
    public OidLiteralValueExpression() 
    {
        this(Binding.create());
    }
    
    /**
     * Constructs an OID literal value node with database, container, page and slot IDs.
     */
    public OidLiteralValueExpression(int db, int cont, int page, int slot) 
    {
        this(Binding.create(db, cont, page, slot));
    }
    
    /**
     * Constructs an OID literal value node with an ID.
     * @param id
     */
	OidLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }
    
    /**
     * Constructs an OID literal value node with an OID string.
     */
    public OidLiteralValueExpression (String oid) 
    {
    	String[] tokens = Util.verifyOidArgument(oid);

    	int slot = Integer.parseInt(tokens[3]);
    	int page = Integer.parseInt(tokens[2]);
    	int cont = Integer.parseInt(tokens[1]);
    	int db = Integer.parseInt(tokens[0]);
    	setIdAfterNullCheck(Binding.create(db, cont, page, slot));
    }
    
    /**
     * Returns the OID value.
     * 
     */
    public String getValue() 
    {
        return getPQLRepresentation();
    }

    /**
     * Sets the OID value.
     */
    public void setValue(int db, int cont, int page, int slot) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.setValue(mId, db, cont, page, slot);
    }
    
    public String toString()
    {
    	return getValue();
    }
    
	@Override
	/**
	 * Returns the type of the expression (oocOidLiteralValueExpression).
	 */
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.OidLiteralValueExpression; 
    }
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitOidLiteralValue(this);
    }
    
    static class Binding
    {
        private static native long create();
        private static native long create(int db, int cont, int page, int slot);
        private static native void setValue(long id, int db, int cont, int page, int slot);
        
    }
}
