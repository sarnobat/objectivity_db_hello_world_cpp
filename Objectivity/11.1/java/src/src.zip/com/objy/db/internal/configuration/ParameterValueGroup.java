package com.objy.db.internal.configuration;

import com.objy.db.internal.tools.ToolRegistry;


public class ParameterValueGroup {

    static
    {
        ToolRegistry.init();
    }
    
    private long mParameterValueGroupPtr; 
    //right now all we need is the default constructor
    /**
     * Creates a parameterValueGroup which is a collection of key/value arguments
     * to be passed to tool execution
     */
    public ParameterValueGroup()
    {
        mParameterValueGroupPtr = Binding.construct();
    }
    
    /**
     * Reserved for internal use
     * @param parameterValueGroupPtr
     */
    public ParameterValueGroup(long parameterValueGroupPtr)
    {
        mParameterValueGroupPtr = parameterValueGroupPtr;
    }
    
    /**
     * Add a parameter key/value
     * @param name Name of the parameter 
     * @param value Value of the parameter
     */
    public void addValue(String name, String value)
    {
        Binding.addValue(mParameterValueGroupPtr, name, value);
    }
    
    /**
     * Remove a parameter key/value
     * @param name Name of parameter to remove
     * @return true if parameter key/value was removed else false
     */
    public boolean removeItem(String name)
    {
        return Binding.removeItem(mParameterValueGroupPtr, name);
    }
    
    /**
     * Reserved for internal use only.
     * @return
     */
    public long getObject()
    {
        return mParameterValueGroupPtr;
    }
    
    protected void finalize() throws Throwable 
    {
        Binding.destruct(mParameterValueGroupPtr);
    }
    
    private static class Binding
    {
        public static native void destruct(long mParameterValueGroupPtr);
        public static native long construct();
        public static native void addValue(long mParameterValueGroupPtr, 
                String name, String value);
        public static native boolean removeItem(long mParameterValueGroupPtr,
                String name);
    }
}
