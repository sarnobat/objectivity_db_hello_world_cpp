/*
 * @(#)ooTreeBasedCollection.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;

import com.objy.db.ObjectIsDeadException;
import com.objy.db.ObjectNotPersistentException;
import com.objy.pm.ooTreeBasedCollectionsPersistor;

/**
 * Abstract superclass for persistence-capable classes that represent 
 * scalable ordered collections containing persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>  Scalable ordered collections  can
 * increase in size with minimal performance degradation. They are
 * implemented using a B-tree data structure so that
 * elements can be added, deleted, and found efficiently. 
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Properties of Scalable Ordered Collections">
 * Properties of Scalable Ordered Collections</a>.
 *
 * <p>Concrete subclasses of <tt>ooTreeBasedCollection</tt> represent more specific kinds of
 * ordered collections:
 * <a href="ooTreeSetX.html">sorted sets</a> of persistent objects,
 * <a href="ooTreeListX.html">lists</a> of persistent objects, and 
 * <a href="ooTreeMapX.html">sorted object maps</a>.
 *
 * <p>Because this class is abstract, you never instantiate it; instead, you
 * work with instances of its concrete derived classes. You should not create
 * your own subclasses of this class.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#first()">first()</a><br>
 *     <a href="#last()">last()</a><br>
 *     <a href="#get(int)">get(int)</a><br>
 *     <a href="#iterator()">iterator()</a><br>
 *     <a href="#ooIterator()">ooIterator()</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#ooAddAll(com.objy.db.util.ooCollection)">ooAddAll(ooCollection)</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#ooRemoveAll(com.objy.db.util.ooCollection)">ooRemoveAll(ooCollection)</a><br>
 *     <a href="#ooRetainAll(com.objy.db.util.ooCollection)">ooRetainAll(ooCollection)</a><br>
 *     <a href="#removeAllDeleted()">removeAllDeleted()</a><br>
 *     <a href="#clear()">clear()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 *     <td>
 *     <a href="#size()">size()</a><br>
 *     <a href="#depth()">depth()</a><br>
 *     <a href="#comparator()">comparator()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Viewing in an MROW&nbsp;Transaction</b></td>
 *     <td VALIGN="top">
 *     <a href="#refresh(int)">refresh(int)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 *     <td>
 *     <a href="#isEmpty()">isEmpty()</a><br>
 *     <a href="#contains(java.lang.Object)">contains(Object)</a><br>
 *     <a href="#ooContainsAll(com.objy.db.util.ooCollection)">ooContainsAll(ooCollection)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Maintaining&nbsp;the&nbsp;B-tree</b></td>
 *     <td>
 *     <a href="#compact()">compact()</a>
 *     </td></tr>
 * </table>
 */
abstract public class ooTreeBasedCollection extends ooCollection
{
    ooTreeBasedCollection() {}

    /**
     * Minimizes the number of nodes in this ordered collection.
     *
     * <p>After you have added all elements that you expect this ordered collection to have,
     * you can call this method to minimize the number of nodes in its B-tree.
     * Doing so saves space and improves read performance. Indexes of
     * elements within the collection remain unchanged.
     *
     * <p>If you call this method before all elements have been added, insert (add) performance
     * will not necessarily improve.  After the B-tree has been compacted, adding an element
     * will very likely cause one or more nodes to be added to the B-tree.
     */
    public void compact()
    {
        getTreeBasedCollectionPersistor().compact();
    }

	/**
	 * Gets the depth of this ordered collection's B-tree. </p>
	 * 
	 * @return	The number of nodes between the root and a leaf node in this ordered collection�s B-tree.
	 */
	public int depth()
    {
        return getTreeBasedCollectionPersistor().depth();
    }
    
    /**
     * Sets this ordered collection to an empty collection, removing any elements it
     * contains. </p>
     *
     * @see #ooRemove(Object)
     * @see #ooRemoveAll(ooCollection)
     * @see #ooRetainAll(ooCollection)
     */
    public void clear()
    {
        getTreeBasedCollectionPersistor().clear();
    }


	/**
	 * Tests whether this ordered collection contains the specified
	 * object. </p>
	 *
	 * @param 	 object  The object to be tested for
	 * containment in this ordered collection.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the element (or key) of interest.  
	 * If this ordered collection has a 
	 * <a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Sorted Collections">
	 * custom comparator</a> that can identify an element based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the element (or key) of interest. 
	 * (Such a custom comparator may, but need not, support the implicit use of
     * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">
	 * comparison arrays</a> to optimize comparison.)</p>
	 *
	 * @return      True if this ordered collection contains an element equal to
	 * the specified element; otherwise, false.</p>
	 */
	public boolean contains(Object object) {
        int[] comparisonArray = null;
        ooCompare comp = (ooCompare)comparator();
        if (comp != null && comp.comparisonArraySize() > 0)
        {
            comparisonArray = new int[comp.comparisonArraySize()];
            comp.setComparisonArrayFromObject(object, comparisonArray);
        }
        return getTreeBasedCollectionPersistor().contains(object, comparisonArray);
    }

    /**
     * Adds all elements (or keys) in the specified collection to this
     * collection. </p>
     *
     * @param 	 collection	The collection whose elements are to
     * be added to this ordered collection.  If the elements of <tt><i>collection</i></tt> are
     * key-value pairs and the elements of this ordered collection are persistent objects,
     * only the keys of <tt><i>collection</i></tt> are added to this
     * collection.</p>
     *
     * @return		True if any elements were added; otherwise, false.</p>
     *
     * @see #add(Object)
     * @see #ooRemoveAll(ooCollection)
     */
    public boolean ooAddAll(ooCollection collection)
    {
        if (comparator() == null)
            return getTreeBasedCollectionPersistor().addAll(collection);
        Iterator itr = collection.keyIterator();
        boolean mod = false;
        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

    /**
     * Tests whether this ordered collection contains all elements (or keys) in the specified
     * collection.
     *
     * <p>The meaning of this method depends on whether the elements of the collections being
     * compared are persistent objects or  key-value pairs.
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of This&nbsp;Collection</b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of <tt><i>collection</i></tt><b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Tests Whether</td></b></tr>
     * <tr><td>persistent objects</td>
     *		<td>persistent objects</td>
     *		<td>This collection contains all elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>persistent objects</td>
     *		<td>key-value pairs</td>
     *		<td>This collection contains all keys of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>persistent objects</td>
     *		<td>All elements of <tt><i>collection</i></tt>
     * are keys of this collection</td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>key-value pairs</td>
     *		<td>All keys of <tt><i>collection</i></tt>
     * are also keys of this collection</td></tr>
     * </table></p>
     *
     * @param 	 collection	The collection whose elements
     * (or keys) are
     * to be tested for containment in this ordered collection.</p>
     *
     * @return		True if this ordered collection contains an element (or key) equal to
     * each element (or key) of <tt><i>collection</i></tt>; otherwise, false. 
     * </p> 
     *
     * @see #contains(Object)
     */
    public boolean ooContainsAll(ooCollection collection) {
        if (comparator() == null)
            return getTreeBasedCollectionPersistor().containsAll(collection);
        else
        {
            Iterator itr = collection.keyIterator();
    	    while (itr.hasNext())
    	        if (!contains(itr.next()))
    	            return false;
    	    return true;
        }
    }


    /**
     * Finds the first element (or key) in this ordered collection. </p>
     *
     * @return      If the elements of this ordered collection are persistent objects,
     * the first element; if the elements are
     * key-value pairs, the key of the first element.</p>
     *
     * @see #last
     * @see #get
     */
    public Object first() {
        if (isEmpty())
            throw new NoSuchElementException("Collection is empty.");
        return getTreeBasedCollectionPersistor().first();
    }

    /**
     * Finds the last element (or key) in this ordered collection. </p>
     *
     * @return      If the elements of this ordered collection are persistent objects,
     * the last element; if the elements are
     * key-value pairs, the key of the last element.</p>
     *
     * @see #first
     * @see #get
     */
    public Object last() {
        if (isEmpty())
            throw new NoSuchElementException("Collection is empty.");
        return getTreeBasedCollectionPersistor().last();
    }

    /**
     * Finds the element (or key) of this ordered collection at the specified
     * index. </p>
     *
     * @param 	 index   The zero-based index of the 
     * element to find.</p> 
     *
     * @return      If the elements of this ordered collection are persistent objects,
     * the element whose index is <tt><i>index</i></tt>; if the elements are
     * key-value pairs, the key of the element whose index is
     * <tt><i>index</i></tt>.</p>
     *
     * @see #first
     * @see #last
     */
    public Object get(int index)
    {
        int size = size();
        if (index < 0 || index > size)
            throw new IndexOutOfBoundsException ("Specified index is out of range: 0 - " + size);
        return getTreeBasedCollectionPersistor().get(index);
    }
    
    /**
     * Tests whether this ordered collection is empty. </p>
     *
     * @return      True if this ordered collection has no elements; otherwise,
     * false.
     */
    public boolean isEmpty()
    {
        return getTreeBasedCollectionPersistor().isEmpty();
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this ordered collection. </p>
     *
     * @return      A scalable-collection iterator for finding the elements of this ordered collection.  
	 * The iterator finds the
     * elements as ordered in the collection.
     */
    public ooCollectionIterator ooIterator()
    {
        return getTreeBasedCollectionPersistor().iterator();
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this ordered collection. </p>
     *
     * @return      A scalable-collection iterator for finding the elements of this ordered collection. 
	 * The iterator finds the
     * elements as ordered in the collection.
     */
    public Iterator iterator()
    {
        return ooIterator();
    }

    /**
     * Removes the first occurrence of the specified object from this ordered collection.
     *
     * <p>If the elements of this ordered collection are persistent objects, this method removes the
     * first element (if any) that is
     * equal to <tt><i>object</i></tt>.
     * If the elements are key-value pairs, this method removes the
     * element (if any) whose key is <tt><i>object</i></tt>. </p>
     *
     * @param 	 object  The object to be removed.</p>
     *
     * @return      True if an element was removed; otherwise, false.</p>
     *
     * @see #clear
     * @see #ooRemoveAll(ooCollection)
     * @see #ooRetainAll(ooCollection)
     */
    public boolean ooRemove(Object object)
    {
        int[] comparisonArray = null;
        ooCompare comp = (ooCompare)comparator();
        if (comp != null && comp.comparisonArraySize() > 0)
        {
            comparisonArray = new int[comp.comparisonArraySize()];
            comp.setComparisonArrayFromObject(object, comparisonArray);
        }
        return getTreeBasedCollectionPersistor().remove(object, comparisonArray);
    }


    /**
     * Removes from this ordered collection all persistent objects that have been
     * deleted from the federated database.
     *
     * <p>If the elements of this ordered collection are persistent objects, this
     * method removes any element that has been deleted.  If the elements are
     * key-value pairs, this method removes any element in which either the
     * key or the value has been
     * deleted.
     *
     * <p>You can call this method to restore this ordered collection's referential
     * integrity.
     */
    public void removeAllDeleted()
    {
        getTreeBasedCollectionPersistor().removeAllDeleted();
    }

    /**
     * Retains all elements of this ordered collection that are also in the specified
     * collection, removing all other elements.
     *
     * <p>Which elements are removed depends on whether the elements of the two collections
     * are persistent objects or key-value pairs.
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of This&nbsp;Collection</b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of <tt><i>collection</i></tt><b></td>
     *	<td VALIGN="top" WIDTH="1%"><b>Removes From This Collection</td></b></tr>
     * <tr><td>persistent objects</td>
     *		<td>persistent objects</td>
     *		<td>All elements that are not also elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>persistent objects</td>
     *		<td>key-value pairs</td>
     *		<td>All elements that are not keys of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>persistent objects</td>
     *		<td>All elements whose keys are not elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *		<td>key-value pairs</td>
     *		<td>All elements whose keys are not also keys of
     * <tt><i>collection</i></tt></td></tr>
     * </table></p>
     *
     * @param 	 collection	The collection whose elements
     * (or keys) are to be retained in this ordered collection.</p>
     *
     * @return		True if any elements were removed; otherwise, false.</p>
     *
     * @see #clear
     * @see #ooRemove(Object)
     * @see #ooRemoveAll(ooCollection)
     */
    public boolean ooRetainAll(ooCollection collection) {
        if (collection.comparator() == null)
            return getTreeBasedCollectionPersistor().retainAll(collection);
        else {
            if (collection == null)
                throw new NullPointerException("The specified collection is null.");
            boolean changed = false;
            Iterator itr = keyIterator();
            while (itr.hasNext())
                if (!collection.contains(itr.next())) {
                    itr.remove();
                    changed = true;
                }
            return changed;
        }
    }

    /**
     * Removes all elements (or keys) of the specified collection from this ordered collection.
     *
     * <p>Which elements are removed depends on whether the elements of the two collections
     * are persistent objects or key-value pairs.
     * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="90%">
     * <tr>
     *  <td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of This&nbsp;Collection</b></td>
     *  <td VALIGN="top" WIDTH="1%"><b>Elements&nbsp;of <tt><i>collection</i></tt><b></td>
     *  <td VALIGN="top" WIDTH="1%"><b>Removes From This Collection</td></b></tr>
     * <tr><td>persistent objects</td>
     *      <td>persistent objects</td>
     *      <td>All elements that are also elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>persistent objects</td>
     *      <td>key-value pairs</td>
     *      <td>All elements that are keys of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *      <td>persistent objects</td>
     *      <td>All elements whose keys are elements of
     * <tt><i>collection</i></tt></td></tr>
     * <tr><td>key-value pairs</td>
     *      <td>key-value pairs</td>
     *      <td>All elements whose keys are also keys of
     * <tt><i>collection</i></tt></td></tr>
     * </table></p>
     *
     * @param 	 collection  The collection whose elements are to be
     * removed from this ordered collection.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #clear
     * @see #ooRemove(Object)
     * @see #ooRetainAll(ooCollection)
     */
    public boolean ooRemoveAll(ooCollection collection)
    {
        if (collection == this)
        {
            if (isEmpty())
                return false;
            else
                return getTreeBasedCollectionPersistor().removeAll(collection);
        }
        boolean changed = false;
        Iterator itr = collection.keyIterator();
        while (itr.hasNext())
            if (ooRemove(itr.next()))
                changed = true;
        return changed;
   }

    /**
     * Gets the comparator for this ordered collection. </p>
     *
     * @return      The comparator for this ordered collection, or null if this
     * collection has a default comparator.
     */
    public Comparator comparator()
    {
        return getTreeBasedCollectionPersistor().comparator();
    }

    /**
     * Refreshes each container used internally by this ordered collection, except 
     * for the container in which the collection itself is stored.  
     *
     * <p>You typically call this method when you need to refresh 
     * your view of a collection that you are reading in an MROW 
     * transaction.  This method calls 
     * {@link com.objy.db.app.storage.ooContObj#refresh <tt>refresh</tt>}
     * on each container that is used internally by the collection--that is, 
     * on the node  
     * containers maintained by an ordered scalable collection, 
     * or the hash-bucket containers maintained by an 
     * unordered scalable
     * collection. This method does not refresh the container in which the 
     * collection itself is stored, nor does it necessarily refresh the 
     * containers that store the collection's elements.</p>        
     *
     * @param 	 mode    The type of lock to obtain for 
     * each refreshed container; one of the following constants defined in 
     * the <tt>com.objy.db.app.oo</tt> interface: 
     * <dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
     * </dl>
     */
   public void refresh(int mode)
   {
      getTreeBasedCollectionPersistor().refresh(mode);
   }
   
   /**
    * Gets the size of this ordered collection. </p>
    *
    * @return       The number of elements in this ordered collection.
    */
    public int size() {
       return getTreeBasedCollectionPersistor().size();
    }

   /**
     * Reserved for internal use; you should not call this method. </p>
     */
    protected ooTreeBasedCollectionsPersistor getTreeBasedCollectionPersistor()
    {
       if (getPersistor() == null)
           throw new ObjectNotPersistentException("Attempted persistence operation on transient object") ;
       if (getPersistor().isDead())
           throw new ObjectIsDeadException("Attempted persistence operation on dead object");
       return (ooTreeBasedCollectionsPersistor) getPersistor() ;
   }
}
