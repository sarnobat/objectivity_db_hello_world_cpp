package com.objy.query.expression;

/**
 * Represents an expression exception. Reserved for internal use.
 */
public class ExpressionException extends RuntimeException 
{
    
    private static final long serialVersionUID = 1L;
    
    /**
     * Constructs an expression setup exception with a message.
     * @param message
     */
    public ExpressionException(String message) 
    {
        super(message);
    }
    
}
