/*
 * @(#)SchemaPolicy.java
 * 
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Defines behavior shared by all schema policies.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>A <i>schema policy</i> controls what types of modifications the application
 * can make to the schema of the federated database during a particular
 * connection. Properties of the schema policy specify whether:
 * <ul>
 * <li>New class descriptions can be added to the schema.
 * <li>Existing class descriptions in the schema can be modified.
 * <li>A field's access control is considered in testing whether its description is
 * the same in the schema and the Java class declaration.
 * <li>Informational messages are printed.
 * </ul>
 *
 * <p>A connection has an associated schema policy that controls
 * which of these modifications the application can make.
 * <ul>
 * <li>If the schema policy does not allow new class descriptions to be added
 * to the schema, an exception will be thrown if the application tries to
 * add a class description, either with an explicit call to the connection's
 * <a href="Connection.html#registerClass(java.lang.String)"><tt>registerClass</tt></a>
 * method, or implicitly by making an object of
 * the class persistent.
 * <LI>If the schema policy does not allow modifications to existing class
 * descriptions,  an exception will be thrown if the application tries to
 * modify a class description, either with an explicit call to
 * <tt>registerClass</tt>, or implicitly by writing a persistent object of
 * a class whose Java definition does not match its existing schema
 * description. The schema policy controls whether the field access control must be
 * the same for a schema class description to match the corresponding Java class
 * declaration. </p>
 * </ul>
 *
 * You can obtain the schema policy for your application's
 * current connection by calling the
 * <a href="Connection.html#getSchemaPolicy()"><tt>getSchemaPolicy</tt></a>
 * method of the connection object.
 *
 * <p>You can call methods of the schema policy to test and set its
 * properties.  In addition, you can lock the schema policy by calling its
 * <a href="#setPolicyLocked()"><tt>setPolicyLocked</tt></a> method.  Once you
 * have locked the policy, you cannot make any additional changes to it.
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	<td>
 *     <a href="#isChangeClassAllowed()">isChangeClassAllowed()</a><br>
 *     <a href="#isCreateClassAllowed()">isCreateClassAllowed()</a><br>
 *     <a href="#isFieldAccessControlEnforced()">isFieldAccessControlEnforced()</a><br>
 *     <a href="#isPolicyLocked()">isPolicyLocked()</a><br>
 *     <a href="#isVerbose()">isVerbose()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Setting&nbsp;Properties</b></td>
 * 	<td>
 *     <a href="#setChangeClassAllowed(boolean)">setChangeClassAllowed(boolean)</a><br>
 *     <a href="#setCreateClassAllowed(boolean)">setCreateClassAllowed(boolean)</a><br>
 *     <a href="#setFieldAccessControlEnforced(boolean)">setFieldAccessControlEnforced(boolean)</a><br>
 *     <a href="#setPolicyLocked()">setPolicyLocked()</a><br>
 *     <a href="#setVerbose(boolean)">setVerbose(boolean)</a>
 * 	</td></tr>
 * </table>
 */
public interface SchemaPolicy
{
	/**
	 * Locks this schema policy.
	 *
	 * <p>By default, a schema policy is unlocked.  After calling this method, you may
	 * not make any additional changes to this schema policy.
	 *
	 * <p>If this schema policy is already locked, this method throws an
	 * <tt>ObjyRuntimeException</tt>.
	 *
	 */
    void setPolicyLocked() ;
    
	/**
	 * Tests whether this schema policy is locked.</p>
	 *
	 * @return		True if this schema policy is locked; otherwise, false.
	 */
    boolean isPolicyLocked() ;
    
	/**
	 * Specifies whether this schema policy allows new classes to be added to
	 * the schema.
	 *
	 * <p>By default, a schema policy allows new classes to be added to
	 * the schema. You may want to change this setting in a deployed
	 * application.
	 *
	 * <p>If this schema policy is locked, this method throws an
	 * <tt>ObjyRuntimeException</tt>.</p>
	 *
	 * @param 	 allowed	True to allow
	 * new classes to be added to the schema and false to disallow new
	 * classes to be added to the schema.
	 */
    void setCreateClassAllowed(boolean allowed) ;
        
	/**
	 * Tests whether this schema policy allows new classes to be added to
	 * the schema.</p>
	 *
	 * @return		True if this schema
	 * policy allows new classes to be added; otherwise, false.
	 */
    boolean isCreateClassAllowed() ;
        
	/**
	 * Specifies whether this schema policy allows existing class
	 * descriptions to be modified.
	 *
	 * <p>By default, a schema policy allows existing class descriptions in
	 * the schema to be modified. You may want to disable modification in a
	 * deployed application.
	 *
	 * <p>If this schema policy is locked, this method throws an
	 * <tt>ObjyRuntimeException</tt>.</p>
	 *
	 * @param 	 allowed	True to
	 * allow existing class descriptions in the schema to be modified
	 * and false to disallow existing class descriptions to be modified.
	 */
    void setChangeClassAllowed(boolean allowed) ;
        
	/**
	 * Tests whether this schema policy allows existing class
	 * descriptions to be modified.</p>
	 *
	 * @return		True if existing class
	 * descriptions can be modified; otherwise, false.
	 */
    boolean isChangeClassAllowed() ;
        
	/**
	 * Specifies whether this schema policy requires a field in a class description
	 * to have the same access control as the corresponding field in the
 	 * Java class declaration.
	 *
	 * <p>By default, a schema policy requires access control to be the
	 * same. You may want to disable this requirement for compatibility with
	 * applications written in other Objectivity/DB programming languages.
	 *
	 * <p>If this schema policy is locked, this method throws an
	 * <tt>ObjyRuntimeException</tt>.</p>
	 *
	 * @param 	 enforced	True to enable the
	 * enforcement of access control, and false to disable the enforcement of 
     * access control.
	 */
    void setFieldAccessControlEnforced(boolean enforced) ;
        
	/**
	 * Tests whether this schema policy enforces access control.</p>
	 *
	 * @return		True if this
	 * schema policy enforces access control; otherwise, false.
	 */
    boolean isFieldAccessControlEnforced() ;

	/**
	 * Specifies whether this schema policy prints informational messages in
	 * addition to error messages.
	 *
 	 * <p>A schema policy always prints error messages and by default
 	 * prints informational messages.
 	 *
	 * <p>If this schema policy is locked, this method throws an
	 * <tt>ObjyRuntimeException</tt>.</p>
	 *
	 * @param 	 verbose	True to make this schema policy print
	 * informational messages, and false to make it print only error messages.
	 */
    void setVerbose(boolean verbose) ;
        
	/**
	 * Tests whether this schema policy prints informational messages.</p>
	 *
	 * @return		True if this schema policy prints informational
	 * messages, and false if it prints only error messages.
	 */
    boolean isVerbose() ;
}


