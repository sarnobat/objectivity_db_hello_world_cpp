/*
 * @(#)oo.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.pm.Access ;

/**
 * Defines constants used as parameters and return values by many methods.
 *
 * <p>You need not implement this interface in any of your classes; however,
 * doing so allows you to refer to the constants with their unqualified names,
 * such as <tt>READ</tt>. If your class does not implement this interface,
 * it must use the fully-qualified constant names, such as
 * <tt>com.objy.db.app.oo.READ</tt>.
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr valign=top><td><a name = "threadPolicy"><b>Thread policies</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how Java threads may interact with
 * sessions and transactions.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#THREAD_POLICY_RESTRICTED">THREAD_POLICY_RESTRICTED</a><br>
 *     <a href="#THREAD_POLICY_UNRESTRICTED">THREAD_POLICY_UNRESTRICTED</a><br>
 *     <a href="#THREAD_POLICY_UNRESTRICTED">THREAD_POLICY_CONCURRENT</a>
 * 	</td>
 * <tr valign=top><td><a name = "transMROW"><b>MROW modes</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify which concurrent access policy is used by
 * a session's transactions.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#MROW">MROW</a><br>
 *     <a href="#NO_MROW">NO_MROW</a>
 * 	</td>
 * <tr valign=top><td><a name = "waitOptions"><b>Wait options</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify whether to wait for locks when
 * starting a transaction.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#WAIT">WAIT</a><br>
 *     <a href="#NO_WAIT">NO_WAIT</a> <!-- <br>
 *     <a href="#TRANS_NO_WAIT">TRANS_NO_WAIT</a> -->
 *     </td>
 * <tr valign=top><td><a name = "ooIndexMode"><b>Index modes</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Control when indexes
 * are updated after indexed objects' key fields are modified.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#SENSITIVE">SENSITIVE</a><br>
 *     <a href="#INSENSITIVE">INSENSITIVE</a><br>
 *     <a href="#EXPLICIT_UPDATE">EXPLICIT_UPDATE</a>
 *     </td>
 * <tr valign=top><td><a name = "ooDownGradeMode"><b>Downgrade modes</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify whether write locks
 * should be downgraded to read locks after a checkpoint operation.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#DOWNGRADE_ALL">DOWNGRADE_ALL</a><br>
 *     <a href="#NO_DOWNGRADE">NO_DOWNGRADE</a>
 *     </td>
 * <tr valign=top><td><a name = "ooMode"><b>Open modes</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how a connection to the federated database was opened.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#openReadOnly">openReadOnly</a><br>
 *     <a href="#openReadWrite">openReadWrite</a><br>
 *     <a href="#notOpen">notOpen</a>
 *     </td>
 * <tr valign=top><td><a name = "ooLockMode"><b>Lock modes</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Control how
 * Objectivity/DB objects are locked.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#READ">READ</a><br>
 *     <a href="#WRITE">WRITE</a><br>
 *     <a href="#NONE">NONE</a>
 *     </td>
 * <tr valign=top><td><a name = "ooAccessMode"><b>Field access levels</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify the access level of attributes that
 * can be tested by predicate queries.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#PUBLIC">PUBLIC</a><br>
 *     <a href="#ALL">ALL</a>
 *     </td>
 * <tr valign=top><td><a name = "ooErrorLevel"><b>Error levels</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify the severity of a runtime error that caused an exception to be thrown.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#NO_ERROR">NO_ERROR</a><br>
 *     <a href="#WARNING">WARNING</a><br>
 *     <a href="#USER_ERROR">USER_ERROR</a><br>
 *     <a href="#SYSTEM_ERROR">SYSTEM_ERROR</a><br>
 *     <a href="#FATAL_ERROR">FATAL_ERROR</a>
 *     </td></tr>
 * <tr valign=top><td><b>Fetch-error reporting options</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how errors are reported when a
 * source object is fetched but errors occur trying to fetch its
 * referenced destination objects.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#ALL_ERRORS">ALL_ERRORS</a><br>
 *     <a href="#INDIVIDUAL_ERROR">INDIVIDUAL_ERROR</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "ooOfflineMode"><b>Offline modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Control whether the offline status of autonomous partitions is being
 * enforced (HA).</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#ENFORCE">ENFORCE</a><br>
 *     <a href="#IGNORE">IGNORE</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "ooAMSUsage"><b>AMS usage modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Control when to use the Advanced Multithreaded
 * Server (AMS).</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#AMS_PREFERRED">AMS_PREFERRED</a><br>
 *     <a href="#AMS_ONLY">AMS_ONLY</a><br>
 *     <a href="#NO_AMS">NO_AMS</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "InternalLock"><b>Internal lock modes</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify the kind of existing lock on an
 * container or special resource that caused a lock requested to fail.
 * </td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#olmNL">olmNL</a><br>
 *     <a href="#olmIS">olmIS</a><br>
 *     <a href="#olmIC">olmIC</a><br>
 *     <a href="#olmIX">olmIX</a><br>
 *     <a href="#olmS">olmS</a><br>
 *     <a href="#olmR">olmR</a><br>
 *     <a href="#olmC">olmC</a><br>
 *     <a href="#olmX">olmX</a><br>
 *     <a href="#olmLastX">olmLastX</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "Logging"><b>Logging options</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify what types of activity will be logged.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#LogNone">LogNone</a><br>
 *     <a href="#LogMain">LogMain</a><br>
 *     <a href="#LogSession">LogSession</a><br>
 *     <a href="#LogTransactionStatistics">LogTransactionStatistics</a><br>
 *     <a href="#LogTransactionTiming">LogTransactionTiming</a><br>
 *     <a href="#LogOther">LogOther</a><br>
 *     <a href="#LogAll">LogAll</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "iteratorPolicy"><b>Iterator policies</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify what happens to open iterators after session checkpoint.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#CLOSE_ITR">CLOSE_ITR</a><br>
 *     <a href="#KEEP_ITR">KEEP_ITR</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "ooAvailability"><b>Availability status</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Availability of a replicated database. (HA)</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#UNKNOWN_AVAILABILITY">UNKNOWN_AVAILABILITY</a><br>
 *     <a href="#UNAVAILABLE">UNAVAILABLE</a>
 *     <a href="#NON_QUORUM_READ_AVAILABLE">NON_QUORUM_READ_AVAILABLE</a>
 *     <a href="#QUORUM_AVAILABLE">QUORUM_AVAILABLE</a>
 *     <a href="#ALL_AVAILABLE">ALL_AVAILABLE</a>
 *     </td></tr>
 *     
 *      <tr valign=top><td><a name="Signals"></a><b>Signal</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Operating system signals that can be handled by the 
 * Objectivity/DB signal handler.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#SIGABRT">SIGABRT</a><br>
 *     <a href="#SIGALRM">SIGALRM</a><br>
 *     <a href="#SIGBREAK">SIGBREAK</a><br>
 *     <a href="#SIGBUS">SIGBUS</a><br>
 *     <a href="#SIGCANCEL">SIGCANCEL</a><br>
 *     <a href="#SIGCHLD">SIGCHLD</a><br>
 *     <a href="#SIGCONT">SIGCONT</a><br>
 *     <a href="#SIGDANGER">SIGDANGER</a><br>
 *     <a href="#SIGEMT">SIGEMT</a><br>
 *     <a href="#SIGFPE">SIGFPE</a><br>
 *     <a href="#SIGFREEZE">SIGFREEZE</a><br>
 *     <a href="#SIGGRANT">SIGGRANT</a><br>
 *     <a href="#SIGHUP">SIGHUP</a><br>
 *     <a href="#SIGILL">SIGILL</a><br>
 *     <a href="#SIGINFO">SIGINFO</a><br>
 *     <a href="#SIGINT">SIGINT</a><br>
 *     <a href="#SIGIO">SIGIO</a><br>
 *     <a href="#SIGIOT">SIGIOT</a><br>
 *     <a href="#SIGKILL">SIGKILL</a><br>
 *     <a href="#SIGLOST">SIGLOST</a><br>
 *     <a href="#SIGLWP">SIGLWP</a><br>
 *     <a href="#SIGMIGRATE">SIGMIGRATE</a><br>
 *     <a href="#SIGMSG">SIGMSG</a><br>
 *     <a href="#SIGPIPE">SIGPIPE</a><br>
 *     <a href="#SIGPOLL">SIGPOLL</a><br>
 *     <a href="#SIGPRE">SIGPRE</a><br>
 *     <a href="#SIGPROF">SIGPROF</a><br>
 *     <a href="#SIGPWR">SIGPWR</a><br>
 *     <a href="#SIGQUIT">SIGQUIT</a><br>
 *     <a href="#SIGRETRACT">SIGRETRACT</a><br>
 *     <a href="#SIGSEGV">SIGSEGV</a><br>
 *     <a href="#SIGSOUND">SIGSOUND</a><br>
 *     <a href="#SIGSTOP">SIGSTOP</a><br>
 *     <a href="#SIGSYS">SIGSYS</a><br>
 *     <a href="#SIGTERM">SIGTERM</a><br>
 *     <a href="#SIGTHAW">SIGTHAW</a><br>
 *     <a href="#SIGTRAP">SIGTRAP</a><br>
 *     <a href="#SIGTSTP">SIGTSTP</a><br>
 *     <a href="#SIGTTIN">SIGTTIN</a><br>
 *     <a href="#SIGTTOU">SIGTTOU</a><br>
 *     <a href="SIGURG#">SIGURG</a><br>
 *     <a href="#SIGUSR1">SIGUSR1</a><br>
 *     <a href="#SIGUSR2">SIGUSR2</a><br>
 *     <a href="#SIGVTALRM">SIGVTALRM</a><br>
 *     <a href="#SIGWAITING">SIGWAITING</a><br>
 *     <a href="#SIGWINCH">SIGWINCH</a><br>
 *     <a href="#SIGXCPU">SIGXCPU</a><br>
 *     <a href="#SIGXFSZ">SIGXFSZ</a><br>
 *     
 *    
 *     </td></tr>
 * <tr valign=top><td><a name = "ooDiskFormat"><b>Disk-format architectures</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Objectivity/DB architecture that defines
 * a disk format for storage pages.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#alphaosf1">alphaosf1</a><br>
 *     <a href="#alphaosf1_32">alphaosf1_32</a><br>
 *     <a href="#altix">altix</a><br>
 *     <a href="#hprisc">hprisc</a><br>
 *     <a href="#ibmrs6000">ibmrs6000</a><br>
 *     <a href="#iris">iris</a><br>
 *     <a href="#linux86">linux86</a><br>
 *     <a href="#linux86gcc3">linux86gcc3</a><br>
 *     <a href="#lynxppc">lynxppc</a><br>
 *     <a href="#solaris4">solaris4</a><br>
 *     <a href="#solaris7">solaris7</a><br>
 *     <a href="#sparc64">sparc64</a><br>
 *     <a href="#win32">win32</a><br>
 *     <a href="#hpuxia64">hpuxia64</a><br>
 *     <a href="#linux86_64">linux86_64</a><br>
 *     <a href="#solaris86_64">solaris86_64</a><br>
 *     <a href="#win64">win64</a>
 *     </td></tr>
 * <tr valign=top><td><a name = "Reference object implementation"><b>Reference type</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Type of reference that implements a particular 
 * <a href = "ooReference.html">reference object</a>.</td> 
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#WEAK">WEAK</a><br>
 *     <a href="#SOFT">SOFT</a>
 *     </td></tr>

 * <tr valign=top><td><a name = "Snapshot"><b>Snapshot info</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Type for specifying the kind of information to capture in a
 * session snapshot.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#NoInfo">NoInfo</a><br>
 *     <a href="#HeaderInfo">HeaderInfo</a><br>
 *     <a href="#SessionInfo">SessionInfo</a><br>
 *     <a href="#DatabasesInfo">DatabasesInfo</a><br>
 *     <a href="#ContainersInfo">ContainersInfo</a><br>
 *     <a href="#CachePagesInfo">CachePagesInfo</a><br>
 *     <a href="#ShadowPagesInfo">ShadowPagesInfo</a><br>
 *     <a href="#ObjectsInfo">ObjectsInfo</a><br>
 *     <a href="#VarraysInfo">VarraysInfo</a><br>
 *     <a href="#PrintRecentPages">PrintRecentPages</a><br>
 *     <a href="#AllInfo">AllInfo</a><br>
 *     </td></tr>
 *     
 *     <tr valign=top><td><a name = "SnapshotFormat"><b>Snapshot info format</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Type for specifying the output format for the information 
 * captured in a session snapshot.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#Readable">Readable</a><br>
 *     <a href="#CSV">CSV</a><br>
 *     </td></tr>
 *     
 *     <tr valign=top><td><a name = "SnapshotSort"><b>Snapshot sort order</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Type for specifying the order in which to write the 
 * information captured in a session snapshot.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#Ascending">Ascending</a><br>
 *     <a href="#Descending">Descending</a><br>
 *     <a href="#Recent">Recent</a>
 *     </td></tr>
 *     
 *     <tr valign=top><td><a name = "PersistencePolicy"><b>Persistence Policy</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Type for specifying the persistence policy that determines whether
 * transient objects are made persistent when they are linked through relationships.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#Reachability">Reachability</a><br>
 *     <a href="#PreRelease11Behavior">PreRelease11Behavior</a>
 *     </td></tr>
 *     
 * </table>
 */
public interface oo
{
    // Connection access modes

	/** Open mode: The connection is not open; sessions may not be created. */
    int notOpen = 0 ;   // same as oocNoOpen

	/** Open mode: The connection is open for read-only access. */
    int openReadOnly  = 1 ;   // same as oocRead

	/** Open mode: The connection is open for read/write access. */
    int openReadWrite = 2 ;   // same as oocUpdate

	/**
	 * Open mode: Not supported. Do not use this constant.
	 */
    int openExclusive = 3 ;   // not supported

	// Lock modes.

	/** Lock mode: The persistent object is not locked. */
    int NONE =  9 ;  // our own addition...

	/**
	 * Lock mode: The persistent object is locked for  read.
	 */
    int READ = 10 ;  // oocLockRead = 0

	/**
	 * Lock mode: The persistent object is locked for write.
	 */
    int WRITE = 11 ;  // oocLockUpdate = 1

	/**
	 * Lock mode: The Objectivity/DB object is locked for exclusive write.
	 */
    /* SPR 15900 -- support for exclusive update lock on database */
    int EXCLUSIVE_WRITE = 12 ;  // oocLockExclusiveUpdate = 3

	/**
	 * Lock mode: Not supported. Do not use this constant.
	 */
    int UPGRADE = -1 ;  // not supported

	/** MROW mode: Transactions use the standard concurrent access policy.*/
    int NO_MROW = 0 ;   // oocNoMROW  = 0 ;

	/** MROW mode: Transactions use the Multiple Readers, One Writer (MROW)
      * concurrent access policy.*/
    int MROW = 8 ;   // oocMROW    = 8 ;

    // ooOfflineMode

	/** <i>(HA)</i> Offline mode: Enforce the offline status of autonomous partitions. */
    int ENFORCE = 1 ;   // oocEnforce = 1 ;

	/** <i>(HA)</i> Offline mode: Ignore the offline status of autonomous partitions. */
    int IGNORE  = 0 ;   // oocIgnore  = 0 ;

    // ooAccessMode - type for predicate queries

	/**
	 * Field access level: The predicate query can test only public fields. This field-access mode
	 * preserves encapsulation.
	 */
    int PUBLIC = 0 ;   // oocPublic          = 0 ;

	/**
	 * Field access level: The predicate query can test all fields.	 To preserve encapsulation,
	 * you should use this field-access mode only within methods of the class
	 * you are querying.
	 */
    int ALL    = 1 ;   // oocAll             = 1 ;

    // ooAMSUsage

	/** AMS usage mode: Use AMS for remote data access if it is available. */
    int AMS_PREFERRED = 0 ;   // oocAMSPreferred    = 0 ;

	/** AMS usage mode: Use AMS exclusively. */
    int AMS_ONLY      = 1 ;   // oocAMSOnly         = 1 ;

	/** AMS usage mode: Never use AMS. */
    int NO_AMS        = 2 ;   // oocNoAMS           = 2 ;

    // ooIndexMode

	/**
	 * Index mode: Indexes are updated automatically when the transaction is committed.
	 */
    int INSENSITIVE     = 1 ;   // oocInsensitive     = 1 ;

	/**
	 * Index mode: Indexes are updated automatically
     * immediately after an indexed object is deleted
	 * or an object of the indexed class is made persistent.
	 * You should use this index mode for a session in which
	 * you perform predicate scans.
	 */
    int SENSITIVE       = 2 ;   // oocSensitive       = 2 ;

	/**
	 * Index mode: Indexes are updated by explicit calls to the
	 * <a HREF="ooObj.html#updateIndexes()"><tt>updateIndexes</tt></a>
	 * method of each new object or modified object.
	 */
    int EXPLICIT_UPDATE = 3 ;   // oocExplicitUpdate  = 3 ;

	/** Wait option: Transactions do not wait for locks when starting. */
    int NO_WAIT        = 0 ;       // oocNoWait          = 0 ;

	/** Wait option: Transactions wait indefinitely for locks when starting. */
    int WAIT           = -1 ;      // oocWait            = -1 ;

    /**
	 * Fetch-error reporting option: Throw a
	 * <a href="../FetchCompletedWithErrors.html">
	 * <tt>FetchCompletedWithErrors</tt></a> exception for each
     * destination object that could not be found or locked.
	 */
    int ALL_ERRORS     = 0 ;

    /**
	 * Fetch-error reporting option: Throw a single
	 * <a href="../ObjyRuntimeException.html"><tt>ObjyRuntimeException</tt></a>
     * for the first destination object that cannot be found or accessed,
     * and terminate the fetch operation immediately.  The
     * <tt>ObjyRuntimeException</tt> has more specific error information
     * than a <tt>FetchCompletedWithErrors</tt> exception.
	 */
    int INDIVIDUAL_ERROR = 1 ;

//	/**
//	 * Transactions use the globally set lock waiting option when starting.
//	 * @see Session#setLockWait
//	 */
	/** Reserved for future use. */
    int TRANS_NO_WAIT  = -12753 ;  // oocTransNoWait     = -12753 ;

    // ooDownGradeMode

	/**
	 * Downgrade mode: After the transaction checkpoint, all write locks obtained during the
	 * transaction are preserved.
	 */
    int NO_DOWNGRADE  = 0 ;   // oocNoDowngrade     = 0 ;

	/**
	 * Downgrade mode: After the transaction checkpoint, all write locks obtained during the
	 * transaction are downgraded to read locks.
	 */
    int DOWNGRADE_ALL = 1 ;   // oocDowngradeAll    = 1 ;

   	// ooErrorLevel

   	/**
   	 * Error level: No exception occurred.
   	 */
    int NO_ERROR     = 0 ;   // oocNoError     = 0 ;

   	/**
   	 * Error level: An abnormal event occurred.
   	 */
    int WARNING      = 1 ;   // oocWarning     = 1 ;

   	/**
   	 * Error level: The programming interface to Objectivity/DB detected a programmer error that is
	 * directly attributable to the application programmer.  For example,
	 * passing an invalid parameter to a public method of the interface
	 * usually causes a programmer error.
   	 */
    int USER_ERROR   = 2 ;   // oocUserError   = 2 ;

   	/**
   	 * Error level: Objectivity/DB detected a system error.  The error might actually
	 * have been caused by a programmer error that was not detected by the
	 * programming interface.
   	 */
    int SYSTEM_ERROR = 3 ;   // oocSystemError = 3 ;

   	/**
   	 * Error level: Objectivity/DB detected an unrecoverable internal
	 * inconsistency that might already have caused data corruption.
   	 */
    int FATAL_ERROR  = 4 ;   // oocFatalError  = 4 ;

    // thread policy

    /**
     * Thread policy: A thread's interaction is restricted; it must be joined to a session to
	 * perform any Objectivity/DB operation with that session or objects belonging
	 * to that session.
     */
    int THREAD_POLICY_RESTRICTED   = 0 ;

    /**
     * Thread policy: A thread's interaction is unrestricted; any given thread can interact
 	 * with any session or objects belonging to any session.
     */
    int THREAD_POLICY_UNRESTRICTED = 1 ;

    /**
     * Thread policy: A thread's interaction is unrestricted; any given thread can interact
     * with any session or objects belonging to any session.  In addition, any
     * number of threads can concurrently perform persistence operations with
     * objects of any session.  
	 * <b>Warning:</b> To prevent data corruption, you must guarantee
     * that no two threads execute Objectivity for Java operations 
	 * in the same session at the same time.
	 * 
     */
    int THREAD_POLICY_CONCURRENT = 2 ;

    /**
     * Internal Lock mode: No lock.
     */
    int olmNL = 0;      /* no lock */

    /**
     * Internal Lock mode: Read intention lock.
     */
    int olmIS = 1;      /* IS mode: intention lock, share */

    /**
     * Internal Lock mode: Write intention lock.
     */
    int olmIC = 2;      /* IC mode: intention lock, change */

    /**
     * Internal Lock mode: Exclusive intention lock.
     */
    int olmIX = 6;      /* IX mode: intention lock, exclusive */

    /**
     * Internal Lock mode: MROW read lock.
     */
    int olmS = 3;       /* S mode: share */

    /**
     * Internal Lock mode: Non-MROW read lock.
     */
    int olmR = 4;       /* R mode: read */

    /**
     * Internal Lock mode: Write lock.
     */
    int olmC = 5;       /* C mode: checked out for update -ub- */

    /**
     * Internal Lock mode: Exclusive lock.
     */
    int olmX = 7;       /* X mode: exclusive */

    /**
     * Internal Lock mode: Exclusive lock; no more lock requests allowed.
     */
    int olmLastX = 8;   /* exclusive, allow no further requests - SPR 2720 */

    // ooAvailability: Constants that describe the availability of a replicated database.
    // Should be kept in sync with "enum ooAvailability" in ooBase.h.

	/**
	 * <i>(HA)</i> Availability status: The database's availability is not currently known, possibly due to an error.
     */
    int UNKNOWN_AVAILABILITY = -1;     //oocUnknownAvailability = -1 ;  

	/**
	 * <i>(HA)</i> Availability status: The database is not available for any purpose, because 
	 * none of its images can be accessed.
	 */	
    int UNAVAILABLE = 0;               //oocUnavailable = 0 ;        
   
	/**
	 * <i>(HA)</i> Availability status: The database is potentially available for nonquorum reading, 
	 * because at least one image can be accessed, but the accessible image(s) do not constitute a quorum.
	 */
    int NON_QUORUM_READ_AVAILABLE = 1; //oocNonQuorumReadAvailable = 1 ;

	/**
	 * <i>(HA)</i> Availability status: The database is available for both reading and updating, because a quorum of its images 
	 * can be accessed; however, the quorum consists of only a subset of the database�s images.
	 */
    int QUORUM_AVAILABLE = 2;          //oocQuorumAvailable = 2 ;       

	/**
	 * <i>(HA)</i> Availability status: The database is available for both reading and updating, because a quorum 
	 * of its images can be accessed; furthermore, this quorum consists of all of the database�s images.
	 */
    int ALL_AVAILABLE = 3;             //oocAllAvailable = 3 ;        

/* These indexes need to be kept in sync with the ooSignals array
 * in jcpp_objy/jConnection.cpp.
 */

    /**
     * Signal: Abnormal termination (abort).
     */
    byte SIGABRT        = Access.getSignalNum((byte)0) ;

    /**
     * Signal: Time-out alarm.
     */
    byte SIGALRM        = Access.getSignalNum((byte)1) ;

    /**
     * Signal: Ctrl-Break sequence (NT only).
     */
    byte SIGBREAK       = Access.getSignalNum((byte)2) ;

    /**
     * Signal: Bus error.
     */
    byte SIGBUS         = Access.getSignalNum((byte)3) ;

    /**
     * Signal: Thread-cancellation signal use by threads library (Solaris
     * only).
     */
    byte SIGCANCEL      = Access.getSignalNum((byte)4) ;

    /**
     * Signal: Change in status of child.
     */
    byte SIGCHLD        = Access.getSignalNum((byte)5) ;

    /**
     * Signal: Continue stopped process.
     */
    byte SIGCONT        = Access.getSignalNum((byte)6) ;

    /**
     * Signal: System crash imminent; free up some space (IBM only).
     */
    byte SIGDANGER      = Access.getSignalNum((byte)7) ;

    /**
     * Signal: Emulation trap.
     */
    byte SIGEMT         = Access.getSignalNum((byte)8) ;

    /**
     * Signal: Floating-point exception.
     */
    byte SIGFPE         = Access.getSignalNum((byte)9) ;

    /**
     * Signal: Checkpoint freeze (Solaris only).
     */
    byte SIGFREEZE      = Access.getSignalNum((byte)10) ;

    /**
     * Signal: Monitor mode granted (IBM only).
     */
    byte SIGGRANT       = Access.getSignalNum((byte)11) ;

    /**
     * Signal: Hangup.
     */
    byte SIGHUP         = Access.getSignalNum((byte)12) ;

    /**
     * Signal: Illegal hardware instruction.
     */
    byte SIGILL         = Access.getSignalNum((byte)13) ;

    /**
     * Signal: Status request from keyboard (DEC Alpha only).
     */
    byte SIGINFO        = Access.getSignalNum((byte)14) ;

    /**
     * Signal: Terminal interrupt character.
     */
    byte SIGINT         = Access.getSignalNum((byte)15) ;

    /**
     * Signal: Asynchronous I/O.
     */
    byte SIGIO          = Access.getSignalNum((byte)16) ;

    /**
     * Signal: Hardware fault.
     */
    byte SIGIOT         = Access.getSignalNum((byte)17) ;

    /**
     * Signal: Termination.
     */
    byte SIGKILL        = Access.getSignalNum((byte)18) ;

    /**
     * Signal: Resource (for example, record lock) lost.
     */
    byte SIGLOST        = Access.getSignalNum((byte)19) ;

    /**
     * Signal: Inter-LWP signal used by threads library (NT only).
     */
    byte SIGLWP         = Access.getSignalNum((byte)20) ;

    /**
     * Signal: Migrate process (IBM only).
     */
    byte SIGMIGRATE     = Access.getSignalNum((byte)21) ;

    /**
     * Signal: Input data is in ring buffer (IBM only).
     */
    byte SIGMSG         = Access.getSignalNum((byte)22) ;

    /**
     * Signal: Broken pipe.
     */
    byte SIGPIPE        = Access.getSignalNum((byte)23) ;

    /**
     * Signal: Pollable event occured.
     */
    byte SIGPOLL        = Access.getSignalNum((byte)24) ;

    /**
     * Signal: Programming exception (IBM only).
     */
    byte SIGPRE         = Access.getSignalNum((byte)25) ;

    /**
     * Signal: Profiling timer expired.
     */
    byte SIGPROF        = Access.getSignalNum((byte)26) ;

    /**
     * Signal: Power fail or restart.
     */
    byte SIGPWR         = Access.getSignalNum((byte)27) ;

    /**
     * Signal: Terminal quit character.
     */
    byte SIGQUIT        = Access.getSignalNum((byte)28) ;

    /**
     * Signal: Monitor mode should be relinquished (IBM only).
     */
    byte SIGRETRACT     = Access.getSignalNum((byte)29) ;

    /**
     * Signal: Segment violation; invalid memory reference.
     */
    byte SIGSEGV        = Access.getSignalNum((byte)30) ;

    /**
     * Signal: Sound control has completed (IBM only).
     */
    byte SIGSOUND       = Access.getSignalNum((byte)31) ;

    /**
     * Signal: Stop.
     */
    byte SIGSTOP        = Access.getSignalNum((byte)32) ;

    /**
     * Signal: Invalid system call.
     */
    byte SIGSYS         = Access.getSignalNum((byte)33) ;

    /**
     * Signal: Termination.
     */
    byte SIGTERM        = Access.getSignalNum((byte)34) ;

    /**
     * Signal: Checkpoint thaw (Solaris only).
     */
    byte SIGTHAW        = Access.getSignalNum((byte)35) ;

    /**
     * Signal: Hardware fault; trace or breakpoint trap.
     */
    byte SIGTRAP        = Access.getSignalNum((byte)36) ;

    /**
     * Signal: Terminal stop character.
     */
    byte SIGTSTP        = Access.getSignalNum((byte)37) ;

    /**
     * Signal: Stop (background read from control tty).
     */
    byte SIGTTIN        = Access.getSignalNum((byte)38) ;

    /**
     * Signal: Stop (background write from control tty).
     */
    byte SIGTTOU        = Access.getSignalNum((byte)39) ;

    /**
     * Signal: Urgent socket condition.
     */
    byte SIGURG         = Access.getSignalNum((byte)40) ;

    /**
     * Signal: User-defined signal 1.
     */
    byte SIGUSR1        = Access.getSignalNum((byte)41) ;

    /**
     * Signal: User-defined signal 2.
     */
    byte SIGUSR2        = Access.getSignalNum((byte)42) ;

    /**
     * Signal: Virtual timer expired.
     */
    byte SIGVTALRM      = Access.getSignalNum((byte)43) ;

    /**
     * Signal: Concurrency signal used by threads library  (Solaris only).
     */
    byte SIGWAITING     = Access.getSignalNum((byte)44) ;

    /**
     * Signal: Window size change.
     */
    byte SIGWINCH       = Access.getSignalNum((byte)45) ;

    /**
     * Signal: CPU time limit exceeded.
     */
    byte SIGXCPU        = Access.getSignalNum((byte)46) ;

    /**
     * Signal: File size limit exceeded.
     */
    byte SIGXFSZ        = Access.getSignalNum((byte)47) ;

    /**
     * Logging option: Logging is disabled
     */
    int LogNone                  = 0 ;

    /**
     * Logging option: Create the main log
     */
    int LogMain                  = 1 ;

    /**
     * Logging option: Create a log per session
     */
    int LogSession               = 2 ;

    /**
     * Logging option: Log transaction statistics in session logs
     */
    int LogTransactionStatistics = 4 ;

    /**
     * Logging option: Log transaction timing in session logs
     */
    int LogTransactionTiming     = 8 ;

    /**
     * Logging option: Enable application defined log items for all logs
     */
    int LogOther                 = 16 ;

    /**
     * Logging option: Enable all logging
     */
    int LogAll                   = 31 ;

    /**
     * Iterator policy: After checkpoint is called all open iterators are
     * closed.
     */
    int CLOSE_ITR = 0 ;

    /**
     * Iterator policy: After checkpoint is called all open iterators are
     * kept with their state preserved for use in subsequent transactions.
     */
    int KEEP_ITR = 1 ;


    /**
     * <a name="ooDiskFormat"></a>Reserved for Internal Use
     */
    int NoDiskFormat = 0 ;

    /**
     * Disk-format architecture: Compaq AlphaServer
     */
    int alphaosf1 = 1 ;

    /**
     * Disk-format architecture: Compaq AlphaServer (prior to Objectivity/DB Release 9.0)
     */
    int alphaosf1_32 = 2 ;

    /**
     * Disk-format architecture: Silicon Graphics Altix 3000
     */
    int altix = 3 ;

    /**
     * Disk-format architecture: HP 9000 Series 700/800
     */
    int hprisc = 4 ;

    /**
     * Disk-format architecture: IBM RISC System/6000
     */
    int ibmrs6000 = 5 ;

    /**
     * Disk-format architecture: Silicon Graphics MIPS
     */
    int iris = 6 ;

    /**
     * Disk-format architecture: Intel Pentium running Linux with gcc less than 3.0
     */
    int linux86 = 7 ;

    /**
     * Disk-format architecture: Intel Pentium running Linux with gcc 3.0 or greater
     */
    int linux86gcc3 = 8 ;

    /**
     * Disk-format architecture: Motorola PowerPC
     */
    int lynxppc = 9 ;

    /**
     * Disk-format architecture: Solaris 2.6
     */
    int solaris4 = 10 ;

    /**
     * Disk-format architecture: Solaris 7 or greater, 32-bit addressing mode
     */
    int solaris7 = 11 ;

    /**
     * Disk-format architecture: Solaris 8 or greater, 64-bit addressing mode
     */
    int sparc64 = 12 ;

    /**
     * Disk-format architecture: Intel Pentium running Microsoft Windows
     */
    int win32 = 13 ;
    
    /**
     * Disk-format architecture: Intel Itanium 2 running HP-UX, 64-bit addressing mode
     */

    int hpuxia64 = 14 ;
    
    /**
     * Disk-format architecture: x86-64 running Linux, 64-bit addressing mode
     */

    int linux86_64 = 15 ;
    
    /**
     * Disk-format architecture: x86-64 running Solaris 10, 64-bit addressing mode
     */

    int solaris86_64 = 16 ;
    
    /**
     * Disk-format architecture:  x86-64 running Microsoft Windows, 64-bit addressing mode
     */

    int win64 = 17 ;
    
    /**
     * Disk-format architecture:  x86 running on a Mac
     */

    int mac86gcc = 18 ;
    
    /**
     * Disk-format architecture:  x86-64 running on a Mac, 64-bit addressing mode
     */

    int mac86_64 = 19 ;

    /**
     * Reference object implementation: Weak reference
     */
    int WEAK = 0 ;

    /**
     * Reference object implementation: Soft reference
     */
    int SOFT = 1 ;

    /**
     * Snapshot info: Specifies that no snapshot information is captured.
     */
    int NoInfo = 0 ;

    /**
     * Snapshot info: Provides version information about the Objectivity for Java 
     * software, the current date and time, and the name of the boot file for 
     * the federated database
     */
    int HeaderInfo = 1 ;

    /**
     * Snapshot info: Provides the current date and time, session name, session 
     * number, current open mode, current MROW mode, current index mode, information about 
     * waiting for locks, information about server timeout, and transaction IDs.
     */
    int SessionInfo = 2 ;

    /**
     * Snapshot info: For each open database, provides its OID, lock information, 
     * file descriptor, and page size.
     */
    int DatabasesInfo = 4 ;

    /**
     * Snapshot info: For each open container, provides its OID, lock mode, free pages, 
     * file descriptor, version number, and states whether or not the container was modified.
     */
    int ContainersInfo = 8 ;

    /**
     * Snapshot info: For each cached page, provides its OID, free space, pin count, and 
     * states whether or not it was written.
     */
    int CachePagesInfo = 16 ;

    /**
     * Snapshot info: For each shadow page, provides its OID, old physical page number, and 
     * new physical page number.
     */
    int ShadowPagesInfo = 32 ;

    /**
     * Snapshot info: For each open object, provides its OID, open mode, and type number.
     */
    int ObjectsInfo = 64 ;

    /**
     * Snapshot info: For each open array, provides its type number and owning object.
     */
    int VarraysInfo = 128 ;

    /**
     * Snapshot info: Provides information on the contents of the two most recently accessed 
     * logical pages.
     */
    int PrintRecentPages = 256 ;

    /**
     * Snapshot info: Provides all information that can be produced by a snapshot.
     */
    int AllInfo = HeaderInfo | SessionInfo | DatabasesInfo | ContainersInfo | CachePagesInfo | ShadowPagesInfo | ObjectsInfo | VarraysInfo | PrintRecentPages ;

    /**
     * Snapshot info format: Specifies plain text.
     */
    int Readable = 0 ;

    /**
     * Snapshot info format: Specifies a comma-separated values format.
     */
    int CSV = 1 ;

    /**
     * Snapshot sort order: Starts with the lowest OID and ends with the highest.
     */
    int Ascending = 0 ;

    /**
     * Snapshot sort order: Starts with the highest OID and ends with the lowest.
     */
    int Descending = 1 ;

    /**
     * Snapshot sort order: For cache pages only, starts with the most recently 
     * accessed pages and ends with the least recently accessed pages. 
     */
    int Recent = 2 ;
    
    /**
     * Persistence policy: Makes transient objects persistent if they become reachable from persistent objects through relationships; 
     * otherwise leaves them transient. See {@link Connection#setPersistencePolicy <tt>Connection.setPersistencePolicy</tt>}.
     */
	int	Reachability = 0;
	
	/**
	 * Persistence policy: Enables the pre-Release 11 behavior of the deprecated methods
	 * {@link Session#setFormTransientRelationships <tt>Session.setFormTransientRelationships</tt>}, 
	 * {@link Session#setAllowTransientRelationships <tt>Session.setAllowTransientRelationships</tt>}, and
	 * {@link Session#persistTransientRelationships <tt>Session.persistTransientRelationships</tt>}.
	 */
	int PreRelease11Behavior = 1;
}


