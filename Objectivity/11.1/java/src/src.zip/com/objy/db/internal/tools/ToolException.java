package com.objy.db.internal.tools;

import com.objy.db.ObjyRuntimeException;

/**
 * Signals an error in the running of a tool
 * 
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class ToolException extends ObjyRuntimeException
{
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ToolException(String message) {
        super(message) ;      
    }

}
