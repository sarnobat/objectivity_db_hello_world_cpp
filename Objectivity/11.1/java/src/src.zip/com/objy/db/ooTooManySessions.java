/*
 * @(#)ooTooManySessions.java
 * 
 * Copyright (c) 2005 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

/**
 * Signals an attempt to create a session from a session pool that has no available sessions
 * and has reached its hard limit, after its session-wait timeout period has expired.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class   ooTooManySessions
       extends ObjyRuntimeException
{
	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ooTooManySessions()
        { super() ; }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ooTooManySessions(String msg)
        { super(msg) ; }   
}
