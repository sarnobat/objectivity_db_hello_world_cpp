/*
 * MODULE NAME:         VArray
 * AUTHOR:              Hua Shu
 * DATE:                May 21, 2012
 *
 * COPYRIGHT:
 *   Copyright 1990-2012 Objectivity, Inc.  All rights reserved.
 *
 * SECURITY:
 *   Objectivity, Inc. Object Code Only source materials -
 *   Company Confidential.
 *
 * DESCRIPTION:
 *
 *
 * USAGE:
 *
 *
 * DEPENDENCIES:
 *
 *
 * UPDATES/MODIFICATIONS:
 *
 *
 * LIMITATIONS/KNOWN BUGS
 *
 */
package com.objy.db.internal;

import com.objy.db.ObjyRuntimeException;
import com.objy.db.app.ooObj;
import com.objy.db.iapp.Persistent;
import com.objy.pm.SessionPersistor;
import com.objy.pm.ooId;

//TODO: For some odd reason we are using pm ooId instead of app ooId(ALSO in the Ref class.  When we tried
//to change it IG encountered errors on some platforms however we did not confirm
//if this was related to casting the pm ooId to app ooId.  We will need to investigate
//this in the future, especially if we move this call from the internal package to
//the public package
public class VArray<T extends Persistent>
{ 
    private ooObj mOwner;
    private String mAttribName;
    private int mOffsetInSchema = -1;
    private long mClassMap = 0;
    SessionPersistor mSessionPersistor;
    
    /**
     * Constructs a varray with the object that owns the varray and the name of the varray attribute. 
     * If the attribute name is incorrect, a runtime exception will be thrown when resizing the varray 
     * or adding element to the varray.
     * @param owner       The objects that owns the varray
     * @param attribName  The name of the VArray attribute. 
     */
    public VArray(ooObj owner, String attributeName)
    {
        mOwner = owner;
        mAttribName = attributeName;
        //Note that owner probably hasn't been persisted yet so can't cache classMap or sessionpersistor yet
      
    } 
    
    /**
     * Caches the offset in schema of the varray to avoid going 
     * through the class map to find the varray attribute each time. 
     * This method is called back from the VArray C++ glue code.
     */
    private synchronized void setOffset(int offset)
    {
        mOffsetInSchema = offset;
    }
    
    private SessionPersistor getSessionPersistor()
    {
        if(mSessionPersistor == null)
            mSessionPersistor = (SessionPersistor)mOwner.getPersistor().getSession().persistor();
        return mSessionPersistor;
    }
    
    private long getClassMap()
    {
        if(mClassMap == 0)
            mClassMap = mOwner.getPersistor().getClassMap();
        return mClassMap;            
    }
    
    /**
     * Gets the size of this varray. 
     * @return Size of the varray
     */
    public long getSize()
    {
        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();            
            return sp.connection().getSize(ownerConnId, getClassMap(), 
                    mAttribName, mOffsetInSchema, this);            
        }
        finally { sp.unlockMonitor() ; }        
    }
    
    /**
     * Extends the varray to a new size.
     * @param newSize The new size
     * @return True if resizing the varray is successful; false otherwise.
     */
    public boolean resize(long newSize)
    {
        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();            
            return sp.connection().resize(ownerConnId, getClassMap(), 
                    mAttribName, newSize, mOffsetInSchema, this);
        }        
        finally { sp.unlockMonitor() ; }       
    }
    
    /**
     * Gets the element of the varray with the specified index.
     * @param index The index of the element
     * @return The element of the varray at the specified index
     */
    public T getAt(long index)
    {
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();      
            long ownerConnId = mOwner.getPersistor().connectionId();//.getOid().getStoreLong();
            return (T)sp.connection().getObjectAt(ownerConnId, getClassMap(), 
                    mAttribName, index, mOffsetInSchema, this, mOwner);

        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Gets the oid of the element of the varray with the specified index.
     * @param index The index of the element
     * @return The oid of the element of the varray at the specified index
     */
    public com.objy.pm.ooId getOidAt(long index)
    {        
        com.objy.pm.ooId oid = new ooId();
        SessionPersistor sp = getSessionPersistor();
        try 
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();//.getOid().getStoreLong();
            sp.connection().getAt(ownerConnId, getClassMap(), 
                    mAttribName, index, oid, mOffsetInSchema, this);
            return oid;
        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Sets the given object at the specified index in the varray.
     * @param obj The object to be set in the varray
     * @param index The index in the varray
     */
    public  void setAt(T obj, long index) throws ObjyRuntimeException
    {        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();
            if (obj == null)
            {                
                sp.connection().setAt(ownerConnId, getClassMap(), mAttribName, 0, index,         
                        mOffsetInSchema, this);
            }
            else if (obj.getPersistor() != null)
            {
                sp.connection().setAt(ownerConnId,getClassMap(), mAttribName, obj.getPersistor().connectionId(),
                        index, mOffsetInSchema, this);
            }
            else
            {
                throw new ObjyRuntimeException("The object must be persistent before setting it to the varray.");
            }
        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Sets the given object at the specified index in the varray.
     * @param oid The oid of the object to be set in the varray
     * @param index The index in the varray
     */
    public  void setOidAt(ooId oid, long index) throws ObjyRuntimeException
    {        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();
            
            sp.connection().setAtByOid(ownerConnId, getClassMap(), mAttribName, oid!=null?oid:new ooId(0,0,0,0,0), index,         
                    mOffsetInSchema, this);
           
        }
        finally { sp.unlockMonitor() ; }    
    }

    
    /**
     * Returns the index of the first occurrence of the specified object in the varray. Returns -1 if the object is not found in the varray.
     * @param obj The object to be checked
     * @return the index if the varray contains the specified object; -1 otherwise.
     */
    public int indexOf(T obj)
    {  
        return indexOf(0, obj);
    }
    
    /**
     * Returns the index of the first occurrence of the specified object in the varray, starting from a specified index. 
     * Returns -1 if the object is not found in the varray.
     * @param obj The object to be checked
     * @return the index if the varray contains the specified object; -1 otherwise.
     */
    public int indexOf(long startIndex, T obj)
    {
        if (startIndex < 0)
        {
            throw new ObjyRuntimeException("The start index must be greater than or equal to zero.");
        }
        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            long ownerConnId = mOwner.getPersistor().connectionId();
            sp.lockMonitor();
            if (obj == null)
            {                
                throw new ObjyRuntimeException("To check the containment of an object in varray, the object cannot be null.");
            }
            else if (obj.getPersistor() == null)
            {
                throw new ObjyRuntimeException("To check the containment of an object in varray, the object must be persistent.");
            }
            return sp.connection().indexOf(ownerConnId, getClassMap(), 
                    mAttribName, startIndex, obj.getPersistor().connectionId(), mOffsetInSchema, this);
        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Returns the index of the first occurrence of the specified object in the varray. Returns -1 if the object is not found in the varray.
     * @param obj The object to be checked
     * @return the index if the varray contains the specified object; -1 otherwise.
     */
    public int indexOf(com.objy.pm.ooId oid)
    {  
        return indexOf(0, oid);
    }
    
    /**
     * Returns the index of the first occurrence of the specified object in the varray, starting from a specified index. 
     * Returns -1 if the object is not found in the varray.
     * @param obj The object to be checked
     * @return the index if the varray contains the specified object; -1 otherwise.
     */
    public int indexOf(long startIndex, com.objy.pm.ooId oid)
    {
        if (startIndex < 0)
        {
            throw new ObjyRuntimeException("The start index must be greater than or equal to zero.");
        }
        SessionPersistor sp = getSessionPersistor();
        try
        {
            long ownerConnId = mOwner.getPersistor().connectionId();
            sp.lockMonitor();
            if (oid == null)
            {                
                throw new ObjyRuntimeException("To check the containment of an object in varray, The specified oid cannot be null.");
            }
            return sp.connection().indexOf(ownerConnId, getClassMap(), 
                    mAttribName, startIndex, oid, mOffsetInSchema, this);
        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Gets all the elements of the varray.
     * @return An array containing all the elements of the varray
     */
    public T[] getAll()
    {
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            return (T[])sp.connection().getAll(mOwner, getClassMap(), 
                mAttribName, mOffsetInSchema, this);
        }
        finally { sp.unlockMonitor() ; }    
        
    }
}
