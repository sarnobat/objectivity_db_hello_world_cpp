package com.objy.query.expression;
/**
 * Represents an object literal value node.
 *
 */
public class ObjectLiteralValueExpression extends LiteralValueExpression 
{

	/**
	 * Constructor taking a class name. The class name must be prefixed with the namespace 
	 * if the class is defined in a non-default namespace, for example, test_data::Person. 
	 */
    public ObjectLiteralValueExpression(String className) 
    {
        this(Binding.create(className));
    }
    
	ObjectLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }
    
	/**
     * Adds an attribute-value pair to this object literal value node.
     */
    public void addAttributeValue(AttributeValueExpression attributeValueExpression, 
    		LiteralValueExpression literalValueExpression) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.addAttributeValue(mId, 
        	attributeValueExpression.getId(), literalValueExpression.getId());       
    }
    
    /**
     * Gets the attribute expression part of the attribute-value pair at the given index.
     */
    public AttributeValueExpression getAttributeExpression(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
    	long objAttrId = Binding.getAttributeExp(mId, index);
        return (AttributeValueExpression)Expression.getExpression(objAttrId);
    }
    
    /**
     * Gets the literal expression part of the attribute-value pair at the given index.
     */
    public LiteralValueExpression getLiteralValueExpression(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
    	long objLitId = Binding.getLiteralValueExp(mId, index);
        return (LiteralValueExpression)Expression.getExpression(objLitId);
    }
    
    /**
     * Gets the number of attribute-value pairs in this object literal value.
     */
    public int getNumberOfObjectAttributes() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getNumberOfObjectAttributes(mId);
    }
    
    /**
     * Gets the class name associated with this object literal value.
     */
    public String getClassName()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getClassName(mId);
    }
    
    /**
     * Gets the string representation of this object literal value.
     */
    // This should return the same result as getPQLRepresentation().
    public String toString()
    {
    	StringBuilder sb = new StringBuilder();
    	sb.append("OBJECT:" + getClassName() + "(");
    	int numOfObjAttrs = getNumberOfObjectAttributes();
    	for (int i = 0; i < numOfObjAttrs; i++)
    	{
    		AttributeValueExpression attrValExp = getAttributeExpression(i);
    		LiteralValueExpression litValExp = getLiteralValueExpression(i);
    		if (attrValExp != null && litValExp != null)
    		{
    			if (i > 0)
        		{
        			sb.append(",");
        		}
        		
	    		sb.append(attrValExp.getAttributeName());
	    		sb.append(":");
	    		sb.append(litValExp.toString());
    		}
    		else
    		{
    			break;
    		}
    	}
    	sb.append(")");
    	return sb.toString();
    }
    
	@Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.ObjectLiteralValueExpression; 
    }
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitObjectLiteralValue(this);
    }
    
    static class Binding
    {
        
        private static native long create(String className);
        private static native void addAttributeValue(long id, long attrValExprId, long litValExprId);
        private static native long getAttributeExp(long id, int index);
        private static native long getLiteralValueExp(long id, int index);
        private static native int getNumberOfObjectAttributes(long id);
        private static native String getClassName(long id);
    }
}
