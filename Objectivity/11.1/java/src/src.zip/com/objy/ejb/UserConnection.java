/*
 * @(#)UserConnection.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.ejb ;

import java.util.Map ;
import java.sql.CallableStatement ;
import java.sql.DatabaseMetaData ;
import java.sql.PreparedStatement ;
import java.sql.Statement ;
import java.sql.SQLException ;
import java.sql.SQLWarning ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.ObjectNameNotUniqueException ;
import com.objy.db.ObjectNameNotFoundException ;

import com.objy.db.app.Connection ;
import com.objy.db.app.Database ;
import com.objy.db.app.Session ;
import com.objy.db.app.ooFDObj ;
import com.objy.db.app.oo ;

/**
 * Represents a connection to an Objectivity/DB federated database within a
 * global transaction.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <h2>Understanding Global Transactions</h2>
 *
 * <p>A <i>global transaction</i> updates multiple resources, such as
 * databases, in a coordinated manner. Global transaction are
 * also called <i>distributed transcations</i>.
 *
 * <p>A <i>transaction manager</i>
 * manages a global transaction on behalf
 * of the application program. A <i>resource manager</i> provides
 * transaction services for a particular resource.  During a global
 * transaction, the interaction with any particular resource is called a
 * <i>transaction branch</i>.
 * If an Objectivity/DB federated database is the resource for a
 * transcation branch of a global transaction, the corresponding
 * resource manager is an <a href="XATransaction.html">
 * Objectivity/DB transaction resource manager</a>.
 *
 * <p>The transaction manager uses the <i>two-phase commit
 * protocol</i> to coordinate the various transaction branches.
 * This protocol ensures that updates made during the global
 * transaction either are committed in
 * all resources or else are fully rolled back, removing them from all
 * resources:
 * <ul>
 * <li>The first phase of a two-phase commit is called the <i>preparation</i>
 * phase. Each resource manager prepares its transaction branch by recording
 * all required updates to the resource in a transaction log file; it then
 * indicates to the transaction manager whether the transaction branch
 * succeeded or failed. </p>
 *
 * <li>In the second phase, the recorded updates are either committed or
 * rolled back. If all transaction branches succeeded, the global
 * transaction itself succeeds and the updates are committed.  If any
 * transaction branch failed, the global transaction fails; each transaction
 * branch is rolled back so that all resources return to the state they were
 * in when the global transaction started.</p>
 * </ul>
 *
 * <p><b>Note:</b> The application program interacts only with the
 * transaction manager,
 * not with the resource managers for the various resources involved in a
 * global transaction. The transaction manager interacts
 * with each resource manager, requesting that it start, stop, prepare,
 * commit, or rollback work in a particular transaction branch.
 *
 * <a name="Obtaining"></a><h2>Obtaining a User Connection</h2>
 *
 * <p>You can obtain a user connection by instantiating this class
 * during a global transaction.
 *
 * <p>A JavaBean can start a global transaction using the JTA interface. The
 * following steps are required:
 * <ol>
 * <li>Obtain the Bean's <tt>SessionContext</tt>.<p>
 *
 * <li>Get a JTA <tt>UserTransaction</tt> from the <tt>SessionContext</tt>.
 * The user transaction object represents a global transaction.</p>
 *
 * <li>Begin the global transaction by calling the <tt>begin</tt> method of
 * the user transaction object.
 * </ol>
 *
 * <p>Once the global transaction is active, you can create a user
 * connection. For example:
 * <pre>
 * SessionContext ctx;       // Bean's session context
 * UserTransaction utx;      // User transaction
 * UserConnection userconn;  // User connection for federated database
 * ...
 * ctx = ... // Get the session context
 * try {
 *   utx = ctx.getUserTransaction(); // Get a JTA user transaction object
 *   utx.begin();                    // Start a global transaction
 * }
 * catch (javax.transaction.NotSupportedException nse) {
 *   log("Could not begin global transaction due to: " + nse);
 * }
 * catch (javax.transaction.SystemException se) {
 *   log("Transaction exception: " + se);
 * }
 * userconn = new UserConnection(this);  // Create user connection
 * ... // <a href="#FD">Interact with the federated database</a> through the user connection
 * try {
 *   utx.commit();  // Commit the global transaction
 *   log("Global transaction committed");
 * }
 * catch (javax.transaction.RollbackException rbe) {
 *   log("Global transaction rolled back due to: " + rbe);
 * }
 * catch (javax.transaction.HeuristicRollbackException hre) {
 *   log("Global transaction rolled back due to: " + hre);
 * }
 * catch (javax.transaction.HeuristicMixedException hme) {
 *   log("Global transaction rolled back due to: " + hme);
 * }
 * catch (javax.transaction.SystemException se) {
 *   log("Transaction exception: " + se);
 * }
 * </pre>
 *
 * <p>When you instantiate this class to create a user connection, you also:
 * <ul>
 * <li>Open a <a href="../db/app/Connection.html">connection</a> to the
 * federated database.</p>
 *
 * <li>Create a <a href="../db/app/Session.html">session</a> for the
 * interaction with the federated database.</p>
 *
 * <li>Create the session's  <a href="XATransaction.html">
 * Objectivity/DB transaction resource manager</a>.
 *
 * </ul>
 *
 * <a name="FD"></a><h2>Accessing the Federated Database</h2>
 *
 * <p>Methods of the user connection provide access to the connected
 * federated database following the ODMG standard for storing and looking up
 * named roots, that is, persistent objects that are identified by root names:
 * <ul>
 * <li>Call the {@link #bind <tt>bind</tt>} method to give an object a root
 * name, making it persistent. </p>
 *
 * <li>Call the {@link #lookup <tt>lookup</tt>} method to find a persistent
 * object by looking up is root name. </p>
 *
 * <li>Call the {@link #unbind <tt>unbind</tt>} method to remove an object's
 * root name.
 * </ul>
 *
 * <p>For information about named roots, see
 * <a href="../../../../guide/jgdLookup.html#Individual Lookup of Named Roots">
 * Individual Lookup of Named Roots</a>.
 *
 * <p>For more sophisticated interaction with the federated database, you can
 * call the user connection's {@link #getFD <tt>getFD</tt>} method to obtain
 * a local representation of the connected federated database.  From the
 * federated database object, you can access all Objectivity/DB operations.
 * You can create a storage hierarchy, find individual storage objects or
 * persistent objects through any available mechanism, create and install
 * custom clustering strategies, and so on.
 *
 * <p>At the end of the global transaction, you should call the user
 * connection's,
 * {@link #close <tt>close</tt>} method. Doing so releases all internal
 * resources used by the user connection object.
 *
 * <p><b>Note:</b> Closing a user connection does <i>not</i> close the connection to
 * the federated database. You may start another global transaction,
 * create another user connection object, and access the federated database
 * through the new user connection.
 *
 * <h2>Restrictions on User Connections</h2>
 *
 * <p>You must create a new user connection for each global transaction.  You
 * may perform Objectivity/DB operations through the user connection
 * <i>only</i> while its global transaction is active. After a call to the
 * <tt>commit</tt> or <tt>rollback</tt> method of the user transaction
 * object, you may not access the federated database through the user
 * connection, its
 * federated database, or any other Objectivity/DB object that you retrieved
 * or created during the preceding global transaction.
 *
 * <p>If you create more than one user connection object, remember that each
 * one has its own session object. The local representations of
 * Objectivity/DB objects that you create or find through a user connection
 * belong to that user connection's session and may not interact with the
 * local representation objects that you create or find through a different
 * user connection. See
 * <A HREF="../../../../guide/jgdApplication.html#Isolation">
 * Object Isolation</A>.
 *
 * <p>You can obtain the user connection's associated session object through
 * its federated database object.  If you do so, you must follow these
 * guidelines:
 * <ul>
 * <li>During a global transaction, you should not call the session's
 * <tt>begin</tt>, <tt>checkpoint</tt>, or <tt>commit</tt> methods.</p>
 *
 * <li>You may call the session's <tt>abort</tt> method during a global
 * transaction.  If you do so, you will abort the Objectivity/DB transaction
 * and also cause all other transaction branches of the global transaction to
 * be rolled back.</p>
 * </ul>
 *
 * <p>If your application needs to interact with the connected federated
 * database in both local and global transactions, you should create a
 * separate session object to use for local transactions.  If you want to
 * perform a local transaction with a user connection's session, you can do
 * so only after the user connection's
 * global transaction has ended.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 * <TD><A HREF="#UserConnection(java.lang.Object)">UserConnection(Object)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Working&nbsp;With&nbsp;Named&nbsp;Roots</B></TD>
 * <TD><A HREF="#bind(java.lang.Object, java.lang.String)">bind(Object, String)</A><BR>
 * 	<A HREF="#unbind(java.lang.String)">unbind(String)</A><BR>
 * 	<A HREF="#lookup(java.lang.String)">lookup(String)</A><BR>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;the Federated&nbsp;Database</B></TD>
 * <TD VALIGN="top" ><A HREF="#getFD()">getFD()<a>
 * </TD></TR>
 *
 * <td VALIGN="top" WIDTH="1%"><B>Setting&nbsp;Properties</B></TD>
 * <TD><A HREF="#setReadOnly(boolean)">setReadOnly(boolean)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 * <TD><A HREF="#isReadOnly()">isReadOnly()</A><BR>
 * <A HREF="#isClosed()">isClosed()</A>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Cleanup</B></TD>
 * 	<TD><A HREF="#close()">close()</A><BR>
 * 	<A HREF="#finalize()">finalize()</A>
 * </TD></TR>
 * </TABLE>
 *
 */
@Deprecated
final public class UserConnection implements java.sql.Connection { // well, some of it...

    // holds the ODMG Database that users can do database operations on
    private Database database = null ;
    private XAConnection xaconnection = null ;

    private Database database() {
        if (database == null) {
            throw new ObjyRuntimeException("This UserConnection has been closed or finalized.  Please instantiate another UserConnection.") ;
        }
        return database ;
    }

    // called from Transaction Manager

	/**
	 * Reserved for internal use; you never call this constructor directly.
	 */
    public UserConnection(Database _database, XAConnection _xaconnection) {
        database = _database ;
        xaconnection = _xaconnection ;
        info("<< Objectivity >> CALLING " + this + " CONSTRUCTOR(db,xaconn), database: " + _database ) ;
    }

    public UserConnection(Database _database, XAConnection _xaconnection, ClassLoader beanClassLoader) {
        database = _database ;
        xaconnection = _xaconnection ;
        database.getConnection().setUserClassLoader(beanClassLoader) ;
        info("<< Objectivity >> CALLING " + this + " CONSTRUCTOR(db,xaconn), database: " + _database ) ;
    }

    // called from Application Bean AFTER UserTransaction is started
    /**
     * Constructs a user connection for the current global transaction.
     *
     * <p><b>Note:</b> This constructor can be called only by a bean in
     * the application server Enterprise JavaBean environment.  The calling
     * object
     * is expected to pass itself (<tt>this</tt>) as a parameter.  This
     * constructor
     * must be called <i>after</i> a global transaction has been started.
     * See <a href="#Obtaining">Obtaining a User Connection</a>.
     *
     * <p>During a global transaction, the user connection can access the
     * federated database specified
     * for the current application server.  If a
     * connection to that federated database is not already opened, the
     * constructor opens the connection.</p>
	 *
     * @param 	 inBeanObject  The calling object (pass
     * <tt>this</tt> as the parameter).</p>
     *
     */
    public UserConnection(Object inBeanObject) {
        debugLevel3("<< Objectivity >> CALLING " + this + " CONSTRUCTOR(inBeanObject)... ") ;

        // use the beanObject to get the classloader.  can also use the beanObject
        // here to get the EJBObject or EJBContext...
        ClassLoader beanClassLoader = inBeanObject.getClass().getClassLoader() ;
        // set the ClassLoader in the Connection here...
        database.getConnection().setUserClassLoader(beanClassLoader) ;

        XADataSource ds = XADataSource.getDataSource();
        xaconnection = (com.objy.ejb.XAConnection) ds.getXAConnection(this) ;
            // get database
	database = xaconnection.getSession().getConnection().getDatabase() ;
	info("<< Objectivity >> NEW " + this + "::" + ds + "::" + xaconnection + "::" + xaconnection.returnXAResource()) ;
    }

    // ODMG Database Methods

    /**
     * Names the specified object with the specified root name in the
	 * connected federated database.
	 *
     * <p>Giving an object a root name makes the object persistent. The named object
     * is made persistent immediately; all transient objects reachable from
     * the named object are made persistent when the Objectivity/DB
     * transaction is committed.</p>
	 *
     * @param 	 object  The object being named.</p>
     *
     * @param 	 name    The root name for the object.
     * This name can be any valid Java string and must be unique
     * within the root dictionary of the federated database.</p>
     *
     * @exception   ObjectNameNotUniqueException If the name already exists in the root
     * dictionary.</p>
     *
     * @see #unbind(String)
     * @see #lookup(String)
     */
    public void bind(Object object, String name) throws ObjectNameNotUniqueException
        { database().bind(object, name) ; }

	/**
     * Removes the specified root name from the root dictionary of the
     * connected federated database.</p>
     *
     * @param 	 name    The root name to be removed.</p>
	 *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
	 */
    public void unbind(String name) throws ObjectNameNotFoundException
        { database().unbind(name) ; }

    /**
     * Finds the object with the specified root name in the
     * connected federated database.</p>
     *
     * @param 	 name    The root name of the object.</p>
     *
     * @return      The object with the specified root name. If that object
     * is the root of a graph of objects, only the root object is
     * retrieved.</p>
     *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
     */
    public Object lookup(String name) throws ObjectNameNotFoundException
        { return database().lookup(name) ; }

    // For Advanced Objectivity Users
    /**
     * Gets the connected federated database.</p>
     *
     * @return		The connected federated database.
     */
    public ooFDObj getFD() {
        if (database == null) throw new ObjyRuntimeException("This UserConnection has been closed.") ;
        return getSession().getFD() ;
    }

    // ??? Is this needed since we provide the ODMG Database functionality?
    //public Database getDatabase() { // use Database to do ODMG database operations
    //    if (database == null) throw new ObjyRuntimeException("This connection has been closed.") ;
    //    return database ;
    //}

    /**
     * Releases the resources used by this user connection.
     *
     * <p>After closing a user connection, you cannot use it in a subsequent
     * global transaction.</p>
     */
    public synchronized void close() {
        debugLevel3("<< Objectivity >> CALLING " + this + ".close().") ;
        if (xaconnection != null) {
            xaconnection.disconnectFromUserConnection() ; // will inform xaconnection that UserConnection is gone...
        }
        database = null ;
    }

    /**
     * Releases the resources used by this user connection and terminates the
     * associated session.</p>
     */
    public synchronized void finalize() { // ???
        debugLevel3("<< Objectivity >> CALLING " + this + ".finalize().") ;
        if (xaconnection != null) {
            xaconnection.releaseConnection() ;  // XAConnection will be made available again
            xaconnection = null ;
        }
   }

    /**
     * Tests whether this user connection is closed.</p>
     *
     * @return True if this user connection is closed; false if it is open.
     */
    public boolean isClosed() {
        if (database == null)
            return true ;
        else
            return false ;
    }

//     * Sets read-only mode for this user connection.
//     *
//     * <p>Enabling read-only mode serves as a hint to enable
//     * transaction optimizations.
//     *
//     * <p><b>Note:</b> You cannot call this method during a global
//     * transaction.  If you call it after ending one global transaction,
//     * the new read-only mode will take affect in the next global transaction
//     * that uses this user connection.</p>
//     *
//     * @param readOnly True to enable read-only mode; false to disable
//     * read-only mode.
//
    /**
     * Reserved for future use; you should not call this method.
     */
    public void setReadOnly(boolean readOnly) {
        if (readOnly == true)
            getSession().setOpenMode(oo.openReadOnly) ;
        else
            getSession().setOpenMode(oo.openReadWrite) ;
    }

    /**
     * Tests whether this user connection is in read-only mode.</p>
     *
     * @return True if read-only mode is enabled; otherwise, false.
     */
    public boolean isReadOnly() {
        if (getSession().getOpenMode() == oo.openReadWrite)
            return false ;
        else
            return true ;
    }

    /**
     * Gets the transaction-branch identifier associated with this user
     * connection.</p>
     *
     * @return The associated transaction-branch identifier.
     */
    public javax.transaction.xa.Xid getXid() {
	return xaconnection.getXid() ;
    }

    public Session getSession() {
        return xaconnection.getSession() ;
    }

  //
  //  UNIMPLEMENTED JDBC METHODS
  //          |
  //          |
  //         \ /
  //          V
  //

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public Statement createStatement() throws SQLException {
        info("<< Objectivity >> CALLING " + this + ".createStatement().") ;
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public PreparedStatement prepareStatement(String sql)
	    throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public CallableStatement prepareCall(String sql) throws SQLException{
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
	public String nativeSQL(String sql) throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void setAutoCommit(boolean autoCommit) throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public boolean getAutoCommit() throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void commit() throws SQLException {
        throw new SQLException("Method is Unsupported in UserConnection.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void rollback() throws SQLException {
        throw new SQLException("Method is Unsupported in UserConnection.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public DatabaseMetaData getMetaData() throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void setCatalog(String catalog) throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }


	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public String getCatalog() throws SQLException {
        throw new SQLException("Method is Unsupported in Objectivity For Java.") ;
    }


    /**
     * Indicates that transactions are not supported.
     */
    int TRANSACTION_NONE	         = 0 ;

    int TRANSACTION_READ_UNCOMMITTED = 1 ;

    int TRANSACTION_READ_COMMITTED   = 2 ;

    int TRANSACTION_REPEATABLE_READ  = 4 ;

    int TRANSACTION_SERIALIZABLE     = 8 ;

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void setTransactionIsolation(int level) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public int getTransactionIsolation() throws SQLException {
	return TRANSACTION_REPEATABLE_READ ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public SQLWarning getWarnings() throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void clearWarnings() throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public Statement createStatement(int resultSetType, int resultSetConcurrency)
      throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public PreparedStatement prepareStatement(String sql, int resultSetType,
					int resultSetConcurrency)
       throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public CallableStatement prepareCall(String sql, int resultSetType,
				 int resultSetConcurrency) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public java.util.Map getTypeMap() throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void setTypeMap(java.util.Map map) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public int getHoldability() throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void setHoldability(int holdability) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public java.sql.Savepoint setSavepoint() throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public java.sql.Savepoint setSavepoint(String name) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void rollback(java.sql.Savepoint savepoint) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public void releaseSavepoint(java.sql.Savepoint savepoint) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public Statement createStatement(int resultSetType, int resultSetConcurrency, int resultSetHoldability)
      throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public PreparedStatement prepareStatement(String sql, int resultSetType,
					int resultSetConcurrency, int resultSetHoldability)
       throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public CallableStatement prepareCall(String sql, int resultSetType,
				 int resultSetConcurrency, int resultSetHoldability) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public PreparedStatement prepareStatement(String sql, int autoGeneratedKeys)
       throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public PreparedStatement prepareStatement(String sql, int[] columnIndexes)
       throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public PreparedStatement prepareStatement(String sql, String[] columnNames)
       throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

    void info(String message) {
        XADataSource.info(message) ;
    }

    void debugLevel1(String message) {
        XADataSource.debugLevel1(message) ;
    }

    void debugLevel2(String message) {
        XADataSource.debugLevel2(message) ;
    }

    void debugLevel3(String message) {
        XADataSource.debugLevel3(message) ;
    }

// the remaining functions are required for JDK 1.6 - add dummy defs until we have time to do properly

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public java.sql.Blob createBlob()
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public java.sql.Clob createClob()
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

    /**
	* Reserved for future use; you should not call this method. </p>
	*/

    public boolean isValid(int timeout)
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public boolean isWrapperFor(java.lang.Class<?> interfaces)
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */


    public java.util.Properties getClientInfo()
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public java.lang.String getClientInfo(java.lang.String name)
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public void setClientInfo(java.util.Properties properties)
    {
    	// TO DO
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public void setClientInfo(java.lang.String name, java.lang.String value)
    {
    	// TO DO
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public java.sql.Array createArrayOf(java.lang.String typeName, java.lang.Object[] elements)
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public java.sql.Struct createStruct(java.lang.String str,java.lang.Object[] obj)
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public java.sql.SQLXML createSQLXML()
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public java.sql.NClob createNClob()
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }

     /**
	 * Reserved for future use; you should not call this method. </p>
	 */

    public <T> T unwrap(java.lang.Class<T> interfaces)
    throws SQLException
    {
    	// TO DO
    	throw new SQLException("Method is Unsupported.") ;
    }
}
