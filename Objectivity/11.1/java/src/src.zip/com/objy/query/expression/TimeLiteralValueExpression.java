package com.objy.query.expression;
/**
 * Represents a Time literal value node.
 *
 */
public class TimeLiteralValueExpression extends LiteralValueExpression
{
	/**
	 * Constructor.
     */
	public TimeLiteralValueExpression() 
    {
        this(Binding.create());
    }
 
	TimeLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }
	
	/**
	 * Constructor taking a java.sql.Time value
     */
	public TimeLiteralValueExpression(java.sql.Time value)
    {
		this(value.toString());
    }
	
    /**
	 * Constructor taking a java.sql.Time string.
     */
	private TimeLiteralValueExpression(String time) 
    {
    	int endOfHours = time.indexOf(":");
    	String hours = time.substring(0, endOfHours);
    	int endOfMinutes = time.indexOf(":", endOfHours+1);
    	String minutes = time.substring(endOfHours+1, endOfMinutes);
    	String seconds = time.substring(endOfMinutes+1);
    	
    	setIdAfterNullCheck(Binding.create(Integer.parseInt(hours), Integer.parseInt(minutes), Integer.parseInt(seconds), 0));
    }
	
    /**
     * Sets the Time literal value using a java.sql.Time value.
     */
    public void setValue(java.sql.Time value)
    {
        throwExceptionIfInvalidOrClosed(getId());
    	String time = value.toString();
    	int endOfHours = time.indexOf(":");
    	String hours = time.substring(0, endOfHours);
    	int endOfMinutes = time.indexOf(":", endOfHours+1);
    	String minutes = time.substring(endOfHours+1, endOfMinutes);
    	String seconds = time.substring(endOfMinutes+1);
    	
        Binding.setValue(getId(), 
        	Integer.parseInt(hours), Integer.parseInt(minutes), Integer.parseInt(seconds), 0);
    }
    
    @Override
    public String toString() 
    {
        return getPQLRepresentation();
    }
    
	@Override
	/**
	 * Returns the type of the expression (oocTimeLiteralValueExpression).
	 */
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.TimeLiteralValueExpression; 
    }
	
	@Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitTimeLiteralValue(this);
    }
	
	static class Binding
	{
	    private static native long create();
	    private static native long create(int hours, int minutes, 
	            int seconds, int millisecs);
	    private static native void setValue(long id, 
	            int hours, int minutes, int seconds, int millisecs) ;
	    
	}
}
