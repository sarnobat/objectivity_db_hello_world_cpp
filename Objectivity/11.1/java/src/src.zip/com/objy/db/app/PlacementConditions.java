package com.objy.db.app;

import com.objy.db.ObjyRuntimeException;
import com.objy.pm.SessionPersistor;

// TODO: Auto-generated Javadoc
/**
 * Represents a <i>placement-conditions object</i> that encapsulates information used for placing new persistent objects.</p>
 * 
 * <p>
 * Whenever you make a new object persistent by calling its {@link ooObj#persist(com.objy.db.app.PlacementConditions) <tt>persist</tt>} method, 
 * you can optionally pass a placement-conditions object 
 * to provide certain application-specific information for use during object placement.
 * </p>
 * 
 * <p>
 * A placement-conditions object can provide any combination of the following information:
 * </p>
 * 
 * <ul>
 * <li>
 * A purpose indicator for activating specialized placement behavior.
 * <li>
 * A placement guide for guiding the placement of the new object.
 * The specified object must be an existing persistent object, and is
 * expected to be related in some way to the object being placed&#x2014;for example, its owner.
 * In a typical scenario, the new object is placed near the specified object in the federated database.
 * </ul>
 * 
 * <p>
 * Whether and how the information is used depends on the placement model that is currently installed in the federated database:</p>
 * <ul>
 * <li>
 * The purpose indicator is used only if the model is configured with a matching purpose 
 * that applies to the class of object being placed.
 * <li>
 * The placement guide is used only if the model defines a placement relationship 
 * between that object's class and the class of the object being placed.
 * </ul>
 * 
 * <p>
 * Any information that is not used during a placement operation is simply ignored.
 * </p>
 * 
 * <p><b>Note: </b>
 * A placement-conditions object must include a placement guide if it will be used to create a persistent object 
 * of an <a href="../util/ooCollection.html"><tt>ooCollection</tt></a> subclass or <a href="../util/ooMap.html"><tt>ooMap</tt></a>. 
 * This is necessary to satisfy the special internal placement rule that applies to objects of these system classes. 
 * The placement guide may be an object of any persistence-capable class, and is normally the intended owner of the collection.
  * (It is strongly recommended that you use the same placement information for both a persistent collection and any 
 * <a href="../util/ooCompare.html">custom comparator</a> that will be assigned to it.)
 * </p>
 * 
 */
public class PlacementConditions {
    
    /**
     * There are two modes for PlacementConditions
     * 1) Pass in a objectId and type number.  Use this if we do not
     *    want to have to open the object in the kernel.
     * 2) Pass in a related object.  Use this if we don't care if we need
     *    to open the object in the kernel (like if we just constructed 
     *    the near object).
     */
    /** The related object id. */
    ooId relatedObjectId=null;  
    /** The related object type number. */
    long relatedObjectTypeNumber=0;
    
    /** The realted object */
    ooObj relatedObject = null;
    
    /** The purpose. */
    private String purpose=null;
    
    /**
     * Constructs an empty placement-conditions object.</p>
     * 
     */
    public PlacementConditions()
    {
        
    }
    
    /**
     * Constructs a new placement-conditions object with the specified purpose indicator.
     * 
     * @param purpose A value indicating the purpose of the placement operation. </p>
     * 
     * @see ooObj#persist(PlacementConditions)
     */
    public PlacementConditions(String purpose)
    {
        this.setPurpose(purpose);
    }
    
    /**
     * Constructs a new placement-conditions object with the specified purpose indicator and placement guide.
     *
     * @param purpose A value indicating the purpose of the placement operation. </p>
     * 
     * @param relatedObject     The placement guide to be used for placing a new persistent object.
     * <tt><i>relatedObject</i></tt>  must be an existing persistent object, and is
     * expected to be related in some way to the object being placed&#x2014;for example, its owner. </p>
     * 
     * @see ooObj#persist(PlacementConditions)
     */
    public PlacementConditions(String purpose, ooObj relatedObject)
    {
        this.setPurpose(purpose);
        this.relatedObject = relatedObject;         
    }
    
    /**
     * Constructs a new placement-conditions object with the specified purpose indicator and placement guide.</p>
     * 
     * <p>
     * Specifying the placement guide as a combination of type number and object identifier is a performance optimization.
     * When this placement-conditions object is used, 
     * the placement system can use the specified type number directly, 
     * instead of potentially inspecting the identified object in memory to obtain the type number.
     * </p>
     *
     * @param purpose A value indicating the purpose of the placement operation. </p>
     * 
     * @param relatedObjectId The object identifier of the placement guide to be used for placing a new persistent object.
     * <tt><i>relatedObjectId</i></tt>  must identify an existing persistent object, which is
     * expected to be related in some way to the object being placed&#x2014;for example, its owner.</p>
     * 
     * @param relatedObjectTypeNumber The type number of the class of the object identified by <tt><i>relatedObjectId</i></tt>.
     * It is your responsibility to ensure that the specified type number matches the type number of the identified object's class. 
     * A mismatch could result in unexpected placement of any persistent objects that are placed using this placement-conditions object. 
     * </p>
     * 
     * 
     * @see ooObj#persist(PlacementConditions)
     */
    public PlacementConditions(String purpose, ooId relatedObjectId, long relatedObjectTypeNumber)
    {
        this.setPurpose(purpose);
        this.setRelatedObject(relatedObjectId, relatedObjectTypeNumber);
    }

    /**
     * Sets the placement guide that is provided by this placement-conditions object.</p>
     * 
      * <p>
     * Specifying the placement guide as a combination of type number and object identifier is a performance optimization.
     * When this placement-conditions object is used, 
     * the placement system can use the specified type number directly, 
     * instead of potentially inspecting the identified object in memory to obtain the type number.
     * </p>

     *
     * @param relatedObjectId   The object identifier of the placement guide to be used for placing a new persistent object.
     * <tt><i>relatedObjectId</i></tt>  must identify an existing persistent object, which is
     * expected to be related in some way to the object being placed&#x2014;for example, its owner.</p>
     *  
      * @param relatedObjectTypeNumber The type number of the class of the object identified by <tt><i>relatedObjectId</i></tt>.
     * It is your responsibility to ensure that the specified type number matches the type number of the identified object's class. 
     * A mismatch could result in unexpected placement of any persistent objects that are placed using this placement-conditions object. 
     * </p>
     * 
     */
    public void setRelatedObject(ooId relatedObjectId, long relatedObjectTypeNumber) {
        this.relatedObjectId = relatedObjectId;
        this.relatedObjectTypeNumber = relatedObjectTypeNumber;
        this.relatedObject = null;
    }
    
    /**
     * Sets the placement guide that is provided by this placement-conditions object.
     *
     * @param relatedObject   The placement guide to be used for placing a new persistent object.
     * <tt><i>relatedObject</i></tt> must be an existing persistent object, and is
     * expected to be related in some way to the object being placed&#x2014;for example, its owner.</p>
     * 
     * 
     * 
     */
    public void setRelatedObject(ooObj relatedObject) {
        this.relatedObjectId = null;
        this.relatedObjectTypeNumber = 0;
        this.relatedObject = relatedObject;
    }

    /**
     * Gets the object identifier of the placement guide that is provided by this placement-conditions object.
     *
     * @return The object identifier.</p>
     * 
     * 
     */
    public ooId getRelatedObjectId() {
        if(relatedObjectId != null)
            return relatedObjectId;
        else if(relatedObject != null)
            return relatedObject.getOid();
        else
            return null;
    }

    /**
     * Gets the type number of the placement guide that is provided by this placement-conditions object.
     *
     * @return The type number.
     */
    public long getRelatedObjectTypeNumber() {
        if(relatedObjectTypeNumber != 0)
            return relatedObjectTypeNumber;
        else if(relatedObject != null)
            return relatedObject.getTypeNumber();
        else
            return 0;       
    }
    
    /**
     * Gets the object  of the placement guide that is provided by this placement-conditions object.
     *
     * @return The type number.
     */
    public ooObj getRelatedObject() {
        if(relatedObject != null)
            return relatedObject;
        else if(relatedObjectId != null)
        {
            Session sess = Session.getCurrent();
            if(sess == null || sess.getFD() == null)
                throw new ObjyRuntimeException("Unable to determine related object.");
            return (ooObj)sess.getFD().objectFrom(relatedObjectId);
        }
        else
            return null;
    }

    /**
     * Sets the purpose indicator that is provided by this placement-conditions object.
     *
     * @param purpose The purpose indicator.
     */
    public void setPurpose(String purpose) {
        this.purpose = purpose;
    }

    /**
     * Gets the purpose indicator that is provided by this placement-conditions object.
     *
     * @return The purpose indicator.
     */
    public String getPurpose() {
        return purpose;
    }

}
