package com.objy.db.internal.tools;

import com.objy.pm.Access;
import com.objy.pm.Configuration;

/**
 * Singleton instance of registry of tools.
 */
public class ToolRegistry {
    
    public static final String PLATFORM = System.getProperty("os.name");
    private static final String glue = "oojava" + Configuration.INTERFACE_VERSION;
    private static final String glueForUnix = "oojava" + "."+Configuration.RELEASE_MAJOR+"."+Configuration.RELEASE_MINOR;
    private static boolean initialized = false;

    private static ToolRegistry smInstance;
    private long mToolRegistryPtr;
    
    static 
    {
        init();
    }
    
    /**
     * Reserved for internal use
     */
    //
    // one time load of the library - Remember that NO exceptions can be
    // thrown in a static initializer
    // do this here in case the user calls a tool before doing a connection.open which is 
    // the normal way oojava.so/dll is loaded
    //
    public static void init()
    {
        if(!initialized)
        {
            String glueToLoad = glue;
            if (!PLATFORM.startsWith("Win"))
            {
                glueToLoad = glueForUnix ; 
            }
            try
            { 
                System.loadLibrary(glueToLoad) ; 
            }
            catch(UnsatisfiedLinkError e1) {
                System.err.println("Load of library: " + System.mapLibraryName(glueToLoad) + " failed") ;
                e1.printStackTrace(System.err) ;
                System.exit(-1) ;
            }
            catch(SecurityException e2) {
                System.err.println("Security exception loading library: " + System.mapLibraryName(glueToLoad)) ;
                System.exit(-1) ;
            }
            //We need to do a init of the java binding here in case the user hasn't already
            //done so via connection.  We must do this here so that we do our own initialization
            //before the tools might possibly call startup via C++ which would cause problems
            //when the java binding decided to actually initialize itself.  
            //Note that it doesn't matter if this is called after connection.Open (which initis
            //the binding) or if connection.Open is called after this as Binding.init calls
            //initAllThreads and initBinding which have flags as to not do work on itself multiple times
            Access.toolInit();
            initialized = true;
        }
    }

    private ToolRegistry(long ptr)
    {
        mToolRegistryPtr = ptr;
    }

    /**
     * Gets singleton instance of ToolRegistry
     * @return Tool Registry
     */
    public static synchronized ToolRegistry getInstance()
    {
        if(smInstance == null)
        {
            smInstance = new ToolRegistry(Binding.construct());
        }
        return smInstance;
    }

    /**
     * Gets a tool.
     * @param name Name of the tool.
     * @return Class representation of the tool
     */
    public  Tool getTool(String name) 
    {
        return new Tool(Binding.getTool(mToolRegistryPtr, name));

    }
    
    /*public Tool getTool(long index) 
    {

    }*/

    /**
     * Gets the number of tools registered in the registry
     * @return number of tools in the registry
     */
    public long getNumberOfTools() 
    {
        return Binding.getNumberOfTools(mToolRegistryPtr);
    }
    
    private static class Binding
    {
        public static native long construct();
        public static native long getNumberOfTools(long toolRegistryPtr);
        public static native long getTool(long toolRegistryPtr, String toolName);
    }


    // This call will tranfer ownership of the tool to the ToolRegistry
    // instance. 
    //public void addTool(Tool tool);

    // Will remove all tools. This should only be used by test code
    //public void reset();




    //private class Impl;
    //private Impl* const mImpl;


    //   private ~ToolRegistry();

    /*private static void shutdown()
    {

    }*/

    // Prevent copy construction or assignment
    private ToolRegistry(ToolRegistry other)
    {

    }

}
