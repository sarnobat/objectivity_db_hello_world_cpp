package com.objy.query.expression;

/**
 * Represents a float literal value node.
 */
public class FloatLiteralValueExpression extends LiteralValueExpression
{
    /**
     * Constructs a float literal value node.
     */
    public FloatLiteralValueExpression() 
    {
        this(Binding.create());
    }
    
    /**
     * Constructs a float literal value node with a float value.
     */
    public FloatLiteralValueExpression(float val) 
    {
        this(Binding.create(val));
    }
    
    /**
     * Constructs a float literal value node with an ID.
     * @param id
     */
    FloatLiteralValueExpression(long id) 
    {
        setIdAfterNullCheck(id);
    }

	/**
	 * Returns the float literal value.
	 */
    public float getValue() 
    {
        throwExceptionIfInvalidOrClosed(getId());
        return Binding.create(getId());
    }
    
    /**
     * Returns the type of the expression (oocFloatLiteralValueExpression).
     */
	@Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.FloatLiteralValueExpression; 
    }
	
	@Override
	public String toString()
    {
    	return Float.toString(getValue());
    }
	
	@Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitFloatLiteralValue(this);
    }
	
	static class Binding
	{
	    private static native long create();
	    private static native long create(float val);
	    private static native float getValue(long id);
	}
}
