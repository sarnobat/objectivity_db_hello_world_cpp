package com.objy.query.expression;
/**
 * Represents expression setup error handler.
 *
 */
public class ExpressionSetupErrorHandler extends AbstractExpression
{

    static {
        Expression.init();
    }
    
    /**
     * Constructs an expression setup error handler.
     */
    public ExpressionSetupErrorHandler()
    {
        setId(Binding.create());
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public ExpressionSetupErrorHandler(long id)
    {
        setId(id);
    }
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    public static ExpressionSetupErrorHandler getErrorHandler(long id)
    {
        return new ExpressionSetupErrorHandler(id);
    }
    
    /**
     * Returns the first error.
     */
    public ExpressionSetupError getFirstError()
    {
        long id = Binding.getFirstError(mId);
        if (id != 0)
        {
            return new ExpressionSetupError(id);
        }
        return null;
    }
    
    /**
     * Returns the number of errors.
     */
    public int getNumberOfErrors()
    {
        return Binding.getNumberOfErrors(mId);
    }
    
    /**
     * Clears the errors.
     */
    public void clearErrors()
    {
        Binding.clearErrors(mId);
    }
    
    static class Binding
    {
        private static native long create();
        private static native long getFirstError(long id);
        private static native int getNumberOfErrors(long id);
        private static native void clearErrors(long id);
        
    }
}
