package com.objy.query.expression;
/**
* Represents an expression construction exception.
*/

@SuppressWarnings("serial")
public class ExpressionConstructionException extends ExpressionException
{
   
   /**
    * Constructs an expression construction exception with a message.
    * @param message
    */
   public ExpressionConstructionException(String message) 
   {
       super(message);
   }
   
}
