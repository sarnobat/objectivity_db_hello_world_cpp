/*
 * @(#)FetchCompletedWithErrors.java
 * 
 * Copyright (c) 1997 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

import com.objy.db.iapp.FetchErrorInfo;
import com.objy.pm.Access;

import java.io.PrintStream;
import java.util.Vector;

/**
 * Signals that a fetch operation completed, but errors occurred.
 *
 * <p>When you fetch a source object and some or all of its reference 
 * attributes, the fetch operation may complete with errors. This situation 
 * arises when the session is able to fetch the source 
 * object, but is unable to find or access the destination 
 * objects of all relevant reference attributes.  
 *
 * <p>By default, when a fetch operation completes with errors, a 
 * <tt>FetchCompletedWithErrors</tt> exception is thrown for each destination 
 * object that could not be found or locked.  You can control this behavior 
 * by calling a session's 
 * <a href="./app/Session.html#setFetchErrorFormat(int)">
 *<tt>setFetchErrorFormat</tt></a> method.  
 *
 * <p>For additional information,
 * see <a href="../../../../guide/jgdPersistence.html#FetchErrors">
 * Errors While Fetching Reference Attributes</a>.
 *
 * <p>An exception of this class is
 * informational. It provides the reference 
 * attribute that was not fetched successfully, the object identifier of 
 * the destination object that could not be found or locked,
 * and possible reasons for the failure.
 * Calling the <a href="ObjyRuntimeException.html#errors()"<tt>errors</tt></a> method on
 * an exception of this class returns a vector of 
 * <a href="./iapp/FetchErrorInfo.html">fetch-error information objects</a>
 * rather than the usual  <a href="./app/ExceptionInfo.html">exception information objects</a>.</p>    
 *
 * <p>An exception of this class is thrown by the default implementation
 * of the <a href="./app/ooObj.html#activate(com.objy.db.iapp.ActivateInfo)"><tt>activate</tt></a> method,
 * which is called at the end of the fetch operation.
 * You can override <tt>activate</tt> to explicitly handle the errors.
 *
 */
public class   FetchCompletedWithErrors
       extends ObjyRuntimeException
{    
	/**
	 * 
	 */
    private Object object ;

	/**
	 * Reserved for internal use.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public FetchCompletedWithErrors(String message, Object object, Vector fetchFailedInfos) {
        super(message) ;
        this.object = object ;
        setErrors(fetchFailedInfos) ;
    }
	/**
	 * Gets the object for which the fetch was completed with errors.
	 * 
	 */
    public Object getObject()
        { return object ; }

    	/**
	 * Prints information about the errors that occurred.
	 * 
	 * <p>If this exception has
	 * <a href="./iapp/FetchErrorInfo.html">fetch-error information
	 * objects</a>, this method prints the ID and description of each
	 * error, in the order in which the errors were reported.
	 *
	 */
    public void reportErrors() {
        PrintStream out = Access.getCurrentSessionOut();
        FetchErrorInfo info ;
        java.util.Enumeration e = errors().elements();
        out.println("Fetch errors encountered when reading object") ;
        out.println("--------------------------------------------") ;
        while (e.hasMoreElements()) {
            info = (FetchErrorInfo)e.nextElement();
            out.println(info.getErrorMessage()) ;
        }
    }
}


