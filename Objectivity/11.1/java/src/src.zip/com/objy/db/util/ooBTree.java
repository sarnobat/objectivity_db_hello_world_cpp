/*
 * @(#)ooBTree.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.lang.reflect.Array;
import java.util.Iterator;

import com.objy.db.app.ooObj;
import com.objy.pm.ooScalableCollectionsPersistor;
import com.objy.pm.ooCollectionIterator;
import com.objy.db.ObjectIsDeadException;
import com.objy.db.ObjectNotPersistentException;

/**
 * Abstract superclass for persistence-capable classes that represent 
 * scalable ordered collections containing persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>  Scalable ordered collections  can
 * increase in size with minimal performance degradation. They are
 * implemented using a B-tree data structure so that
 * elements can be added, deleted, and found efficiently. 
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Scalable Ordered Collections">
 * Scalable Ordered Collections</a>.
 *
 * <p>Concrete subclasses of <tt>ooBTree</tt> represent more specific kinds of
 * ordered collections:
 * <a href="ooTreeSet.html">sorted sets</a> of persistent objects,
 * <a href="ooTreeList.html">lists</a> of persistent objects, and 
 * <a href="ooTreeMap.html">sorted object maps</a>.
 *
 * <p>Because this class is abstract, you never instantiate it; instead, you
 * work with instances of its concrete derived classes. You should not create
 * your own subclasses of this class.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 * 	   <td>
 * 	   <a href="#first()">first()</a><br>
 * 	   <a href="#last()">last()</a><br>
 * 	   <a href="#get(int)">get(int)</a><br>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Indexes</b></td>
 * 	   <td>
 * 	   <a href="#indexOf(java.lang.Object)">indexOf(Object)</a><br>
 * 	   <a href="#indexOf(java.lang.Object, int)">indexOf(Object, int)</a><br>
 * 	   <a href="#lastIndexOf(java.lang.Object)">lastIndexOf(Object)</a><br>
 * 	   <a href="#lastIndexOf(java.lang.Object, int)">lastIndexOf(Object, int)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	   <td>
 * 	   <a href="#contains(java.lang.Object)">contains(Object)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Setting&nbsp;Properties</b></td>
 * 	   <td>
 * 	   <a href="#maxNodesPerContainer(int)">maxNodesPerContainer(int)</a><br>
 * 	   <a href="#maxVArraysPerContainer(int)">maxVArraysPerContainer(int)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Maintaining&nbsp;the&nbsp;B-Tree</b></td>
 * 	   <td>
 * 	   <a href="#compact()">compact()</a>
 * 	   </td></tr>
 * </table>
 */
abstract public class ooBTree extends ooCollection
{
	ooBTree() {}

	/**
	 * Minimizes the number of nodes in this ordered collection's B-tree.
	 *
	 * <p>After you have added all elements that you expect this collection to have,
	 * you can call this method to minimize the number of nodes in its B-tree.
	 * Doing so saves space and improves read performance. Indexes of
	 * elements within the collection remain unchanged.
	 *
	 * <p>If you call this method before all elements have been added, insert (add) performance
	 * will not necessarily improve.  After the B-tree has been compacted, adding an element
	 * will very likely cause one or more nodes to be added to the B-tree.
	 */
    public void compact()
    {
        getCollectionPersistor().compact();
    }

	/**
	 * Tests whether this ordered collection contains the specified
	 * object. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be tested for
	 * containment in this ordered collection.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the element (or key) of interest.  If this is a sorted collection
	 * with an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the element (or key) of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		True if this ordered collection contains an element equal to
	 * the specified element; otherwise, false.</p>
	 */
    public boolean contains(Object object) {
        return getCollectionPersistor().contains(object);
    }

	/**
	 * Finds the first element (or key) in this ordered collection. </p>
	 *
	 * @return		If the elements of this ordered collection are persistent objects,
	 * the first element; if the elements are
	 * key-value pairs, the key of the first element.</p>
	 *
	 * @see #last
	 * @see #get
	 */
    public Object first() {
        return getCollectionPersistor().first();
    }

	/**
	 * Finds the element (or key) of this ordered collection at the specified
	 * index. </p>
	 *
	 * @param		<tt><i>index</i></tt>	The zero-based index of the 
     * element to find.</p> 
	 *
	 * @return		If the elements of this ordered collection are persistent objects,
	 * the element whose index is <tt><i>index</i></tt>; if the elements are
	 * key-value pairs, the key of the element whose index is
	 * <tt><i>index</i></tt>.</p>
	 *
	 * @see #first
	 * @see #last
	 */
    public Object get(int index)
    {
        return getCollectionPersistor().get(index);
    }

	/**
	 * Searches forward in this ordered collection, starting at the specified index, for
	 * the first element (or key)
	 * that is equal to the specified object.
	 *
	 * <p>If elements of this ordered collection are persistent objects, this method compares
	 * each element with <tt><i>object</i></tt>; if elements are key-value pairs,
	 * this method compares the key of each element
	 * with <tt><i>object</i></tt>. Search stops when a matching element is found;
	 * if more than one element matches, this method finds the one closest to the beginning
	 * of the collection (but at or after the starting index). </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object whose index is to be
	 * found.</p>
	 *
	 * @param		<tt><i>index</i></tt>	The zero-based index at which search should
	 * start.</p>
	 *
	 * @return		The index of the first element in this ordered collection
	 * at or after the index <tt><i>index</i></tt>, that is equal to (or
	 * whose key is equal to)
 	 * <tt><i>object</i></tt>. If no such element is found, this method
	 * returns -1.</p>
	 *
	 * @see #lastIndexOf(Object, int)
	 */
    public int indexOf(Object object, int index) {
        return getCollectionPersistor().indexOf(object, index);
    }

	/**
	 * Searches forward in this ordered collection (from the beginning)
	 * for the first element (or key)
	 * that is equal to the specified object.
	 *
	 * <p>If elements of this ordered collection are persistent objects, this method compares
	 * each element with <tt><i>object</i></tt>; if elements are key-value pairs,
	 * this method compares the key of each element
	 * with <tt><i>object</i></tt>. Search stops when a matching element is found;
	 * if more than one element matches, this method finds the one closest to the beginning
	 * of the collection. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object whose index is to be
	 * found.</p>
	 *
	 * @return		The (zero-based) index of the first element of this ordered collection
	 * that is equal to (or
	 * whose key is equal to) <tt><i>object</i></tt>. If no such element
	 * is found, this method returns -1.</p>
	 *
	 * @see #lastIndexOf(Object, int)
	 */
    public int indexOf(Object object) {
        return indexOf(object, 0);
    }

	/**
	 * Finds the last element (or key) in this ordered collection. </p>
	 *
	 * @return		If the elements of this ordered collection are persistent objects,
	 * the last element; if the elements are
	 * key-value pairs, the key of the last element.</p>
	 *
	 * @see #first
	 * @see #get
	 */
    public Object last() {
        return getCollectionPersistor().last();
    }

	/**
	 * Searches backward in this ordered collection, starting at the specified index,
	 * to find an element (or key)  that is equal to the
	 * specified object.
	 *
	 * <p>If elements of this ordered collection are persistent objects, this method compares
	 * each element with <tt><i>object</i></tt>; if elements are key-value pairs,
	 * this method compares the key of each element
	 * with <tt><i>object</i></tt>. Search stops when a matching element is found;
	 * if more than one element matches, this method finds the one closest to the end
	 * of the collection (but at or before the starting index). </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object whose index is to be
	 * found.</p>
	 *
	 * @param		<tt><i>index</i></tt>	The index at which search should
	 * end.</p>
	 *
	 * @return		The index of the last element of this ordered collection,
	 * at or before the index <tt><i>index</i></tt>, that is equal to (or
	 * whose key is equal to)
 	 * <tt><i>object</i></tt>. If no such element is found, this method
	 * returns -1.</p>
	 *
	 * @see #indexOf(Object, int)
	 */
    public int lastIndexOf(Object object, int index) {
      int tempIndex = indexOf(object, 0);
	    int lastIndex = tempIndex;
	    while (tempIndex != -1 && tempIndex <= index)
	    {
		    lastIndex = tempIndex;
		    tempIndex = indexOf(object, lastIndex + 1);
	    }
	    if (tempIndex == index) return index;
	    return lastIndex;
    }

	/**
	 * Searches backward in this ordered collection, starting at the end, for an element
	 * (or key) that is equal to the specified object.
	 *
	 * <p>If elements of this ordered collection are persistent objects, this method compares
	 * each element with <tt><i>object</i></tt>; if elements are key-value pairs,
	 * this method compares the key of each element
	 * with <tt><i>object</i></tt>. Search stops when a matching element is found;
	 * if more than one element matches, this method finds the one closest to the end
	 * of the collection. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object whose index is to be
	 * found.</p>
	 *
	 * @return		The index of the last element in this ordered collection
	 * that is equal to (or
	 * whose key is equal to) <tt><i>object</i></tt>. If no such element
	 * is found, this method returns -1.</p>
	 *
	 * @see #indexOf(Object, int)
	 */
    public int lastIndexOf(Object object) {
        return lastIndexOf(object, size() - 1);
    }

	/**
	 * Sets the maximum number of B-Tree nodes for this ordered
	 * collection that can be stored in a single container. </p>
	 *
	 * @param		<tt><i>max</i></tt>	The maximum number of
	 * nodes per container for this ordered collection.</p>
	 *
	 * @see			#maxVArraysPerContainer
	 * @see			<a href="../../../../../guide/jgdCollections.html#NodeArrayCont">
	 *				Containers for Nodes and Arrays</a>
	 */
    public void maxNodesPerContainer(int max)
    {
        getCollectionPersistor().maxNodesPerContainer(max);
    }

	/**
	 * Sets the maximum number of arrays per container for this ordered
	 * collection. </p>
	 *
	 * @param		<tt><i>max</i></tt>	The maximum number of
	 * arrays for this ordered collection that can be stored in a single
	 * container.</p>
	 *
	 * @see			#maxNodesPerContainer
	 * @see			<a href="../../../../../guide/jgdCollections.html#NodeArrayCont">
	 *				Containers for Nodes and Arrays</a>
	 */
    public void maxVArraysPerContainer(int max)
    {
        getCollectionPersistor().maxVArraysPerContainer(max);
    }

	/**
	 * Reserved for internal use; you should not call this method. </p>
	 */
     protected ooScalableCollectionsPersistor getCollectionPersistor()
     {
        if (getPersistor() == null)
            throw new ObjectNotPersistentException("Attempted persistence operation on transient object") ;

        if (getPersistor().isDead())
            throw new ObjectIsDeadException("Attempted persistence operation on dead object");
//System.out.println(getPersistor()) ;
        return (ooScalableCollectionsPersistor) getPersistor() ;
    }

}
