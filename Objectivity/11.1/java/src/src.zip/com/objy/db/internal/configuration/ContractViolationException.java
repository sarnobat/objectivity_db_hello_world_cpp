package com.objy.db.internal.configuration;

import com.objy.db.ObjyRuntimeException;

/*
 * The corresponding C++ class is in the objy namespace and it is meant as a 
 * generic tool.  When it starts to get more widespread use we will want
 * to move this to com.objy.db.app???
 */
public class ContractViolationException extends ObjyRuntimeException
{
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ContractViolationException(String message) {
        super(message) ;      
    }
    

}
