/*
 * @(#)ooTreeMap.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.AbstractCollection;
import java.util.AbstractMap;
import java.util.AbstractSet;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.SortedMap;
import java.util.Collection;
import java.util.Set;
import java.util.Map;
import com.objy.pm.ooTreeMapPersistor;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.iapp.Persistent;

/**
 * Persistence-capable class for sorted object maps.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Sorted Object Maps</h2>
 *
 * <p>A <i>sorted object map</i> is a scalable ordered collection of
 * key-value pairs; each key and each value is a persistent object.
 * No two elements of the object map may have the same key. As the name implies,
 * each element of an object map is a mapping from its key object to its
 * value object.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Scalable Ordered Collections">
 * Scalable Ordered Collection</a>.
 *
 * <p><h2>Working With a Sorted Object Map</h2>
 *
 * <P>A sorted object map is transient when it is created; you can make it
 * persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created a sorted object map, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building an Object Map">
 * Building an Object Map</a></p>
 *
 * <li>Look up particular objects in the sorted object map as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Object Maps">
 * Individual Lookup in Object Maps</a></p>
 *
 * <li>Iterate over the sorted object map as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Keys and Values of an Object Map">
 * Finding the Keys and Values of an Object Map</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make a sorted object map persistent before you call
 * any methods defined by the <tt>ooTreeMap</tt>, <tt>ooBTree</tt>, or
 * <tt>ooCollection</tt> classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of key-value
 * pairs:
 *
 * <ul>
 * <li> <a href="ooHashMap.html"><tt>ooHashMap</tt></a> represents
 * an <i>unordered</i> object map. </p>
 *
 * <li> <a href="ooMap.html"><tt>ooMap</tt></a> represents
 * a nonscalable <i>unordered name map</i>, that is, a collection of
 * key-value pairs in which the key is a string and the value is
 * a persistent object. </p>
 * </ul>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 	<td>
 *     <a href="#ooTreeMap()">ooTreeMap()</a><br>
 *     <a href="#ooTreeMap(com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeMap(ooContObj, ooContObj)</a><br>
 *     <a href="#ooTreeMap(int)">ooTreeMap(int)</a><br>
 *     <a href="#ooTreeMap(int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeMap(int, ooContObj, ooContObj)</a><br>
 *     <a href="#ooTreeMap(com.objy.db.util.ooCompare)">ooTreeMap(ooCompare)</a><br>
 *     <a href="#ooTreeMap(com.objy.db.util.ooCompare, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeMap(ooCompare, ooContObj, ooContObj)</a><br>
 *     <a href="#ooTreeMap(com.objy.db.util.ooCompare, int)">ooTreeMap(ooCompare, int)</a><br>
 *     <a href="#ooTreeMap(com.objy.db.util.ooCompare, int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeMap(ooCompare, int, ooContObj, ooContObj)</a>
 * 	</td></tr>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Adding,&nbsp;Removing,&nbsp;and Changing&nbsp;Elements</b></td>
 * 	   <td>
 *     <a href="#put(java.lang.Object, java.lang.Object)">put(Object, Object)</a><br>
 *     <a href="#putAll(java.util.Map)">putAll(Map)</a><br>
 *     <a href="#ooAddAll(com.objy.db.util.ooCollection)">ooAddAll(ooCollection)</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#remove(java.lang.Object)">remove(Object)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 * 	<td>
 *     <a href="#get(java.lang.Object)">get(Object)</a><br>
 *     <a href="#firstKey()">firstKey()</a><br>
 *     <a href="#lastKey()">lastKey()</a><br>
 *     <a href="#keyIterator()">keyIterator()</a><br>
 *     <a href="#valueIterator()">valueIterator()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Indexes</b></td>
 * 	   <td>
 * 	   <a href="#indexOf(java.lang.Object, int)">indexOf(Object, int)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	   <td>
 *     <a href="#containsKey(java.lang.Object)">containsKey(Object)</a><br>
 *     <a href="#containsValue(java.lang.Object)">containsValue(Object)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting Views of the Object Map</b></td>
 * 	   <td>
 *     <a href="#entrySet()">entrySet()</a><br>
 *     <a href="#keySet()">keySet()</a><br>
 *     <a href="#values()">values()</a><br>
 *     <a href="#headMap(java.lang.Object)">headMap(Object)</a><br>
 *     <a href="#subMap(java.lang.Object, java.lang.Object)">subMap(Object, Object)</a><br>
 *     <a href="#tailMap(java.lang.Object)">tailMap(Object)</a>
 * 	</td></tr>
 * </table>
 */
final public class ooTreeMap extends ooBTree implements SortedMap
{
    private transient Set keySet = null;
    private transient Set entrySet = null;
    private transient Collection values = null;

 	/**
	 * Reserved for internal use.
	 */
    public transient int _maxUsedSizePerNode;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _adminContainer;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _arrayContainer;

	/**
	 * Constructs an empty sorted object map with a default comparator and
     * the default
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>. </p>
	 */
    public ooTreeMap()
    {}

	/**
	 * Constructs an empty sorted object map with a default comparator, the
     * default
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>, and the specified containers for internal objects. </p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeMap(ooContObj adminContainer, ooContObj arrayContainer)
    {
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty sorted object map with the specified
	 * comparator and the default
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted object map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.
	 */
    public ooTreeMap(ooCompare compare)
    {
        _comparator = compare;
    }

	/**
	 * Constructs an empty sorted object map with the specified
	 * comparator, the default
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>, and the specified containers
	 * for internal objects. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted object map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeMap(ooCompare compare, ooContObj adminContainer, ooContObj arrayContainer)
    {
      _comparator = compare;
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty sorted object map with a default comparator and the
	 * specified node size. </p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted object map's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.
	 */
    public ooTreeMap(int maxNodeSize)
    {
         _maxUsedSizePerNode = maxNodeSize;
    }

	/**
	 * Constructs an empty sorted object map with a default comparator and the
	 * specified node size and containers
	 * for internal objects. </p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted object map's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeMap(int maxNodeSize, ooContObj adminContainer, ooContObj arrayContainer)
    {
      _maxUsedSizePerNode = maxNodeSize;
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty sorted object map with the specified comparator
	 * and node size. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted object map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted object map's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 */
    public ooTreeMap(ooCompare compare, int maxNodeSize)
    {
        _comparator = compare;
        _maxUsedSizePerNode = maxNodeSize;
    }

	/**
	 * Constructs an empty sorted object map with the specified
	 * comparator, node size, and containers
	 * for internal objects. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted object map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted object map's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted object map. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeMap(ooCompare compare, int maxNodeSize, ooContObj adminContainer, ooContObj arrayContainer)
    {
      _comparator = compare;
      _maxUsedSizePerNode = maxNodeSize;
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

  /**
	 * Overrides the inherited method; disallows adding an element to
	 * this sorted object map.
	 *
	 * <p>This method always throws an exception. You should use
	 * {@link #put <tt>put</tt>} instead of this method. </p>
	 *
	 * @param   object    Ignore
	 * @return  Ignore
	 */
    public boolean add(Object object) {
         throw new UnsupportedOperationException();
    }

	/**
	 * Tests whether the specified
	 * object is a key of this sorted object map.
	 *
	 * <p>This method is equivalent to
	 * {@link #containsKey <tt>containsKey</tt>}; the intention of your code
	 * will  be clearer if you call <tt>containsKey</tt> instead of this
	 * method. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be tested for
	 * containment in this sorted object map.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the key of interest.  If this sorted object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		True if this sorted object map contains an element
	 * with the specified key; otherwise, false.</p>
	 */
    public boolean contains(Object object) {
         return containsKey(object);
    }

	/**
	 * Tests whether this sorted object map contains an element with the specified key.
	 *
	 * <p>You can call this method to check whether this sorted object map
	 * maps the specified key to some value.  </p>
	 *
	 * @param		<tt><i>key</i></tt>	The key to be tested for containment
	 * in this sorted object map.
	 *
	 * <p>Typically, <tt><i>key</i></tt> is a persistent object, namely
	 * the key of interest.  If this sorted object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>key</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		True if this sorted object map contains an element
	 * with the specified key; otherwise, false.</p>
	 *
	 * @see #containsValue(Object)
	 */
    public boolean containsKey(Object key)
    {
        return getCollectionPersistor().contains(key);
    }

	/**
	 * Tests whether this sorted object map contains an element with the specified value.
	 *
	 * <p>You can call this method to check whether this sorted object map
	 * maps at least one key to the specified value. </p>
	 *
	 * @param		<tt><i>value</i></tt>	The value to be tested for containment
	 * in this sorted object map.</p>
	 *
	 * @return		True if this sorted object map contains an element whose value is
	 * <tt><i>value</i></tt>; otherwise, false.</p>
	 *
	 * @see #containsKey(Object)
	 */
    public boolean containsValue(Object value)
    {
        return ((ooTreeMapPersistor)getCollectionPersistor()).containsValue(value);
    }

    static class Entry implements Map.Entry {
	    Object key;
	    Object value;

	    Entry(Object key, Object value) {
	        this.key = key;
	        this.value = value;
	    }

	    // Returns the key in this entry
	    public Object getKey() {
	        return key;
	    }

	    // Returns the value in this entry.
	    public Object getValue() {
	        return value;
	    }

	    public Object setValue(Object value) {
	        Object oldValue = this.value;
	        this.value = value;
	        return oldValue;
	    }
    } // End Entry class

    // Iterator class
    private class EntryIterator implements java.util.Iterator {
	    private ooCollectionIterator keyItr;
	    private Entry firstExcluded = null;

	    EntryIterator() {
	        keyItr = keyIterator();
	    }

	    EntryIterator(Entry first, Entry firstExcluded) {
	        keyItr = keyIterator();
	        if (first != null)
	        {
	            keyItr.goTo(first.getKey());
 	            keyItr.previous();
	        }
	        this.firstExcluded = firstExcluded;
	    }

	    public boolean hasNext() {
            	return keyItr.hasNext() && (firstExcluded == null 
                    || ooTreeMap.this.compare(get(keyItr.nextIndex()), firstExcluded.getKey()) < 0);
	    }

	    public Object next() {
	        if (!hasNext())
	            return null;
	        return new Entry(keyItr.next(), keyItr.currentValue());
	    }

	    public void remove() {
	        keyItr.remove();
	    }
    } // End EntryIterator class

    private class SubMap extends AbstractMap implements SortedMap {
        // fromKey is significant only if fromStart is false.  Similarly,
        // toKey is significant only if toEnd is false.
        protected boolean fromStart = false, toEnd = false;
	    private Object  fromKey, toKey;

	    SubMap(Object fromKey, Object toKey) {
	        if (fromKey != null && toKey != null && compare(fromKey, toKey) > 0)
		        throw new IllegalArgumentException("fromKey > toKey");
	        this.fromKey = fromKey;
	        this.toKey = toKey;
	        fromStart = (fromKey == null);
	        toEnd = (toKey == null);
	    }

	    SubMap(Object key, boolean headMap) {
            if (headMap) {
                fromStart = true;
                toKey = key;
                toEnd = (toKey == null);
            } else {
                toEnd = true;
                fromKey = key;
                fromStart = (fromKey == null);
            }
	    }

	    SubMap(boolean fromStart, Object fromKey, boolean toEnd, Object toKey){
            this.fromStart = fromStart;
            this.fromKey= fromKey;
            this.toEnd = toEnd;
            this.toKey = toKey;
	    }

	    public boolean isEmpty() {
	        return entrySet.isEmpty();
	    }

	    public boolean containsKey(Object key) {
	        return inRange(key) && ooTreeMap.this.containsKey(key);
	    }

        public Comparator comparator() {
            return ooTreeMap.this.comparator();
        }

	    public Object get(Object key) {
	        if (!inRange(key))
                return null;
	        return ooTreeMap.this.get(key);
	    }

	    public Object put(Object key, Object value) {
	        if (!inRange(key))
		        throw new IllegalArgumentException("key out of range");
	        return ooTreeMap.this.put(key, value);
	    }

        public Object firstKey() {
            return fromStart ? ooTreeMap.this.firstKey() : getFirstKey();
        }

        public Object lastKey() {
            return toEnd ? ooTreeMap.this.lastKey() : getToKey();
        }

 	private Object getFirstKey() {
 	    ooCollectionIterator itr = keyIterator();
 	    itr.goTo(fromKey);
	    return itr.current();
 	}

 	private Object getToKey() {
 	    ooCollectionIterator itr = keyIterator();
        itr.goTo(toKey);
        return itr.current();
 	}

	    private transient Set entrySet = new EntrySetView();

	    public Set entrySet() {
	        return entrySet;
	    }

	    protected class EntrySetView extends AbstractSet {
	        private transient int size = -1;

	        public int size() {
		        if (size == -1) {
		            size = 0;
		            java.util.Iterator i = iterator();
		            while (i.next() != null) {
			            size++;
		            }
		        }
		        return size;
	        } // End size method

	        public boolean isEmpty() {
		        return !iterator().hasNext();
	        } // End isEmpty method

	        public boolean contains(Object o) {
		        if (!(o instanceof Map.Entry))
		            return false;
		        Map.Entry entry = (Map.Entry)o;
		        Object key = entry.getKey();
                if (!inRange(key))
                    return false;
                Object obj = get(key);
                return obj != null &&
                       valEquals(obj, entry.getValue());
	        } // End contains method

	        public boolean remove(Object o) {
		        if (!(o instanceof Map.Entry))
		            return false;
		        Map.Entry entry = (Map.Entry)o;
		        Object key = entry.getKey();
                if (!inRange(key))
                    return false;
                Object obj = get(key);
                if (obj!=null && valEquals(obj,entry.getValue())){
		            ooTreeMap.this.remove(key);
		            return true;
                }
                return false;
	        } // End remove method

	        public java.util.Iterator iterator() {
                return new EntryIterator(fromStart ? null : new ooTreeMap.Entry(fromKey, get(fromKey)), toEnd ? null : new ooTreeMap.Entry(toKey, get(toKey)));
	        } // End iterator method
	    } // End EntrySetView class

        public SortedMap subMap(Object fromKey, Object toKey) {
            if (!inRange(fromKey))
		        throw new IllegalArgumentException("fromKey out of range");
            if (!inRange2(toKey))
                throw new IllegalArgumentException("toKey out of range");
            return new SubMap(fromKey, toKey);
        }

        public SortedMap headMap(Object toKey) {
            if (!inRange2(toKey))
                throw new IllegalArgumentException("toKey out of range");
            return new SubMap(fromStart, fromKey, false, toKey);
        }

        public SortedMap tailMap(Object fromKey) {
            if (!inRange(fromKey))
                throw new IllegalArgumentException("fromKey out of range");
            return new SubMap(false, fromKey, toEnd, toKey);
        }

	    protected boolean inRange(Object key) {
	        return (fromStart || compare(key, fromKey) >= 0) &&
                   (toEnd     || compare(key, toKey)   <  0);
	    }

        // This form allows the high endpoint (as well as all legit keys)
	    private boolean inRange2(Object key) {
	        return (fromStart || compare(key, fromKey) >= 0) &&
                   (toEnd     || compare(key, toKey)   <= 0);
        }

        protected ooTreeMap.Entry firstEntry() {
            Object key = firstKey();
	        return key == null ? null : new ooTreeMap.Entry(key, get(key));
        }

        protected ooTreeMap.Entry lastEntry() {
            Object key = lastKey();
	        return key == null ? null : new ooTreeMap.Entry(key, get(key));
        }
    } // End SubMap class

    /**
	 * Gets a set view of the key-value pairs in this object map.
	 *
	 * <p>Each element in the returned set is an instance of a
	 * class that implements <tt>java.util.Map.Entry</tt>. The set is backed
     * by this object map, so changes to this object map are reflected in the
     * set, and vice-versa.
     *
     * <p>If this object map is modified during an iteration over the set,
     * the results of the iteration are undefined.
     *
     * <p>You can remove elements from the set by calling the set's
     * <tt>remove</tt>, <tt>removeAll</tt>, <tt>retainAll</tt>  or
     * <tt>clear</tt> methods.  In addition, you can iterate over the set
     * and call the iterator's <tt>remove</tt> method to remove an element.
     * Any element (key-value pair) that you remove from the set is also
     * removed from this object map.
     *
     * <p>You may not add elements to the set.</p>
     *
     * @return      A set view of the key-value pairs in this object map.</p>
     *
	 * @see	#keySet
	 * @see	#values
	 */
    public Set entrySet() {
	    if (entrySet == null) {
	        entrySet = new AbstractSet() {
                public java.util.Iterator iterator() {
                    return new EntryIterator();
                }

                public boolean contains(Object o) {
                    if (!(o instanceof Map.Entry))
                        return false;
                    Map.Entry entry = (Map.Entry)o;
                    Object value = get(entry.getKey());
                    return ooTreeMap.this.containsKey(entry.getKey()) && valEquals(value, entry.getValue());
                }

		        public boolean remove(Object o) {
                    if (!(o instanceof Map.Entry))
                        return false;
                    Map.Entry entry = (Map.Entry)o;
                    return contains(entry.getKey()) && ooTreeMap.this.remove(entry.getKey()) != null;
                }

                public int size() {
                    return ooTreeMap.this.size();
                }

                public void clear() {
                    ooTreeMap.this.clear();
                }
            }; // End entrySet = ...
        } // End if entrySet is null
	    return entrySet;
    } // End entrySet method

	/**
	 * Finds the first key in this sorted object map. </p>
	 *
	 * @return		The key of the first element of this sorted object
     * map.</p>
	 *
	 * @see #lastKey
	 */
    public Object firstKey()
    {
        Object first = ((ooTreeMapPersistor)getCollectionPersistor()).first();
        if (first == null)
            throw new NoSuchElementException();
        return first;
    }

	/**
	 * Finds the value associated with the specified key in this sorted
	 * object map.  </p>
	 *
	 * @param		<tt><i>key</i></tt>	The key to be looked up.
	 *
	 * <p>Typically, <tt><i>key</i></tt> is a persistent object, namely
	 * the key of interest.  If this sorted object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>key</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		The value in the element with the specified key, or
	 * null if this sorted object map contains no mapping for that key.
	 *
	 * <p>A return value of null does not necessarily indicate that no element
	 * has the specified key. It is possible that this sorted object map explicitly
	 * maps the specified key to null. The
	 * {@link #containsKey <tt>containsKey</tt>} method may be used to
	 * distinguish these two cases.</p>
	 *
	 * @see #put(Object, Object)
	 */
    public Object get(Object key)
    {
       return getCollectionPersistor().get(key);
    }

	/**
	 * Gets a view of the beginning of this sorted object map up to,
	 * but not including, the specified key.
     *
     * <p>The returned sorted map contains all elements of this object map
     * whose keys sort before the specified key,
     * according to this object map's comparator. If you want a view that
     * includes the element with a particular key, specify as your parameter
     * a key that sorts after the desired key.
     *
     * <p>The returned sorted map is backed by this object map, so changes
     * in the returned sorted map are reflected in this object map, and
     * vice-versa.
     *
     * <p>The returned sorted map throws an
     * <tt>IllegalArgumentException</tt> if an attempt is made to
     * insert a new key-value pair whose key is equal to, or sorts after,
     * <tt><i>toKey</i></tt>.</p>
     *
     * @param   <tt><i>toKey</i></tt>   An object specifying the
     * (exclusive) upper limit for keys in the returned map.</p>
     *
     * @return  A view of the specified initial range of this sorted object
     * map. </p>
     *
	 * @see	#subMap(Object, Object)
	 * @see	#tailMap(Object)
	 */
    public SortedMap headMap(Object toKey)
    {
	    return new SubMap(toKey, true);
    }

	/**
	 * Searches forward in this sorted object map, starting at the specified index, for
	 * the first key that is equal to the specified object.
	 *
	 * <p>This method compares the key of each element
	 * with <tt><i>object</i></tt>. Search stops when a matching element is found;
	 * if more than one element matches, this method finds the one closest to the beginning
	 * but at or after the starting index. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object whose index is to be
	 * found.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the key of interest.  If this sorted object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @param		<tt><i>index</i></tt>	The zero-based index at which search should
	 * start.</p>
	 *
	 * @return		The index of the first element in this sorted object map
	 * at or after the index <tt><i>index</i></tt>,
	 * whose key is equal to <tt><i>object</i></tt>. If no such element is found, this method
	 * returns -1.</p>
	 */
    public int indexOf(Object object, int index)
    {
      if (comparator() == null)
        return super.indexOf(object, index);
      else
      {
         ooCollectionIterator itr = keyIterator();
         int i = -1;
         if (itr.goTo(object))
         {
            i = itr.previousIndex() + 1;
            if (i < index)
            {
              itr.goToIndex(index);
              i = -1;
              Object tObj;
              Comparator comp = comparator();
              while ((tObj = itr.next()) != null &&  comp.compare(tObj, object) != 0);
              if (tObj == null)
                i = itr.previousIndex() + 1;
             }
          }
          itr.close();
          return i;
      }
   }

	/**
	 * Initializes a scalable-collection iterator to find all keys in this sorted
	 * object map.  </p>
	 *
	 * @return		A scalable-collection iterator that finds all the persistent objects used as
	 * keys in elements of this sorted object map. The iterator finds the
	 * keys in their sorted order. </p>
	 *
	 * @see	#valueIterator
	 */
    public ooCollectionIterator keyIterator()
    {
        return ooIterator();
    }

	/**
	 * Finds the last key in this sorted object map. </p>
	 *
	 * @return		The key of the last element of this sorted object map.</p>
	 *
	 * @see #firstKey
	 */
    public Object lastKey()
    {
        Object last = ((ooTreeMapPersistor)getCollectionPersistor()).last();
        if (last == null)
            throw new NoSuchElementException();
        return last;
    }

	/**
	 * Gets a set view of the keys in this object map.
	 *
	 * <p>The returned set is backed
     * by this object map, so changes to this object map are reflected in the
     * set, and vice-versa.
     *
     * <p>If this object map is modified during an iteration over the set,
     * the results of the iteration are undefined.
     *
     * <p>You can remove keys from the set by calling the set's
     * <tt>remove</tt>, <tt>removeAll</tt>, <tt>retainAll</tt>  or
     * <tt>clear</tt> methods.  In addition, you can iterate over the set
     * and call the iterator's <tt>remove</tt> method to remove a key.
     * When you remove a key from the set, the corresponding key-value pair
     * is removed from this object map.
     *
     * <p>You may not add elements to the set.</p>
     *
     * @return      A set view of the keys in this object map.</p>
     *
	 * @see	#values
	 * @see	#entrySet
	 */
    public Set keySet()
    {
	    if (keySet == null) {
	        keySet = new AbstractSet() {
		        public java.util.Iterator iterator() {
		            return keyIterator();
		        }
		        public int size() {
		            return ooTreeMap.this.size();
		        }
                public boolean contains(Object o) {
                    return ooTreeMap.this.contains(o);
                }
		        public boolean remove(Object o) {
		            return (ooTreeMap.this.remove(o) != null);
		        }
		        public void clear() {
		            ooTreeMap.this.clear();
		        }
	        }; // End keySet = ...
	    } // End if keySet is null
	    return keySet;
    } // End keySet method

	/**
	 * Adds all elements in the specified collection to this sorted object
	 * map.
	 *
	 * <p>If <tt><i>collection</i></tt> is an object map, its elements are
	 * added to this sorted object map. If this sorted object map currently
	 * has an element with the same
	 * key as an element of <tt><i>collection</i></tt>, the existing element
	 * is replaced by the element of <tt><i>collection</i></tt>.
	 *
	 * <p>If <tt><i>collection</i></tt> is a collection of persistent objects,
	 * each of its elements is added as a key to this sorted object map; the
	 * associated values are null. If this sorted object map currently
	 * has an element whose key is an element of <tt><i>collection</i></tt>,
	 * the value of the existing element is replaced by null. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection
	 * whose elements are to be added to this sorted object
	 * map.</p>
	 *
	 * @return		True if any elements were added; otherwise, false.</p>
	 */
    public boolean ooAddAll(ooCollection collection)
    {
        if (collection == null || collection.isEmpty())
            return false;
        Iterator kItr;
        Iterator vItr;
        if (collection instanceof ooHashMap)
            {
                kItr = ((ooHashMap) collection).keyIterator();
                vItr = ((ooHashMap) collection).valueIterator();
            }
        else if (collection instanceof ooTreeMap)
            {
                kItr = ((ooTreeMap) collection).keyIterator();
                vItr = ((ooTreeMap) collection).valueIterator();
            }
        else
            {
                kItr = collection.ooIterator();
                Object obj;
                while (kItr.hasNext())
                {
                    obj = kItr.next();
                    if (obj instanceof java.util.Map.Entry)
                        put(((java.util.Map.Entry)obj).getKey(), ((java.util.Map.Entry)obj).getValue());
                    else
                        put(obj, null);
                }
                return true;
            }

        while (kItr.hasNext())
            put(kItr.next(), vItr.next());
       return true;
    }

	/**
	 * Removes the element of this sorted object map, if any, with the specified
	 * key. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The key to be removed.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the key of the element to be
	 * removed from this sorted object map.  If this sorted object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the key of the element to be removed. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 *
	 * @see	#remove(Object)
	 */
   public boolean ooRemove(Object object)
   {
        return getCollectionPersistor().remove(object);
   }

	/**
	 * Maps the specified key to the specified value in this sorted object map.
	 *
	 * <p>If this sorted object map already contains an element with the specified
	 * key, this method replaces the value in that element.  Otherwise, this
	 * method adds a new element with the specified key and value. </p>
	 *
	 * @param		<tt><i>key</i></tt>	The key;
	 * must be an instance of a persistence-capable class.
	 * If <tt><i>key</i></tt> is transient, this method makes it
	 * persistent.</p>
	 *
	 * @param		<tt><i>value</i></tt>	The value;
	 * must be an instance of a persistence-capable class
	 * or null. If <tt><i>value</i></tt> is a transient object, this method
	 * makes it persistent.</p>
	 *
	 * @return		The value previously associated with <tt><i>key</i></tt>
	 * in this sorted object map, or null if there was no mapping for
	 * <tt><i>key</i></tt>.
	 *
	 * <p>Note that a null return might indicate that this sorted object
	 * map previously mapped <tt><i>key</i></tt> to null.</p>
	 *
	 * @see #get(Object)
	 * @see #putAll(Map)
	 */
    public Object put(Object key, Object value)
    {
        Object ret = get(key);
        getCollectionPersistor().put(key, value);
        return ret;
    }

	/**
	 * Adds all elements in the specified map to this sorted object map.
	 *
	 * <p>If this sorted object map currently has an element with the same
	 * key as an element of <tt><i>map</i></tt>, the existing element
	 * is replaced by the element of <tt><i>map</i></tt>. </p>
	 *
	 * @param		<tt><i>map</i></tt>	The
	 * map whose elements are to be added to this sorted object map.
	 * Every key
	 * and every value in <tt><i>map</i></tt> must be an instance of a
	 * persistence-capable class. If any key or value is transient, this
	 * method makes it persistent.</p>
	 *
	 * @see #put(Object, Object)
	 * @see #ooAddAll(ooCollection)
	 */
    public void putAll(Map map)
    {
        if (map instanceof ooCollection)
            ooAddAll((ooCollection) map);
        else
            {
                Iterator itr = map.entrySet().iterator();
                java.util.Map.Entry obj;
                 while (itr.hasNext())
                 {
                   obj = (java.util.Map.Entry) itr.next();
                   put(obj.getKey(), obj.getValue());
                 }
            }
    }

	/**
	 * Initializes a scalable-collection iterator to find all values in this sorted
	 * object map. </p>
	 *
	 * @return		A scalable-collection iterator that finds all the persistent objects used as values
	 * in elements of this sorted object map. The iterator finds the
	 * values in the sorted order of their keys. </p>
	 *</p>
	 *
	 * @see	#keyIterator
	 */
    public ooCollectionIterator valueIterator()
    {
        return ((ooTreeMapPersistor)getCollectionPersistor()).valueIterator();
    }

	/**
	 * Gets a collection view of the values in this object map.
	 *
	 * <p>The returned collection is backed
     * by this object map, so changes to this object map are reflected in the
     * collection, and vice-versa.
     *
     * <p>If this object map is modified during an iteration over the
     * collection, the results of the iteration are undefined.
     *
     * <p>You can remove values from the collection by calling the
     * collection's <tt>remove</tt>, <tt>removeAll</tt>, <tt>retainAll</tt>
     * or  <tt>clear</tt> methods.  In addition, you can iterate over the
     * collection and call the iterator's <tt>remove</tt> method to remove a
     * value.  When you remove a value from the collection, the
     * corresponding key-value pair is removed from this object map.
     *
     * <p>You may not add elements to the collection.</p>
     *
     * @return      A collection view of the values in this object map.</p>
     *
	 * @see	#keySet
	 * @see	#entrySet
	 */
    public Collection values() {
	    if (values==null) {
	        values = new AbstractCollection() {
		        public java.util.Iterator iterator() {
		            return valueIterator();
		        }
                public boolean contains(Object o) {
                    return containsValue(o);
                }
                public boolean remove(Object o) {
                    boolean ret = false;
                    ooCollectionIterator itr = valueIterator();
                    if (itr.goTo(o))
                    {
                        itr.remove();
                        ret = true;
                    }
                    itr.close();
                    return ret;
                }
                public int size() {
                    return ooTreeMap.this.size();
                }
            }; // End values = ...
        } // End if values is null
	    return values;
    } // End value method

	/**
	 * Removes the element of this sorted object map, if any, with the specified
	 * key. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The key to be removed.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the key of the element to be
	 * removed from this sorted object map.  If this sorted object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the key of the element to be removed. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		The value in the element that was removed, or null
	 * if there was no mapping for <tt><i>object</i></tt>.
     * A null return can also indicate that this sorted object map previously
	 * mapped the key <tt><i>object</i></tt> to null.
	 */
    public Object remove(Object object)
    {
        Object ret = get(object);
        getCollectionPersistor().remove(object);
        return ret;
    }

	/**
	 * Gets a view of the portion of this sorted object map
	 * whose keys are in the specified range.
	 *
	 * <p>The returned sorted map contains all elements of this object map
     * whose keys are equal to, or sort after, <tt><i>fromKey</i></tt>
     * and sort before <tt><i>toKey</i></tt>,
     * according to this object map's comparator.
     *
     * <p>The returned sorted map is backed by this object map, so changes
     * in the returned sorted map are reflected in this object map, and
     * vice-versa.
     *
     * <p>The returned sorted map throws an
     * <tt>IllegalArgumentException</tt> if an attempt is made to
     * insert a new key-value pair whose key sorts before
     * <tt><i>fromKey</i></tt> or is equal to, or sorts after,
     * <tt><i>toKey</i></tt>.</p>
     *
     * @param   <tt><i>fromKey</i></tt>   An object specifying the
     * (inclusive) lower limit for keys in the returned map.</p>
     *
     * @param   <tt><i>toKey</i></tt>   An object specifying the
     * (exclusive) upper limit for keys in the returned map.</p>
     *
     * @return  A view of the specified range of this sorted object map.</p>
     *
	 * @see	#headMap(Object)
	 * @see	#tailMap(Object)
	 */
    public SortedMap subMap(Object fromKey, Object toKey)
    {
	    return new SubMap(fromKey, toKey);
    }

	/**
	 * Gets a view of the end of this sorted object map, starting with
	 * the specified key.
	 *
	 * <p>The returned sorted map contains all elements of this object map
     * whose keys are equal to, or sort after, <tt><i>fromKey</i></tt>
     * according to this object map's comparator.
     *
     * <p>The returned sorted map is backed by this object map, so changes
     * in the returned sorted map are reflected in this object map, and
     * vice-versa.
     *
     * <p>The returned sorted map throws an
     * <tt>IllegalArgumentException</tt> if an attempt is made to
     * insert a new key-value pair whose key sorts before
     * <tt><i>fromKey</i></tt>.</p>
     *
     * @param   <tt><i>fromKey</i></tt>   An object specifying the
     * (inclusive) lower limit for keys in the returned map.</p>
     *
     * @return  A view of the specified final range of this sorted object
     * map.</p>
     *
	 * @see	#subMap(Object, Object)
	 * @see	#headMap(Object)
	 */
    public SortedMap tailMap(Object fromKey)
    {
	    return new SubMap(fromKey, false);
    }

    // Test two values  for equality.  Differs from o1.equals(o2) only in
    // that it copes with with null o1 properly.
    protected static boolean valEquals(Object o1, Object o2) {
        return (o1==null ? o2==null : o1.equals(o2));
    }

    // Compares two keys using the correct comparison method for this TreeMap.
    protected int compare(Object k1, Object k2) {
        int returnVal = 0;
        if (comparator() == null) {
            returnVal = ((Persistent) k1).getPersistor().compareOoId(((Persistent) k2).getPersistor());
        } else {
            returnVal = comparator().compare(k1, k2);
        }
        return returnVal;
    }

    // Returns the first Entry in the ooTreeMap (according to the ooTreeMap's
    // key-sort function).  Returns null if the ooTreeMap is empty.
    private Entry firstEntry() {
        Object key = firstKey();
	    return key == null ? null : new Entry(key, get(key));
    }

    // Returns the last Entry in the ooTreeMap (according to the ooTreeMap's
    // key-sort function).  Returns null if the ooTreeMap is empty.
    private Entry lastEntry() {
        Object key = lastKey();
	    return key == null ? null : new Entry(key, get(key));
    }
 }
