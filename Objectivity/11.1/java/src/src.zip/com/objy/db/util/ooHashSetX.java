/*
 * @(#)ooHashSetX.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Iterator;
import java.util.Set;

import com.objy.db.ObjectIsDeadException;
import com.objy.db.ObjectNotPersistentException;
import com.objy.pm.ooCollectionIterator;
import com.objy.pm.ooHashBasedCollectionsPersistor;
import com.objy.pm.ooHashSetXPersistor;

/**
 * Persistence-capable class for unordered sets of persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Unordered Sets</h2>
 *
 * <p>An <i>unordered set</i> is a scalable unordered collection
 * of persistent objects with no duplicate elements.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Properties of Scalable Unordered Collections">
 * Properties of Scalable Unordered Collections</a>.
 *
 * <p><h2>Working With an Unordered Set</h2>
 *
 * <P>An unordered set is transient when it is created; you can make it
 * persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created an unordered set, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a Set">
 * Building a Set</a></p>
 *
 * <li>Look up particular elements in the unordered set as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Sets">
 * Individual Lookup in Sets</a></p> 
 *
 * <li>Iterate over the unordered set as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Elements of a List or Set">
 * Finding the Elements of a List or Set</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make an unordered set persistent before you call
 * any methods defined by the <tt>ooHashSetX</tt>, <tt>ooHashBasedCollection</tt>, or <tt>ooCollection</tt>
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of persistent 
 * objects: 
 * <ul>
 * <li><a href="ooTreeSetX.html"><tt>ooTreeSetX</tt></a> represents
 * a <i>sorted</i> collection of persistent objects with no duplicate 
 * elements.</p> 
 *
 * <li><a href="ooTreeListX.html"><tt>ooTreeListX</tt></a> represents an
 * <i>ordered</i> collection of persistent objects that <i>can contain 
 * duplicate elements</i>.</p> 
 * </ul></p>
 * 
 * 
 * The related class <a href="ooCompare.html"><tt>ooCompare</tt></a> is the abstract base class for custom comparators for
 * unordered sets.</p>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr> <td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 *      <td>
 *      <a href="#ooHashSetX()">ooHashSetX()</a><br>
 *      <a href="#ooHashSetX(com.objy.db.util.ooCompare)">ooHashSetX(ooCompare)</a><br>
 *      <a href="#ooHashSetX(int)">ooHashSetX(int)</a><br>
 *      <a href="#ooHashSetX(com.objy.db.util.ooCompare, int)">ooHashSetX(ooCompare, int)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#addAll(java.util.Collection)">addAll(Collection)</a><br>
 *     <a href="#remove(java.lang.Object)">remove(Object)</a><br>
 *     <a href="#removeAll(java.util.Collection)">removeAll(Collection)</a><br>
 *     <a href="#retainAll(java.util.Collection)">retainAll(Collection)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 *     <td>
 *     <a href="#iterator()">iterator()</a><br>
 *     <a href="#get(java.lang.Object)">get(Object)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 *     <td>
 *     <a href="#containsAll(java.util.Collection)">containsAll(Collection)</a><br>
 *     </td></tr>
 * </table>
 *
 */
final public class ooHashSetX extends ooHashBasedCollection implements Set
{
    /**
     * Reserved for internal use.
     */  
    public transient int _pagesPerBucket = 1;
    
    /**
     * Constructs an empty unordered set with a default comparator
     * and the default number of pages per bucket. 
     */
    public ooHashSetX()
    { 
        _pagesPerBucket = 100;
    }

	/**
	 * Constructs an empty unordered set with a default comparator and the specified number 
	 * of pages per bucket. </p>
	 *
	 * @param 	 pagesPerBucket  Maximum number of logical pages 
	 * to allocate for each hash bucket in the unordered set. This integer value must be
	 * less than or equal to
	 * <tt><i>storagePageSize</tt></i> divided by 2.5, where <tt><i>storagePageSize</tt></i> 
	 * is the size of the storage pages 
	 * in the database that will contain the initial hash bucket.
	 * For additional information about bucket size, see
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size and Capacity</a>.
	 * 
	 * 
	 */
	public ooHashSetX(int pagesPerBucket)
    {
        _pagesPerBucket = pagesPerBucket;
    }

	/**
	 * Constructs an empty unordered set with the specified custom comparator and
	 * the default number of pages per bucket.</p>
	 * 
	 * @param 	 compare	<a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Unordered Collections">
	 * Custom comparator</a>
	 * for the new unordered set. 
	 * The comparator must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>. 
	 */
	public ooHashSetX(ooCompare compare)
    {
        _pagesPerBucket = 100;
        _comparator = compare;
    }

	/**
	 * Constructs an empty unordered set with the specified custom comparator and 
	 * the specified number of pages per bucket.</p>
	 * 
	 * @param 	 compare	<a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Unordered Collections">
	 * Custom comparator</a>
	 * for the new unordered set. 
	 * The comparator must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>. </p>
	 *
	 * @param 	 pagesPerBucket  Maximum number of logical pages 
	 * to allocate for each hash bucket in the unordered set. This integer value must be
	 * less than or equal to
	 * <tt><i>storagePageSize</tt></i> divided by 2.5, where <tt><i>storagePageSize</tt></i> 
	 * is the size of the storage pages 
	 * in the database that will contain the initial hash bucket.
	 * For additional information about bucket size, see
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size and Capacity</a>.
	 * 
	 */
	public ooHashSetX(ooCompare compare, int pagesPerBucket)
    {
        _comparator = compare;
        _pagesPerBucket = pagesPerBucket;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    protected ooHashBasedCollectionsPersistor getHashBasedCollectionPersistor() {
        if (getPersistor() == null)
            throw new ObjectNotPersistentException("Attempted persistence operation on transient object");
        if (getPersistor().isDead())
            throw new ObjectIsDeadException("Attempted persistence operation on dead object");
        return (ooHashBasedCollectionsPersistor) getPersistor();
    }

    /**
     * Adds all elements in the specified collection to this unordered
     * set. </p>
     *
     * @param 	 collection  The collection
     * whose elements are to be added to this unordered set. Every element
     * of <tt><i>collection</i></tt> must be an instance of a
     * persistence-capable class. If any element is transient, this
     * method makes it persistent.</p>
     *
     * @return      True if any elements were added; otherwise, false.
     *
     * <p>This method returns false if this unordered set already contains
     * all the elements of <tt><i>collection</i></tt>.
     */
    public boolean addAll(Collection collection)
    {
        Iterator itr;
        if (collection instanceof ooCollection)
            itr = ((ooCollection)collection).keyIterator();
        else
            itr = collection.iterator();
        boolean mod = false;

        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

    /**
     * Tests whether this unordered set contains all elements in the
     * specified collection. </p>
     *
     * @param 	 collection  The collection whose elements are
     * to be tested for containment in this unordered set.</p>
     *
     * @return      True if this unordered set contains elements equal to
     * each element of <tt><i>collection</i></tt>; otherwise, false.
     */
    public boolean containsAll(Collection collection) {
        if (comparator() == null)
            return getHashBasedCollectionPersistor().containsAll((ooCollection) collection);
        else
        {
            Iterator itr;
            if (collection instanceof ooCollection)
                itr = ((ooCollection)collection).keyIterator();
            else
                itr = collection.iterator();
            while (itr.hasNext())
                if (!contains(itr.next()))
                    return false;
            return true;
        }
    }

    /**
     * Finds the element of this unordered set that is equal to the
     * specified lookup data, as determined by the comparator for this
     * unordered  set.
     *
     * <p><b>Note: </b>This unordered set must have a custom
     * comparator that can identify an element based on class-specific
     * data.  See
     * <a href="../../../../../guide/jgdCollections.html#Custom Comparator Class for Unordered Collections">
     * Custom Comparator Class for Unordered Collections</a>.
     * </p>
     *
     * @param 	 lookupValue The object that identifies
     * the desired element.</p>
     *
     * @return      The element found equal to <tt><i>lookupValue</i></tt>, or null
     * if this unordered set does not contain such an element.
     */
    public Object get(Object lookupValue)
    {
        return ((ooHashSetXPersistor)getHashBasedCollectionPersistor()).get(lookupValue);
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this
     * unordered set. </p>
     *
     * @return      A scalable-collection iterator for finding the elements of this
     * unordered set. The iterator finds the
     * elements in an undefined order.
     *
     * <p>If you want to call any methods that are specific to Objectivity
     * for Java scalable-collection iterators, you should cast the returned iterator
     * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
     */
    public Iterator iterator()
    {
        return getHashBasedCollectionPersistor().iterator();
    }

    /**
     * Removes the specified object from this unordered set. </p>
     *
     * @param 	 object  The object to be removed.</p>
     *
     * @return      True if an element was removed; otherwise, false.</p>
     *
     * @see #removeAll(Collection)
     * @see #retainAll(Collection)
     */
    public boolean remove(Object object) {
        return getHashBasedCollectionPersistor().remove(object);
    }

    /**
     * Removes all elements of the specified collection from this
     * unordered set. </p>
     *
     * @param 	 collection  The collection whose elements are to be
     * removed from this unordered set.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #remove(Object)
     * @see #retainAll(Collection)
     */
    public boolean removeAll(Collection collection)
    {
        if (collection == this)
        {
            if (isEmpty())
            return false;
            else
            return getHashBasedCollectionPersistor().removeAll((ooCollection) collection);
            }

        boolean changed = false;
        Iterator itr;

        if (collection instanceof ooCollection)
            itr = ((ooCollection)collection).keyIterator();
        else
            itr = collection.iterator();
        while (itr.hasNext())
        {
            if (ooRemove(itr.next()))
                changed = true;
        }
        return changed;
    }

    /**
     * Retains all elements of this unordered set that are also in the
     * specified collection, removing all other elements. </p>
     *
     * @param 	 collection  The collection whose elements
     * are to be retained in this unordered set.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #remove(Object)
     * @see #removeAll(Collection)
     */
    public boolean retainAll(Collection collection) 
    {
        if (collection instanceof ooCollection && ((ooCollection) collection).comparator() == null)
            return getHashBasedCollectionPersistor().retainAll((ooCollection) collection);
        else
        {
            boolean changed = false;
            Iterator itr = iterator();
            while (itr.hasNext())
                if (!collection.contains(itr.next()))
                {
                    itr.remove();
                    changed = true;
                }
            return changed;
        }
    }
}

