package com.objy.query.expression;

abstract class AbstractExpression
{
    long mId;
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    public synchronized long getId()
    {
        return mId;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    protected synchronized void setId(long id) 
    {
        mId = id;
    }
    
    /**
     * An utility method that checks the validity of the id before setting it. 
     * @param id
     */
    void setIdAfterNullCheck(long id)
    {
        if (id != 0)
        {
            setId(id);
        }
        else
        {
            throw new ExpressionException("Cannot set the id for the expression because it is invalid. id = " + id);
        }
    }
    
    /**
     * An utility method that throws exception if the id is 0, indicating an invalid expression.
     */
    void throwExceptionIfInvalidOrClosed(long id)
    {
        if (id != 0) return;
        throw new ExpressionException("The expression is invalid");
    }
}
