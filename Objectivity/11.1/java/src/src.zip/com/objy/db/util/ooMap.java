/*
 * @(#)ooMap.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util ;

import com.objy.db.ObjyRuntimeException ;

import com.objy.db.app.Connection;
import com.objy.db.app.ooObj;
import com.objy.db.app.Iterator ;
import com.objy.db.app.Session ;

import com.objy.db.iapp.PooMap ;

import com.objy.pm.ooMapInitialValues ;
import com.objy.pm.Access ;

/**
 * Persistence-capable class for unordered name maps.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Name Maps</h2>
 *
 * <p>A <i>name map</i> is a nonscalable collection of key-value pairs; each 
 * key is a string and each value is a persistent object.
 * No two elements of the name map may have the same key.
 * As the name implies,
 * each element of a name map is a mapping from a name to an object with that
 * name. The word <i>name</i> is used as a synonym for <i>key</i> because
 * an object's key is often a name; however, a key can
 * be any valid Java string that identifies the object.  Keys can be strings
 * of any length.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Properties of Nonscalable Unordered Collections">
 * Properties of Nonscalable Unordered Collections</a>.
 *
 * <p>A name map provides an efficient way to assign identifying keys to 
 * persistent objects and to look up objects by their keys. Objectivity/DB 
 * uses name maps to implement its dictionaries of named roots and 
 * scope-named objects.  In addition, you 
 * can instantiate this class to create your own
 * application-specific dictionary for objects.
 *
 * <p>By default,
 * a name map maintains referential integrity of its elements. See 
 * <a href="../../../../../guide/jgdCollections.html#Referential Integrity of a Collection">
 * Referential Integrity of a Collection</a>.
 *
 *
 * <p><h2>Working With a Name Map</h2>
 *
 * <P>A name map is transient when it is created; you can make it 
 * persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>If you abort the transaction in which you make a name map persistent, 
 * it reverts to the transient state.  This behavior is standard for objects 
 * of all persistence-capable classes. Note, however, that any 
 * <a href="../../../../../guide/jgdCollections.html#growthCharacteristics">
 * growth characteristics</a> that you set when you 
 * created the name map will be <i>reset to their default values</i> when the 
 * name map is made transient. For this reason, if you create a name map with 
 * non-default values for its growth characteristics, you should commit or 
 * checkpoint the transaction as soon as possible after you make the new name 
 * map persistent.
 *
 * <p>After you have created an unordered object map, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a Name Map">
 * Building a Name Map</a></p>
 *
 * <li>Look up particular objects in the name map as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Name Maps">
 * Individual Lookup in Name Maps</a></p>
 *
 * <li>Iterate over the name map as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Keys and Values of a Name Map">
 * Finding the Keys and Values of a Name Map</a>
 *</ul>
 *
 * <a name="runtimeStats"></a>
 * <p>Name maps accumulate statistical information about runtime usage.  You
 * can print a summary of this information or clear the statistical parameters,
 * resetting them to zero.  The statistical parameters record:
 * <ul><li>The number of elements added.
 * <li>The number of elements deleted.
 * <li>The number of times the hash table was rehashed.
 * </ul>
 *
 * <p>You can call any of the methods in this class on a persistent name map. 
 * Adding a transient object to a persistent name map makes the object persistent.
 * 
 * <p>If you leave a name map transient, you can call its methods except as noted in the individual method descriptions.
 * The name map and any transient elements remain transient until
 * you explicitly make the name map persistent. 
 *
 * <p><a name="disableTransient"></a>
 * <b>Note: </b>For backward compatibility, you can disallow the use of transient name maps.
 * To do so, you call the connection's {@link Connection#setPersistencePolicy <tt>setPersistencePolicy</tt>} method 
 * with the value <a href="../app/oo.html#PersistencePolicy"><tt>oo.PreRelease11Behavior</tt></a>,
 * and use deprecated methods to disallow transient relationships. 
 * 
 * 
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of key-value pairs.
 *
 * <ul>
 * <li> <a href="ooHashMapX.html"><tt>ooHashMapX</tt></a> represents an
 * <i>unordered object map</i>, that is, a collection of key-value pairs in 
 * which both the key and the value are
 * persistent objects. </p>
 *
 * <li> <a href="ooTreeMapX.html"><tt>ooTreeMapX</tt></a> represents
 * a <i>sorted object map</i>. </p>
 * </ul>
 *
 * <p>Both object map classes represent scalable collections; unlike name
 * maps, they can increase in size with minimal performance degradations.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 	<td>
 *     <a href="#ooMap()">ooMap()</a><br>
 *     <a href="#ooMap(long, long, long)">ooMap(long, long, long)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 * 	<td>
 *     <a href="#add(java.lang.Object, java.lang.String)">add(Object, String)</a><br>
 *     <a href="#forceAdd(java.lang.Object, java.lang.String)">forceAdd(Object, String)</a><br>
 *     <a href="#remove(java.lang.String)">remove(String)</a><br>
 *     <a href="#replace(java.lang.Object, java.lang.String)">replace(Object, String)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Objects</b></td>
 * 	<td>
 *     <a href="#lookup(java.lang.String)">lookup(String)</a><br>
 *     <a href="#lookup(java.lang.String, int)">lookup(String, int)</a><br>
 *     <a href="#elements()">elements()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 * 	<td>
 *     <a href="#keys()">keys()</a><br>
 *     <a href="#getMaxAverageDensity()">getMaxAverageDensity()</a><br>
 *     <a href="#getBinCount()">getBinCount()</a><br>
 *     <a href="#getElementCount()">getElementCount()</a><br>
 *     <a href="#getGrowthFactor()">getGrowthFactor()</a><br>
 *     <a href="#printStatistics()">printStatistics()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	<td>
 *     <a href="#isMember(java.lang.String)">isMember(String)</a><br>
 *     <a href="#isIntegrityMaintained()">isIntegrityMaintained()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Runtime&nbsp;Statistics</b></td>
 * 	<td>
 *     <a href="#clearParameters()">clearParameters()</a><br>
 *     <a href="#printStatistics()">printStatistics()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Maintaining&nbsp;the&nbsp;Hash&nbsp;Table</b></td>
 * 	<td>
 *     <a href="#rehash(long)">rehash(long)</a><br>
 *     <a href="#isIntegrityMaintained()">isIntegrityMaintained()</a><br>
 *     <a href="#setIntegrityMaintained(boolean)">setIntegrityMaintained(boolean)</a><br>
 * 	</td></tr>
 * </table>
 */
final public class   ooMap
             extends ooObj
{
	/**
	 * Reserved for internal use.</p>
	 */
    public ooMapInitialValues initialValues ; // only needed for transient->persistent creation
    public PooMap transientManager ;

	/**
	 * Constructs a name map.
	 *
	 * <p>The new name map's hash table has 11 bins, a
     * <a href="../../../../../guide/jgdCollections.html#maxAveDensity">
	 * maximum average density</A> of 5 elements
	 * per bin, and a 
     * <a href="../../../../../guide/jgdCollections.html#growthFactor">
	 * growth factor</a> of 100%.
	 * </p>
	 *
	 */
    public ooMap() {
	// do this and the one below via Access
	if (Connection.current().isPersistOnReachability() || Session.getCurrent().getFormTransientRelationships())
	    transientManager = Access.new_TransientMapPersistor() ;
    }

	/**
	 * Constructs a name map with the
	 * specified number of bins, maximum average density, and growth factor.
	 *
	 * <p><b>Note: </b>If you create a name map with non-default 
     * values for number of bins, maximum average density, or growth factor, 
     * you should commit or checkpoint the transaction as soon as you make the
     * name map persistent.  If the transaction is aborted, the name map
     * will revert to the transient state and its growth characteristics will
	 * be reset to the default values (11 bins, 5 elements per bin, and a 
     * 100% growth factor).</p>
	 *
	 * @param 	 binCount	The initial number of bins in the
	 * new name map's hash table. For optimal performance,
     * the number of bins should be a prime number.</p>
	 *
	 * @param 	 maxAverageDensity	The
     * <a href="../../../../../guide/jgdCollections.html#maxAveDensity">
	 * maximum average density</A>
 	 * allowed before the new name map's hash table must be resized. </p>
	 *
	 * @param 	 growthFactor	The
     * <a href="../../../../../guide/jgdCollections.html#growthFactor">
	 * growth factor</a>
	 * for the new name map's hash table, expressed as a percentage (for example, use 80
	 * for a growth factor of 80%).
	 */
    public ooMap(long binCount, long maxAverageDensity, long growthFactor) {
        initialValues = new ooMapInitialValues(
            binCount,
            maxAverageDensity,
            growthFactor) ;
	if (Connection.current().isPersistOnReachability() || Session.getCurrent().getFormTransientRelationships())
	    transientManager = Access.new_TransientMapPersistor(binCount, maxAverageDensity, growthFactor) ;
    }

	/**
	 * Adds an element with a unique key to this name map.
	 *
	 * Before you call this method, you can call
	 * <a href="#isMember(java.lang.String)"><tt>isMember</tt></a> to test whether <tt><i>name</i></tt>
	 * is already a key.
	 * </p>
	 *
	 * @param 	 object	The object to be added with the
	 * specified key, or null to make <tt><i>name</i></tt> the key for
	 * a null object reference. If an object is specified, it must
	 * be an instance of a persistence-capable class. 
	 * If this name map is persistent and the specified object is transient,
	 * this method makes the object persistent.</p>
	 *
	 * @param 	 name	The key for the new element.</p>
	 *
	 * @exception   com.objy.db.ObjyRuntimeException    If this name map already contains
	 * an element with the key <tt><i>name</i></tt>.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 * 
	 *
	 * @see	#forceAdd(Object, String)
	 * @see #remove(String)
	 * @see #replace(Object, String)
	 */
	public void add(Object object, String name)
        { ooMapPersistor().add(object, name) ; }

	/**
	 * Adds an element to this name map even if its key is not unique.
	 *
	 * <p>This method is more efficient than {@link #add <tt>add</tt>},
	 * because it doesn't check that <tt><i>name</i></tt> is a unique key. If this
	 * name map already contains an element with that key, the key will be ambiguous.
	 * In that case, it is undefined which object will be returned if you
	 * call <a href="#lookup(java.lang.String)"><tt>lookup</tt></a> with <tt><i>name</i></tt> as the key.
	 *
	 * <p><b>Note:</b> You should call this method only if you are sure that
	 * this name map doesn't contain an element with the specified key.
	 * </p>
	 *
	 * @param 	 object	The object to be added with the
	 * specified key, or null to make <tt><i>name</i></tt> the key for
	 * a null object reference. If an object is specified, it must
	 * be an instance of a persistence-capable class. 
	 * If this name map is persistent and the specified object is transient,
	 * this method makes the object persistent.</p>
	 *
	 * @param 	 name	The key for the new element.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this name map
	 * is transient.</p>
	 *
 	 * @see #replace(Object, String)
	 */
    public void forceAdd(Object object, String name)
        { ooMapPersistor().forceAdd(object, name) ; }

	/**
	 * Replaces the element with the specified key in this name map.
	 *
	 * <p>If this name map contains an element with the key <tt><i>name</i></tt>,
	 * this method replaces that element's object with <tt>object</tt>.
	 * Otherwise, this method adds a new element whose key is <tt><i>name</i></tt> 
	 * and whose value is <tt>object</tt>.
	 * </p>
	 *
	 * @param 	 object	The new object for the element with
	 * the specified key, or null to make <tt><i>name</i></tt> the key for
	 * a null object reference.  If an object is specified, it must
	 * be an instance of a persistence-capable class. 
	 * If this name map is persistent and the specified object is transient,
	 * this method makes the object persistent.</p>
	 *
	 * @param 	 name	The key of the element to be replaced.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this name map
	 * is transient, 
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 * @see #remove(String)
	 */
	public void replace(Object object, String name)
        { ooMapPersistor().replace(object, name) ; }

	/**
	 * Removes the element with the specified key from this name map.
	 *
	 * <p>If <a href="#forceAdd(java.lang.Object, java.lang.String)"><tt>forceAdd</tt></a> was used to add more than one
	 * element with the key <tt><i>name</i></tt>, this method deletes only the first such
	 * element it finds and gives no indication that there are other elements
	 * with the same key.
	 * </p>
	 *
	 * @param 	 name	The key of the element to be removed.
	 * This method throws an exception if this
	 * name map does not contain an element with the key <tt><i>name</i></tt>.
	 * Before you call this method, you can call
	 * <a href="#isMember(java.lang.String)"><tt>isMember</tt></a> to test whether <tt><i>name</i></tt>
	 * is a key.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 * @see #add(Object, String)
	 * @see #replace(Object, String)
	 */
	public void remove(String name)
        { ooMapPersistor().remove(name) ; }

	/**
	 * Resizes this name map's hash table.
	 *
	 * <p>Objectivity/DB automatically increases the size of the hash table as
	 * necessary. The only time you should need to call this method is when
	 * the number of bins is very large and the total number of elements is
	 * relatively small. This situation can occur when many elements are
	 * deleted after the hash table has grown to its peak size.
	 * </p>
	 *
	 * @param 	 binCount	The new number of bins for
	 * the hash table.  If this parameter is 0, the default number of bins
	 * (11) is used.  For optimal performance, the number of bins should
	 * be a prime number.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this name map
	 * is transient.
	 *
	 */
    public void rehash(long binCount)
        { ooMapPersistor().rehash(binCount) ; }

	/**
	 * Resets the <a href="#runtimeStats">statistical parameters</a> for this
	 * name map to zero.
	 * </p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 * @see #printStatistics
	 */
	public void clearParameters()
        { ooMapPersistor().clearParameters() ; }

	/**
	 * Overrides the inherited method; disallows copying for name maps.
	 *
	 * <p>This method always throws an exception.  If you want to copy this name map,
	 * you should create a new name map and add the elements of this name map to the new name map.
	 * </p>
	 *
	 * @param 	 near	Ignore
	 * @return  Ignore
	 */
    public Object copy(Object near)
        { throw new ObjyRuntimeException("copy(Object) not valid for ooMap");}

	/**
	 * Tests whether this name map has an element with the specified key.
	 * </p>
	 *
	 * @param 	 name	The key to be tested.</p>
	 *
	 * @return		True if this name map has an element with the key
	 * <tt><i>name</i></tt>; otherwise, false.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public boolean isMember(String name)
        { return ooMapPersistor().isMember(name) ; }

	/**
	 * Finds the object in this name map with the specified key.
	 * </p>
	 *
	 * @param 	 name	The key to be looked up.
	 * This method throws an <tt>ObjyRuntimeException</tt>  if this
	 * name map does not contain an element with the key <tt><i>name</i></tt>.
	 * Before you call this method, you can call
	 * <a href="#isMember(java.lang.String)"><tt>isMember</tt></a> to test whether <tt><i>name</i></tt>
	 * is a key.</p>
	 *
	 * @return		The object in this name map with the specified key; the returned object is locked for read.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public Object lookup(String name)
        { return ooMapPersistor().lookup(name) ; }

	/**
	 * Finds the object in this name map with the specified key, locking the
	 * found object as specified.
	 * </p>
	 *
	 * @param 	 name	The key to be looked up.
	 * This method throws an <tt>ObjyRuntimeException</tt>  if this
	 * name map does not contain an element with the key <tt><i>name</i></tt>.
	 * Before you call this method, you can call
	 * <a href="#isMember(java.lang.String)"><tt>isMember</tt></a> to test whether <tt><i>name</i></tt>
	 * is a key.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the found object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
	 *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
	 * @return		The object in this name map with the specified key; the returned object
	 * is locked as specified by <tt><i>lockMode</i></tt>.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 */
	public Object lookup(String name, int lockMode)
        { return ooMapPersistor().lookup(name, lockMode) ; }

	/**
	 * Gets the maximum average density of this name map's hash table.
	 * </p>
	 *
	 * @return		The 
	 * <a href="../../../../../guide/jgdCollections.html#maxAveDensity">
	 * maximum average density</A>
	 * allowed before this name map must be resized.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public long getMaxAverageDensity()
        { return ooMapPersistor().getMaxAverageDensity() ; }

	/**
	 * Gets number of bins in this name map's hash table.
	 * </p>
	 * 
	 * <p>This method is meaningful only if this name map is persistent.</p>
	 *
	 * @return		The number of bins currently in this name map's hash table.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public long getBinCount()
        { return ooMapPersistor().getBinCount() ; }

	/**
	 * Gets the number of elements in this name map.
	 * </p>
	 *
	 * @return		The number of elements currently in this name map.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public long getElementCount()
        { return ooMapPersistor().getElementCount() ; }

	/**
	 * Gets the growth factor of this name map's hash table.
	 * </p>
	 * 
	 * <p>This method is meaningful only if this name map is persistent.</p>
	 *
	 * @return		The 
	 * <a href="../../../../../guide/jgdCollections.html#growthFactor">
	 * growth factor</a>, expressed as a percentage (for example, a
	 * return value of 100 indicates a growth factor of 100%).</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public long getGrowthFactor()
        { return ooMapPersistor().getGrowthFactor() ; }

	/**
	 * Tests whether Objectivity/DB automatically maintains
	 * the referential integrity of this name map.
	 *
	 * <p>By default, Objectivity/DB maintains the
     * <a href="../../../../../guide/jgdCollections.html#Referential Integrity of a Collection">
	 * referential integrity</a> of name maps.  You
	 * can disable the automatic maintenance of referential integrity for a
	 * particular name map by calling its
	 * <a href="#setIntegrityMaintained(boolean)"><tt>setIntegrityMaintained</tt></a> method.
	 * </p>
	 *
	 * @return		True if Objectivity/DB maintains the
	 * referential integrity of this name map;
	 * otherwise, false.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException    If this name map
	 * is transient.
	 *
	 */
    public boolean isIntegrityMaintained()
        { return ooMapPersistor().isIntegrityMaintained() ; }

	/**
	 * Enables or disables maintenance of referential integrity for this
	 * name map.
	 *
	 * <p>By default, Objectivity/DB maintains the
     * <a href="../../../../../guide/jgdCollections.html#Referential Integrity of a Collection">
	 * referential integrity</a> of name maps.  You
	 * may disable referential integrity to reduce the overhead of adding and
	 * deleting elements.  However, if you disable referential integrity, you
	 * are responsible for deleting elements from the name map when the
	 * corresponding objects are deleted from the federated database.
	 *
	 * <p> If you call this method, you must call it before any elements are
	 * added to this name map.
	 *
	 * <p><b>Warning:</b> Do not disable referential integrity unless you are
	 * fully aware of the consequences.
	 * </p>
	 *
	 * @param 	 maintain	True to maintain referential integrity
	 * and false to disable maintenance of referential integrity.</p>
	 *
 	 * @exception   com.objy.db.ObjectNotPersistentException    If this name map
	 * is transient.</p>
	 *
	 * @see #isIntegrityMaintained
	 */
    public void setIntegrityMaintained(boolean maintain)
        { ooMapPersistor().setIntegrityMaintained(maintain) ; }

	/**
	 * Initializes an object iterator to get all the keys of this
	 * name map.
	 *
	 * <p>You must not modify the map during an iteration by adding
	 * or deleting name map elements.
	 * </p>
	 *
	 * @return		An object iterator that gets all the strings that are 
	 * used as names in this name map.</p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 * @see #elements
	 */
	public Iterator keys()
        { return ooMapPersistor().keys() ; }

	/**
	 * Initializes an object iterator to find all the values in this
	 * name map.
	 *
	 * <p>You must not modify the map during an iteration by adding
	 * or deleting name map elements.
	 * </p>
	 *
	 * @return		An object iterator that finds all the persistent objects 
	 * that are named in this name map. </p>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 * @see	#keys
	 */
	public Iterator elements()
        { return ooMapPersistor().elements() ; }

	/**
	 * Prints runtime statistics for this name map to the standard output stream (<tt>System.out</tt>).
	 *
	 * <p>This method prints the <a href="#runtimeStats">runtime statistics</a>
	 * accumulated since this name map was created or since its
	 * <a href="#clearParameters()"><tt>clearParameters</tt></a> method was 
	 * last called.  It also prints this name map's 
	 * <a href="../../../../../guide/jgdCollections.html#growthCharacteristics">
	 * growth characteristics</a>
	 * and indicates whether Objectivity/DB automatically maintains the 
	 * <a href="../../../../../guide/jgdCollections.html#Referential Integrity of a Collection">
	 * referential integrity</a> of this name map.
	 *
	 * <p>The output identifies this name map by its object identifier, and gives the current
	 * date and time.  This method produces output similar to:
	 * <pre>
	 *     *********************************************
	 *     Run statistics of ooMap #2-3-4-10  (Wed Mar 04 14:56:30 1998)
	 *
	 *     ** Number of elements added            =>  10
	 *     ** Number of elements removed          =>  0
	 *     ** Number of rehashes                  =>  0
	 *     ** Current state:
	 *             Number of bins                 =>  11
	 *             Number of elements             =>  10
	 *             Maximum average density        =>  5
	 *             Percent growth                 =>  100
	 *             Average length per bin         =>  0.909091
	 *             Maximum length                 =>  3
	 *             Standard deviation of length   =>  0.899954
	 *             Maintain referential integrity =>  Yes
	 *     ***********************************************
	 * </pre>
	 *
	 * @exception   com.objy.db.ObjectNotPersistentException  If this name map is transient
	 * and you have <a href="#disableTransient">disallowed transient relationships</a> for backward compatibility with pre-Release&nbsp;11 behavior.</p>
	 *
	 */
	public void printStatistics()
        { ooMapPersistor().printStatistics() ; }
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized PooMap ooMapPersistor() {
	if (transientManager == null)
	    return (PooMap)persistor() ;
	else
	    return (PooMap)transientManager ;
    }
	/**
	 * Reserved for internal use; you should not call this method.
	 */
	public void nullTransientManager()
        { transientManager = null ; }
}
