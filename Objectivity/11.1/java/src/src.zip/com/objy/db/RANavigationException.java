package com.objy.db;

public class RANavigationException extends ObjyRuntimeException
{
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public RANavigationException()
        { super() ; }

    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public RANavigationException(String msg)
        { super(msg) ; }
}
