package com.objy.query.expression;
/**
 * Implements a utility as a PQL Expression visitor that prints the elements of the expression node. 
 */
public class PQLExpressionVisitor extends ExpressionVisitor 
{

    // Visit operation on attribute value expression
    @Override
    public void visitAttributeValue(AttributeValueExpression attributeValue) {
    	System.out.println("Attribute name: "+attributeValue.getAttributeName()+ ", result type: "+ 
    			attributeValue.getResultSpec().getDataTypeName());
    }

    //@Override
    //public void visitLiteralValue(LiteralValueExpression literalValue) {
    //	if (literalValue.getVariableName() != null)
    //	    System.out.println("Variable name: "+literalValue.getVariableName());
    //}
    
    // Visit operation on operator expression. If not override, returns true.
    @Override
    public boolean visitOperator(OperatorExpression op) {
    	System.out.println("Operator: "+op.getTokenName());
        return true;
    }

    // Visit operation on boolean literal value expression.
    @Override
    public void visitBoolLiteralValue
       (BoolLiteralValueExpression booleanLiteralValue) {
    	System.out.println("Boolean literal value: "+booleanLiteralValue.getValue());
    	//System.out.println("Boolean literal value PQL representation: "+booleanLiteralValue.getPQLRepresentation());
    }

    // Visit operation on string literal value expression.
    @Override
    public void visitStringLiteralValue
       (StringLiteralValueExpression stringLiteralValue) {
    	System.out.println("String literal value: "+stringLiteralValue.getValue());
    	//System.out.println("String literal value PQL representation: "+stringLiteralValue.getPQLRepresentation());
    }

    // Visit operation on int literal value expression.
    @Override
    public void visitIntLiteralValue
       (IntLiteralValueExpression intLiteralValue) {
    	System.out.println("Int literal value: "+intLiteralValue.getValue());
    	//System.out.println("Int literal value PQL representation: "+intLiteralValue.getPQLRepresentation());
    }

    // Visit operation on unsigned int literal value expression.
    @Override
    public void visitUIntLiteralValue
       (UIntLiteralValueExpression uintLiteralValue) {
    	System.out.println("UInt literal value: "+uintLiteralValue.getValue());
    	//System.out.println("UInt literal value PQL representation: "+uintLiteralValue.getPQLRepresentation());
    }

    // Visit operation on float literal value expression.
    @Override
    public void visitFloatLiteralValue
       (FloatLiteralValueExpression floatLiteralValue) {
    	System.out.println("Float literal value: "+floatLiteralValue.toString());
    	//System.out.println("Float literal value PQL representation: "+floatLiteralValue.getPQLRepresentation());
    }

    // Visit operation on date literal value expression.
    @Override
    public void visitDateLiteralValue
       (DateLiteralValueExpression dateLiteralValue) {
    	System.out.println("Date literal value: "+dateLiteralValue.toString());
    	System.out.println("Date literal value PQL representation: "+dateLiteralValue.getPQLRepresentation());
    }

    // Visit operation on time literal value expression.
    @Override
    public void visitTimeLiteralValue
       (TimeLiteralValueExpression timeLiteralValue) {
    	System.out.println("Time literal value: "+timeLiteralValue.toString());
    	System.out.println("Time literal value PQL representation: "+timeLiteralValue.getPQLRepresentation());
    }

    // Visit operation on datetime literal value expression.
    @Override
    public void visitDateTimeLiteralValue
       (DateTimeLiteralValueExpression dateTimeLiteralValue) {
    	System.out.println("DateTime literal value: "+dateTimeLiteralValue.toString());
    	System.out.println("DateTime literal value PQL representation: "+dateTimeLiteralValue.getPQLRepresentation());
    }

    // Visit operation on interval literal value expression.
    @Override
    public void visitIntervalLiteralValue
       (IntervalLiteralValueExpression intervalLiteralValue) {
    	System.out.println("Interval literal value: "+intervalLiteralValue.toString());
    	System.out.println("Interval literal value PQL representation: "+intervalLiteralValue.getPQLRepresentation());
    }

    // Visit operation on object literal value expression.
    @Override
    public void visitObjectLiteralValue
       (ObjectLiteralValueExpression objectLiteralValue) {
    	//System.out.println("Object literal value: "+objectLiteralValue.toString());
    	System.out.println("Object literal value PQL representation: "+objectLiteralValue.getPQLRepresentation());
    }
    
    // Visit operation on OID literal value expression.
    @Override
    public void visitOidLiteralValue
       (OidLiteralValueExpression oidLiteralValue) {
    	System.out.println("OID literal value: "+oidLiteralValue.getValue());
    	System.out.println("OID literal value PQL representation: "+oidLiteralValue.getPQLRepresentation());
    }
    
    // Visit operation on ordered list literal value expression.
    @Override
    public void visitOrderedListLiteralValue
       (OrderedListLiteralValueExpression orderedListLiteralValue) {
    	System.out.println("Ordered list literal value PQL representation: "+orderedListLiteralValue.toString());
    	//System.out.println("Ordered list literal value PQL representation: "+orderedListLiteralValue.getPQLRepresentation());
    }

    // Visit operation on class type literal value expression.
    @Override
    public void visitClassTypeLiteralValue
       (ClassTypeLiteralValueExpression classTypeLiteralValue) {
    	System.out.println("Class type literal value: "+classTypeLiteralValue.getValue());
    	//System.out.println("Class type literal value PQL representation: "+classTypeLiteralValue.getPQLRepresentation());
    }


}
