/*
 * @(#)XAConnection.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.ejb ;

import javax.transaction.xa.XAResource ;
import javax.sql.ConnectionEventListener ;

import java.sql.Connection ;
import java.sql.SQLException ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.app.Database ;
import com.objy.db.app.Session ;
import com.objy.db.app.oo ;

/**
 * Reserved for internal use.
 */
@Deprecated
final public class XAConnection implements javax.sql.XAConnection {
    
    // holds the Session
    private Session session = null ;  // Objy session
    private UserConnection userconnection = null ;
    private XADataSource datasource = null ;   // use setter only
    private javax.transaction.Transaction enlistedTx = null ;

    public void setDataSource(XADataSource ds) {
        //if (ds == null) info("<< Objectivity >> Setting " + this + " datasource to NULL...") ;
        datasource = ds ;
    }
    public XADataSource getDataSource() {
        return datasource ;
    }

    public XAConnection(XADataSource _datasource, int _mode) {
        debugLevel3("<< Objectivity >> CALLING " + this + " CONSTRUCTOR  ") ;
        setDataSource(_datasource) ;
        session = new Session() ;    
        session.setThreadPolicy(oo.THREAD_POLICY_UNRESTRICTED) ;
        session.setOpenMode(_mode) ; // ????
    }
    
    public XAResource getXAResource() {  // the only XAConnection method implemented
        if (session == null) throw new ObjyRuntimeException("This XAConnection has been closed().") ;
        session.join() ; // session joins the current thread
        XATransaction temp = session.getXAResource() ;
        info("<< Objectivity >> CALLING " + this + ".getXAResource(): returning " + temp) ;
        return temp ;
    }

    // Close the physical connection.  This will also close the
    // associated DatabaseConnection.
    synchronized void disconnectFromUserConnection() {
        // No more UserConnection, but XAConnection may still be active
        userconnection = null ;
        if (datasource == null) return ;
        info("<< Objectivity >> CALLING " + this + ".disconnectFromUserConnection() <<<") ;
        boolean connectionIsAvailable = datasource.disconnectConnection(this) ;  // delist xaresource if Transaction is done...
        //if (connectionIsAvailable)
        //    datasource = null ;
    }
   
    // Close the physical connection.  This will also close the
    // associated DatabaseConnection.
    synchronized void releaseConnection() {  // XAConnection can be made available again...
        // kills session and xaresource
        //if (datasource == null) throw new ObjyRuntimeException("This XAConnection is already closed.") ;
        if (datasource == null) {
            //info("<< Objectivity >> " + this + ".releaseConnection() datasource is NULL...") ;
            return ;
        }
        info("<< Objectivity >> CALLING " + this + ".releaseConnection() <<<") ;
        datasource.releaseConnection(this) ;  // delists if necessary and puts back into ConnectionPool
        setDataSource(null) ;
        userconnection = null ;
    }
   
    public synchronized void close() {  // ??? What does this mean???
        // kills session and xaresource
        info("<< Objectivity >> CALLING " + this + ".close() <<<") ;
        if (datasource == null) return ;
        datasource.closeConnection(this) ;  // delist and nuke
        setDataSource(null) ;
        userconnection = null ;
    }

    public synchronized void finalize() {
        // kills session and xaresource
        if (datasource == null) return ;
        info("<< Objectivity >> CALLING " + this + ".finalize() <<<") ;
        datasource.closeConnection(this) ;  // delist and nuke
        setDataSource(null) ;
        userconnection = null ;
    }
    
    public synchronized void setEnlistedTx(javax.transaction.Transaction tx) {
        enlistedTx = tx ;
    }
    
    public synchronized javax.transaction.Transaction getEnlistedTx() {
        return enlistedTx ;
    }
    public synchronized void delistMyself() {
        if (getDataSource() != null) {
            getDataSource().delistMe(this) ;
        }
        else {
            debugLevel3("<< Objectivity >> XADataSource for " + this + " is null, cannot delist...") ;
        }
    }

  // Create an object handle for this physical connection.  The object
  // returned is a temporary handle used by application code to refer to
  // a physical connection that is being pooled.
  //
  // Returns  a Connection object
  public synchronized java.sql.Connection getConnection() {
      // need to add more code here to integrate with connection pool
      if (userconnection == null) {
        userconnection = new UserConnection(session.getConnection().getDatabase(), this) ;
      }
      info("<< Objectivity >> CALLING " + this + ".getConnection(): returning " + userconnection) ;
      return (java.sql.Connection) userconnection ;
  }
  
  public synchronized java.sql.Connection getConnection(ClassLoader beanClassLoader) {
      // need to add more code here to integrate with connection pool
      if (userconnection == null) {
        userconnection = new UserConnection(session.getConnection().getDatabase(), this, beanClassLoader) ;
      }
      info("<< Objectivity >> CALLING " + this + ".getConnection(): returning " + userconnection) ;
      return (java.sql.Connection) userconnection ;
  }

    public javax.transaction.xa.Xid getXid() {
	return ((com.objy.pm.SessionPersistor)session.persistor()).getXid() ;
    }
  
  // FOR INTERNAL USE - Objy helpers
  public Session getSession() {
    return session ;
  }
      
  void info(String message) {
      XADataSource.info(message) ;
  }
  
  void debugLevel1(String message) {
        XADataSource.debugLevel1(message) ;
  }

  void debugLevel2(String message) {
        XADataSource.debugLevel2(message) ;
  }

  void debugLevel3(String message) {
        XADataSource.debugLevel3(message) ;
  }

  void setUserConnection(UserConnection userconn) {
    if (userconnection == null) {
        userconnection = userconn ;
    }
  }
  
  public UserConnection getUserConnection() {
      return userconnection ;
  }

    // debugging
    XAResource returnXAResource() {  // the only XAConnection method implemented
        if (session != null) {
            return session.getXAResource() ;
        }
        else return null ;
    }


  //
  //  UNIMPLEMENTED JDBC METHODS 
  //          |
  //          |
  //         \ /
  //          .
  //
  
   // Add an event listener.
  public void addConnectionEventListener(ConnectionEventListener listener) { 
        // throw new SQLException("Method is Unsupported.") ;
    }


   // Remove an event listener.
  public void removeConnectionEventListener(ConnectionEventListener listener) { 
        // throw new SQLException("Method is Unsupported.") ;
    }
    
    
// the remaining functions are required for JDK 1.6 - add dummy defs until we have time to do properly

  public void addStatementEventListener(javax.sql.StatementEventListener l)
  {
    // TO DO
	  //throw new SQLException("Method is Unsupported.") ;
  }
  
  public void removeStatementEventListener(javax.sql.StatementEventListener l)
  {
    // TO DO
	 // throw new SQLException("Method is Unsupported.") ;
  }
}
