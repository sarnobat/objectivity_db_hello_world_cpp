/*
 * @(#)ooReferenceData.java
 *
 * Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import java.lang.ref.ReferenceQueue ;

/**
 * Represents a <i>reference-data object</i> that encapsulates information used for creating
 * <a href = "ooReference.html">garbage-collectible reference objects</a>.</p>
 *
 * <p>A reference-data object contains  information needed
 * for fetching the data of a garbage-collectible reference field 
 * (that is, a field of type <a href = "ooReference.html">ooReference</a>)
 * within a persistent object.
 * This information specifies the following characteristics of a 
 * garbage-collectible reference object to be created for the field:</p>
 * <ul type="desc">
 * <li>
 * The reference type of the internal reference (either weak or soft).
 * </li>
 * <li>
 * The reference queue (if any) with which to register the internal reference.
 * (A single reference queue is normally used for the internal references of
 * all garbage-collectible reference objects held by a particular persistent object.)
 * </li>
 * </ul>
 * 
 * <p>When you define a persistence-capable class that has 
 * garbage-collectible reference fields,
 * you must override the <a href = "ooObj.html#getReferenceData()"><tt>getReferenceData</tt></a> 
 * method of the class to create and return a reference-data object 
 * appropriate for each such field.
 * When the data of a persistent object of the class is fetched, 
 * the fetch operation 
 * checks each of the object's garbage-collectible reference fields 
 * to determine whether the field currently holds a reference object.
 * If it does not (for example, 
 * because its referent has been garbage collected), the fetch operation
 * calls the persistent object's <tt>getReferenceData</tt> method
 * to obtain the reference data needed 
 * for creating a new garbage-collectible reference object for the field.</p>
 * 
 *  
 * 
 */
public class ooReferenceData 
{

    private int refType ;
    private ReferenceQueue queue ;

    /**
     * Constructs a reference-data object containing the information necessary
     * for a persistent object to maintain a garbage-collectible reference field.</p>
     *
     * You use this constructor in your override of the
     * {@link com.objy.db.app.ooObj#getReferenceData <tt>getReferenceData</tt>} method of
     * a persistence-capable class.  
	 * The constructed reference-data object contains
	 * the information needed for creating
	 * a garbage-collectible reference object for a particular field
	 * of the overriding class.</p>
     *
     * @param 	 refType The desired reference type 
	 * of the relevant garbage-collectible reference object; one
     * of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
     *  <dt><tt>WEAK</tt><dd>Create an internal weak reference.</dd>
     *  <dt><tt>SOFT</tt><dd>Create an internal soft reference.</dd>
     * </dd></dl></dl></p>
     *
     * @param 	 queue The reference queue to be used by
     * the relevant garbage-collectible reference object.
	 * (<b>Note: </b> The same reference queue is normally used by 
	 * all garbage-collectible reference objects held by a particular persistent object.)</p>
     *
     * @see ooObj#getReferenceData
     */
    public ooReferenceData(int refType, ReferenceQueue queue) 
	{
	this.refType = refType ;
	this.queue = queue ;
    }

    /**
     * Gets the reference type specified by this reference-data object.</p>
	 * 
     *
     * @return   The reference type of
	 * a  garbage-collectible reference object created from this reference-data object; 
	 * one of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
     *  <dt><tt>WEAK</tt><dd>Create an internal weak reference.</dd>
     *  <dt><tt>SOFT</tt><dd>Create an internal soft reference.</dd>
     * </dd></dl></dl>
     */
    public int getRefType() 
	{
	return refType ;
    }

    /**
     * Gets the reference queue specified by this reference-data object.</p>
     *
     * @return   The reference queue to be used
     * by a  garbage-collectible reference object created from this reference-data object.</p>
     */
    public ReferenceQueue getQueue() {
	return queue ;
    }

}
