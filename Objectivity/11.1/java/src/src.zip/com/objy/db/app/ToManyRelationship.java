/*
 * @(#)ToManyRelationship.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.pm.Access ;
import com.objy.pm.TransientRelationshipManager;
import com.objy.query.ObjectQualifier;

import com.objy.db.iapp.Persistent ;
import com.objy.db.iapp.PooObj ;
import com.objy.db.iapp.PToManyRelationshipManager ;
import com.objy.db.iapp.PToManyTransientRelationshipManager ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.ObjectIsDeadException ;
import com.objy.db.ObjectNotPersistentException ;

import java.util.Collection ;
import java.util.List ;
import java.util.ListIterator ;

/**
 *
 * Represents a relationship manager for a particular to-many 
 * <a href="../../../../../guide/jgdOrganization.html#Relationships">
 * relationship</a> of a source object.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr> <td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>The source class of the relationship must declare a <i>relationship 
 * field</i> whose type is <tt>ToManyRelationship</tt> and define a public 
 * static relationship-definition method. See
 * <a href="../../../../../guide/jgdDefiningClasses.html#Defining Relationships">
 * Defining Relationships</a>.
 *
 * <p>The relationship field of a source object is initialized to reference 
 * an object of this class, which manages the relationship for that source 
 * object. You call methods of this relationship manager to 
 * create, test, follow, and delete the source object's association links. 
 * See  <a href="../../../../../guide/jgdLinking.html#Linking With Relationships">
 * Linking With Relationships</a>.  
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>The <a href = "ToOneRelationship.html"><tt>ToOneRelationship</tt></a> 
 * class represents a relationship manager for a particular to-one 
 * relationship of a source class.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Adding&nbsp;and&nbsp;Deleting&nbsp;Relationships</B></TD>
 *
 * <TD><A HREF="#add(java.lang.Object)">add(Object)<BR>
 * </A><A HREF="#remove(java.lang.Object)">remove(Object)<BR>
 * </A><A HREF="#clear()">clear()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 *
 * <TD>
 * <A HREF="#includes(java.lang.Object)">includes(Object)<BR></A>
 * <A HREF="#exists()">exists()<BR></A>
 * <A HREF="#contains(java.lang.Object)">contains(Object)<BR></A>
 * <A HREF="#isEmpty()">isEmpty()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Related&nbsp;Objects</B></TD>
 *
 * <TD>
 * <A HREF="#scan()">scan()<BR></A>
 * <A HREF="#scan(java.lang.String)">scan(String)<BR></A>
 * <A HREF="#scan(com.objy.query.ObjectQualifier)">scan(ObjectQualifier)<BR></A>
 * <A HREF="#get(int)">get(int)<BR></A>
 * <A HREF="#iterator()">iterator()<BR></A>
 * <A HREF="#toArray()">toArray()<BR></A>
 * <A HREF="#toArray(java.lang.Object[])">toArray(Object[])<BR></A>
 * <A HREF="#toArray(java.lang.Object[], boolean)">toArray(Object[], boolean)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Association&nbsp;Arrays</B></TD>
 *
 * <TD>
 * <A HREF="#ensureCapacity(int)">ensureCapacity(int)<BR></A>
 * <A HREF="#indexOf(java.lang.Object)">indexOf(Object)<BR></A>
 * <A HREF="#size()">size()<BR></A>
 * <A HREF="#trimToSize()">trimToSize()</A>
 * </TD></TR>
 * </TABLE>
 */
public final class ToManyRelationship implements java.io.Serializable, List
{
    private transient Persistent owner ;
    private transient PToManyRelationshipManager toManyManager ;
    private transient PToManyTransientRelationshipManager transientManager ;
    private transient boolean inline ;
    private transient Boolean isBidirectional = null;

    private ToManyRelationship()
        { }
        
    private ToManyRelationship(Persistent owner)
    { 
        this.owner = owner ;
    }

    private ToManyRelationship(
        boolean    isBidirectional,
        byte       inlineMode,
        long       relationMap,
        Persistent owner)
    {
        this.owner = owner ;
        this.isBidirectional = new Boolean(isBidirectional);
        switch(inlineMode) {
            case Relationship.INLINE_LONG :
            case Relationship.INLINE_SHORT :
                toManyManager = Access.new_ToManyRelationshipInlineManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
		inline = true ;
                break ;
            case Relationship.INLINE_NONE :
                toManyManager = Access.new_ToManyRelationshipManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
		inline = false ;
                break ;
            default :
                throw new ObjyRuntimeException("Relationship inline mode is invalid") ;
        }
    }

    private void cpp_createManager(
        boolean    isBidirectional,
        byte       inlineMode,
        long       relationMap)
    {
        switch(inlineMode) {
            case Relationship.INLINE_LONG :
            case Relationship.INLINE_SHORT :
		inline = true ;
                toManyManager = Access.new_ToManyRelationshipInlineManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
                break ;
            case Relationship.INLINE_NONE :
		inline = false ;
                toManyManager = Access.new_ToManyRelationshipManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
                break ;
            default :
                throw new ObjyRuntimeException("Relationship inline mode is invalid") ;
        }
	convertTransient() ;
    }
    
    private boolean isBidirectional()
    {
    	if(this.isBidirectional==null)
    		this.isBidirectional = TransientRelationshipManager.getRelationShipUsingReflection(owner,this).isBidirectional();
   		return this.isBidirectional.booleanValue();
    }

    /**
     * Adds an association link from the source object to the specified 
     * destination object.
     * </p>
     *
     * @param 	 object   The destination object for the new 
     * association link.
     * <p>If <tt><i>object</i></tt> is transient, linking it to a persistent source object makes it 
     * persistent; otherwise, <tt><i>object</i></tt> remains transient. 
     * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * <p>If <tt><i>object</i></tt> is null, this method is equivalent to
     * <a href="#clear()"><tt>clear</tt></a>.
     *
     * @return True if the addition is successful
     */
    public boolean add(Object object)
    {
    	PooObj per = persistor() ;
    	if (per == null) {
    		// SPR 21306 makes spr 19769 a user option 
    		boolean otherIsPersistent = object != null && ((Persistent)object).getPersistor() != null && !((Persistent)object).getPersistor().isDead() ;
    		//if (!useTransientRelationships() || otherIsPersistent)
    		if (!useTransientRelationships() ||  
        			(otherIsPersistent &&
        				(persistUnreachableTransientsWithRelToPersistent() || 
        					isBidirectional())))
        		{
        			Access.setRelationshipField(owner, (Persistent)object);
        		}
    		else {
    			if (transientManager == null)
    				transientManager = Access.new_ToManyTransientRelationshipManager() ;
    			transientManager.add(object, owner, this) ;
    			return true ;
    		}
	}
        toManyManager.add(persistor(), object) ;
        return true ;
    }

    /**
     * Removes the association link from the source object and the specified 
     * destination object.
     *
     * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * specified object is not a destination object.
     * </p>
	 *
     * @param 	 object   The destination object whose 
     * association link is being removed.
     *
     * @return True if the removal is successful
     */
    public boolean remove(Object object)
    {
        PooObj per = persistor() ;
        if (per != null) toManyManager.remove(per, object) ;
	else if (useTransientRelationships() && transientManager != null)
	    transientManager.remove(object, owner) ;
        return true ;
    }

    /**
     * Removes all association links from the source object.
     */
    public void clear()
    {
        PooObj per = persistor() ;
        if (per != null) toManyManager.clear(per) ; 
	else if (useTransientRelationships() && transientManager != null)
	    transientManager.clear(owner) ;
    }

    /**
     * Tests whether the source object is related to the specified 
     * destination object.</p>
     *
     * @param 	 object  The destination object
	 * being tested.</P>
	 *
     * @return True if the source object is related to the specified 
     * destination object; otherwise, false.
     */
    public boolean includes(Object object)
    { 
        PooObj per = persistor() ;
        if (per == null) {
	    if (useTransientRelationships() && transientManager != null)
		return transientManager.includes(object) ;
	    else
		return false ;
	}
        else return toManyManager.includes(per, object) ;
    }

    /**
     * Tests whether any destination objects are related to the source object.
     * </p>
     * @return  True if any destination objects are related to the source 
     * object; otherwise, false.
     *
     * <b>Note: </b>A dangling link from a unidirectional relationship
     * will also return true.
     */
    public boolean exists()
    {
        PooObj per = persistor() ;
        if (per == null) {
	    if (useTransientRelationships() && transientManager != null)
		return transientManager.exists() ;
	    else
		return false ;
	}
        else return toManyManager.exists(per) ;
    }

    /**
     * Initializes an object iterator to find all destination objects linked 
     * by the relationship to the source object.
     * </p>
     *
     * <b>Note: </b>If the relationship is unidirectional, and a destination
     * object has been deleted or moved, but the dangling link has not been deleted or updated, 
	 * this method will still find the now-invalid object identifier for that object.
	 * When the object iterator attempts to visit that object, 
     * an <tt>ObjectNotFoundException</tt> is thrown.</p>
	 * 
	 * 
     * @return  An object iterator that finds the destination objects.
     */
    public Iterator scan()
    { 
        PooObj per = persistor() ;
        if (per == null) {
	    if (useTransientRelationships() && transientManager != null)
		return transientManager.scan() ;
	    else
		return new Iterator(Access.getEmptyItr()) ;
	}
	else return toManyManager.scan(per) ;
    }

    /**
     * Initializes an object iterator to find those destination objects linked
     * by the relationship to the
     * source object that satisfy the specified predicate.
     *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate query, thus 
     * ensuring that the query uses the most up-to-date information.
     * This behavior is controlled by a connection object's predicate-scan 
     * policy.  See  
     * <a href="../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
	 *
     * @param 	 predicate   The condition that the 
     * destination objects must
     * satisfy, expressed in the Objectivity/DB
     * <a href="../../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
     *
     * @return  An object iterator that finds the specified destination 
     * objects.</p> 
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     */
    public Iterator scan(String predicate)
    { 
        PooObj per = persistor() ;
        if (per != null) return toManyManager.scan(per, predicate) ;
        else return new Iterator(Access.getEmptyItr()) ;
    }
    
    /**
     * Initializes an object iterator to find those destination objects linked
     * by the relationship to the source object qualified by an ObjectQualifier.
	 *
	 * <p>By default, this method updates the session's
     * Objectivity/DB cache before performing the predicate scan, thus
     * ensuring that the scan uses the most up-to-date information.
     * This behavior is controlled by the connection object's predicate-scan
     * policy.  See
     * <a href="../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.
     * </p>
	 *
     * @param 	 oq      The ObjectQualifier instance. </p>
     *
	 * @return		An object iterator that finds the specified objects.</p>
     *
     * @see Connection#setPredicateScanAutoFlush(boolean)
     * @see Connection#isPredicateScanAutoFlush
     */
    public Iterator scan(ObjectQualifier oq)
    { 
        PooObj per = persistor() ;
        if (per != null) return toManyManager.scan(per, oq) ;
        else return new Iterator(Access.getEmptyItr()) ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public void add(int index, Object element)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public boolean addAll(Collection c)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public boolean addAll(int index, Collection c)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Tests whether the source object is related to the specified 
     * destination object.</p>
     *
     * @param 	 object  The destination object
	 * being tested.</P>
	 *
     * @return True if the source object is related to the specified 
     * destination object; otherwise, false.
     */
    public boolean contains(Object object)
    {
	return includes(object) ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public boolean containsAll(Collection c)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Resizes the association array for the source object to be
     * able to hold the indicated number of relationships.
     *
     * This method is only supported for inline relationships.  An
     * ensureCapacity method for non-inline relationships is
     * available on ooObj.
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
     *
     * @param 	 minCapacity   The desired capacity
     * of the association array.
     *
     * @see ooObj#ensureCapacity
     */
    public void ensureCapacity(int minCapacity)
    {
	if (inline) {
	    PooObj per = persistor() ;
	    if (per == null) Access.setRelationshipField(owner, null) ;
	    toManyManager.ensureCapacity(per, minCapacity) ;
	}
        else throw new UnsupportedOperationException() ;
    }

    /**
     * Finds the destination object related to the source object at
     * the indicated index.</p>
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
     * 
     * @param 	 index   The index in the association
     * array of the destination object to be found.
     *
     * @return  The destination object at the indicated index or null
     * if no destination object is related to the source object or
     * the index is invalid.
     */
    public Object get(int index)
    {
        PooObj per = persistor() ;
        if (per == null) return null ;
        else return toManyManager.get(per, index) ;
    }

    /**
     * Finds the first occurrence in the source object's association
     * array of the destination object.</p>
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
     * 
     * @param 	 object   The destination object whose 
     * association array index is being found.
     *
     * @return  The index in the source object's association array 
     * where the first occurrence of the destination object is found
     * or -1 if the destination object is not found.
     */
    public int indexOf(Object object)
    {
        PooObj per = persistor() ;
        if (per == null) return -1 ;
        else return toManyManager.indexOf(per, object) ;
    }

    /**
     * Tests whether any destination objects are related to the source object.
     * </p>
     * @return  False if any destination objects are related to the source 
     * object; otherwise, true.
     */
    public boolean isEmpty()
    {
        return !exists() ;
    }

    /**
     * Initializes an object iterator to find all destination objects linked 
     * by the relationship related to the source object.
     * </p>
     *
     * @return  An object iterator that finds the destination objects.
     */
    public java.util.Iterator iterator()
    {
        return scan() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public int lastIndexOf(Object o)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public ListIterator listIterator()
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public ListIterator listIterator(int index)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public Object remove(int index)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public boolean removeAll(Collection c)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public boolean retainAll(Collection c)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public Object set(int index, Object element)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Returns the number of relationships for the source object
     * currently in its association array.
     *
     * This method is only supported for inline relationships.  A size
     * method for non-inline relationships is available on ooObj.
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
     *
     * @return	The size of the default association array for the source
     * object.</p>
     *
     * @see ooObj#size
     */
    public int size()
    {
	if (inline) {
	    PooObj per = persistor() ;
	    if (per == null) return 0 ;
	    else return toManyManager.size(per) ;
	}
        else throw new UnsupportedOperationException() ;
    }

    /**
     * Reserved for future use; you should not call this method.</p>
     */
    public List subList(int fromIndex, int toIndex)
    {
        throw new UnsupportedOperationException() ;
    }

    /**
     * Finds an array of all the destination objects related to the
     * source object by the relationship.</p>
     * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
	 * 
     * @return  An array of all the destination objects related to 
     * the source object by the relationship.
     */
    public Object[] toArray()
    {
        PooObj per = persistor() ;
        if (per == null) return null ;
        else return toManyManager.toArray(per, null, false) ;
    }

	/**
	 * Finds an array of all the destination objects related to the
	 * source object by the relationship.  The runtime type of
	 * the returned array is that of the specified array.</p>
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
	 * </p>
	 * 
	 * If an invalid destination object is encountered while processing the
	 * destination objects sequentially, this method catches the exception,
	 * leaving the returned array empty (if the array is too small) or else filling
	 * the array, but only up to the object prior to the one that triggered the exception.</p>
	 *  
	 * @param 	 a   The array into which the
	 * objects found are to be stored, if it is big enough; otherwise,
	 * a new array of the same runtime type is allocated for this
	 * purpose.</p>
	 *
	 * @return  An array of all the destination objects related to 
	 * the source object by the relationship.
	 */
	public Object[] toArray(Object a[])
    {
        PooObj per = persistor() ;
        if (per == null) return null ;
        else return toManyManager.toArray(per, a, false) ;
    }

	/**
	 * Finds an array of all the destination objects related to the
	 * source object by the relationship.  The runtime type of
	 * the returned array is that of the specified array.</p>
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
	 * </p>
	 *
	 * By default, if an invalid destination object is encountered while processing the
	 * destination objects sequentially, this method catches the exception,
	 * leaving the returned array empty (if the array is too small) or else filling
	 * the array, but only up to the object prior to the one that triggered the
	 * exception. You can specify true for the <tt><i>ignoreEx</i></tt> parameter to 
	 * cause this method to ignore
	 * such exceptions, allowing all slots of the returned array to be filled,
	 * except for the one(s) that caused the exceptions. You can then test each element
	 * of the array for a <tt>NullPointerException</tt>.</p>
	 * 
	 * @param 	 a   The array into which the
	 * objects found are to be stored, if it is big enough; otherwise,
	 * a new array of the same runtime type is allocated for this
	 * purpose.</p>
	 *
	 * @param 	 ignoreEx   True to ignore any exception
	 * encountered while processing the destination objects; false to
	 * allow it to be thrown.</p>
	 *
	 * @return  An array of all the destination objects related to 
	 * the source object by the relationship.
	 */
	public Object[] toArray(Object a[], boolean ignoreEx)
    {
        PooObj per = persistor() ;
        if (per == null) return null ;
        else return toManyManager.toArray(per, a, ignoreEx) ;
    }

    /**
     * Resizes the association array for the source object to the
     * defined number of relationships.
     *
     * This method is only supported for inline relationships.  A
     * trimToSize method for non-inline relationships is available
     * on ooObj.
	 * 
	 * <p>This method throws an <tt>ObjyRuntimeException</tt> if the
	 * source object is transient. (This method becomes available
	 * when the source object becomes persistent.)
	 * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * </p>
	 * 
     *
     * @see ooObj#trimToSize
     */
    public void trimToSize()
    {
	if (inline) {
	    PooObj per = persistor() ;
	    if (per == null) Access.setRelationshipField(owner, null) ;
	    toManyManager.trimToSize(per) ;
	}
        else throw new UnsupportedOperationException() ;
    }

    private PooObj persistor() {
        PooObj answer = owner.getPersistor() ;

        if (answer != null && answer.isDead())
            throw new ObjectIsDeadException("Attempted persistent operation on dead object");

        return answer ;
    }

    private boolean useTransientRelationships() {
	if (Session.getCurrent() == null)
	    throw new ObjyRuntimeException("Attempted relationship operation without creating a session") ;
	return Connection.current().isPersistOnReachability() || Session.getCurrent().getFormTransientRelationships();
    }

    private boolean persistUnreachableTransientsWithRelToPersistent() {
    	return Session.getCurrent().getPersistUnreachableTransientsWithRelationshipToPersistent();
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public PToManyTransientRelationshipManager getTransientManager() {
	return transientManager ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void setTransientManager(PToManyTransientRelationshipManager transientManager) {
	this.transientManager =	transientManager ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void nullTransientManager() {
	transientManager = null ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void convertTransient() {
	if (transientManager != null && transientManager.notFormed()) {
	    Iterator itr = transientManager.scan() ;
	    while (itr.hasNext()) {
		Object item = itr.next() ;
		boolean form = Session.getCurrent().existingTransientRelationship(owner, item, transientManager) ;
		transientManager.terminate(owner, item) ;
		if (form)
		    toManyManager.add(persistor(), item) ;
	    }
	    itr.close() ;
	    nullTransientManager() ;
	}
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public Persistent getOwner() {
	return owner ;
    }
}
