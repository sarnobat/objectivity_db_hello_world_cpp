package com.objy.query.expression;
/**
 * Represents an operator expression node.
 *
 */
public class OperatorExpression extends Expression {
    
    /**
     * Constructs an operator expression node with the token name of the operator.
     */
    public OperatorExpression(String tokenName) 
    {
        Util.verifyStringArgument(tokenName);
        setIdAfterNullCheck(Binding.create(tokenName));
    }
    
    /**
     * Constructs an operator expression node identified by an ID.
     */
    OperatorExpression(long id) 
    {
        setIdAfterNullCheck(id);
    }

    /**
     * Returns the token name, or null if none has been assigned.
     */
    public String getTokenName() 
    {
        throwExceptionIfInvalidOrClosed(getId());
        return Binding.getName(getId());
    }

    /**
     * Sets the operator to delegate to for evaluation. 
     * This method enables query builders and some non PQL parsers 
     * to set the operator explicitly instead of utilizing the automatic
     * operator selection based on token name and operand characteristics
     * performed during complete setup.
     */
    public synchronized void setOperator(Operator op) 
    {
        throwExceptionIfInvalidOrClosed(getId());
        if (op.getId() != 0)
        {
            Binding.setOperator(getId(), op.getId());
        }
    }

    /**
     *  Returns the operator delegated to for evaluation.
     */
    public synchronized Operator getOperator() 
    {
        throwExceptionIfInvalidOrClosed(getId());
        return Operator.getOperator(Binding.getOperator(getId()));
    }

    /**
     * Returns the operand list of the operator expression node, from which the operands can be retrieved.
     */
    public synchronized OperandList getOperandList() 
    {
        throwExceptionIfInvalidOrClosed(getId());
        return new OperandList(Binding.getOperandList(getId()));
    }

    /**
     * Adds the specified operand to the operand list of the operator expression node at the specified position.
     */
    public synchronized void addOperand(Expression operand, int position)
    {
        throwExceptionIfInvalidOrClosed(getId());
        OperandList opList = getOperandList();
        if (opList != null)
        {
            opList.addOperand(operand, position);
        }
    }
    
    /**
     * Returns an operator group containing all compatible operators for 
     * the given operand number.  
     * The caller is responsible for deleting the returned group.
     * <p>This method enables query builders to guide operator selection for 
     * input to the operator.
     */
    /*public OperatorGroup getCompatibleOperators(int operandNumber) 
    {
        long conn = Binding.getCompatibleOperators(getId(), operandNumber);
        if (conn == 0)
            return null;
        return new OperatorGroup(conn);
    }*/

    /**
     * Returns a name list containing all the names of compatible attributes 
     * for the given operand number. 
     * The caller is responsible for deleting the returned list.
     * <p>This method enables query builders to guide attribute selection for
     * input to the operator.
     */
    /*private NameList getCompatibleAttributeNames(int operandNumber)
    {
        long conn = Binding.getCompatibleAttributeNames(getId(), operandNumber);
        if (conn == 0)
            return null;
        return new NameList(conn);
    }*/

    // Causes the expression to evaluate itself using the provided object and
    // place the result in the passed in result object.
    //        public void evaluate(ooObjectBaseInt object, ooExpressionResult result);

    /** Calls visitOperator on the passed-in visitor, passing in this operator
     * expression node. If that returns true, calls accept on each operand 
     * passing in the visitor.
     */
    @Override
    public void accept(ExpressionVisitor visitor) {
    	if (visitor.visitOperator(this))
    	{
    		visitor.visitOperandList(getOperandList());
    	}
    }
    
    static class Binding
    {
        private static native long create(String tokenName);
        
        private static native String getName(long id);
        
        private static native void setOperator(long thisId, long opId);
        
        private static native long getOperator(long id);
        
        private static native long getOperandList(long id);
        
        //private static native long getCompatibleOperators(long id, int operandNumber);      
        
        //private static native long getCompatibleAttributeNames(long id, int operandNumber);       
    }
}
