/*
 * @(#)PSession.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

import java.util.Vector ;
import java.io.PrintStream;

import com.objy.db.app.Connection ;
import com.objy.db.app.Transaction ;
import com.objy.db.app.LogListener ;
import com.objy.db.app.ooId ;
import com.objy.db.app.ooFDObj ;
import com.objy.db.app.SessionData ;
import com.objy.db.app.TransactionListener ;
import com.objy.db.app.storage.ClusterReason;
import com.objy.db.app.storage.ClusterStrategy;

import com.objy.ejb.XATransaction ;

/**
 * Reserved for internal use.
 */
public interface PSession
{
    Connection getConnection();

    Transaction getTransaction();

    XATransaction getXAResource();

    ooFDObj getFD();

    //-----------------------------
    // Partition Process Functions
    //-----------------------------
    void setOfflineMode(int offlineMode);

    int getOfflineMode();
    
    //-----------------------
    // Transaction Processing
    //-----------------------
    boolean isOpen();

    void begin() ;

    void abort() ;

    void commit() ;

    void checkpoint(int downGradeMode) ;

    ClusterStrategy getClusterStrategy();

    ClusterStrategy setClusterStrategy(ClusterStrategy _clusterStrategy) ;

    void requestCluster(Object requestObject, com.objy.db.app.storage.ClusterReason reason, Object obj);

    long tryCreate(Object object, PHasSession persistor, int priority, long typeNumber, com.objy.db.app.ooId nearId, int pagesPerContainer, ClusterStrategy strategy);
  
    String getSchemaName(long typeNumber);

    boolean isHashBucket(long typeNumber);

    boolean isTreeNode(long typeNumber);

    boolean isTerminated();

    void terminate() ;

    Vector threads();

    void setThreadPolicy(int _threadPolicy);

    int getThreadPolicy();
    
    void upgrade() ;
    
    void dropCachedObject(Object object) ;
    
    void clearSpecialReferences() ;
    
    Object reloadCachedObject(Object object) ;
    
    void setOut(PrintStream outputStream) ;

    void setErr(PrintStream outputStream) ;

    void addToLog(String label, String text) ;

    void startTimer() ;

    void stopTimer() ;

    void startStatistics() ;

    void stopStatistics() ;

    SessionData getSessionData(String name) ;

    void setSessionData(String name, SessionData data) ;

    void addTransactionListener(TransactionListener listener) ;

    void removeTransactionListener(TransactionListener listener) ;

    void setLogListener(LogListener listener) ;

    boolean obtainedFromSessionPool() ;

    String poolName() ;

    void returnSessionToPool() ;

    void setIteratorPolicy(int policy) ;

    int getIteratorPolicy() ;
    
    @Deprecated // OBJY-17572
    boolean getFormTransientRelationships() ;

    @Deprecated // OBJY-17572
    void setFormTransientRelationships(boolean option) ;

    @Deprecated // OBJY-17572
    void setAllowTransientRelationships(boolean option) ;

    int nestCount() ;

    boolean getSafeIteratorPolicy() ;

    void setSafeIteratorPolicy(boolean policy) ;

    //------------------------------------------
    // Transaction options and active values API
    //------------------------------------------
    int getCacheInitialPages();

    int getCacheMaximumPages();

    long getTransactionID();

    void setLockConflictInfo(boolean mode);

    //
    // Accessing
    //
    int getMrowMode();

    int getWaitOption();

    int getIndexMode();

    void setMrowMode(int mrowMode);

    void setWaitOption(int waitOption);

    void setIndexMode(int indexMode);

    //
    // Accessing
    //
    int getOpenMode() ;

    void setOpenMode(int _openMode) ;

    boolean isRecoveryAutomatic() ;

    void setRecoveryAutomatic(boolean _recoveryAutomatic) ;

    boolean isLoadSchemaAutomatic() ;

    void setLoadSchemaAutomatic(boolean _loadSchemaAutomatic) ;

    //-----------------------
    // Java thread management
    //-----------------------
    void join();

    //void join(Thread t);

    boolean isJoined();

    boolean isJoined(Thread t);

    void leave();

    //void leave(Thread t);

    //-------------------
    // Process Functions
    //-------------------
    //void disableLocking();

    void printRunStatus();

    void setLargeObjectMemoryLimit(long size);

    void setHotMode(boolean hotMode);

    void setFlushCacheAfterCommit(boolean mode) ;
    
    void setDeadenObjectsAfterCommit(boolean mode) ;

    //void setLockWait(int waitOption);

    void setUseIndex(boolean useIndex);
    
    void setFetchErrorFormat(int option) ;

    boolean getContainerRefetch() ;

    void setContainerRefetch(boolean option) ;

    void setIteratorSkipInternal(boolean skipFlag) ;

    boolean getAllowUnregisterableTypes() ;

    void setAllowUnregisterableTypes(boolean option) ;

    boolean getReturn_Class_Object() ;

    void setReturn_Class_Object(boolean option) ;

    Object new_Class_Object_From_Oid(String oidString) ;

    Object new_Class_Object_From_Oid(long oidLong) ;

    Object new_Class_Object_From_Oid(ooId oid) ;

    void setRPCTimeout(long time) ;

    void setConnectRetries(int retries) ;

    void openContainers(ooId[] objects, int openMode) ;

    @Deprecated // OBJY-17572
    void persistTransientRelationships() ;

    @Deprecated  // OBJY-17572
    void persistTransientRelationships(Object near, ClusterReason reason) ;

    boolean existingTransientRelationship(Persistent owner, Object to, PToOneTransientRelationshipManager transientManager) ;

    boolean existingTransientRelationship(Persistent owner, Object to, PToManyTransientRelationshipManager transientManager) ;

    void setBufferSpace(int page_size, int initial_page_space, int maximum_page_space, int initial_large_objects, int maximum_large_objects) ;

    void releaseFiles() ;

    void setAllowNonQuorumRead() ;

    void snapShot(int info, int infoFormat, String fileName, boolean onException, int sortOrder, ooId scope) ;

    Object ffc(String lN, String mN, Object[] args) ;

    int getAutoFlushThreshold() ;

    void setAutoFlushThreshold(int threshold) ;

    boolean isDeadenObjectsInExternallyModifiedContainers() ;

    void setDeadenObjectsInExternallyModifiedContainers(boolean option) ;

    void setOptimizeScanOrder(boolean state) ;
    
	void setClassObjectPoolSize(int size);
	
	public int getClassObjectPoolSize();

	@Deprecated // OBJY-17572
	void setPersistUnreachableTransientsWithRelationshipToPersistent(boolean persist);
	
	@Deprecated // OBJY-17572
	public boolean getPersistUnreachableTransientsWithRelationshipToPersistent();

}
