/*
 * @(#)DeactivateInfo.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.objy.db.iapp ;

/**
 * Defines behavior shared by all deactivate information objects.
 *
 * <p>After a session's current transaction is committed or aborted, 
 * a deactivate event occurs for each of the session's persistent objects.
 * A persistent object's <tt>deactivate</tt> method handles 
 * the deactivate event; the parameter to that method is a deactivate 
 * information object specifying the reason why deactivation occurred.
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 */
public interface DeactivateInfo
    extends PersistentEventInfo
{
	/**
	 * Gets the reason why the deactivate event occurred.</p>
	 *
	 * @return		The reason why the deactivate event occurred;
	 * one of the following constants defined in the <tt>PersistentEventInfo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>EVENT_COMMIT</tt><dd>The transaction was committed.
     *
	 *  <dt><tt>EVENT_ABORT</tt><dd>The transaction was aborted.
	 * </dl></dl>
	 */
    public int getReason() ;
}