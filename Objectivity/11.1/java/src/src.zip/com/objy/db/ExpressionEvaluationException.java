package com.objy.db;


@SuppressWarnings("serial")
public class ExpressionEvaluationException extends ObjyRuntimeException
{
    /**
     * Constructs an expression setup exception with a message.
     * @param message
     */
    public ExpressionEvaluationException(String message) 
    {
        super(message);
    }

}
