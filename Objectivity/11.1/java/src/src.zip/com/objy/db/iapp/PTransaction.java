/*
 * @(#)PTransaction.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

import com.objy.db.app.Session ;
import com.objy.db.app.Transaction ;

/**
 * Reserved for internal use.
 */
public interface PTransaction
       extends   PRoot
{
    //
    // ODMG Operations
    //
    void begin() ;

    void abort() ;

    void commit() ;

    void checkpoint() ;

    void checkpoint(int downGradeMode) ;

    //
    // ODMG testing
    //
    boolean isOpen() ;

    //
    // ODMG thread mgmt
    //
    void join() ;

    void leave() ;

    boolean isJoined() ;

    //
    // ODMG locking
    //
    void lock(Object object, int mode) ;

    //
    // Misc
    //
    Session getSession() ;

    Transaction getTarget() ;
}



