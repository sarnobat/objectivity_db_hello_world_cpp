/*
 * @(#)Persistent.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.iapp ;

/**
 * Defines the behavior shared by all persistent objects.
 *
 * <P>The <tt>Persistent</tt> interface
 * provides <i>implicit</i> persistence behavior. Its methods give
 * access to an object's
 * <a href="../../../../../guide/jgdDefiningClasses.html#Persistors">
 * persistor</a>. An object's persistor contains all the internal 
 * Objectivity/DB state for the object and implements persistence behavior 
 * for the object.  To perform any Objectivity/DB operation on a persistent 
 * object, Objectivity for Java calls the appropriate method of the object's 
 * persistor. 
 *
 * <p>To define a persistence-capable class with the minimal public API,
 * you define a class
 * that implements the <tt>Persistent</tt> interface. Your class must
 * provide a mechanism for
 * getting and setting an object's persistor.
 * If you desire, you can also implement
 * public or private methods to perform additional Objectivity/DB operations;
 * see
 * <a href="../../../../../guide/jgdDefiningClasses.html#Implementing Persistence Behavior">
 * Implementing Persistence Behavior</a>.
 *
 * <h2>Related Classes and Interfaces</h2>
 *
 * <p>Alternative ways to define a persistence-capable class are:
 * <ul>
 * <li>Define a descendant class of
 * <a href="../app/ooObj.html"><tt>ooObj</tt></a>.
 * The class inherits default implementations for public methods that get
 * and set an object's persistor, that perform Objectivity/DB operations
 * explicitly, and that handle persistent events. You do not need to
 * implement any persistence behavior unless you want to modify the default
 * implementation.</P>
 *
 * <li>Implement the
 * <a href="IooObj.html"><tt>IooObj</tt></a> interface,
 * which provides public methods to get and set an object's
 * persistor, to perform Objectivity/DB operations explicitly, and to handle
 * persistent events. You must implement all these methods.</p>
 *
 * <li>Implement the
 * <a href="PersistentEvents.html"><tt>PersistentEvents</tt></a>
 * interface, which has public methods to get and set the persistor and
 * to handle persistent events; you need to implement those methods. If you
 * desire, you can also implement public or private methods to perform
 * Objectivity/DB operations explicitly.</p>
 * </ul>
 *
 * <p>For additional information, see
 * <a href="../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>.
 */
public interface Persistent
{
    /**
     * Gets the object providing persistence behavior for this object.</p>
     *
     * @return This object's persistor.
     *
     */
    PooObj getPersistor() ;                 // return previously passed in PooObj instance

    /**
     * Sets the object providing persistence behavior for this object.</p>
     *
     *<p><b>Note:</b>You should not call this method directly.</p>
     *
     * @param persistor The object providing persistence behavior for this object.
     */
    void   setPersistor(PooObj persistor) ; // store PooObj instance for later retrieval
}