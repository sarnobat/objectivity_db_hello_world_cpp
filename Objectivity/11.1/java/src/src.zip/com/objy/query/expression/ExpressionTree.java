package com.objy.query.expression;

/**
 * Represents an expression tree.
 */
public class ExpressionTree extends Closable
{
    // Keep owner member to work around the lack of reference counting 
    // of the C++ Expression Tree objects.  
    private Object owner = null;
    
    static 
    {
        Expression.init();
    }
    
    /**
     * Constructs an expression tree with an error handler.
     */
    public ExpressionTree(ExpressionSetupErrorHandler errorHandler)
    {
        setIdAfterNullCheck(Binding.create());
        setErrorHandler(errorHandler);
    }
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    ExpressionTree(long id, Object obj)
    {
        setIdAfterNullCheck(id);
        owner = obj;
    }
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    public static ExpressionTree getExpressionTree(long id, Object owner)
    {
        return new ExpressionTree(id, owner);
    }
    
    /**
     * Sets the error handler for this expression tree.
     * @param errorHandler
     */
    public synchronized void setErrorHandler(ExpressionSetupErrorHandler errorHandler)
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (errorHandler != null && errorHandler.getId() != 0)
        {
            Binding.setErrorHandler(mId, errorHandler.getId());
        }
        else
        {
            throw new ExpressionException("Error handler is not set for this expression tree.");
        }
    }
    
    /**
     * Returns the error handler for this expression tree.
     * @return errorHandler An instance of ExpressionSetupErrorHandler
     */
    public synchronized ExpressionSetupErrorHandler getErrorHandler() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return ExpressionSetupErrorHandler.getErrorHandler(Binding.getErrorHandler(mId));
    }
    
    /**
     * 
     */
    public synchronized void setup(String className, String predicateString)
    {
        if (getErrorHandler() == null)
        {
            throw new ExpressionException("Error handler is not set for this expression tree.");
        }
        throwExceptionIfInvalidOrClosed(mId);
        Binding.setup(mId, className, predicateString) ;
    }
    
    /**
     * Sets the class name and the predicate expression. Validates the existence of the class and 
     * the expression tree. 
     * @param className
     * @param predicateExpression
     */
    public synchronized void setup(String className, Expression predicateExpression) throws ExpressionSetupException
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.setup(mId, className, predicateExpression.getId()) ;
    }
    
    /**
     * Sets the class number or shape and the predicate string. Validates the existence of the class and 
     * the expression tree. 
     * @param typeNumber Type number of the class
     * @param predicateString Predicate string
     */
    public synchronized void setup(long typeNumber, String predicateString)
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.setup(mId, typeNumber, predicateString) ;
    }
    
    public synchronized void setup(long typeNumber, Expression predicateExpression)
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.setup(mId, typeNumber, predicateExpression.getId()) ;
    }
    
    /**
     * Completes the setup of the predicate expression associated with this expression tree. No exceptions are thrown. 
     * The error handler collects all the errors of the setup. 
     */
    public synchronized void completeSetup() throws ExpressionException
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.completeSetup(mId) ;
    }

    /**
     * Returns true if the setup of the expression tree is completed. Otherwise, returns false.
     */
    public synchronized boolean isSetupCompleted()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.isSetupCompleted(mId) ;
    }
    
    /**
     * Returns the PQL string for the expression tree. 
     * 
     * @return String The PQL string, or null if the setup of the expression is not completed. 
     */
    public synchronized String getPQLRepresentation() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getPQLRepresentation(mId) ;
    }
    
    /**
     * Generates the expression tree using the given predicate string, 
     * using the specified error handler to collect errors. </p>
     * 
     * @return Expression
     */
    public static Expression generateExpressionTreeFromPQL(String predicate, ExpressionSetupErrorHandler errorHandler) 
    {
        return Expression.getExpression(Binding.generateExpressionTreeFromPQL(predicate, errorHandler.getId())) ;
    }
    
    /**
     * Returns the expression associated with this expression tree.
     */
    public Expression getExpression() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Expression.getExpression(Binding.getPredicateExpression(mId)) ;
    }
    
    /**
     * Returns the type number of this expression tree.
     */
    public long getTypeNumber()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getShapeNumber(mId) ;
    }
    
    /**
     * Returns the literalValueExpression paired with the specified variableName. 
     * Throws ExpressionSetupException if not found or the type of the literal does not match 
     * the specified type.
     * @param variableName The name of the variable
     * @param expressionType The type of the expression
     */
    public synchronized LiteralValueExpression getVariableLiteralValue(String variableName, ExpressionType expressionType)
    {
        throwExceptionIfInvalidOrClosed(mId);
        ExpressionSetupErrorHandler handler = getErrorHandler();
        handler.clearErrors();
        Expression expr = Expression.getExpression(Binding.getVariableLiteralValue(mId, variableName, 
                expressionType.getIntValue()));
        if (handler.getNumberOfErrors() > 0)
        {
            ExpressionSetupError error = handler.getFirstError();
            throw new ExpressionSetupException(error.getDescription(), error);
        }
        if (expr instanceof LiteralValueExpression)
        {
            return (LiteralValueExpression)expr;
        }
        return null;
    }
    
    @Override
    final synchronized void closeNative()
    {
        Binding.close(getId());
    }
    
    @Override
    protected void finalize()
    {
        close();
    }
    
    @Override
    public synchronized void close()
    {
        if (mId != 0 && owner == null && !mIsClosed)
        {
            closeNative();
            setId(0);
            mIsClosed = true;
        }
    }
    
    static class Binding
    {
        private static native long     create();
        private static native long     getErrorHandler(long exprTreeId);
        private static native void     setErrorHandler(long exprTreeId, long errorHandlerId);
        private static native String   getPQLRepresentation(long exprTreeId);
        private static native long     getPredicateExpression(long exprTreeId);
        private static native long     getVariableLiteralValue(long exprTreeId, String variableName, int exprType);
        private static native long     generateExpressionTreeFromPQL(String pql, long errorHandlerId);
        private static native long     getShapeNumber(long exprTreeId);
        private static native boolean  isSetupCompleted(long exprTreeId);
        private static native void     completeSetup(long exprTreeId);
        private static native void     setup(long exprTreeId, String className, long exprId);
        private static native void     setup(long exprTreeId, long classOrShapeNumber, long exprId);
        private static native void     setup(long exprTreeId, String className, String predicate);
        private static native void     setup(long exprTreeId, long classOrShapeNumber, String predicate);
        private static native void     close(long exprTreeId);
    }
}
