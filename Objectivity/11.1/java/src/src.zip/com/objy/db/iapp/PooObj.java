/*
 * @(#)PooObj.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.iapp;

import com.objy.db.app.PlacementConditions;
import com.objy.db.app.ooId ;
import com.objy.db.app.ooObj ;
import com.objy.db.app.Iterator ;
import com.objy.db.app.Session;
import com.objy.db.app.storage.ClusterStrategy;
import com.objy.db.app.storage.ooContObj;
import com.objy.query.ObjectQualifier;

/**
 * Defines the behavior shared by all persistors.
 *
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>Every persistent object has an associated internal object
 * called a <i>persistor</i>.  Objectivity for Java creates a persistor when
 * a transient object is made persistent and when an existing persistent
 * object is retrieved from the federated database.  During its lifetime, a persistent
 * object may have different persistors; a null persistor indicates that the
 * object is transient; a dead persistor indicates that the object
 * is dead.
 *
 * <p>A persistor contains all the internal Objectivity/DB state for a persistent
 * object.  A persistent object delegates all Objectivity/DB operation requests to
 * its persistor.
 *
 * <p><b>Note:</b> Persistors should never be shared. A persistor's methods
 * should be called <i>only</i> by its persistent object and
 * Objectivity for Java.  If an object of a persistence-capable class is
 * transient or a dead object, its persistor should not be accessed; calling
 * methods of the persistor may have unexpected results.
 *
 * <p>If you define your own persistence-capable classes that do not derive
 * from <tt>ooObj</tt>, methods of your classes should ensure that persistor
 * methods are called only when appropriate.  In particular, these methods
 * should verify that the object is persistent and not dead before calling
 * any methods of its persistor that perform Objectivity/DB operations.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Locking</b></td><td>
 * 	<a href="#lock(int)">lock(int)</a><br>
 * 	<a href="#lockNoProp(int)">lockNoProp(int)</a><br>
 *  <a href="#refreshOpenContainer(int)">refreshOpenContainer(int)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Fetching&nbsp;Persistent&nbsp;Data</b></td><td>
 * 	<a href="#fetch()">fetch()</a><br>
 * 	<a href="#fetch(java.lang.String)">fetch(String)</a><br>
 * 	<a href="#fetch(java.lang.String, boolean)">fetch(String, boolean)</a><br>
 * 	<a href="#fetch(int)">fetch(int)</a><br>
 * 	<a href="#fetch(java.lang.String, int)">fetch(String, int)</a><br>
 * 	<a href="#fetch(java.lang.String, int, boolean)">fetch(String, int, boolean)</a><br>
 * 	<a href="#markModified()">markModified()</a><br>
 * 	<a href="#clearModified()">clearModified()</a><br>
 * 	<a href="#markFetchRequired()">markFetchRequired()</a><br>
 * 	<a href="#isFetchRequired()">isFetchRequired()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Modifying</b></td><td>
 * 	<a href="#markModified()">markModified()</a><br>
 * 	<a href="#move(java.lang.Object)">move(Object)</A><br>
 * 	<a href="#delete()">delete()</A><br>
 * 	<a href="#deleteNoProp()">deleteNoProp()</A><br>
 * 	<a href="#clearModified()">clearModified()</a><br>
 * 	<a href="#write()">write()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Copying</b></td><td>
 *  <a href="#copy(java.lang.Object)">copy(Object)</a><br>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td><td>
 * 	<a href="#getContainer()">getContainer()</a><br>
 * 	<a href="#getSession()">getSession()</a><br>
 * 	<a href="#getOid()">getOid()</A><br>
 * 	<a href="#getOid(boolean)">getOid(boolean)</A><br>
 * 	<a href="#getReferenceOids()">getReferenceOids()</A><br>
 *  <a href="#getTypeNumber()">getTypeNumber()</A>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td><td>
 * 	<a href="#isPersistent()">isPersistent()</a><br>
 * 	<a href="#isModified()">isModified()</a><br>
 * 	<a href="#isFetchRequired()">isFetchRequired()</a><br>
 * 	<a href="#isValid()">isValid()</a><br>
 *  <a href="#isContainerUpdated()">isContainerUpdated()</a><br>
 * 	<a href="#isDead()">isDead()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Clustering</b></td><td>
 * 	<a href="#cluster(java.lang.Object)">cluster(Object)</a><br>
 * 	<a href="#cluster(java.lang.Object, com.objy.db.app.storage.ClusterStrategy)">cluster(Object, ClusterStrategy)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With Scope-Named&nbsp;Objects</b></td><td>
 * 	<a href="#nameObj(java.lang.Object, java.lang.String)">nameObj(Object, String)</a><br>
 * 	<a href="#unnameObj(java.lang.Object)">unnameObj(Object)</a><br>
 * 	<a href="#lookupObj(java.lang.String)">lookupObj(String)</a><br>
 * 	<A HREF="#lookupObj(java.lang.String, int)">lookupObj(String, int)</A><br>
 * 	<a href="#lookupObjName(java.lang.Object)">lookupObjName(Object)</a><br>
 * 	<a href="#scopedObjects()">scopedObjects()</a>
 * 	</td></tr>
 * 
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Scope&nbsp;Objects</b></td><td>
 * 	<a href="#scopedBy()">scopedBy()</a>
 * 	</td></tr>
 * 
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Indexes</b></td><td>
 * 	<a href="#updateIndexes()">updateIndexes()</a>
 * 	</td></tr>
 * 
 * <tr><td VALIGN="top" WIDTH="1%"><b>Managing&nbsp;Default&nbsp;Association&nbsp;Arrays</b></td><td>
 * 	<a href="#size()">size()</a><br>
 * 	<a href="#trimToSize()">trimToSize()</a><br>
 * 	<a href="#ensureCapacity(int)">ensureCapacity(int)</a>
 * 	</td></tr>
 * 
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Internal Persistent&nbsp;Objects</B></TD>
 * <TD>
 *   	<A HREF="#deleteReference(java.lang.Object)">deleteReference(Object)</A><BR>
 *   	<A HREF="#dropCachedReference(java.lang.Object)">dropCachedReference(Object)</A><BR>
 * 	<a href="#getReferenceOids()">getReferenceOids()</A>
 * </TD></TR>
 * </table>
 */
public interface PooObj
       extends   PHasSession
{
	/**
	 * Gets the session in which this persistor's object was made persistent
     * or retrieved.</p>
	 *
	 * @return	The session to which this persistor's object belongs.
	 */
    Session getSession() ;

	/**
	 * Finds the container in which this persistor's object is stored.
	 *
	 * <p>If this persistor's object was retrieved from a federated database,
     * the return  value is the
	 * container in which the object is stored.  If the object was created
	 * programmatically, the return value is the container in which
	 * the object will be stored when the transaction is committed.</p>
     *
     * @return	The container in which the object is stored.
     */
    ooContObj getContainer() ;

	/**
	 * Gets the object identifier of this persistor's object.</p>
	 *
	 * @return		The object identifier of this persistor's object.
	 */
    ooId getOid() ;

    /**
     * Gets the class map of this persistor's object.</p>
     *
     * @return      The class map of this persistor's object.
     */
    long getClassMap() ;
    
	/**
	 * Gets the object identifier of this persistor's object, optionally
     * looking up the type number for the object's class.</p>
	 *
	 * <p>The <tt><i>getTypeNumber</i></tt> parameter controls whether this method
	 * gets just the object's location in the federated database or both its
     * location and the type number of its class.</p>
     *
	 * <ul type=disc>
     * <li>Pass true as the parameter to get
     * a complete object identifier, which specifies both the object's
     * location and the type number of its class.
     * (This is equivalent to the default <a href="#getOid()">
     * <tt>getOid</tt></a> method.) The session must
     * obtain a read lock on this persistor's object to look up the type
     * number. </p>
     *
     * <li>Pass false as the parameter to avoid locking the object.
     * In that case, this method does not look up the type number.
     * It returns a partial object identifier, which specifies the object's
     * location, but not the type number of its class.
     *</ul></p>
     *
	 * @param 	 getTypeNumber	True to get both the
     * location of this persistor's object and the type number of its class;
     * false to get just the object's location.</p>
     *
	 * @return		The object identifier of this persistor's object.</p>
	 */
    ooId getOid(boolean getTypeNumber) ;

	/**
	 * Tests whether this persistor's object represents a valid persistent
     * object.</p>
	 *
	 * @return	    True if the object is persistent, and false if it is
	 * dead. (An object is persistent if it is neither dead nor transient;
	 * however, transient objects do not have persistors, so this method
	 * cannot be called for a transient object.)
	 */
    boolean isPersistent() ;

	/**
	 * Tests whether this persistor is dead.
	 *
	 * <p>A dead persistor indicates that its object is a
     * <a href="../../../../../guide/jgdPersistence.html#Dead Persistent Objects">
	 * dead object</a>.
	 * Once a persistor is dead, you should not call its methods that
	 * perform Objectivity/DB operations.</p>
	 *
	 * @return	    True if this persistor is dead; otherwise, false.
	 */
    boolean isDead() ;

	/**
	 * Tests whether this persistor's object has been marked as modified.
	 *
	 * <p>A persistent object that is marked as modified will be written to the
	 * federated database when the transaction is committed.</p>
	 * 
	 * <p>This method should be called only while the session owning this object is in a transaction;
	 * otherwise, this method returns false, regardless of the actual state of the object.</p>
	 *
	 * @return	    True if the object is persistent and marked as modified;
	 * otherwise, false.
	 * False is the only return value while the session is not in a transaction. </p>
	 *
	 * @see #markModified
	 */
    boolean isModified() ;

	/**
	 * Tests whether this persistor's object's persistent data needs to be fetched.
	 *
     * <p>You can call this method if you want to explicitly test 
	 * whether this object contains its most recent persistent data. 
	 * In most situations, however, it is more efficient 
	 * to simply call the <a href="#fetch()"><tt>fetch</tt></a> method,
	 * which implicitly tests this object's persistent data
	 * and then transfers the current persistent data as necessary.</p>
	 * 
	 * <p>The <tt>isFetchRequired</tt> method checks whether any updates 
	 * have occurred in this object's container 
	 * since the last transaction in which this object's data was fetched. 
	 * If so, this method returns true, and a subsequent fetch operation 
	 * will actually transfer the object's data.
	 * If no objects in the container have been modified since the 
	 * last time this object's data was fetched, this method will
	 * return false.</p>
	 * 
	 * <p>This method should be called only while the session owning this object is in a transaction;
	 * otherwise, this method returns true, regardless of the actual state of the object.</p>
	 *
	 * @return		True if the object's persistent data must be fetched; false
	 * if the object already contains its most recent persistent data.
	 * True is the only return value while the session is not in a transaction. 
	 * 
	 */
    boolean isFetchRequired() ;

	/**
	 * Tests whether this persistor's object is a valid persistent object.
	 *
	 * <p>When you retrieve a persistent object, the retrieved object is
	 * guaranteed to reference a valid persistent object.  However, if some
	 * other session then deletes the object from the federated
	 * database or moves it, the retrieved object becomes invalid.</p>
	 *
	 * <p><b>Note:</b>  If, for some reason, the session cannot access this
     * persistor's object for read, this
	 * method returns false.</p>
	 *
	 * @return		True if the object represents a valid persistent object,
	 * otherwise, false.
	 */
    boolean isValid() ;

	/**
	 * Marks this persistor's object as needing to have its persistent data <a href="#fetch()">fetched</a>.
	 *
     * <p>Applications typically do not need to call this method explicitly.</p>
     *
     * @see com.objy.db.app.ooObj#markFetchRequired
     *
     */
    void markFetchRequired() ;

	/**
	 * Locks this persistor's object for write, fetches its persistent data
     * if it is not already fetched, and marks it as modified.
	 *
	 * <p>If the object is not currently locked for write,
	 * this method locks it for write.  The
	 * write lock is not propagated along association links to destination objects.
	 * If the object does not contain its most recent persistent data, this method
	 * fetches that data.  There is no overhead for calling this method if
	 * the object is already locked for write and its data has already been fetched during the
	 * current transaction.
	 *
	 * <p>You must call this method whenever you make
     * changes to the object's attributes; typically, you call this
	 * method from every attribute-access method that sets the value of an
	 * attribute of your persistence-capable class.  Only objects that are
     * marked as modified
	 * are written to the federated database when the transaction is committed.
	 *
 	 * <p> The modified mark is removed at the end of
     * the current transaction or by an explicit call to the
     * <a href="#write()"><tt>write</tt></a> method.</p>
	 *
     * @see com.objy.db.app.ooObj#markModified
	 * @see #isModified
	 *
	 */
    void markModified() ;



    /**
     * Removes the modified mark from this persistor's object.
     *
     * <p>The modified mark indicates that the object needs to be written to
     * the federated database.  You can call this method if you want to prevent your
	 * changes to the object from being written to the federated database.
	 *
     * <p>If you want to prevent a newly persistent object
	 * from being written to the federated database, you should either
	 * abort the transaction, or call the object's
	 * <a href="#delete()"><tt>delete</tt></a> method.
     */
    void clearModified() ;

	/**
	 * Locks this persistor's object for read and fetches its persistent data.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If the object is not currently locked,
	 * this method locks it for read
	 * before fetching its data.
	 * This method fetches all the persistent data and marks the object as
     * not needing to have its data fetched.
	 * 
	 * <p>If the object's persistent data is current, 
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.</p>
	 * 
	 * <p>If the object has reference attributes, 
	 * this method also locks every destination for read, 
	 * but does not fetch the data of these objects. 
	 * The read lock is not propagated to related objects. 
	 * 
	 */
    void fetch() ;

	/**
	 * Locks this persistor's object for read and performs a
     * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the named reference attributes.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If the object is not currently locked,
	 * this method locks it for read
	 * before fetching its data; the read lock is not
	 * propagated to related objects.
	 * This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
     * attributes of primitive types, string classes, and date and time
     * classes.</p>
     *
     * <li>Those reference attributes that are specified by the
     * <tt><i>references</i></tt> parameter.
     * </ul>
     *
	 * <p><b>Note:</b> After this method is executed, the object is still
     * marked as needing to have its data fetched.
	 *
	 * <p>If the object's persistent data is current, 
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.</p>
     *
	 * @param 	 references  Colon-separated list of
     * attribute names. Any reference attributes named in the string are
     * fetched; other reference attributes are not fetched.  If the string is
     * null, no reference attributes are fetched. If the string is an empty string, 
     * all reference attributes are fetched.
	 */
    void fetch(String references) ;

	/**
	 * Locks this persistor's object for read and performs a
     * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the reference attributes
     * specified by name or regular expression.
     *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If the object is not currently locked,
	 * this method locks it for read
	 * before fetching its data; the read lock is not
	 * propagated to related objects. This method fetches:</p>
	 * <ul type=disc>
	 * 
	 * <li>All relationship fields, array attributes, and
     * attributes of primitive types, string classes, and date and time
     * classes.</p>
     *
     * <li>Those reference attributes that are specified by the
     * <tt><i>references</i></tt> parameter.
     * </ul>
     *
	 * <p><b>Note:</b> After this method is executed, the object is still
     * marked as needing to have its data fetched.
	 *
	 * <p>If the object's persistent data is current, 
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.</p>
     *
	 * @param 	 references  Colon-separated list of
     * attribute names or regular expressions (as indicated by the
     * <tt><i>regexp</i></tt> parameter). Any reference attributes named in
     * the string (or whose names match a regular expression in the string)
     * are fetched; other reference attributes are not fetched.  If the string is
     * null, no reference attributes are fetched. If the string is an empty string, 
     * all reference attributes are fetched.</p>
	 *
	 * @param 	 regexp  True if the
     * <tt><i>references</i></tt> string may contain regular expressions;
     * false if it must contain attribute names.
	 */
   void fetch(String references, boolean regexp) ;

	/**
	 * Fetches this persistor's object's persistent data after obtaining a
     * specified lock.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If the object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching the object's data; the lock is not
	 * propagated to related destination objects.
	 * This method fetches all the persistent data and marks the object as
     * not needing to have its data fetched.
	 *
	 * <p>If the object's persistent data is current, 
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.</p>
	 *
 	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
	 */
    void fetch(int lockMode) ;

	/**
	 * Obtains the specified lock on this persistor's object and performs a
     * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the named reference attributes.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If the object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching the object's data; the lock is not
	 * propagated to related destination objects. This method fetches:</p>
	 * <ul type=disc>
	 * 
	 * <li>All relationship fields, array attributes, and
     * attributes of primitive types, string classes, and date and time
     * classes.</p>
     *
     * <li>Those reference attributes that are specified by the
     * <tt><i>references</i></tt> parameter.
     * </ul>
     *
	 * <p><b>Note:</b> After this method is executed, the object is still
     * marked as needing to have its data fetched.
	 *
	 * <p>If the object's persistent data is current, 
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.</p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names. Any reference attributes named in the string are
     * fetched; other reference attributes are not fetched.  If the string is
     * null, no reference attributes are fetched.  
     * If the string is an empty string, all reference attributes are fetched.</p>
     *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 */
    void fetch(String references, int lockMode) ;

	/**
	 * Obtains the specified lock on this persistor's object and performs a
     * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the reference attributes
     * specified by name or regular expression.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If the object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching the object's data; the lock is not
	 * propagated to related destination objects. This method fetches:</p>
	 * <ul type=disc>
	 * 
	 * <li>All relationship fields, array attributes, and
     * attributes of primitive types, string classes, and date and time
     * classes.</p>
     *
     * <li>Those reference attributes that are specified by the
     * <tt><i>references</i></tt> parameter.
     * </ul>
     *
	 * <p><b>Note:</b> After this method is executed, the object is still
     * marked as needing to have its data fetched.
	 *
	 * <p>If the object's persistent data is current, 
	 * this method has no effect, other than locking the object as appropriate.
	 * There is no overhead for repeated calls to
	 * <tt>fetch</tt>.</p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names or regular expressions (as indicated by the
     * <tt><i>regexp</i></tt> parameter). Any reference attributes named in
     * the string (or whose names match a regular expression in the string)
     * are fetched; other reference attributes are not fetched.  If the string is
     * null, no reference attributes are fetched.
     * If the string is an empty string, all reference attributes are fetched.</p>
     *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @param 	 regexp  True if the
     * <tt><i>references</i></tt> string may contain regular expressions;
     * false if it must contain attribute names.
	 */
    void fetch(String references, int lockMode, boolean regexp) ;

	/**
	 * Transfers this persistor's object's data to the Objectivity/DB cache
     * of the object's session.
	 *
	 * <p>This method writes the object's data to its session's
     * Objectivity/DB cache.  Each session has its own Objectivity/DB cache,
     * so the written data will not be visible to
     * other sessions or processes. The changes will be transferred to the
     * federated database when you commit or checkpoint the current
	 * transaction.  If the transaction is aborted, the changes are never
	 * transferred to the federated database.
	 *
	 * <p>Only data for this persistor's object is written to the cache.  If
     * that object
     * references destination objects, those destination objects are
     * <i>not</i> written.
     *
	 * <p>This method removes any modified mark from the object. If you make
	 * additional changes after calling this method, you must call
	 * <a href="#markModified()"><tt>markModified</tt></a>
	 * or <tt>write</tt> again; otherwise, your changes will be lost.
	 *
	 * <p>You typically do not call this method.  Instead, you call the
	 * session's
	 * <a href="../app/Session.html#checkpoint()"><tt>checkpoint</tt></a>
	 * method, which writes all changes to the federated database.  The
	 * <tt>checkpoint</tt> method makes changes accessible to <i>all</i>
	 * other clients, not just to other transactions of your process.
	 */
    void write() ;

	/**
	 * Explicitly locks this persistor's object and propagates the
	 * lock to related destination objects.
	 *
	 * <p>This method locks the object for the specified access and
     * propagates the lock
	 * to any destination objects linked to
	 * the object through relationships for which lock
	 * propagation is enabled.
	 *
	 * <p>Locking a basic object implicitly locks the object's container. Locking
	 * a container implicitly locks all basic objects in the container.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
     * <p>The lock mode is limited by the open mode of the object's
     * session</a>.
     * If you try to set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>,
	 * this method throws a runtime exception.
	 *
	 * <p>If the object is already locked, you can call this method to upgrade a
	 * read lock to a write lock, but not to downgrade a write lock to a read
	 * lock.</p>
	 *
	 * @see #lockNoProp
	 */
    void lock(int lockMode) ;

	/**
	 * Explicitly locks this persistor's object for the specified access.
	 *
	 * <p>Unlike the <a href="./PooObj.html#lock(int)"><tt>lock</tt></a>
	 * method, this method does not propagate the lock to related destination
     * objects.
	 *
	 * <p>Locking a basic object implicitly locks the object's container. Locking
	 * a container implicitly  locks all basic objects in the container.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for
	 * the object; one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
     * <p>The lock mode is limited by the open mode of the object's
     * session</a>.
     * If you try to set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>, this method
	 * throws a runtime exception.
	 */
    void lockNoProp(int lockMode) ;

	/**
	 * Deletes this persistor's object from the federated database.
	 *
	 * <p>Until the current transaction is committed, the deleted object
     * continues to
     * exist in your application's memory, but its persistor is marked dead.
	 * Once a persistor is dead, you should not call its methods that
	 * perform Objectivity/DB operations.
     *
     * <p>The deleted object is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
     * write a persistent object that references a dead object.
	 *
 	 * <p>Unlike the <a href="#delete()"><tt>delete</tt></a>
	 * method, this method does not propagate the deletion operation
	 * to related destination objects.</p>
	 *
     * @see #isDead
     * @see #delete
     *
	 */
    void deleteNoProp() ;

	/**
	 * Deletes this persistor's object from the federated database and propagates the deletion
	 * operation to related objects.
	 *
	 * <p>This method propagates the deletion operation to any objects
	 * associated to the object through relationships for which deletion
	 * propagation is enabled.
	 *
	 * <p>Until the current transaction is committed, this object
	 * continues to
     * exist in your application's memory, but its persistor is marked
     * dead.
	 * Once a persistor is dead, you should not call its methods that
	 * perform Objectivity/DB operations.
	 *
     * <p>Each deleted object is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
     * write a persistent object that references a dead object.</p>
     *
     * @see #deleteNoProp
     * @see #isDead
	 */
    void delete() ;

	/**
	 * Removes this persistor's object's reference to the specified internal 
     * persistent object and deletes that object.</p>
         *
	 * <p>
	 * <b>Note:</b> You should delete an internal persistent object
	 * <i>only</i> 
	 * if you also plan to delete the persistent object that referenced it.
	 * </p>
	 *
	 * @param 	 objectReference	The
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> to be deleted.  This persistor's object
     * must reference <tt><i>object</i></tt>, and <tt><i>object</i></tt>
	 * must be an array, a string element of an
	 * array, or a date or time type that is stored in the
	 * federated database as an internal persistent object
	 * (<tt>java.util.Date</tt>, <tt>java.sql.Date</tt>, or
     * <tt>java.sql.Time</tt>,
	 * <tt>java.sql.Timestamp</tt>).
	 */
    void deleteReference(Object objectReference) ;

	/**
	 * Drops the specified internal persistent object from the
	 * internal session cache.</p>
	 *
     * <p>The object to be released is an
     * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
     * internal persistent object</a> that is referenced by some persistent
     * object.
     *
     * <p><b>Note: </b> You should call this method only if the memory
     * consumed by Objectivity for Java prevents your application from
     * running to completion. In that situation, you
     * should call this method only when the persistent object
     * that references <tt><i>object</i></tt> has
     * itself been released and is waiting to be garbage collected.</p>
     *
	 * @param 	 objectReference	The
	 * internal persistent object to be deleted; must be an instance of
	 * <tt>java.util.Date</tt>, <tt>java.sql.Date</tt>,
     * <tt>java.sql.Time</tt>, or <tt>java.sql.Timestamp</tt>.
	 *
	 */
    void dropCachedReference(Object objectReference) ;

	/**
	 * Makes the specified object persistent, clustering it with this
	 * persistor's object, subject to the
     * session's clustering strategy.</p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.
	 * The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The session's
	 * clustering strategy determines where to locate the object relative
	 * to this persistor's object. See
     * <a href="../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this persistor's object's database, adding it to that
     * database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
	 * @see     <a 
     * href="../app/storage/ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>ooDBObj.addContainer(ooContObj, int, String, long, long)</tt></a>
	 */
    void cluster(Object object) ;

	/**
	 * Makes the specified object persistent, clustering it with this
	 * persistor's object, subject to the specified clustering strategy.</p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.
	 * The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The specified
	 * clustering strategy determines where to locate the object relative
	 * to this persistor's object. See
     * <a href="../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this persistor's object's database, adding it to that
     * database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
     * @param 	 strategy    Clustering strategy to determine 
     * the location of a basic object.
     * This parameter is ignored if
     * <tt><i>object</i></tt> is a container.</p>
	 *
	 * @see     <a 
     * href="../app/storage/ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>ooDBObj.addContainer(ooContObj, int, String, long, long)</tt></a>
	 */
    void cluster(Object object, ClusterStrategy strategy);   
    
    /**
     * Persist this object in the databse.
     *
     */
    void persist();
    
    /**
     * Persist this object in the databse.
     *
     * @param placementConditions the PlacementConditions object providing additional information including a related object and purpose that the placement model can be configured to use.
     */
    public void persist(PlacementConditions placementConditions);

	/**
	 * <a href="../../../../../guide/jgdPersistence.html#Copying a Basic Object">
	 * Copies</a> this persistor's object (a basic object), clustering
	 * the new object with the specified object.
	 *
	 * <p>You should call this method for persistent objects only.  If this
	 * object is not locked, this method locks its container for read-only
     * access.</p>
	 *
	 * @param 	 o The object with which to cluster the
	 * new copy.  The <tt><i>o</i></tt> object must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>o</i></tt> is a database:<dd>The new copy is stored in
	 * the default container of that database.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>o</i></tt> is a persistent container:<dd>The new copy is
	 * stored in that container.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>o</i></tt> is a persistent basic object:<dd>The new copy is
	 * stored in the same container as <tt><i>o</i></tt>.
	 * The object is put on the same logical page as <tt><i>o</i></tt>, if the page has enough space. 
	 * Otherwise, the object is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @return		The new copy of this persistor's object.
	 * The returned object is persistent. If the transaction is aborted, the new
     * object becomes a dead object and is not stored persistently.
	 */
    Object copy(Object o) ;

	/**
	 * Moves this persistor's object (a basic object), clustering it with the specified object.
	 *
	 * <p>You should call this method for persistor of basic objects only.
     * If this persistor's object
	 * is not locked, this method locks its container and the container
	 * to which it will be moved, for read/write access.
	 *
	 * <p><b>Warning: </b>This method changes the object identifier of the object.
	 * When you move an object you should, within the same transaction, update references to the object within all relevant
	 * relationships, collections (including root name maps), scope names, and
	 * indexes. In the case of a reference within a name map or root name,
	 * corruption of the federated database could result if the reference is
	 * not updated. See
	 * <a href="../../../../../guide/jgdPersistence.html#Moving a Basic Object">
	 * Moving a Basic Object</a>
	 * for further information.</p>
	 *
	 * @param 	 o The object with which to cluster the
	 * object.  The <tt><i>o</i></tt> object must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>o</i></tt> is a database:<dd>The object is moved to
	 * the default container of that database.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>o</i></tt> is a persistent container:<dd>The object is
	 * moved to that container.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>o</i></tt> is a persistent basic object:<dd>The object is
	 * moved to the container in which <tt><i>o</i></tt> is stored.
	 * The object is put on the same logical page as <tt><i>o</i></tt>, if the page has enough space. 
	 * Otherwise, the object is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl>
	 *
	 */
    void move(Object o) ;

	/**
	 * Names the specified scope object in the scope of this persistor's object.
     *
     * <p>If the specified object is transient, this method makes it persistent.
     * If the specified object is already persistent, this method locks its
	 * container for write.
	 *
	 * <p>This method obtains a write lock on the name map in which the
     * object stores its scope names.</p>
	 *
	 * @param 	 o	The object to be named.</p>
	 *
	 * @param 	 scopeName	The name for the specified
	 * object in the scope of this persistor's object.
     * This name can be any valid Java string and must be unique
	 * within the name scope of this persistor's object.  </p>
     *
     * @see #lookupObj(String)
     * @see #unnameObj(Object)
	 */
    void nameObj(Object o, String scopeName) ;

	/**
	 * Removes the specified object's name from the
	 * name scope of this persistor's object.
	 *
	 * <p>This method locks both this persistor's object and
     * <tt><i>object</i></tt> for write.</p>
	 *
	 * @param 	 obj	The object whose name is to be
	 * removed. This method throws an <tt>ObjyRuntimeException</tt> if
	 * <tt><i>object</i></tt> has no name in the name scope of this
     * persistor's object.</p>
	 *
     * @see #lookupObj(String)
     * @see #nameObj(Object, String)
	 */
    void unnameObj(Object obj) ;

	/**
	 * Looks up the name of the specified object in the scope defined
     * by this persistor's object.</p>
	 *
	 * @param 	 obj	The object whose name is to be
	 * looked up. This method throws an <tt>ObjyRuntimeException</tt>
     * if <tt><i>object</i></tt> has no name in the name scope of this
     * persistor's object.</p>
     *
	 * @return		The scope name of the specified object in the
	 * name scope of this persistor's object.</p>
	 *
	 * @see #lookupObj(String)
	 */
    String lookupObjName(Object obj) ;

	/**
	 * Finds the object with the specified scope name in the scope defined
     * by this persistor's object.</p>
	 *
	 * @param 	 scopeName	The scope name to look up.
	 * This method throws an <tt>ObjyRuntimeException</tt> if there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this
     * persistor's object.</p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this persistor's object. </p>
	 *
	 * @see #lookupObjName(Object)
	 */
    Object lookupObj(String scopeName) ;

	/**
	 * Finds the object with the specified scope name in the scope defined
     * by this persistor's object, locking the
	 * found object as specified.</p>
	 *
	 * @param 	 scopeName	The scope name to look up.
	 * This method throws an <tt>ObjyRuntimeException</tt> if there is no
	 * object named <tt><i>scopeName</i></tt> in the scope of this
     * persistor's object.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this persistor's object; the returned object
	 * is locked as specified by <tt><i>lockMode</i></tt>. </p>
	 *
	 * @see #lookupObjName(Object)
	 */
    Object lookupObj(String scopeName, int lockMode) ;

	/**
	 * Initializes an object iterator to find all objects named in the
	 * name scope of this persistor's object.</p>
	 *
	 * @return		An object iterator that finds the named objects.
	 */
    Iterator scopedObjects() ;

	/**
	 * Initializes an object iterator to find all scope objects that define
	 * scope names for this persistor's object.</p>
	 *
	 * @return		An object iterator that finds the scope objects.
     */
    Iterator scopedBy() ;

	/**
	 * Updates the indexes that include this persistor's object.
	 *
	 * <p>If a session's index mode is <tt>EXPLICIT_UPDATE</tt>,
     * indexes are not updated automatically to reflect changes to indexed attributes.
     * You must call this method after creating an object and initializing
     * its indexed attributes, and after modifying the indexed attributes of an
     * existing object.
	 */
    void updateIndexes() ;

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    int compareOoId(PooObj obj);

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    int hashOoId();

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    Object getTarget();

    //long connectionId() ;   // reserved

	/**
	 * Resizes the default association array for this persistor's
	 * object to be able to hold the indicated number of relationships.
	 */
    void ensureCapacity(int minCapacity) ;

	/**
	 * Returns the number of associations for this persistor's
	 * object currently in the default association array.
	 *
	 * @return	The size of the default association array for this persistor's object.</p>
	 */
    int size() ;

	/**
	 * Resizes the default association array for this persistor's
	 * object to the defined number of relationships.
	 */
    void trimToSize() ;

    /**
     * Gets the object identifiers of 
     * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
     * internal persistent objects</a> referenced by this persistor's object.</p>
     *
     * @return		An array of object identifiers of
     * internal persistent objects referenced by this persistor's object.</p>
     */
    ooId[] getReferenceOids() ;
    
    /**
    * Reopens the container of this persistor's object, refreshing the session's view of 
     * the container in the MROW transaction reading it. 
     * 
 	 * <p>You should call this method only during an MROW session and
	 * only if you locked the container of this persistor's object for read, and another session
	 * subsequently updated some object in the container.  You can
	 * call the <a href="#isContainerUpdated()"><tt>isContainerUpdated</tt></a> method to
	 * check whether another session has made updates in this container since you
	 * locked it.
	 *
	 * <p>Note that this method does not automatically refetch any existing
	 * fetched object in the container.</p>
	 *
	 * <p> This method throws an exception if the container being refreshed
	 * no longer exists. </p>
     * 
     * @param mode The intended level of access to the reopened container;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock on the container.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock on the container.
     * </dl></dl></p>
     */
    void refreshOpenContainer(int mode);
    
    /**
     * Tests whether the container of this persistor's object has already been 
     * updated by another transaction.
     * 
   	 * <p>You should call this method only during an MROW session in
	 * which you locked the container of this persistor's object for read. If this method
	 * returns true, your application's copies of the container and its
  	 * objects are out of date, because an MROW update session has concurrently accessed an object in the same container and then committed.  
 	 * You can call the
	 * <a href="#refreshOpenContainer(int)"><tt>refreshOpenContainer</tt></a> method to
	 * update the session's copy of this container and its objects.</p>
     * 
     * @return        True if the container has been updated and committed by another 
     * transaction since being locked for read by the current MROW transaction; 
     * otherwise, false. </p>
     */
    boolean isContainerUpdated();
    
	/**
	 * Gets the Objectivity/DB type number of the class of this persistor's.</p>
	 * 
	 * <p>The type number uniquely identifies the class of an object in the federated database schema.</p>
	 *
	 * @return		The Objectivity/DB type number of the class of this persistor's object.</p>
	 */
     public long getTypeNumber();
    
    
}
