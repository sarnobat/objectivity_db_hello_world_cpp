package com.objy.query.expression;

/**
 * Represents a name list.
 *
 */
public class NameList extends AbstractExpression
{
    /**
     * Constructs a name list with an ID.
     * @param id
     */
    NameList(long id) 
    {
       setIdAfterNullCheck(id);
    }

    /**
     * Returns the name at the given index from the list.
     * @param index The given index
     * @return The name
     */
    public String getName(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getName(mId, index);
    }

    /**
     * Adds a name to the list.
     */
    public void addName(String value) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.addName(mId, value);
    }

    /**
     * Returns the total number of names in the list.
     * @return The number of names.
     */
    public int getNumberOfNames() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getNumberOfNames(mId);
    }
    
    static class Binding
    {
        private static native int getNumberOfNames(long id);        
        private static native String getName(long id, int i);      
        private static native void addName(long id, String value);
        
    }
}
