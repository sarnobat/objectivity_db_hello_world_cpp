/*
 * @(#)ooHashSet.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.Collection;
import java.util.Iterator;
import java.util.Set;
import com.objy.db.app.ooObj;
import com.objy.db.app.storage.ooContObj;
import com.objy.pm.ooCollectionIterator ;
import com.objy.pm.ooHashSetPersistor ;

/**
 * Persistence-capable class for unordered sets of persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Unordered Sets</h2>
 *
 * <p>An <i>unordered set</i> is a scalable unordered collection
 * of persistent objects with no duplicate elements.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Scalable Unordered Collections">
 * Scalable Unordered Collections</a>.
 *
 * <p><h2>Working With an Unordered Set</h2>
 *
 * <P>An unordered set is transient when it is created; you can make it
 * persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created an unordered set, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a Set">
 * Building a Set</a></p>
 *
 * <li>Look up particular elements in the unordered set as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Sets">
 * Individual Lookup in Sets</a></p> 
 *
 * <li>Iterate over the unordered set as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Elements of a List or Set">
 * Finding the Elements of a List or Set</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make an unordered set persistent before you call
 * any methods defined by the <tt>ooHashSet</tt> or <tt>ooCollection</tt>
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of persistent 
 * objects: 
 * <ul>
 * <li><a href="ooTreeSet.html"><tt>ooTreeSet</tt></a> represents
 * a <i>sorted</i> collection of persistent objects with no duplicate 
 * elements.</p> 
 *
 * <li><a href="ooTreeList.html"><tt>ooTreeList</tt></a> represents an
 * <i>ordered</i> collection of persistent objects that <i>can contain 
 * duplicate elements</i>.</p> 
 * </ul>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 		<td>
 *     	<a href="#ooHashSet()">ooHashSet()</a><br>
 *     	<a href="#ooHashSet(com.objy.db.util.ooCompare)">ooHashSet(ooCompare)</a><br>
 *     	<a href="#ooHashSet(int)">ooHashSet(int)</a><br>
 *     	<a href="#ooHashSet(com.objy.db.util.ooCompare, int)">ooHashSet(ooCompare, int)</a><br>
 *      <a href="#ooHashSet(int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooHashSet(int, ooContObj, ooContObj)</a><br>
 *      <a href="#ooHashSet(com.objy.db.util.ooCompare, int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooHashSet(ooCompare, int, ooContObj, ooContObj)</a><br>
 *      <a href="#ooHashSet(com.objy.db.util.ooCompare, int, int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooHashSet(ooCompare, int, int, ooContObj, ooContObj)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 * 	   <td>
 *     <a href="#addAll(java.util.Collection)">addAll(Collection)</a><br>
 *     <a href="#remove(java.lang.Object)">remove(Object)</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#removeAll(java.util.Collection)">removeAll(Collection)</a><br>
 *     <a href="#retainAll(java.util.Collection)">retainAll(Collection)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 * 	   <td>
 * 	   <a href="#iterator()">iterator()</a><br>
 * 	   <a href="#get(java.lang.Object)">get(Object)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	   <td>
 * 	   <a href="#containsAll(java.util.Collection)">containsAll(Collection)</a><br>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Setting&nbsp;Properties</b></td>
 * 	   <td>
 * 	   <a href="#maxBucketsPerContainer(int)">maxBucketsPerContainer(int)</a>
 * 	   </td></tr>
 * </table>
 *
 */
final public class ooHashSet extends ooCollection implements Set
{
	/**
	 * Reserved for internal use.
	 */
    public transient int _bucketSize = 30011;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _adminContainer = null;

 	/**
	 * Reserved for internal use.
	 */	 
    public transient int _initialBuckets = 1;
    
 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _bucketContainer = null;


	/**
	 * Constructs an empty unordered set with a default comparator,
	 * the default 
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * hash-bucket size</a>, one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
	 * hash bucket</a>, a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
	 * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
	 * hash-bucket container</a>. </p>
	 */
    public ooHashSet()
    { }

	/**
	 * Constructs an empty unordered set with the
	 * specified hash-bucket size, a default comparator,
	 * one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
	 * hash bucket</a>, a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
	 * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * hash-bucket container</a>. </p>
	 *
	 * @param		<tt><i>bucketSize</i></tt>	The size of a hash bucket 
     * in the new unordered set's hash table. See
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size</a>.
	 */
    public ooHashSet(int bucketSize)
    {
        _bucketSize = bucketSize;
    }

	/**
	 * Constructs an empty unordered set with the specified 
     * comparator, the default hash-bucket 
     * size, one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * hash bucket</a>, a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * hash-bucket container</a>. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new set; must be
	 * an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.
	 */
    public ooHashSet(ooCompare compare)
    {
        _comparator = compare;
    }

	/**
	 * Constructs an empty unordered set with the specified 
     * comparator and hash-bucket size, one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * hash bucket</a>, 
     * a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * hash-bucket container</a>. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new set; must be
	 * an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>bucketSize</i></tt>	The size of a hash bucket 
     * in the new unordered set's hash table. See
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size</a>.
	 */
    public ooHashSet(ooCompare compare, int bucketSize)
    {
        _comparator = compare;
        _bucketSize = bucketSize;
    }

	/**
	 * Constructs an empty unordered set with  
	 * a default comparator, the default 
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * hash-bucket size</a>, and the specified 
     * number of initial hash buckets, administrator container, 
     * and hash-bucket container. </p>  
	 *
	 * @param		<tt><i>initialBuckets</i></tt>	The minimum number of 
     * initial hash buckets to create for the new unordered set. See
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * Hash Buckets</a>.</p>
     *
	 * @param		<tt><i>adminContainer</i></tt>	The container in 
     * which to store the hash administrator for the new unordered 
     * set; specify null to store the hash administrator in a newly 
     * created container. See
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * Hash Administrator</a>.</p>
     *
	 * @param		<tt><i>bucketContainer</i></tt>	The container in 
     * which to store the initial hash buckets for the new unordered 
     * set; specify null to store each initial hash bucket in its 
     * own newly created container. See
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * Containers for Hash Buckets</a>.
	 */
    public ooHashSet(int initialBuckets, ooContObj adminContainer, ooContObj bucketContainer)
    {
        _adminContainer = adminContainer;
        _initialBuckets = initialBuckets;
        _bucketContainer = bucketContainer;
    }

	/**
	 * Constructs an empty unordered set with  
	 * the default 
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * hash-bucket size</a> and the specified 
     * comparator, number of initial hash buckets, administrator container, 
     * and hash-bucket container. </p>  
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new set; must be
	 * an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>initialBuckets</i></tt>	The minimum number of 
     * initial hash buckets to create for the new unordered set. See
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * Hash Buckets</a>.</p>
     *
	 * @param		<tt><i>adminContainer</i></tt>	The container in 
     * which to store the hash administrator for the new unordered 
     * set; specify null to store the hash administrator in a newly 
     * created container. See
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * Hash Administrator</a>.</p>
     *
	 * @param		<tt><i>bucketContainer</i></tt>	The container in 
     * which to store the initial hash buckets for the new unordered 
     * set; specify null to store each initial hash bucket in its 
     * own newly created container. See
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * Containers for Hash Buckets</a>.
	 */
    public ooHashSet(ooCompare compare, int initialBuckets, ooContObj adminContainer, ooContObj bucketContainer)
    {
        _comparator = compare;
        _adminContainer = adminContainer;
        _initialBuckets = initialBuckets;
        _bucketContainer = bucketContainer;
    }

    
	/**
	 * Constructs an empty unordered set with the specified 
     * comparator, hash-bucket size, number of initial hash buckets, 
     * administrator container, and hash-bucket container. </p>  
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new set; must be
	 * an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>bucketSize</i></tt>	The size of a hash bucket 
     * in the new unordered set's hash table. See
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size</a>.</p>
	 *
	 * @param		<tt><i>initialBuckets</i></tt>	The minimum number of 
     * initial hash buckets to create for the new unordered set. See
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * Hash Buckets</a>.</p>
     *
	 * @param		<tt><i>adminContainer</i></tt>	The container in 
     * which to store the hash administrator for the new unordered 
     * set; specify null to store the hash administrator in a newly 
     * created container. See
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * Hash Administrator</a>.</p>
     *
	 * @param		<tt><i>bucketContainer</i></tt>	The container in 
     * which to store the initial hash buckets for the new unordered 
     * set; specify null to store each initial hash bucket in its 
     * own newly created container. See
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * Containers for Hash Buckets</a>.
	 */
    public ooHashSet(ooCompare compare, int bucketSize, int initialBuckets, ooContObj adminContainer, ooContObj bucketContainer)
    {
        _comparator = compare;
        _bucketSize = bucketSize;
        _adminContainer = adminContainer;
        _initialBuckets = initialBuckets;
        _bucketContainer = bucketContainer;
    }

	/**
	 * Adds all elements in the specified collection to this unordered
	 * set. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection
	 * whose elements are to be added to this unordered set. Every element
	 * of <tt><i>collection</i></tt> must be an instance of a
	 * persistence-capable class. If any element is transient, this
	 * method makes it persistent.</p>
	 *
	 * @return		True if any elements were added; otherwise, false.
	 *
	 * <p>This method returns false if this unordered set already contains
 	 * all the elements of <tt><i>collection</i></tt>.
	 */
    public boolean addAll(Collection collection)
    {
        Iterator itr;
    	if (collection instanceof ooCollection)
    	    itr = (Iterator) ((ooCollection)collection).keyIterator();
    	else
    	    itr = collection.iterator();
        boolean mod = false;

        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

	/**
	 * Tests whether this unordered set contains all elements in the
	 * specified collection. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements are
	 * to be tested for containment in this unordered set.</p>
	 *
	 * @return		True if this unordered set contains elements equal to
	 * each element of <tt><i>collection</i></tt>; otherwise, false.
	 */
    public boolean containsAll(Collection collection) {
        if (comparator() == null)
            return getCollectionPersistor().containsAll((ooCollection) collection);
        else
        {
            Iterator itr;
    	    if (collection instanceof ooCollection)
    	        itr = ((ooCollection)collection).keyIterator();
    	    else
    	        itr = collection.iterator();
    	    while (itr.hasNext())
    	        if (!contains(itr.next()))
    	            return false;
    	    return true;
        }
    }

    /**
     * Finds the element of this unordered set that is equal to the
	 * specified lookup data, as determined by the comparator for this
 	 * unordered  set.
	 *
	 * <p><b>Note: </b>This unordered set must have an application-defined
	 * comparator that can identify an element based on class-specific
	 * data.  See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Unordered Collections">
	 * Comparator Class for Unordered Collections</a>.
	 * </p>
	 *
	 * @param		<tt><i>lookupValue</i></tt>	The object that identifies
	 * the desired element.</p>
	 *
	 * @return		The element found equal to <tt><i>lookupValue</i></tt>, or null
	 * if this unordered set does not contain such an element.
	 */
    public Object get(Object lookupValue)
    {
        return ((ooHashSetPersistor)getCollectionPersistor()).get(lookupValue);
    }

	/**
	 * Initializes a scalable-collection iterator to find the elements of this
	 * unordered set. </p>
	 *
	 * @return		A scalable-collection iterator for finding the elements of this
	 * unordered set. The iterator finds the
	 * elements in an undefined order.
	 *
	 * <p>If you want to call any methods that are specific to Objectivity
	 * for Java scalable-collection iterators, you should cast the returned iterator
	 * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
	 */
    public Iterator iterator()
    {
        return getCollectionPersistor().iterator();
    }

	/**
	 * Sets the maximum number of hash buckets per container for this
	 * unordered set. </p>
	 *
	 * @param		<tt><i>max</i></tt>	The maximum number of
	 * hash buckets for this unordered set that can be stored in a single
	 * container.
	 */
    public void maxBucketsPerContainer(int max)
    {
        ((ooHashSetPersistor)getCollectionPersistor()).maxBucketsPerContainer(max);
    }

	/**
	 * Removes the specified object from this unordered set.
	 *
	 * <p>This method is equivalent to {@link #remove <tt>remove</tt>}.</p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be removed.</p>
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 */
   public boolean ooRemove(Object object)
   {
        return remove(object);
   }

	/**
	 * Removes the specified object from this unordered set. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be removed.</p>
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 *
	 * @see #removeAll(Collection)
	 * @see #retainAll(Collection)
	 */
    public boolean remove(Object object) {
        return getCollectionPersistor().remove(object);
    }

	/**
	 * Removes all elements of the specified collection from this
	 * unordered set. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements are to be
	 * removed from this unordered set.</p>
	 *
	 * @return		True if any elements were removed; otherwise, false.</p>
	 *
	 * @see #remove(Object)
	 * @see #retainAll(Collection)
	 */
    public boolean removeAll(Collection collection)
    {
        Object obj;
        if (collection == this)
        {
            if (isEmpty())
            return false;
            else
            return getCollectionPersistor().removeAll((ooCollection) collection);
            }

    	boolean changed = false;
    	Iterator itr;

    	if (collection instanceof ooCollection)
    	    itr = ((ooCollection)collection).keyIterator();
    	else
    	    itr = collection.iterator();
    	while ((obj = itr.next()) != null)
    	{
    		if (ooRemove(obj))
    			changed = true;
    	}
    	return changed;
   }

	/**
	 * Retains all elements of this unordered set that are also in the
	 * specified collection, deleting all other elements. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements
	 * are to be retained in this unordered set.</p>
	 *
	 * @return		True if any elements were removed; otherwise, false.</p>
	 *
	 * @see #remove(Object)
	 * @see #removeAll(Collection)
	 */
    public boolean retainAll(Collection collection) {
        if (collection instanceof ooCollection && ((ooCollection) collection).comparator() == null)
            return getCollectionPersistor().retainAll((ooCollection) collection);
        else
        {
        	boolean changed = false;
	        Iterator itr = keyIterator();
        	while (itr.hasNext())
		        if (!collection.contains(itr.next()))
		{
			itr.remove();
			changed = true;
		}
	    return changed;
	    }
    }
}
