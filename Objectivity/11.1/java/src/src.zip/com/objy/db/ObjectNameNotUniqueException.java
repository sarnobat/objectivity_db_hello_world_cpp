/*
 * @(#)ObjectNameNotUniqueException.java
 * 
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

/**
 * Signals an attempt to assign a root name to an object when that name is
 * already assigned to an object in the same database or federated database.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching checked exceptions.
 */
public class   ObjectNameNotUniqueException
       extends ODMGException
{
	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching checked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ObjectNameNotUniqueException()
        { super() ; }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching checked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ObjectNameNotUniqueException(String msg)
        { super(msg) ; }    
}


