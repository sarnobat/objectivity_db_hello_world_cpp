package com.objy.db.internal.configuration;

import com.objy.db.internal.tools.ToolRegistry;

/**
 * Uniform tool interface manager.  Used to specify alternate providers which supply parameters 
 * to tools.
 * 
 *
 */
public class Manager {
    private static Manager smInstance;
    private long mManagerPtr;
 
    static
    {
        ToolRegistry.init();
    }

    /**
     * Get an instance to the Uniform tool interface Manager
     * @return Uniform tool interface manager
     */
    public static Manager getInstance()
    {
        if(smInstance == null)
        {
            smInstance = new Manager(Binding.construct()); //define this to call native
        }
        return smInstance;        
    }

     /**
     * Gets the ParameterValueGroup associated to the tool specified by the provider.  
     * Verification of the values will occur when retrieving the values.
     * @param specification Specification of the tool
     * @return ParameterValueGroup - Collection of parameter key/Values
     */
    public ParameterValueGroup getValues(Specification specification)
    {
        return new ParameterValueGroup(Binding.getValues(mManagerPtr, specification.mSpecificationPtr));       
    }

    /**
     * Gets the ParameterValueGroup associated to the tool specified by the provider.  
     * Verification of the values will occur when retrieving the values.
     * @param specification Specification of the tool
     * @return ParameterValueGroup - Collection of parameter key/Values
     */    
    public ParameterValueGroup getValues(String specificationName)
    {
        return new ParameterValueGroup(Binding.getValues(mManagerPtr,specificationName));       
    }
    /*
        // Parameter item methods
        const ParameterItem* getParameterItem(const char* name) const;
        const ParameterItem* getParameterItem(const char* name, ParameterItem::ItemType expectedType) const;

        // Validator methods
        const ParameterValidator* getValidator(const char* name) const;
        const ParameterValidator* getValidator(size_t index) const;
        size_t getNumberofValidators() const;

        // Provider methods
        void registerProvider(ValueProvider* valueProvider);
        size_t getNumberOfProviders() const;
        ValueProvider* getProvider(size_t index);
        ValueProvider* getProvider(const char* name);
        void enableProvider(const char* providerName, const configuration::ParameterValueGroup& args);
        void enableProvider(const char* providerName, const char* args);
        void enableProvider(const char* providerName, int argc, const char* argv[]);

        // Specification methods
        void registerSpecification(Specification* specification);
        size_t getNumberOfSpecifications() const;
        const Specification* getSpecification(const char* specificationName) const;
        void getValues(const char* specificationName, configuration::ParameterValueGroup& values);
        void getValues(const Specification* specification, configuration::ParameterValueGroup& values);

        // Enumeration definition methods
        void registerEnumDefinition(ParameterEnumDefinition* enumDefinition);
        ParameterEnumDefinition* getEnumDefinition(const char* enumDefinitionName) const;

        // Documentation Methods
        const char* composeHelpMessage(const char* providerName, 
                                       const char* specificationName, 
                                       size_t screenWidth = 80, 
                                       size_t maxParameterNameWidth = 20) const;
        const char* composeUsageMessage(const char* providerName, 
                                        const char* specificationName) const;

        const char* getRepresentation(const ParameterItem& item) const;
        const char* getRepresentation(const ParameterValueItem& item) const;

        // Will reset all providers to their pre-enablement state. All specifications and enum definitions
        // will be removed as well. This should only be used by test code
        void reset();
     */


    // Prevent external construction or destruction
    private Manager()
    {

    }
    
    
    private Manager(long managerPtr)
    {
        mManagerPtr = managerPtr;
    }

    // Prevent copy construction or assignment
    private Manager( Manager other)
    {

    }


    //void registerDefaultProviders();
    /*static void shutdown()
    {

    }*/
    
    private static class Binding
    {
        public static native long construct();
        public static native long getValues(long managerPtr, String specificationName);
        public static native long getValues(long managerPtr, long specification);
        
    }

    /*void addValidator(ParameterValidator* validator);
        void addParameterItem(ParameterItem* item);	
        void addParameterItemSpecialization(ParameterItem* specialization);
        void loadDefaultConfigurationRegistry();*/


}
