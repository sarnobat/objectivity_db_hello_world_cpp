/*
 * @(#)ExceptionInfo.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Defines behavior shared by all exception information objects.
 *
 * <p>An exception information object contains descriptive information
 * about a runtime exception, including:
 * <ul>
 * <li>The severity level of the exception.
 * <li>The ID for the type of exception.
 * <li>A description of the error condition that caused the exception to be
 * thrown.
 * </ul>
 *
 * <a name="Obtaining"><h2>Obtaining Exception Information Objects</h2>
 *
 * <p>When an Objectivity for Java operation results in Objectivity/DB errors,
 * Objectivity for Java traps those errors and throws an exception.
 * The exception is an instance of
 * <a href="../ObjyException.html"><tt>ObjyException</tt></a>,
 * <a href="../ObjyRuntimeException.html"><tt>ObjyRuntimeException</tt></a>,
 * or one of
 * their derived classes. The exception object has a vector of exception
 * information objects, one for each Objectivity/DB error that
 * occurred. The order of exception information objects in the vector is
 * the order in which the Objectivity/DB kernel reported the errors.
 *
 * <p>You obtain exception information objects by calling the
 * <tt>errors</tt> method of an exception object; you never create an
 * instance of this class directly.  You call methods of the exception
 * information object to get the error's level of
 * severity, identifying number, and descriptive message.
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 */
public interface ExceptionInfo 
{
	/**
	 * Gets the severity level of the error.</p>
	 *
	 * @return		The severity level, which indicates the type of error
	 * that caused the exception to be thrown; one of the following
	 * constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>WARNING</tt>
	 *		<dd>An abnormal event occurred. Your application should notify
	 * 		the user of the condition; no other action is required.
	 *  <dt><tt>USER_ERROR</tt>
	 * 		<dd>Objectivity for Java detected a programmer error,
	 * 		such as passing an invalid parameter to a public method of the
	 *		interface.
	 *  <dt><tt>SYSTEM_ERROR</tt>
	 * 		<dd>Objectivity/DB detected a system error. The error
	 * 		might actually have been caused by a programmer error that was
	 *		not detected by the programming interface.  Without in-depth
	 * 		analysis, it is often difficult to tell whether an error
	 * 		is attributable to the programmer or to Objectivity/DB.
	 *  <dt><tt>FATAL_ERROR</tt>
	 *		<dd>Objectivity/DB detected an unrecoverable internal
	 * 		inconsistency that might already have caused data corruption.
	 *		Your application should abort the transaction and shut down as
	 *		quickly as possible.
     * </dd></dl></dl>
	 */
    int getLevel() ;
        
	/**
	 * Gets the ID for the type of error that occurred.</p>
	 *
	 * @return		The ID for the type of error that occurred.
	 */
    long getId() ;
        
	/**
	 * Gets the description of the error condition.</p>
	 *
	 * @return		The description of the error condition.
	 */
    String getMessage() ;
        
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    boolean isUserError() ;      
}

