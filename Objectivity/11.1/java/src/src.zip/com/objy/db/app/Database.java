/*
 * @(#)Database.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

import com.objy.db.DatabaseOpenException ;
import com.objy.db.DatabaseNotFoundException ;
import com.objy.db.DatabaseClosedException ;
import com.objy.db.ObjectNameNotUniqueException ;
import com.objy.db.ObjectNameNotFoundException ;

import com.objy.db.iapp.PConnection ;
import com.objy.db.iapp.PooObj ;

import com.objy.pm.Access ;

/**
 * Represents an ODMG database.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>The ODMG standard does not include the concept of a federation of 
 * databases; as 
 * a consequence, an ODMG database corresponds to an Objectivity/DB federated
 * database in which all persistent objects are stored in the default
 * database.
 *
 * <p>Methods of <tt>Database</tt> allow you to open and close a database and
 * to store and look up persistent objects by their root names.
 *
 * <p><b>Note: </b>Your application should work with an instance of this class <i>only</i> if
 * it requires ODMG compliance; otherwise, it should work with 
 * <a href="Connection.html">connection objects</a> instead.
 * For additional information about ODMG applications, see
 * <A HREF="../../../../../guide/jgdODMGApplication.html#_top_">
 * Conforming to the ODMG Standard</A>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr valign=top WIDTH="1%"><td><a name = "ooMode"><b>Open modes</b> <i>(ODMG)</I><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how a connection to a federated database is opened.</td>
 * <td VALIGN="top">
 *     <a href="#notOpen">notOpen</a><br>
 *     <a href="#openReadOnly">openReadOnly</a><br>
 *     <a href="#openReadWrite">openReadWrite</a>
 *     </td>
 * </TABLE></p>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Opening&nbsp;and&nbsp;Closing&nbsp;Databases</B></TD>
 *
 * <TD><A HREF="#open(java.lang.String, int)">open(String, int)</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#isOpen()">isOpen()</A><BR>
 * 	<A HREF="#close()">close()</A> <i>(ODMG)</I>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information</B></TD>
 * <TD><A HREF="#current()">current()</A><BR>
 * 	<A HREF="#getConnection()">getConnection()<a>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 * <TD><A HREF="#isOpen()">isOpen()</A><BR>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Working&nbsp;With&nbsp;Named&nbsp;Roots</B></TD>
 * <TD><A HREF="#bind(java.lang.Object, java.lang.String)">bind(Object, String)</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#unbind(java.lang.String)">unbind(String)</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#lookup(java.lang.String)">lookup(String)</A> <i>(ODMG)</I><BR>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Static&nbsp;Utilities</B></TD>
 * <td><A HREF="#open(java.lang.String, int)">open(String, int)</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#current()">current()<BR></A>
 * </TD></TR>
 *
 * </TABLE>
 *
 */
 final public class Database
{
    private transient PConnection persistor ;
     
	/** <i>(ODMG)</I> Open mode: The database is not open; transactions may not be created. */
    public static final int notOpen = oo.notOpen ;
    
	/** <i>(ODMG)</I> Open mode: The database is open for read-only access. */
    public static final int openReadOnly  = oo.openReadOnly ;
    
	/** <i>(ODMG)</I> Open mode: The database is open for read/write access. */
    public static final int openReadWrite = oo.openReadWrite ;
    
	/**
	 * <i>(ODMG)</I> Not supported. Do not use this constant.
	 */
    public static final int openExclusive = oo.openExclusive ;
    
    private Database() { }
    
	/**
	 * Reserved for internal use; to create an ODMG database object, call 
	 * the static method
	 * <a href="#open(java.lang.String, int)"><tt>Database.open</tt></a>.
	 *
	 * <p>You should not use this constructor.
	 */
    public Database(PConnection persistor) 
        { this.persistor = persistor ; }
    
    /**
     * <i>(ODMG)</I> Opens a connection to the specified federated database
	 * and returns the ODMG database object associated with the connection.
     *
     * <p> You must open a connection <i>before</i> creating any
     * <a href="Transaction.html">transactions</a>
     * (or <a href="Session.html">sessions</a>)
     * that interact with the federated database.
     *
     * <p><b>Note: </b>There can be only <i>one</i> instance of the
     * <tt>Database</tt> class in an application.
     *
     * <p>This method creates a
 	 * <a href="Connection.html">connection</a> object through
	 * which your application interacts with the federated database.  You can
	 * obtain the connection object by calling the
	 * <a href ="#getConnection()"><tt>getConnection</tt></a> method of the returned
	 * ODMG database object.</p>
     *
     * @param 	 bootFilePath The pathname of the
     * boot file of the federated database to which a connection is
     * being opened. If this parameter is an empty string (<tt>""</tt>) or
     * null,
     * the value of the <tt>OO_FD_BOOT</tt> environment variable is used
     * as the boot file path; however, using <tt>OO_FD_BOOT</tt> is not recommended 
     * because doing so can lead to unexpected results.</p>
     *
     * @param 	 mode	The open mode for the new ODMG database
	 * object; one of the following constants defined in this class (and also in
	 * the <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
	 *  <dt><tt>openReadOnly</tt><dd>Open the database for
	 * read-only access.</dd>
	 *  <dt><tt>openReadWrite</tt><dd>Open the database for
	 * read/write access.</dd>
	 * </dd></dl></dl>
	 *
     * <p>The open mode limits the open mode of each
     * <a href="Session.html">session</a>
     * object created after the database is
	 * opened.  As a consequence, it also limits the lock modes of any
     * storage objects or persistent objects that belong to those sessions.
     * A database open mode of <tt>openReadWrite</tt> permits session
	 * open modes of
     * <tt>openReadWrite</tt> or <tt>openReadOnly</tt>;
     * a database open mode of <tt>openReadOnly</tt>
     * permits the session open mode <tt>openReadOnly</tt>.</p>
     *
     * @return		The newly created ODMG database object.</p>
	 *
     * @exception	DatabaseOpenException   If a connection to the
	 * federated database is already open.</p>
     *
     * @exception	DatabaseNotFoundException If the federated database
     * doesn't exist.</p>
     *
     * @see #close
     * @see #isOpen
     */
    public static Database open(String bootFilePath, int mode)  // ODMG
        throws DatabaseOpenException, DatabaseNotFoundException
    {
        Connection connection = Connection.open(bootFilePath, mode);
        return connection.getDatabase() ;
    }
  
    /**
     * Tests whether the connection between the associated connection object
     * and the federated database is open.</p>
     *
     * @return         True if the connection is open; otherwise false.</p>
     *
     * @see #open(String, int)
     * @see #close
     */
    public boolean isOpen()
        { return persistor().isOpen() ; }
        
    /**
     * Gets this application's ODMG database object.</p>
     *
     * @return		The current ODMG database object, or null if there is no
     * such object (because the static method
     * <a href="#open(java.lang.String, int)"><tt>Database.open</tt></a> has not been
     * called).
     */
    public static Database current()
        { return Access.connection_getCurrent().getDatabase() ; }
        
	/**
	 * Gets the connection associated with this ODMG database object.</p>
	 *
	 * @return		The connection object associated with this ODMG database object.
	 */
    public Connection getConnection()
        { return persistor().getConnection() ; }
        
    /**
     * <i>(ODMG)</I> Closes the connection associated with this ODMG database object.
     *
     * <p>This method terminates all sessions.
     * It should be called before exiting from an application.</p>
     *
     * @exception       DatabaseClosedException   If
     * this connection object is already closed.</p>
     *
     * @exception       com.objy.db.TransactionInProgressException  If any transaction is
     * open without terminating any sessions and have the database open.</p>
     *
     * @see #isOpen
     * @see #open(String, int)
     */
    public void close() throws DatabaseClosedException
        { persistor().close() ; }
        
    /**
     * <i>(ODMG)</I> Names the specified object with the specified root name in the
	 * connected federated database.
	 *
     * <p>Giving an object a root name makes the object persistent. The named object
     * is made persistent immediately; all transient objects reachable from
     * the named object are made persistent on transaction commit.
     *
     * <p>This method can be called only during a transaction.</p>
	 *
     * @param 	 object  The object being named.</p>
     *
     * @param 	 name    The root name for the object.
     * This name can be any valid Java string and must be unique
     * within the root dictionary of the federated database.</p>
     *
     * @exception   ObjectNameNotUniqueException If the name already exists in the root
     * dictionary.</p>
     *
     * @see #unbind(String)
     * @see #lookup(String)
     */
    public void bind(Object object, String name) throws ObjectNameNotUniqueException
        { persistor().bind(object, name) ; }

	/**
     * <i>(ODMG)</I> Removes the specified root name from the connected federated database.
     *
     * <p>This method can be called only during a transaction.</p>
	 *
     * @param 	 name    The root name to be removed.</p>
	 *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
	 */
    public void unbind(String name) throws ObjectNameNotFoundException
        { persistor().unbind(name) ; }
        
	/**
     * <i>(ODMG)</I> Finds the object with the specified root name in the
	 * connected federated database.
	 *
     * <p>This method can be called only during a transaction.</p>
	 *
     * @param 	 name    The root name of the object.</p>
	 *
     * @return      The object with the specified root name. If that object
     * is the root of a graph of objects, only the root object is 
     * retrieved.</p> 
	 *
     * @exception   ObjectNameNotFoundException If the name doesn't exist in the root
     * dictionary.</p>
     *
     * @see #bind(Object, String)
	 */
    public Object lookup(String name) throws ObjectNameNotFoundException
        { return persistor().lookup(name) ; }
                
    private PConnection persistor()
        { return persistor ; }        
}
