/*
 * @(#)PersistentEvents.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.objy.db.iapp;

/**
 * Defines the behavior for persistent objects that can receive notifications
 * of
 * <a href="../../../../../guide/jgdDefiningClasses.html#PersistentEvents">
 * persistent events</a>.
 *
 * <p>To define a persistence-capable class with the minimal public API and
 * the ability to respond to persistent events</a>,
 * you define a class that
 * implements the <tt>PersistentEvents</tt> interface. Your class must
 * provide mechanisms for
 * getting and setting an object's persistor and for
 * handling persistent events.
 * If you desire, you can also implement
 * public or private methods to perform additional Objectivity/DB operations;
 * see
 * <a href="../../../../../guide/jgdDefiningClasses.html#Implementing Persistence Behavior">
 * Implementing Persistence Behavior</a>.
 *
 * <h2>Related Classes and Interfaces</h2>
 *
 * <p>Alternative ways to define a persistence-capable class are:
 * <ul>
 * <li>Define a descendant class of
 * <a href="../app/ooObj.html"><tt>ooObj</tt></a>.
 * The class inherits default implementations for public methods that get
 * and set an object's persistor, that perform Objectivity/DB operations
 * explicitly, and that handle persistent events. You do not need to
 * implement any persistence behavior unless you want to modify the default
 * implementation.</P>
 *
 * <li>Implement the
 * <a href="IooObj.html"><tt>IooObj</tt></a> interface,
 * which provides public methods to get and set an object's
 * persistor, to perform Objectivity/DB operations explicitly, and to handle
 * persistent events. You must implement all these methods.</p>
 *
 * <li>Implement the
 * <a href="Persistent.html"><tt>Persistent</tt></a>
 * interface, which
 * has public methods to get and set the persistor; you
 * need to implement these methods. If you desire, you can also implement
 * public or private methods to perform Objectivity/DB operations
 * explicitly.</p>
 * </ul>
 *
 * <p>For additional information, see
 * <a href="../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>.
 *
 */
public interface PersistentEvents
       extends   Persistent
{
	/**
     * Handles an activate event, which is triggered when this persistent
     * object's data is fetched from the federated database.
     *
     * <p>Notification of an activate event is sent to a persistent
	 * object <i>after</i> the object's data is fetched from the federated 
     * database.  An activate event is
	 * triggered after execution of the <tt>fetch</tt> or
	 * <tt>markModified</tt></a> method  of the
     * object's persistor if the object has 
	 * not yet been fetched.</p>
     *
     * @param 	 info	An
 	 * <a href="ActivateInfo.html">activate information object</a>
	 * containing information about any exceptions that occurred
	 * during the fetch operation.
     */
    void activate(ActivateInfo info) ;

    /**
     * Handles a deactivate event, which
     * is triggered when the session
     * to which this persistent object belongs is
     * committed or aborted, provided deactivation has been enabled for this object.
     *
     * <p> When you override this method in a persistence-capable class that implements
     * either the <tt>PersistentEvents</tt> or <tt>IooObj</tt> interface, 
     * you must also explicitly
     * enable the method for each object of the class. Enabling this method for an object
     * ensures that the object will survive until the method is called, preventing
     * the object from being garbage collected first. The <tt>deactivate</tt> method 
     * is called for an object only if you have explicitly imported the 
     * class <tt>com.objy.pm.Access</tt> and called 
     * <tt>Access.setInterfaceOverride(<i>persistor</i>, true)</tt>, 
     * where <i><tt>persistor</tt></i> is the object's persistor.
     *
     * <p>Notification of the deactivate event is sent to objects
	 * belonging to a session <i>after</i> the session's current transaction
	 * is committed or aborted.</p>
	 *
	 * <p><b>Note: </b>If you implement this method in a persistence-capable 
     * class, your implementation must not perform any Objectivity/DB 
     * operations (because the transaction has been terminated).
	 *
     * @param 	 info    A
 	 * <a href="DeactivateInfo.html">deactivate information object</a>
     * specifying the reason why deactivation occurred.
     */
    void deactivate(DeactivateInfo info) ;

    /**
     * Handles a pre-write event, which is triggered when this persistent
	 * object's data is being written to its session's Objectivity/DB cache.
	 *
     * <p>Notification of a pre-write event is sent to a persistent
	 * object <i>before</i> the object is written to the cache. See
	 * <a href="../../../../../guide/jgdCache.html#Updating the Objectivity/DB Cache">
	 * Updating the Objectivity/DB Cache</a>. </p>
     *
     * @param 	 info    A
 	 * <a href="PreWriteInfo.html">pre-write information object</a>
     * specifying the reason why the object is being written.
    */
    void preWrite(PreWriteInfo info) ;
}
