/*
 * @(#)ooTreeListX.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.lang.reflect.Array;
import java.util.AbstractList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import com.objy.db.iapp.Persistent;
import com.objy.pm.ooTreeListXPersistor;

/**
 * Persistence-capable class for lists of persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Lists</h2>
 *
 * <p>A <i>list</i> is a scalable ordered collection; unlike a set, a list
 * can contain duplicate elements and null elements.
 * An element of a list can be located by position, given as
 * a zero-based index.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Properties of Scalable Ordered Collections">
 * Properties of Scalable Ordered Collections</a>.</p>
 *
 * Methods defined in this class add elements to the list, or insert elements into it, 
 * at an indicated position.  The elements of a
 * list are kept in the order in which they were added or inserted.
 * Note, however, that an element's index may change as
 * elements are inserted in front of it in the list. For example, the element 
 * that was at 
 * index 2 will be at index 4 after two elements are added to the front of 
 * the list. </p>
 * 
 * The order of elements in a list is determined entirely the operation that added
 * them; consequently, a list does not have an associated comparator.</p>
 *
 * <p><h2>Working With a List</h2>
 *
 * <P>A list is transient when it is created; you can make it persistent
 * in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created a list, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a List">
 * Building a List</a></p>
 *
 * <li>Look up particular elements in the list as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Lists">
 * Individual Lookup in Lists</a></p>
 *
 * <li>Iterate over the list as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Elements of a List or Set">
 * Finding the Elements of a List or Set</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make a list persistent before you call
 * any methods defined by the <tt>ooTreeListX</tt>, <tt>ooTreeBasedCollection</tt>, or 
 * <tt>ooCollection</tt> 
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.</p>
 * 
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of persistent 
 * objects: 
 
 * <ul>
 * <li><a href="ooHashSetX.html"><tt>ooHashSetX</tt></a> represents
 * an <i>unordered</i> collection of persistent objects <i>with no duplicate 
 * elements</i>.</p>
 *
 * <li><a href="ooTreeSetX.html"><tt>ooTreeSetX</tt></a> represents
 * a <i>sorted</i> collection of persistent objects <i>with no duplicate 
 * elements</i>. 
 * </ul>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr> <td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 *      <td>
 *      <a href="#ooTreeListX()">ooTreeListX()</a><br>
 *      <a href="#ooTreeListX(int, boolean)">ooTreeListX(int, boolean)</a><br>
 *      </td></tr>
 * <tr> <td VALIGN="top" WIDTH="1%"><b>Adding,&nbsp;Removing,&nbsp;and Changing&nbsp;Elements</b></td>
 *      <td>
 *      <a href="#add(java.lang.Object)">add(Object)</a><br>
 *      <a href="#add(int, java.lang.Object)">add(int, Object)</a><br>
 *      <a href="#addFirst(java.lang.Object)">addFirst(Object)</a><br>
 *      <a href="#addLast(java.lang.Object)">addLast(Object)</a><br>
 *      <a href="#addAll(java.util.Collection)">addAll(Collection)</a><br>
 *      <a href="#addAll(int, java.util.Collection)">addAll(int, Collection)</a><br>
 *      <a href="#remove(int)">remove(int)</a><br>
 *      <a href="#remove(java.lang.Object)">remove(Object)</a><br>
 *      <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *      <a href="#removeAll(java.util.Collection)">removeAll(Collection)</a><br>
 *      <a href="#removeRange(int, int)">removeRange(int, int)</a><br>
 *      <a href="#retainAll(java.util.Collection)">retainAll(Collection)</a><br>
 *      <a href="#set(int, java.lang.Object)">set(int, Object)</a>
 *      </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 *      <td>
 *      <a href="#listIterator()">listIterator()</a><br>
 *      <a href="#listIterator(int)">listIterator(int)</a><br>
 *      <a href="#toArray()">toArray()</a><br>
 *      <a href="#toArray(java.lang.Object[])">toArray(Object[])</a>
 *      </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Indexes</b></td>
 *     <td>
 *     <a href="#indexOf(java.lang.Object)">indexOf(Object)</a><br>
 *     <a href="#indexOf(java.lang.Object, int)">indexOf(Object, int)</a><br>
 *     <a href="#lastIndexOf(java.lang.Object)">lastIndexOf(Object)</a><br>
 *     <a href="#lastIndexOf(java.lang.Object, int)">lastIndexOf(Object, int)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 *     <td>
 *     <a href="#contains(java.lang.Object)">contains(Object)</a><br>
 *     <a href="#containsAll(java.util.Collection)">containsAll(Collection)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Views</b></td>
 *     <td>
 *     <a href="#subList(int, int)">subList(int, int)</a><br>
 *     </td></tr> 
 * </table>
 */
final public class ooTreeListX extends ooTreeBasedCollection implements List
{
    /**
     * Reserved for internal use.
     */
    public transient int _numberOfElements;
    public transient boolean _useShortRefs;

	/**
	 * Constructs an empty list with default storage characteristics. 
	 */
	public ooTreeListX()
    {
      _numberOfElements = 5;
      _useShortRefs = false;
    }

	/**
	 * Constructs an empty list with the specified storage characteristics. </p>
	 *
	 * @param 	 numberOfElements Expected number of elements to be accommodated by
	 * the new list. The specified value serves as a hint to help Objectivity/DB optimize the
	 * amount of space it reserves for the array associated with the root node in the
	 * list�s B-tree.
	 * 
	 * You can specify 0 to request the maximum amount space be reserved. 
	 * The maximum is equal to the size of one storage page in the container in which
	 * the new list is clustered.</p>
	 * 
	 * @param 	 useShortRefs Specifies how the new list will be linked 
	 * to its elements:
	 * <ul>
	 * <li> Specify false to create a list that is linked to its
	 * elements by standard object identifiers.
	 * <li> (<i>For advanced users only.</i>) Specify true to to create a list that is linked to its
	 * elements by short object identifiers, which are safe to use only with appropriate object placement. 
	 * Specify true only after obtaining technical consultation from Objectivity.
	 * </ul>
	 * 
	 * 
	 * 
	 */
	public ooTreeListX(int numberOfElements, boolean useShortRefs)
    {
        _numberOfElements = numberOfElements;
        _useShortRefs = useShortRefs;
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this
     * list. </p>
     *
     * @return      A scalable-collection iterator for finding the elements of this
     * list. The iterator finds the
     * elements in their order in the list.
     *
     * <p>If you want to call any methods that are specific to Objectivity
     * for Java scalable-collection iterators, you should cast the returned iterator
     * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
     */
    public ListIterator listIterator()
    {
        return getTreeBasedCollectionPersistor().iterator();
    }

    /**
     * Initializes a scalable-collection iterator to find the elements of this
     * list, starting at the specified index. </p>
     *
     * @param 	 index   The index of the first element to
     * be found by the returned iterator.</p>
     *
     * @return      A scalable-collection iterator for finding the elements of this
     * list, starting at <tt><i>index</i></tt>. The iterator finds the
     * elements in their order in the list.
     *
     * <p>If you want to call any methods that are specific to Objectivity
     * for Java scalable-collection iterators, you should cast the returned iterator
     * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
     */
    public ListIterator listIterator(int index)
    {
        ooCollectionIterator itr = getTreeBasedCollectionPersistor().iterator();
        if (itr.goToIndex(index) == null)
        {   // check if index out of bounds
            int size = size();
            if (index < 0 || index > size)
                throw new IndexOutOfBoundsException("Index " + index + " is out of bounds 0:" + size);
        }
        return itr;
    }

    /**
     * Adds the specified object at the end of this list. </p>
     *
     * @param 	 object	The element to be added;
     * must be an instance of a persistence-capable class.
     * If <tt><i>object</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @return		True if an element was added; otherwise, false.</p>
     *
     * @see #ooAddAll(ooCollection)
     * @see #ooRemove(Object)
     */
    public boolean add(Object object) {
         return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).add(object);
    }
    
    /**
     * Inserts the specified object into this list at the specified index.
     *
     * <p>This method inserts the new element, increasing the size of the list by one and
     * effectively incrementing the indexes of all subsequent elements.  For example, if
     * <tt><i>index</i></tt> is 2, this method inserts the new element before the third
     * existing element.  The new element now has index 2, and what used to be the third
     * element is now the fourth element (and has index 3). </p>
     *
     * @param 	 index   The index where the new element
     * is to be inserted.</p>
     *
     * @param 	 element The object to be inserted at the specified index;
     * must be an instance of a persistence-capable class.
     * If <tt><i>element</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @see         #addFirst(Object)
     * @see         #addAll(Collection)
     * @see         #set(int, Object)
     * @see         #remove(int)
     */
    public void add(int index, Object element)
    {
        ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).add(index, element);
    }

    /**
     * Adds all elements in the specified collection to the end of this
     * list. </p>
     *
     * @param 	 collection  The collection
     * whose elements are to be added to this list. Every element of
     * <tt><i>collection</i></tt> must be an instance of a
     * persistence-capable class. If any element is transient, this
     * method makes it persistent.  Note: <tt><i>collection</i></tt> must not
     * be this list; that is, you cannot use this method to add another copy
     * of this list's elements to this list.</p>
     *
     * @return      True if any elements were added; otherwise, false.
     */
    public boolean addAll(Collection collection)
    {
        if (collection instanceof ooCollection)
            return getTreeBasedCollectionPersistor().addAll((ooCollection)collection);
        Iterator itr = collection.iterator();
        boolean mod = false;
        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

    /**
     * Inserts all elements in the specified collection of objects into this list
     * at the specified index.
     *
     * <p>This method inserts the new element, increasing the size of the list and
     * effectively incrementing the indexes of all subsequent elements. </p>
     *
     * @param 	 index   The index where the first of the
     * new elements is to be inserted.</p>
     *
     * @param 	 collection  The collection whose elements are to
     * be added to this list.  Every element of
     * <tt><i>collection</i></tt> must be an instance of a
     * persistence-capable class. If any element is transient, this
     * method makes it persistent. Note: <tt><i>collection</i></tt> must not
     * be this list; that is, you cannot use this method to insert another copy
     * of this list's elements into this list.</p>
     *
     * @return      True if any elements were added; otherwise, false.</p>
     *
     * @see         #add(int, Object)
     * @see         #addFirst(Object)
     */
    public boolean addAll(int index, Collection collection)
    {
        if (collection instanceof ooCollection)
            return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).addAll(index, (ooCollection)collection);
        Iterator itr = collection.iterator();
        int stop = collection.size() + index;
        for (int i = index; i < stop; i++)
            add(i, itr.next());
        return true;
    }

    /**
     * Adds the specified object to the beginning of this list.
     *
     * <p>The new element becomes the first element of this list,
     * effectively incrementing the indexes of all existing elements. </p>
     *
     * @param 	 element  The object to be added;
     * must be an instance of a persistence-capable class.
     * If <tt><i>object</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @see         #add(int, Object)
     * @see         #addAll(Collection)
     */
    public void addFirst(Object element)
    {
        add(0, element);
    }

    /**
     * Adds the specified object to the end of this list.
     *
     * <p>The new element becomes the last element of this list. </p>
     *
     * @param 	 element  The object to be added;
     * must be an instance of a persistence-capable class.
     * If <tt><i>object</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @see         #add(int, Object)
     * @see         #addAll(Collection)
     */
    public void addLast(Object element)
    {
        ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).addLast(element);
    }

    /**
     * Searches forward in this list (from the beginning)
     * for the first element (or key)
     * that is equal to the specified object.
     *
     * <p>This method compares
     * each element in the list with <tt><i>object</i></tt>.
	 * Searching stops when a matching element is found;
     * if more than one element matches, this method finds the one closest to the beginning
     * of the list. </p>
     *
     * @param 	 object  The object whose index is to be
     * found.</p>
     *
     * @return      The (zero-based) index of the first element of this list
     * that is equal to (or
     * whose key is equal to) <tt><i>object</i></tt>. If no such element
     * is found, this method returns -1.</p>
     *
     * @see #lastIndexOf(Object, int)
     */
    public int indexOf(Object object) {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).indexOf(object, 0, false);
    }
    
    /**
     * Searches forward in this list, starting at the specified index, for
     * the first element (or key)
     * that is equal to the specified object.
     *
     * <p>This method compares
     * each element in this list with <tt><i>object</i></tt>. 
	 * Searching stops when a matching element is found;
     * if more than one element matches, this method finds the one closest to the beginning
     * of the collection (but at or after the starting index). </p>
     *
     * @param 	 object  The object whose index is to be
     * found.</p>
     *
     * @param 	 index   The zero-based index at which search should
     * start.</p>
     *
     * @return      The index of the first element in this list
     * at or after the index <tt><i>index</i></tt>, that is equal to (or
     * whose key is equal to)
     * <tt><i>object</i></tt>. If no such element is found, this method
     * returns -1.</p>
     *
     * @see #lastIndexOf(Object, int)
     */
    public int indexOf(Object object, int index) {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).indexOf(object, index, true);
    }
    
    /**
     * Searches backward in this list, starting at the end, for an element
     * (or key) that is equal to the specified object.
     *
     * <p>This method compares
     * each element in this list with <tt><i>object</i></tt>. 
	 * Searching stops when a matching element is found;
     * if more than one element matches, this method finds the one closest to the end
     * of the collection. </p>
     *
     * @param 	 object  The object whose index is to be
     * found.</p>
     *
     * @return      The index of the last element in this list
     * that is equal to (or
     * whose key is equal to) <tt><i>object</i></tt>. If no such element
     * is found, this method returns -1.</p>
     *
     * @see #indexOf(Object, int)
     */
    public int lastIndexOf(Object object) {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).lastIndexOf(object, size() - 1, false);
    }

    /**
     * Searches backward in this list, starting at the specified index,
     * to find an element (or key)  that is equal to the
     * specified object.
     *
     * <p>This method compares
     * each element in this list with <tt><i>object</i></tt>. 
	 * Searching stops when a matching element is found;
     * if more than one element matches, this method finds the one closest to the end
     * of the collection (but at or before the starting index). </p>
     *
     * @param 	 object  The object whose index is to be
     * found.</p>
     *
     * @param 	 index   The index at which search should
     * end.</p>
     *
     * @return      The index of the last element of this list,
     * at or before the index <tt><i>index</i></tt>, that is equal to (or
     * whose key is equal to)
     * <tt><i>object</i></tt>. If no such element is found, this method
     * returns -1.</p>
     *
     * @see #indexOf(Object, int)
     */
    public int lastIndexOf(Object object, int index) {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).lastIndexOf(object, index, true);
    }

    /**
     * Tests whether this list contains the specified
     * object. </p>
     *
     * @param 	 object  The persistent object to be tested for
     * containment in this list.
     *
     *
     * @return      True if this list contains an element equal to
     * the specified element; otherwise, false.</p>
     */
    public boolean contains(Object object) {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).contains(object);
    }

    /**
     * Tests whether this list contains all elements in the
     * specified collection. </p>
     *
     * @param 	 collection  The collection whose elements 
     * are to be tested for containment in this list.
     * If <tt><i>collection</i></tt> is not a persistent collection, it 
     * should contain only persistent objects.  If it 
     * contains any transient object, this method returns false.</p>
     *
     * @return      True if this list contains elements equal to
     * each element of <tt><i>collection</i></tt>; otherwise, false.
     *
     * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the 
     * <tt>equals</tt> method.  Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object identifiers.
     *
     */
    public boolean containsAll(Collection collection) 
    {
        if (collection instanceof ooCollection)
            return getTreeBasedCollectionPersistor().containsAll((ooCollection) collection);
        else
        {
            Iterator itr = collection.iterator();
            while (itr.hasNext())
                if (!contains(itr.next()))
                    return false;
            return true;
        }
    }

    /**
     * Removes the first occurrence of the specified object from this list.
     *
     * <p>This method is equivalent to
     * {@link #remove <tt>remove</tt>}. </p>
     *
     * @param 	 object  The object to be removed.</p>
     *
     * @return      True if an element was removed; otherwise, false.</p>
     */
    public boolean ooRemove(Object object)
    {
        return remove(object);
    }

    /**
     * Removes from this list the first occurrence of each element of the 
     * specified collection. </p>
     *
     * <p>This method compares each persistent object in the specified 
     * collection with the elements of this list.  Any element of this list 
     * that is equal to an element of the specified collection is 
     * removed from this list.
     *
     * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the <tt>equals</tt> method.  
     * Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object 
     * identifiers.</p>
     *
     * @param 	 collection  The collection
     * whose elements are to be removed from this list.
     * If <tt><i>collection</i></tt> is not a persistent collection, any 
     * transient objects it contains are ignored; only persistent objects 
     * are compared with elements of this list.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #remove(int)
     * @see #remove(Object)
     * @see #removeRange(int, int)
     * @see #retainAll(Collection)
     */
    public boolean removeAll(Collection collection)
    {
        return getTreeBasedCollectionPersistor().removeAll((ooCollection) collection);
    }

    /**
     * Removes from this list all elements with indexes in the specified
     * range. </p>
     *
     * @param 	 fromIndex   The index of the first
     * element to be removed.</p>
     *
     * @param 	 toIndex The index after the last element to
     * be removed.</p>
     *
     * @see #remove(int)
     * @see #remove(Object)
     * @see #removeAll(Collection)
     */
    public void removeRange(int fromIndex, int toIndex)
    {
        ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).removeRange(fromIndex, toIndex);
    }

    /**
     * Removes the element at the specified index from this list.
     *
     * <p>This method removes the specified element, reducing the size of the list
     * and effectively reducing the indexes of all subsequent elements.  For example, if
     * <tt><i>index</i></tt> is 2, this method removes the third
     * element.  The new element that used to be the fourth element (with index 3)
     * is now the third element (and has index 2). </p>
     *
     * @param 	 index   The zero-based index of the element
     * to be removed.</p>
     *
     * @return      The object that was removed from this list.
     */
    public Object remove(int index)
    {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).removeObject(index);
    }

    /**
     * Removes the first occurrence of the specified persistent object from 
     * this list. </p>
     *
     * <p>This method compares the specified object to the elements of this 
     * list; the first element that is equal to the specified object is 
     * removed from this list.
     *
     * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the 
     * <tt>equals</tt> method.  Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object 
     * identifiers.</p>
     *
     * @param 	 object  The persistent object to be 
     * removed from this list. Because 
     * all elements of the list are persistent objects, this method returns 
     * false if <tt><i>object</i></tt> is transient.</p>
     *
     * @return      True if an element was removed; otherwise, false. </p>
     *
     * @see #remove(int)
     * @see #removeAll(Collection)
     * @see #removeRange
     * @see #retainAll(Collection)
     */
     public boolean remove(Object object) {
         if (object instanceof Persistent)
             return ((ooTreeListXPersistor) getTreeBasedCollectionPersistor()).remove(object);
         return false;
     }

    /**
     * Retains all elements of this list that are also in the
     * specified collection, removing all other elements. </p>
     *
     * <p>This method compares each element of this list with the persistent 
     * objects in the specified collection. Any element of  
     * this list that is equal to an element of the specified collection is 
     * retained in this list; other elements of this list are removed.
     *
     * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the 
     * <tt>equals</tt> method.  Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object 
     * identifiers.</p>
     *
     * @param 	 collection  The collection whose elements
     * are to be retained in this list.
     * If <tt><i>collection</i></tt> is not a persistent collection, any 
     * transient objects it contains are ignored; only persistent objects 
     * are compared with elements of this list.</p>
     *
     * @return      True if any elements were removed; otherwise, false.</p>
     *
     * @see #remove(int)
     * @see #remove(Object)
     * @see #removeAll(Collection)
     */
    public boolean retainAll(Collection collection) {
        if (collection instanceof ooCollection && ((ooCollection) collection).comparator() == null)
            return getTreeBasedCollectionPersistor().retainAll((ooCollection) collection);
        else
        {
            if (collection == null)
                throw new NullPointerException("The specified collection is null.");            
            boolean changed = false;
            Iterator itr = keyIterator();
            while (itr.hasNext())
                if (!collection.contains(itr.next()))
                {
                    itr.remove();
                    changed = true;
                }
            return changed;
        }
    }
    
    /**
     * Creates an array containing all the elements in this list. </p>
     *
     * @return      A new array containing all of the elements in
     * this list.
     * The returned array contains the
     * elements in their order in this list.
     */
    public Object[] toArray() {
        Object answer[] = (Object[])Array.newInstance(java.lang.Object.class, size()) ;
        Iterator itr = iterator();
        int i = 0;
        while (itr.hasNext())
            answer[i++] = itr.next();
        return answer ;
    }

    /**
     * Returns an array that contains all elements in this list and whose
     * runtime type is that of the specified array.
     *
     * <p>If the specified array is large enough to hold all elements of this
     * list, this method replaces the elements of that array with the
     * elements of this list and returns the updated array.
     * If the array has more elements than this list, the element in the array
     * immediately following the end of the list is set to null.  
	 * Using the null element to
     * determine the length of this list is not recommended, because lists can contain null
     * elements, so the caller cannot be sure that the first null
     * element of the array indicates the end of the list whose elements were
     * stored in the array.
     *
     * <p>If the specified array is smaller than this list, this method
     * allocates a new array with the runtime type of
     * the specified array and the size of this list. It then
     * sets the elements of the new array to the elements of this
     * list and returns the new array. </p>
     *
     * @param 	 a   The array giving the runtime type of the
     * returned array.</p>
     *
     * @return      An array containing the elements of this list.
     * The returned array contains the
     * elements in their order in this list.
     */
    public Object[] toArray(Object[] a) {
        int size = size();
        if (a.length < size)
            a = (Object[])Array.newInstance(a.getClass().getComponentType(), size);
        Iterator itr = iterator();
        for (int i=0; i<size; i++)
            a[i] = itr.next();

        if (a.length > size)
            a[size] = null;
        return a;
    }

    /**
     * Replaces the element at the specified index with the specified object.
     *
     * <p>Replacing an element does not change the size of this list.</p>
     *
     * @param 	 index   The index of the element
     * to be replaced.</p>
     *
     * @param 	 element The object that is to replace
     * the existing element at
     * the specified index; must be an instance of a persistence-capable class.
     * If <tt><i>element</i></tt> is transient, this method makes it
     * persistent.</p>
     *
     * @return      The element previously at the specified index.</p>
     *
     * @see         #add(int, Object)
     * @see         #get
     * @see         #remove(int)
     */
    public Object set(int index, Object element)
    {
        return ((ooTreeListXPersistor)getTreeBasedCollectionPersistor()).setObject(index, element);
    }

	/**
	 * Returns a view of the specified range within this list.</p>
	 * 
	 * <p>If <tt><i>fromIndex</i></tt> and <tt><i>toIndex</i></tt> are equal, the returned sublist is empty.</p>
	 * 
	 * The returned list is backed by this list, so non-structural changes in the returned list 
	 * are reflected in this list, and vice-versa.</p>
	 * 
	 * @param 	 fromIndex   Low endpoint (inclusive) of the range.</p>
	 * @param 	 toIndex   High endpoint (exclusive) of the range.</p>
	 * 
	 * @return      A view of the specified range within this list.</p>
	 */
	public List subList(int fromIndex, int toIndex)
    {
        return new SubList(fromIndex, toIndex);
    }

    private class SubList extends AbstractList {
        private int fromIndex, toIndex;
        private int size = -1;

        SubList(int from, int to) {
            if (from != 0 && to != 0 && from > to)
                throw new IndexOutOfBoundsException("fromIndex > toIndex");
            if (from < 0 || to > ooTreeListX.this.size()) 
                throw new IndexOutOfBoundsException("fromIndex < 0, or toIndex > size of the list");
            this.fromIndex = from;
            this.toIndex = to;
        }

        public Object get(int index) {
            if (!inRange(index))
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
            return ooTreeListX.this.get(index);
        }
        
        public Object set(int index, Object o)
        {
            Object prevObj = null;
            if (inRange(index))
                prevObj = ooTreeListX.this.set(fromIndex+index, o);
            else 
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
            return prevObj;
        }

        public void add(int index, Object o)
        {
            if (inRange(index))
                ooTreeListX.this.add(fromIndex+index, o);
            else 
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
        }
        
        public boolean addAll(int index, Collection c)
        {
            if (!inRange(index))
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
            return ooTreeListX.this.addAll(fromIndex+index, c);
        }

        public Object remove(int index)
        {
            if (inRange(index))
                return ooTreeListX.this.remove(fromIndex+index);
            else 
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");            
        }
        
        public void removeRange(int from, int to)
        {
            if (!inRange(fromIndex+from) || !inRange(fromIndex+to))
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
            ooTreeListX.this.removeRange(fromIndex+from, fromIndex+to);
        }
        
        public Object[] toArray() {
            Object answer[] = (Object[])Array.newInstance(java.lang.Object.class, size()) ;
            Iterator itr = iterator();
            int i = 0;
            while (itr.hasNext())
                answer[i++] = itr.next();
            return answer ;
        }

        public Object[] toArray(Object[] a) {
            int size = size();
            if (a.length < size)
                a = (Object[])Array.newInstance(a.getClass().getComponentType(), size);
            Iterator itr = iterator();
            for (int i=0; i<size; i++)
                a[i] = itr.next();
        
            if (a.length > size)
                a[size] = null;
            return a;
        }

        public List subList(int from, int to)
        {
            if (!inRange(fromIndex+from) || !inRange(fromIndex+to))
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
            return new SubList(fromIndex+from, fromIndex+to);
        }
        
        public ListIterator listIterator(int index)
        {
            if (!inRange2(fromIndex+index))
                throw new IndexOutOfBoundsException("specified index is out of the subList's range");
            ListIterator itr = new EntryIterator(fromIndex+index, toIndex);
            return itr;
        }

        public Iterator iterator()
        {
            return new EntryIterator(fromIndex, toIndex);
        }

        public int size()
        {
            if (size == -1)
            {
                size = 0;
                java.util.Iterator itr = iterator();
                while(itr.hasNext()) {
                    size++;
                    itr.next();
                }
            }
            return size;
        }

        private boolean inRange(int index) {
            return (index >= fromIndex && index < toIndex);
        }
        
        // allows first excluded index. 
        private boolean inRange2(int index) {
            return (index >= fromIndex && index <= toIndex);
        }
    } // End SubList class

    // Iterator class
    private class EntryIterator implements java.util.ListIterator {
        private ooCollectionIterator listItr;
        private int firstIndex = 0;
        private int firstExcludedIndex = 0;
        
        EntryIterator() {
            listItr = (ooCollectionIterator)listIterator();
        }
        
        EntryIterator(int first, int firstExcluded) {
            firstIndex = first;
            firstExcludedIndex = firstExcluded;
            if (firstIndex != 0)
            {
                listItr = (ooCollectionIterator)listIterator(firstIndex);
                listItr.goToIndex(firstIndex);
                listItr.previous();
            }
            else
                listItr = (ooCollectionIterator)listIterator();
        }
        
        public boolean hasNext() {
            return listItr.hasNext() && (listItr.nextIndex() < firstExcludedIndex);
        }
        
        public boolean hasPrevious() {
            return listItr.hasPrevious() && (listItr.previousIndex() >= firstIndex);
        }
        
        public Object next() {
            if (!hasNext())
                return null;
            return listItr.next();
        }
        
        public Object previous() {
            if (!hasPrevious())
                return null;
            return listItr.previous();
        }

        public void remove() {
            listItr.remove();
        }
        
        public int nextIndex() {
            int actualIndex = listItr.nextIndex();
            if (actualIndex < firstExcludedIndex)
                return actualIndex-firstIndex;
            else // return list size if list iterator is at end of list
                return firstExcludedIndex - firstIndex; 
        }
        
        public int previousIndex() {
            int actualIndex = listItr.previousIndex();
            if (actualIndex < firstIndex)
                return -1;
            else
                return actualIndex-firstIndex;
        }
        
        public void add(Object o) {// throws UnsupportedOperationException
            listItr.add(o); 
        }
        
        public void set(Object o) {
            listItr.set(o); 
        }
    } // End EntryIterator class
 }

