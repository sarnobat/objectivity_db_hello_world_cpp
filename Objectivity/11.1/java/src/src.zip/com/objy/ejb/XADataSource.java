/*
 * @(#)XADataSource.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.ejb ;

import com.objy.ejb.internal.ConnectionPool;
import com.objy.ejb.internal.ApplicationServerServices;
import com.objy.db.DatabaseOpenException ;
import com.objy.db.DatabaseNotFoundException ;
import com.objy.db.DatabaseClosedException ;
import com.objy.db.ObjyRuntimeException ;
import com.objy.db.app.Connection ;
import com.objy.db.app.Session ;
import com.objy.db.app.oo ;

import java.sql.SQLException ;
import javax.naming.Context ;
import javax.naming.InitialContext ;
import javax.naming.NamingException ;
import javax.transaction.xa.XAResource ;

/**
 * Reserved for internal use.
 */
// This is equivalent to OFJ com.objy.db.app.Connection
@Deprecated
final public class XADataSource implements javax.sql.XADataSource {
    private static int instanceCount = 0 ;  // ** ONLY MODIFY THRU SYNCHRONIZED ACCESSOR setInstanceCount() **
    private static Connection connection = null ;   // Objy Connection
    private static ConnectionPool connectionPool = null ;  // *ALL* access to the ConnectionPool *MUST* be synchronized on connectionPool object

    /*
    * Connection Pool Parameters
    */
    private static String  bootfilepath = null ;
    private static boolean autofdshutdown = true ;
    private static int     openmode = oo.notOpen ;
    private static boolean restrictedThreadPolicy = true ;  // default is true
    private static int  timeBeforeFDShutdown = 3600000 ;  // default - 1 hour
    private static String  dataSourceName = null ;

    /*
    * Debugging Parameters
    */
    private static Session registeredSession = null ;  // FOR TESTING ONLY
    private static boolean verbose = false ;      // connection pool parameter
    private static int debugLevel = 0 ;  // connection pool parameter

    private javax.transaction.Transaction currentGlobalTx = null ;

    public javax.transaction.Transaction getCurrentGlobalTx() {
        return currentGlobalTx ;
    }
    public void setCurrentGlobalTx(javax.transaction.Transaction tx) {
        currentGlobalTx = tx ;
    }

    // Called by Application Server Only when installed as Connection Pool
    // The Application Server is expected to set the bootfilepath and openmode
    // [sjoe] I would open the FD here, but the bootfilepath and openmode have
    // not yet been set by the app server.  Have to wait for first
    // getXAConnection()...
    public XADataSource() {
        debugLevel3("<< Objectivity >> CALLING " + this + " CONSTRUCTOR.") ;
        setInstanceCount(+1) ;
    }

    // !!!! CALLED BY USERCONNECTION CONSTRUCTOR ONLY !!!!
    synchronized javax.sql.XAConnection getXAConnection(UserConnection userconn) {
        XAConnection tempXAConn = (com.objy.ejb.XAConnection) getXAConnection() ;
        Session tempSess = tempXAConn.getSession() ;

        tempXAConn.setUserConnection(userconn) ;
        tempXAConn.setEnlistedTx(enlistResource(tempSess)) ; // enlist the xaresource here
        return tempXAConn ;
    }

    public synchronized UserConnection getUserConnection(ClassLoader beanClassLoader) {
        XAConnection tempXAConn = (com.objy.ejb.XAConnection) getXAConnection() ;
        Session tempSess = tempXAConn.getSession() ;

        tempXAConn.setEnlistedTx(enlistResource(tempSess)) ; // enlist the xaresource here
        return (UserConnection)tempXAConn.getConnection(beanClassLoader) ;
    }

    public synchronized javax.sql.XAConnection getXAConnection() {
        if (connection == null) {  // lazy open because XADataSource static variables are unavailable when AppServer is coming up...
            info("<< Objectivity >> INITIALIZING " + this + " DataSource.") ;
            initializeObjyAndConnectionPool() ;
        }
        else { // ??? MAKE THIS THREAD-SAFE
            synchronized (connectionPool) {
                if (connection.isOpen() == false) {  // connection has already been opened, but may need reopen()ing
                    Connection tempConn = reopenObjyAndConnectionPool() ;
                    if (tempConn != null)
                        info("<< Objectivity >> REOPENED " + tempConn + " DataSource Connection.") ;
                }
            }
        }
	connection.useContextClassLoader(true) ;
        setCurrentGlobalTx(ApplicationServerServices.getGlobalTransaction(setInstanceCount(0) > 2)) ;  // Set the current global transaction here
        javax.sql.XAConnection temp = null ;
        synchronized (connectionPool) {
            temp = connectionPool.getConnection(this, openmode) ;
        }

	if (ApplicationServerServices.getApplicationServer().equals("WebLogic"))
	    ApplicationServerServices.registerWebLogicTransaction(((XAConnection)temp).returnXAResource()) ;

        return temp ;
    }

    public synchronized void finalize() {
        info("<< Objectivity >> " + this + " finalize() instance count: " + setInstanceCount(0)) ;
        if (setInstanceCount(-1) == 1 && autofdshutdown == true) {
            info("<< Objectivity >> Sleep for " + (timeBeforeFDShutdown/60000) + " minute(s) before closing FD...") ;
            try {
                Thread.sleep(timeBeforeFDShutdown) ;
                if (setInstanceCount(0) == 1) closeObjyConnection() ;
            }
            catch (InterruptedException e) { }  // interrupts countdown for FD shutdown
        }
    }

    // Called when UserConnection is closed but XAConnection/XAResource may still be active
    public synchronized boolean disconnectConnection(XAConnection xaconn) {
        info("<< Objectivity >> CALLING XADataSource.disconnectConnection() " + xaconn) ;
        boolean okayToDelist = false ;
	if (xaconn.getEnlistedTx() != null)
	    synchronized (connectionPool) {
		okayToDelist = connectionPool.disconnectConnection(xaconn) ;
		if (okayToDelist) {  // enlisted TX is done, xaconnection can be made available again
		    delistResource(xaconn.getEnlistedTx(), xaconn.getSession().getXAResource(), XAResource.TMSUCCESS) ;
		    xaconn.setEnlistedTx(null) ;
		}
	    }
        return okayToDelist ;
    }

    // Called when UserConnection is finalized
    public synchronized void releaseConnection(XAConnection xaconn) {
        info("<< Objectivity >> CALLING XADataSource.releaseConnection() " + xaconn) ;
        boolean okayToDelist = false ;
	if (xaconn.getEnlistedTx() != null)
	    synchronized (connectionPool) {
		okayToDelist = connectionPool.releaseConnection(xaconn) ;
	    }
        if (okayToDelist) {
            delistResource(xaconn.getEnlistedTx(), xaconn.getSession().getXAResource(), XAResource.TMSUCCESS) ;
            xaconn.setEnlistedTx(null) ; // XAConnection is no longer associated with javax.transaction.Transaction
        }
    }

    // Called by xaconnection when a connection needs to delist itself
    synchronized void delistMe(XAConnection xaconn) {
        info("<< Objectivity >> CALLING XADataSource.delistMe() " + xaconn) ;
        delistResource(xaconn.getEnlistedTx(), xaconn.getSession().getXAResource(), XAResource.TMSUCCESS) ;
        xaconn.setEnlistedTx(null) ; // XAConnection is no longer associated with javax.transaction.Transaction
    }

    // Called when XAConnection is closed explicitly by Application Server - (I've never seen this happen)
    public synchronized void closeConnection(XAConnection xaconn) {
        synchronized (connectionPool) {
            connectionPool.closeConnection(xaconn) ;
        }
        if (xaconn.getEnlistedTx() != null) {
            delistResource(xaconn.getEnlistedTx(), xaconn.getSession().getXAResource(), XAResource.TMSUCCESS) ;
            xaconn.setEnlistedTx(null) ; // XAConnection is no longer associated with javax.transaction.Transaction
        }
    }

    public synchronized void close() { // close the datasource/fdb
        if (connection == null) throw new ObjyRuntimeException("DataSource Connection Is Not Open") ;
        closeObjyConnection() ;
    }

    //  PRIVATE METHODS
    private static synchronized void closeObjyConnection() {
        info("<< Objectivity >> Closing XADataSource Connection, INSTANCE COUNT: " + setInstanceCount(0) ) ;
        if (connection != null && connection.isOpen() == true) {
            // clean up connection pool
            synchronized (connectionPool) {
                connectionPool.readyForShutdown() ;
            }
            try{
                connection.close() ;
                info("<< Objectivity >> XADataSource.finalize() Connection " + connection + " CLOSED ...") ;
            }
            catch (DatabaseClosedException exception) {
                info("<< Objectivity >> COULD NOT CLOSE XADataSource (finalize) Connection " + connection + " ...") ;
            }
        }
        else {
            if (connection == null) {
                info("<< Objectivity >> Cannot Close XADataSource Connection.  Connection in XADataSource is NULL ...") ;
            }
            else if (connection.isOpen() == false) {
                info("<< Objectivity >> Cannot close FDB.  Connection in XADataSource is NOT OPEN ...") ;
            }
        }
    }

    private static synchronized Connection reopenObjyAndConnectionPool() { // reopen the federated database, reinitialize availableConnections
        if (connection.isOpen() == false) {
            connection.setOpenMode(openmode) ;
            try {
                connection.reopen() ;
                connectionPool.initializeAvailableConnections(openmode) ;
                return connection ;
            }
            catch (DatabaseOpenException exception) {
                throw new ObjyRuntimeException("Cannot Reopen XADataSource. Federated Database \"" + bootfilepath + "\" Could Not Be Opened") ;
            }
            catch (DatabaseNotFoundException exception) {
                throw new ObjyRuntimeException("Cannot Reopen XADataSource. Federated Database \"" + bootfilepath + "\" Could Not Be Found") ;
            }
        }
        return null ;
    }

    private static synchronized void initializeObjyAndConnectionPool() { // open the federated database and get a Database instance
        // FD is opened the first time a DataSource is instantiated
        // FD can only be opened once...
        info("<< Objectivity >> OPENING XADataSource Connection (to FDB) ...") ;
        if (connection != null) return ;

        String tempbootfilepath = null ;
        if (bootfilepath == null) {
            // ??? info("Attempting to open Federated Database with OO_FD_BOOT") ;
            // ??? tempBootFilePath = "" ;
            tempbootfilepath = "" ;
            //throw new ObjyRuntimeException("Bootfilepath property has not been set") ;
        }
        else
            tempbootfilepath = bootfilepath ;

        if (openmode == oo.notOpen) {
            openmode = oo.openReadWrite ;  // make default read/write
        }

        try {
            connection = Connection.open(tempbootfilepath, openmode) ;
        }
        catch (DatabaseOpenException exception) {
            throw new ObjyRuntimeException("Cannot open XADataSource. Federated Database \"" + tempbootfilepath + "\" Could Not Be Opened") ;
        }
        catch (DatabaseNotFoundException exception) {
            throw new ObjyRuntimeException("Cannot open XADataSource. Federated Database \"" + tempbootfilepath + "\" Could Not Be Found") ;
        }
        if (!restrictedThreadPolicy) {
            info("<< Objectivity >> Setting THREAD POLICY to UNRESTRICTED") ;
            connection.setThreadPolicy(oo.THREAD_POLICY_UNRESTRICTED) ;  // ??? will app server handle this?
        }
        // initialize Connection Pool
        info("<< Objectivity >> INITIALIZING CONNECTION POOL...") ;
        connectionPool = new ConnectionPool() ;
        connectionPool.initializeAvailableConnections(openmode) ;
    }

    private synchronized javax.transaction.Transaction enlistResource(Session sess) {
        javax.transaction.Transaction tempTx = getCurrentGlobalTx() ;
        XATransaction xares = sess.getXAResource() ;

        if (tempTx == null)
            throw new ObjyRuntimeException("Could not obtain ANY Transaction Manager...") ;

        try {  // got a Transaction Manager
            tempTx.enlistResource(xares) ;
            info("<< Objectivity >> ENLISTED XARESOURCE " + xares + " IN CURRENT GLOBAL TRANSACTION ...") ;
            // ??? do we need to join the thread, especially if the Tx was used in another thread ?
        }
        catch (javax.transaction.SystemException e) {
            e.printStackTrace() ;
            throw new ObjyRuntimeException("Could not Enlist Objectivity XAResource in javax.transaction.Transaction") ;
        }
        catch (javax.transaction.RollbackException e2) {
            e2.printStackTrace() ;
            throw new ObjyRuntimeException("Could not Enlist Objectivity XAResource in javax.transaction.Transaction") ;
        }
	catch (java.lang.IllegalStateException ie) {
            ie.printStackTrace() ;
            throw new ObjyRuntimeException("Could not Enlist Objectivity XAResource in javax.transaction.Transaction") ;
	}
        return tempTx ;
    }

    private synchronized void delistResource(javax.transaction.Transaction tempTx, XATransaction xares, int flag) {
        try{
            info("<< Objectivity >> DELISTING XARESOURCE " + xares + " ... ") ;
            tempTx.delistResource(xares, flag) ;
        }
        catch (javax.transaction.SystemException e) {
            throw new ObjyRuntimeException("Could not Delist Objectivity XAResource") ;
        }
        catch (java.lang.IllegalStateException ie) {
            // do nothing
        }
   }

    private int translateModeToInt(String _mode) {
        if (_mode.equalsIgnoreCase("readonly") || _mode.equalsIgnoreCase("openreadonly")) {
            return oo.openReadOnly ;
        } else if (_mode.equalsIgnoreCase("readwrite") || _mode.equalsIgnoreCase("openreadwrite")) {
            return oo.openReadWrite ;
        } else if (_mode.equalsIgnoreCase("notopen")) {
            return oo.notOpen ;
        } else
            throw new ObjyRuntimeException("Open Mode String \"" + _mode + "\" is not valid") ;
    }

    private String translateModeToString(int _mode) {
        if (_mode == oo.openReadOnly) {
            return new String("readonly") ;
        } else if (_mode == oo.openReadWrite ) {
            return new String("readwrite") ;
        } else if (_mode == oo.notOpen ) {
            return new String("notopen") ;
        } else
            throw new ObjyRuntimeException("Open Mode String \"" + _mode + "\" is not valid") ;
    }

    private static synchronized int setInstanceCount(int i) {
        instanceCount = instanceCount + i ;
        return instanceCount ;
    }

    // setters/getters
    public void setBootfilepath(String _bootfilepath) {  // used by App Server
        info("<< Objectivity >> Application Server setting bootfilepath to \"" + _bootfilepath + "\"") ;
        bootfilepath = _bootfilepath ;
    }
    public String getBootfilepath() {
        return bootfilepath ;
    }
    public void setOpenmode(String _mode) {  // used by App Server
        openmode = translateModeToInt(_mode) ;
    }
    public String getOpenmode() {
        return translateModeToString(openmode) ;
    }
    public void setTimeBeforeFDShutdown(int millis) {  // used by App Server
        timeBeforeFDShutdown = millis ;
    }
    public int getTimeBeforeFDShutdown() {
        return timeBeforeFDShutdown ;
    }
    public void setVerbose(String toggle) {  // for debugging
        if (toggle.equalsIgnoreCase("true")) {
            verbose = true ;
        } else {
            verbose = false ;
        }
    }
    public boolean getVerbose() {  // for debugging
        return verbose ;
    }
    public void setAutofdshutdown(String toggle) {
        if (toggle.equalsIgnoreCase("false")) {
            autofdshutdown = false ;
        } else {
            autofdshutdown = true ;
        }
    }
    public boolean getAutofdshutdown() {
        return autofdshutdown ;
    }
    public void setDebugLevel(int value) {
        if (value < 0) {
            debugLevel = 0 ;
        }
        else if (value >=1 && value <= 3){
            debugLevel = value ;
        }
        else if (value > 3) {
            debugLevel = 3 ;
        }
        System.out.println("<< Objectivity >> Setting Debug Output Level to: " + debugLevel) ;
    }

    public int getDebugLevel() {
        return debugLevel ;
    }
    public void setThreadPolicy(String _policy) {
        if (_policy.equalsIgnoreCase("unrestricted")) {
            restrictedThreadPolicy = false ;
        } else {
            restrictedThreadPolicy = true ; // default
        }
    }
    public String getThreadPolicy() {
        if (restrictedThreadPolicy)
            return ("restricted") ;
        else
            return ("unrestricted") ;
    }
    public void setInitialConnections(int initial) {
        info("<<< Objectivity >>> Application Server setting Initial Connections to \"" + initial + "\"") ;
        ConnectionPool.setInitialConnections(initial) ;
    }
    public int getInitialConnections() {
        return ConnectionPool.getInitialConnections() ;
    }
    public void setMaxConnections(int max) {
        ConnectionPool.setMaxConnections(max) ;
    }
    public int getMaxConnections() {
        return ConnectionPool.getMaxConnections() ;
    }

    public void setDataSourceName(String _dataSourceName) {
	dataSourceName = _dataSourceName ;
	try {
	    // when there's more than one data source the class name will
	    // have to be provided by the user as another property
	    getInitialContext().bind(dataSourceName, Class.forName("com.objy.ejb.XADataSource")) ;
	}
	catch (ClassNotFoundException cnfe) {
	    throw new ObjyRuntimeException("Could not load class for Data Source") ;
	}
	catch (NamingException ne) {
	    throw new ObjyRuntimeException("Could not bind Data Source on JNDI server") ;
	}
    }

    public String getDataSourceName() {
	return dataSourceName ;
    }

    public static XADataSource getDataSource() {
	/*
	try {
	    Class dataSource = (Class)getInitialContext().lookup(dataSourceName) ;
	    return (XADataSource)dataSource.newInstance() ;
	}
	catch (NamingException ne) {
	    throw new ObjyRuntimeException("Could not find Data Source on JNDI server") ;
	}
	catch (IllegalAccessException ne) {
	    throw new ObjyRuntimeException("Could not instantiate Data Source") ;
	}
	catch (InstantiationException ne) {
	    throw new ObjyRuntimeException("Could not instantiate Data Source") ;
	}
	*/
	return new XADataSource() ;
    }


  //
  //  UNIMPLEMENTED JDBC METHODS
  //          |
  //          |
  //         \ /
  //          .
  //


  // Get the log writer for this data source.
  //
  // The log writer is a character output stream to which all logging
  // and tracing messages for this data source object instance will be
  // printed.  This includes messages printed by the methods of this
  // object, messages printed by methods of other objects manufactured
  // by this object, and so on.  Messages printed to a data source
  // specific log writer are not printed to the log writer associated
  // with the java.sql.Drivermanager class.  When a data source object is
  // created the log writer is initially null, in other words, logging
  // is disabled.
  //
  // Returns the log writer for this data source, null if disabled
    public java.io.PrintWriter getLogWriter() {
        return null ;
    }

  // Set the log writer for this data source.
  //
  // The log writer is a character output stream to which all logging
  // and tracing messages for this data source object instance will be
  // printed.  This includes messages printed by the methods of this
  // object, messages printed by methods of other objects manufactured
  // by this object, and so on.  Messages printed to a data source
  // specific log writer are not printed to the log writer associated
  // with the java.sql.Drivermanager class. When a data source object is
  // created the log writer is initially null, in other words, logging
  // is disabled.
  //
  // out - the new log writer; to disable, set to null
  //
    public void setLogWriter(java.io.PrintWriter out) {
    }

  // Sets the maximum time in seconds that this data source will wait
  // while attempting to connect to a database.  A value of zero
  // specifies that the timeout is the default system timeout
  // if there is one; otherwise it specifies that there is no timeout.
  // When a data source object is created the login timeout is
  // initially zero.
  //
  // seconds - the data source login time limit
  //
    public void setLoginTimeout(int seconds) {
    }

  // Gets the maximum time in seconds that this data source can wait
  // while attempting to connect to a database.  A value of zero
  // means that the timeout is the default system timeout
  // if there is one; otherwise it means that there is no timeout.
  // When a data source object is created the login timeout is
  // initially zero.
  //
  // Returns the data source login time limit
  //
    public int getLoginTimeout() {
        return 0 ;
    }

    public synchronized javax.sql.XAConnection getXAConnection(String user, String password) throws SQLException {
        throw new SQLException("Method is Unsupported.") ;
    }

    public static void info(String message) {
         if (verbose == true)
             System.out.println(message) ;
    }
    public static void debugLevel1(String message) {
        if (debugLevel == 1 || debugLevel == 2 || debugLevel == 3)
             System.out.println(message) ;
    }
    public static void debugLevel2(String message) {
         if (debugLevel == 2 || debugLevel == 3)
             System.out.println(message) ;
    }
    public static void debugLevel3(String message) {
        if (debugLevel == 3)
             System.out.println(message) ;
    }

    private static Context getInitialContext() {
	try {
	    return new InitialContext() ;
	}
	catch (NamingException ne) {
	    throw new ObjyRuntimeException("Could not locate JNDI server") ;
	}
    }

}
