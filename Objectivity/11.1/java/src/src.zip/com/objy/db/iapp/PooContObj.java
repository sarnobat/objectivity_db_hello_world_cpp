/*
 * @(#)PooContObj.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

import java.util.Vector ;

import com.objy.db.app.ooId ;
import com.objy.db.app.ooObj ;
import com.objy.db.app.Iterator ;
import com.objy.db.app.storage.ooAPObj;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.app.storage.ooDBObj;
import com.objy.query.ObjectQualifier;

/**
 * Reserved for internal use.
 */
public interface PooContObj
       extends   PooObj
{
    ooDBObj getDB() ;

    String getName() ;

    String getFileName() ;

    String getHostName() ;

    String getPathName() ;

    int getPageSize() ;

    boolean isExternal() ;

    void changeExternalContainerLocation(String hostName, String pathName, boolean catalogOnly) ;

    long getNumLogicalPages() ;

    long getCountLogicalPages() ;

    long getPageCount() ;

    long getGrowthFactor() ;

    int getHash() ;
    
    ooId getOid() ;

    long getNumber() ;

    int getMaxPagesForSmallPageMap() ;

    //
    // Deleting
    //
    void delete() ;

    void deleteNoProp() ;

    //
    // Testing
    //
    boolean isUpdated() ;

    //
    // Maintenance
    //
    void refresh(int lockMode) ;
    
    void flush() ;

    //
    // Locking
    //
    void releaseReadLock() ;

    void lockNoProp(int lockMode) ;

    //--------------------
    // Contained Iterators
    //--------------------
    Iterator contains() ;  // returns all objects in container
    
    //---------------
    // Scan Iterators
    //---------------
    Iterator scan(String className) ;

    Iterator scan(String className, String predicate) ;

    Iterator scan(String className, String predicate, int access) ;

    Iterator scan(String className, ObjectQualifier oq);
    
    //----------
    // Indexes
    //----------
    void addIndex(String indexName, String className, String fieldList);

    void addUniqueIndex(String indexName, String className, String fieldList);

    void dropIndex(String indexName) ;

    boolean hasIndex(String indexName) ;

    boolean indexConsistent(String indexName) ;

    //--------------------
    //  Schema Evolution
    //--------------------
    void convertObjects() ;

}


