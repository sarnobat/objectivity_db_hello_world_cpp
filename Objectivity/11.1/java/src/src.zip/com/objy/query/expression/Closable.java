package com.objy.query.expression;

abstract class Closable extends AbstractExpression //implements AutoCloseable JDK 7
{
    boolean mIsClosed = false;
    
    @Override
    void throwExceptionIfInvalidOrClosed(long id) throws ExpressionException
    {
        if (id != 0) return;
        if (mIsClosed)
        {
            throw new ExpressionException("The object is already closed");
        }
        else 
        {
            throw new ExpressionException("The object is invalid");
        }
    }
    
    /**
     * Closes the expression tree.
     */
    //@Override JDK 7
    public synchronized void close()
    {
        if (mId != 0 && !mIsClosed)
        {
            closeNative();
            setId(0);
            mIsClosed = true;
        }
    }
    
    /**
     * Performs the closing operation of the expression element. 
     * Have to be implemented by the sub-classes to define the JNI call to 
     * release the native resource. 
     */
    abstract void closeNative();
    
}