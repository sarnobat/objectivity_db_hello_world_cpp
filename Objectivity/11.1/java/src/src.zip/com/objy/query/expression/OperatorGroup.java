package com.objy.query.expression;
/**
 * Represents an operator group, which contains a number of operators.
 *
 */
public class OperatorGroup extends AbstractExpression
{
 
    /**
     * Constructs an operator group using an operator group name.
     */
    public OperatorGroup(String operatorGroupName) 
    {
        setIdAfterNullCheck(Binding.create(operatorGroupName));
    }
    
    /**
     * Constructs an operator group using an ID.
     */
    public OperatorGroup(long id) 
    {
        setIdAfterNullCheck(id);
    }

    /**
     * Returns the operator group's name.
     */
    public String getName() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getName(mId);
    }

    /**
     * Returns the total number of operators in the group.
     */
    public int getNumberOfOperators() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getNumberOfOperators(mId);
    }

    /**
     * Returns the operator at the specified index. 
     */
    public Operator getOperator(int index) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Operator.getOperator(Binding.getOperator(mId, index));
    }

    /**
     * Returns the operator with the specified operator name.
     */
    public Operator getOperator(String operatorName) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Operator.getOperator(Binding.getOperatorByName(mId, operatorName));   
    }

    static class Binding
    {
        private static native long create(String operatorGroupName);
        
        // Returns the operator group's name.
        private static native String getName(long id);
        
        // Returns the total number of operators in the group.
        private static native int getNumberOfOperators(long id);
       
        // Returns the operator for the specified index. 
        private static native long getOperator(long groupId, int index);
        
        // Returns the operator with the specified operator name
        private static native long getOperatorByName(long groupId, String opName);
        
    }
}
