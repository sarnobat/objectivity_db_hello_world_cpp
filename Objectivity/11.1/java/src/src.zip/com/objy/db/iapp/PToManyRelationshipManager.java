/*
 * @(#)PToManyRelationshipManager.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.objy.db.iapp ;

import com.objy.db.app.Iterator ;
import com.objy.query.ObjectQualifier;

/**
 * Reserved for internal use.
 */
public interface PToManyRelationshipManager
       extends   PRelationshipManager
{
    void add(PooObj from, Object to) ;

    void remove(PooObj from, Object to) ;

    void clear(PooObj from) ;

    Iterator scan(PooObj from) ;

    Iterator scan(PooObj from, String predicate) ;
    
    Iterator scan(PooObj per, ObjectQualifier oq);

    void ensureCapacity(PooObj from, int minCapacity) ;

    Object get(PooObj from, int index) ;

    int indexOf(PooObj from, Object obj) ;

    int size(PooObj from) ;

    Object[] toArray(PooObj from, Object obj[], boolean ignoreEx) ;

    void trimToSize(PooObj from) ;
	
}


