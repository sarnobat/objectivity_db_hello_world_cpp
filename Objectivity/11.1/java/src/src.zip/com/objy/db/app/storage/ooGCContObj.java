/*
 * @(#)ooGCContObj.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app.storage ;
/**
 * Represents a garbage-collectible container.
 *
 * <p>A <i>garbage-collectible container</i> allows you to store 
 * named roots and their object graphs and to work with the graph much as you 
 * would with an object graph in the memory of a Java application.
 * In Java, when an object is no longer referenced
 * from any other object, it is subject to garbage collection.  In the 
 * a garbage-collectible container, an object that cannot be reached by 
 * following links from a named root is subject to garbage collection.
 * In a federated database, unlike Java memory, garbage collection
 * does not occur automatically. Instead, you must use the
 * <tt>oogc</tt> administration tool when you want to delete unreferenced
 * objects.  
 *
 * <p>For additional information about garbage-collectible containers, see
 * <a href="../../../../../../guide/jgdStorage.html#gcContainers">
 * Garbage-Collectible Containers</a>.  For information about
 * named roots, see
 * <a href="../../../../../../guide/jgdLookup.html#Individual Lookup of Named Roots">
 * Individual Lookup of Named Roots</a>.
 *
 * <p><b>Note:</b> You must make a container 
 * <a href="../../../../../../guide/jgdStorage.html#Making a Container Persistent">
 * persistent</a> before you call  any
 * methods defined by the <tt>ooContObj</tt> class. See the <tt>ooObj</tt>
 * method descriptions for restrictions on methods inherited from that class. 
 *
 * <p>If your application needs persistent container-specific data, you can 
 * define your own garbage-collectible container class by
 * subclassing ooGCContObj and defining attributes to represent the 
 * container-specific information. See 
 * <a href="../../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>. 
 *
 * <p>For additional information about containers and a discussion of how  
 * an application can create and work with containers,
 * see <A HREF="../../../../../../guide/jgdStorage.html#Containers">
 * Containers</A>.
 *
 */
public class   ooGCContObj 
       extends ooContObj
{
	/**
	 * Constructs a garbage-collectible container.
	 *
	 * <p>The newly created container object is transient; to make it
	 * persistent, you must add it to a database by calling the
	 * <a href="ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)"><tt>addContainer</tt></a>
	 * method of the database.
	 */
    public ooGCContObj() {}
}
 


