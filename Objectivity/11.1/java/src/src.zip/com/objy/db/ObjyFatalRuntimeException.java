package com.objy.db;

/**
 * Signals a fatal exception exception has occurred in the Objectivity 
 * runtime.
 *
 * Upon catching this exception you should not attempt any further database
 * operations and should have the application exit as soon as possible.
 * 
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class ObjyFatalRuntimeException extends ObjyRuntimeException
{
    
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ObjyFatalRuntimeException()
        { super() ; }

    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ObjyFatalRuntimeException(String msg)
        { super(msg) ; }

}
