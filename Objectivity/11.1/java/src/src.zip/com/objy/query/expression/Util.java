package com.objy.query.expression;

class Util 
{
    static void verifyStringArgument(String str)
    {
        if (str == null || str.isEmpty())
            throw new IllegalArgumentException("Argument cannot be null or empty. ");
    }

    static void verifyUIntArgument(long val) 
    {
        if (val < 0 || val > 0xffffffff)
            throw new IllegalArgumentException("Invalid value for unsigned int. Valid range 0 to 4294967295 (2^32-1)");
    }

    static String[] verifyOidArgument(String str)
    {
    	Util.verifyStringArgument(str);
    	String[] tokens;
    	if (str.startsWith("#"))
    	{
    		tokens = str.substring(1).split("-");
    	}
    	else
    	{
    		tokens = str.split("-");
    	}
    	if (tokens.length < 4)
    		throw new IllegalArgumentException("Invalid OID argument. ");
    	return tokens;
    }
    
    static String[] verifyIntervalArgument(String str)
    {
    	Util.verifyStringArgument(str);
    	
    	String[] tokens = str.split(":");
        
        boolean invalid = false;
        for (int i = 0; i < tokens.length; i++)
        {
        	try
        	{
        	    Integer.parseInt(tokens[i]);
        	}
        	catch (NumberFormatException e)
        	{
        		invalid = true;
        	}
        	if (invalid)
        	{
        		break;
        	}
        }
        if (tokens.length < 4 || invalid)
        {
            throw new IllegalArgumentException("Invalid Interval argument. ");
        }
 
        return tokens;
    }
}
