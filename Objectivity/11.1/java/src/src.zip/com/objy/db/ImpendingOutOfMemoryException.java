/*
 * @(#)ImpendingOutOfMemoryException.java
 * 
 * Copyright (c) 2008 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

import com.objy.db.ObjyRuntimeException ;

/**
 * Signals that memory usage in the virtual machine has exceeded 95%.
 *
 * <p>When <a href = "app/Connection.html#setMemoryCheckPolicy(boolean)">memory checking</a> 
 * is activated in a connection, 
 * an <tt>ImpendingOutOfMemoryException</tt> is thrown if Objectivity for Java finds that
 * over 95% of the virtual machine's memory is in use.  
 * This allows recovery that may not be possible once an <tt>OutOfMemoryError</tt> 
 * is triggered.
 * For example, your exception handler could 
 * <a href="../../../../guide/jgdSessionCache.html#Availability of Local Representations for Garbage Collection">
 * release strong references to persistent objects</a>
 * (usually by 
 * <a href="../../../../guide/jgdCache.html#Updating the Objectivity/DB Cache">
 * updating the Objectivity/DB cache</a>),
 * as well as releasing strong references to non-Objectivity/DB objects.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 * 
 * 
 */
public class ImpendingOutOfMemoryException extends ObjyRuntimeException
{
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ImpendingOutOfMemoryException()
        { super() ; }

    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ImpendingOutOfMemoryException(String msg)
        { super(msg) ; }   
}

