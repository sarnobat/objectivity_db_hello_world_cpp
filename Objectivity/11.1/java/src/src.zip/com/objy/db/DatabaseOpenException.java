/*
 * @(#)DatabaseOpenException.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved. 
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

/**
 * Signals an attempt to open a connection to a federated database when
 * the connection is already open.
 *
 * <p>This exception is also thrown if you call an <tt>open</tt> method with
 * an illegal open mode, or if the open mode is set to <tt>notOpen</tt>.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching checked exceptions.
 */
public class   DatabaseOpenException
       extends ODMGException
{
	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching checked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public DatabaseOpenException()
        { super() ; }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching checked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public DatabaseOpenException(String msg)
        { super(msg) ; }
}


