/*
 * @(#)ManyToOne.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

import com.objy.db.ObjySchemaException ;

/**
 * Defines a many-to-one 
 * <a href="../../../../../guide/jgdOrganization.html#Relationships">
 * relationship</a> in a source class.
 *
 * <p>The source class of the relationship must declare a relationship field
 * of type <a href = "ToOneRelationship.html"><tt>ToOneRelationship</tt></a>
 * and define a public static <i>relationship-definition method</i> that 
 * returns a properly initialized instance of this class. See
 * <a href="../../../../../guide/jgdDefiningClasses.html#Defining Relationships">
 * Defining Relationships</a>.
 *
 * <p><TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 *
 * <TD>
 *      <A HREF="#ManyToOne(java.lang.String, java.lang.String, java.lang.String, byte)">ManyToOne(String,
 * String, String, byte)</a><br>
 *     <A HREF="#ManyToOne(java.lang.String, java.lang.String, 
java.lang.String, byte, byte, boolean, boolean, byte)">ManyToOne(String,
 * String, String, byte, byte, boolean, boolean, byte)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 *
 * <TD><A HREF="#isToMany()">isToMany()<BR>
 * </A><A HREF="#isOtherToMany()">isOtherToMany()</A> </TD>
 * </TR>
 * </TABLE>
 *
 */
final public class   ManyToOne
             extends Relationship
{
    /**
     * Constructs a bidirectional many-to-one relationship with the specified
     * versioning and copy semantics, delete and lock propagation
     * behavior, and storage mode.
     *
     * <p>You should use this constructor <i>only</i> in the static 
     * relationship-definition method that creates and returns the 
     * relationship object corresponding to a particular 
	 * relationship field of a source object.</p>
	 *
     * @param 	 memberName      The name of the relationship 
     * field.</p> 
     *
     * @param 	 otherClassName  The package-qualified name of 
     * the destination class.</p>
     *
     * @param 	 otherMemberName The name of the inverse 
     * relationship field in the destination class.</p>
     *
     * @param 	 copyMode    Specifies what to do with the 
     * association link for this relationship when the source object
     * is copied; one of the following constants defined in the 
     * <tt>Relationship</tt> class:
     * <dl><dd><dl>
	 * <dt><tt>COPY_DELETE</tt><dd>Delete the association link from
	 * the copy of the source object and leave it in the 
	 * original source object.</dd>
	 *
	 * <dt><tt>COPY_MOVE</tt><dd>Move the association link from
	 * the original source object to the copy.</dd>
	 *
	 * <dt><tt>COPY_COPY</tt><dd>Copy the association link from
	 * the original source object to the copy of the source object.</dd>
     * </dd></dl></dl></p>
     *
     * @param 	 versionMode    Specifies what to do with 
     * association link for this relationship when 
	 * a new version of the source object is created;
     * one of the following constants defined in the
	 * <tt>Relationship</tt> class:
     * <dl><dd><dl>
	 * <dt><tt>VERSION_DELETE</tt><dd>Delete the association link from
	 * the new version of the source object and leave it in the 
	 * original source object.</dd>
	 *
	 * <dt><tt>VERSION_MOVE</tt><dd>Move the association link from
	 * the original source object to the new version of the object.</dd>
	 *
	 * <dt><tt>VERSION_COPY</tt><dd>Copy the association link from
	 * the original source object to the new version of the object.</dd>
     * </dd></dl></dl></p>
     *
	 * <b>Note:</b> Currently, applications in several other programming
	 * languages supported by Objectivity can create new 
	 * versions of basic objects, but Java applications cannot.</p> 
	 *
     * @param 	 deletePropagate True if delete operations 
     * on a source object should be propagated to its destination object; 
     * otherwise false.</p> 
     *
     * @param 	 lockPropagate   True if an explicit lock 
     * obtained for a source object should be propagated to its destination 
     * object; otherwise false.</p>
     *
     * @param 	 inlineMode Specifies how to store the 
     * association link for this relationship; one of the following 
     * constants defined in the 
	 * <tt>Relationship</tt> class:
     * <dl><dd><dl>
	 *  <dt><tt>INLINE_NONE</tt><dd>Store the association 
     * link in the source object's system default association array.</dd>
     *
	 *  <dt><tt>INLINE_LONG</tt><dd>Store the association 
     * link inline in the the data for the source object as a standard object 
     * identifier for the destination object.</dd>
     *
	 *  <dt><tt>INLINE_SHORT</tt><dd>(<i>For advanced users only.</i>)  
	 *  Store the association 
     * link inline in the data for the source object as a short object 
     * identifier for the destination object.
     * Short object identifiers are safe to use only with appropriate object placement. 
     * Specify this constant only after obtaining technical consultation from Objectivity.
     * </dd>
	 * </dd></dl></dl>
     *
     */
    public ManyToOne(  // bidirectional - has otherMemberName
        String memberName, String otherClassName, String otherMemberName,
        byte copyMode, byte versionMode,
        boolean deletePropagate, boolean lockPropagate,
       byte inlineMode)
    {
        super(memberName, otherClassName, otherMemberName,
                copyMode, versionMode,
                deletePropagate, lockPropagate,
                inlineMode) ;
    }
    
    /**
     * Constructs a bidirectional many-to-one relationship with the default
     * versioning and copy semantics, no delete or lock propagation, and the
     * specified storage mode.
     *
     * <p>When you create a copy or a new version of a source object,
     * the association links for the relationship are 
     * deleted in the new copy or 
	 * version and kept in the original source object.
 	 *
     * <p>You should use this constructor <i>only</i> in the static 
     * relationship-definition method that creates and returns the 
     * relationship object corresponding to a particular 
	 * relationship field of a source object.</p>
	 *
     * @param 	 memberName      The name of the relationship 
     * field.</p> 
     *
     * @param 	 otherClassName  The package-qualified name of 
     * the destination class.</p>
     *
     * @param 	 otherMemberName The name of the inverse 
     * relationship field in the destination class.</p>
     *
     * @param 	 inlineMode Specifies how to store the 
     * association link for this relationship; one of the following 
     * constants defined in the 
	 * <tt>Relationship</tt> class:
     * <dl><dd><dl>
	 *  <dt><tt>INLINE_NONE</tt><dd>Store the association 
     * link in the source object's system default association array.</dd>
     *
	 *  <dt><tt>INLINE_LONG</tt><dd>Store the association 
     * link inline in the the data for the source object as a standard object 
     * identifier for the destination object.</dd>
     *
	 *  <dt><tt>INLINE_SHORT</tt><dd>(<i>For advanced users only.</i>)  
	 *  Store the association 
     * link inline in the data for the source object as a short object 
     * identifier for the destination object.
     * Short object identifiers are safe to use only with appropriate object placement. 
     * Specify this constant only after obtaining technical consultation from Objectivity.
     * </dd>
	 * </dd></dl></dl>
     */
    public ManyToOne(String memberName, String otherClassName, String otherMemberName, byte inlineMode)
    {
        super(memberName, otherClassName, otherMemberName,
                COPY_DELETE, VERSION_DELETE, false, false,
                inlineMode) ;
    }
    
    /**
     * Tests whether this relationship is a to-many relationship.
	 * <p>All many-to-one relationships are to-one relationships,
	 * so this method always returns false.</p>
	 *
     * @return      False.</p>
     */
    public boolean isToMany()
        { return false ; }
        
    /**
     * Tests whether this relationship's destination class 
     * defines an inverse to-many relationship.
     *
	 * <p>All many-to-one relationships are bidirectional and
	 * the inverse of all many-to-one relationships is always to-many,
	 * so this method always returns true.</p>
	 *
     * @return      True.</p>
     */
    public boolean isOtherToMany()
        { return true ; }
    
	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public void assertValidMember(String className, Class memberClass, String memberName) {
        super.assertValidMember(className, memberClass, memberName) ;
        if ( !memberClass.equals(ToOneRelationship.class) )
            throw new ObjySchemaException("Relationship definition does not match member type for: "
                + className+"."+ getMemberName() ) ;
    }
}


