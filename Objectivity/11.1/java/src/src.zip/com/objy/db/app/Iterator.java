/*
 * @(#)Iterator.java
 * 
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

import java.util.Enumeration ;

import com.objy.db.iapp.PItr ;

import com.objy.db.ObjyRuntimeException;

/**
 * Represents an object iterator.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>An application uses an object iterator to step through a group of 
 * objects found in the federated database.
 * Typically, an object iterator finds Objectivity/DB objects; an object 
 * iterator can also find strings that are used as names in the federated 
 * database. For information about obtaining and working with object
 * iterators, see
 * <a href="../../../../../guide/jgdIterators.html#Object Iterators">
 * Object Iterators</a>.
 *
 * <a name="APIsummary"><h2>API Summary</h2>
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 * 	<td>
 *     <a href="#getSession()">getSession()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	<td>
 *     <a href="#isOpen()">isOpen()</a><br>
 *     <a href="#hasNext()">hasNext()</a><br>
 *     <a href="#isOptimizeScanOrder()">isOptimizeScanOrder()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Elements</b></td>
 * 	<td>
 *     <a href="#next()">next()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Cleanup</b></td>
 * 	<td>
 *     <a href="#close()">close()</a><br>
 * 	</td></tr>
 * </table>
 */
final public class Iterator
    implements Enumeration, java.util.Iterator
{
    private PItr iterator ;

	/**
	 * Reserved for internal use; to obtain an object iterator, call the appropriate method to
	 * create and initialize an object iterator that finds the desired items.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public Iterator(PItr iterator) { 
        if (iterator == null)
            throw new ObjyRuntimeException("Users should not directly instantiate Iterator") ;
        this.iterator = iterator ; 
    }

	/**
	 * Gets the session in which this object iterator was created and 
     * initialized.</p> 
	 *
	 * @return	The session in which this object iterator was created and initialized.
	 */
    public Session getSession()
        { return iterator.getSession() ; }
        
    /**
     * Closes this object iterator.
     *
     * <p>You can call this method to signal that you are finished using
     * this object iterator even though you have not accessed all its elements.
     */
    public void close()
        { iterator.close() ; }
        
    /**
     * Tests whether this object iterator is open.
 	 *
     * <p>An object iterator is open between the time when it is created and when it
     * is closed.  An object iterator may be closed
     * automatically or by an explicit call to the
     * <a href="#close()"<tt>close</tt></a> method.</p>
     *
     * @return  True if the object iterator is open; otherwise false.
     */
    public boolean isOpen() 
        { return iterator.isOpen() ; }
        
    /**
     * @deprecated	Use {@link #hasNext <tt>hasNext</tt>}.
     */        
    public boolean hasMoreElements()
        { return iterator.hasMoreElements() ; }
    
    /**
     * Tests whether this object iterator has more elements.</p>
     *
     * @return		True if this object iterator has at least one more element; otherwise, false.
     */
    public boolean hasNext()
        { return iterator.hasMoreElements() ; }
        
    /**
     * @deprecated	Use {@link #next <tt>next</tt>}.
     */        
    public Object nextElement()
        { return iterator.nextElement() ; }
        
 	/**
 	 * Gets the next element from this object iterator.
 	 *
 	 * <p>If this object iterator has no more elements, this method throws an
	 * exception. You should call this method only if the
     * <a href="#hasNext()"><tt>hasNext</tt></a> method returns
	 * true.</p>
 	 *
 	 * @return		The next element from this object iterator.
	 */
    public Object next()
        { return iterator.nextElement() ; }
        
	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public void remove()
     {   
        throw new UnsupportedOperationException();
     }

	/**
	 * Tests whether an object iterator uses an optimized scan order.</p>
	 * 
	 * @return		True if this object iterator's scan order is optimized; 
	 * false if this object iterator scans the logical pages of a container 
	 * in order by logical-page identifier.
	 * 
	 * @see	Session#setOptimizeScanOrder
	 */
    public boolean isOptimizeScanOrder()
        { return iterator.isOptimizeScanOrder() ; }

}