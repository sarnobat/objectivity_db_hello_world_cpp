/*
 * @(#)PooReference.java
 * 
 * Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp ;

import com.objy.db.app.ooReference ;

/**
 * Represents the internal reference that is held by a 
 * <a href = "../app/ooReference.html">garbage-collectible reference object</a>.
 *
 * <p>You should not create an instance of this class.
 */
public interface PooReference
{
    /**
     * Reserved for internal use; you should not call this method.
     */
    Object get() ;

    /**
     * Gets the long array of data (if there is one) 
	 * that has been set for the garbage-collectible reference object
	 * holding this internal reference.</p>
     *
     * <p>
	 * If the referent is needed again 
	 * after it has been garbage collected, 
	 * the information in the array of long integers 
	 * can be used to restore it to local memory. 
	 * For example, if the garbage-collected referent is an element 
	 * in a custom persistent collection, 
	 * the array information could be used to restore pathways 
	 * among the collection's intermediate nodes.
	 * </p>
     * 
     * @return	An array of long integers that can be used for restoring 
	 * the referent to memory if it is needed again after being garbage collected.</p>
     *
     * @see #setData
     */
    long[] getData() ;

    /**
     * Sets an optional long array of data for
	 * the garbage-collectible reference object
	 * holding this internal reference.</p>
     *
     * <p>
	 * If the referent is needed again 
	 * after it has been garbage collected, 
	 * the information in the array of long integers 
	 * can be used to restore it to local memory. 
	 * For example, if the garbage-collected referent is an element 
	 * in a custom persistent collection, 
	 * the array information could be used to restore pathways 
	 * among the collection's intermediate nodes.
	 * </p>
     * 
     * @param 	 data An array of long integers 
	 * that can be used for restoring the referent to memory 
	 * if it is needed again after being garbage collected.</p>
     *
     * @see #getData
     */
    void setData(long[] data) ;

    /**
     * Reserved for internal use; you should not call this method.
     */
    void terminate() ;

    /**
     * Reserved for internal use; you should not call this method.</p>
     *
     */
    boolean isTerminated() ;
}
