package com.objy.db.internal;

import com.objy.db.ObjyRuntimeException;
import com.objy.db.TransactionNotInProgressException;
import com.objy.db.app.Iterator;
import com.objy.db.app.Session;
import com.objy.pm.QueryScanItr;
import com.objy.pm.SessionPersistor;

public class Query
{
    public static final int NO_MAX_PREFERENCE_RANK = 65535; 
    private Query()
    {
    
    }
        
    public static Iterator execute(String className, String predicate,
            long maxPreferenceRank)
    {
        Session sess = Session.getCurrent();
        if(sess == null)
        {
            //OBJY-20098 For a better, clearer error message throw TransactionNotInProgressException
            //when we can't get a session, since in order to be in a transaction you need a session.
            throw new TransactionNotInProgressException("There is no transaction in progress") ;
        }
        SessionPersistor sp = (SessionPersistor)sess.persistor();
        // write out dirty objects but does no list management
        // Note: flushForScanWithPredicate() could throw an exception that
        // came out of preWrite().  If so, then we complete abruptly with
        // that exception and no itr instance is returned
        sp.flushForScanWithPredicate() ;

        try 
        { 
            sp.lockMonitor() ;
            if (className == null)
                throw new ObjyRuntimeException(className + " must not be null") ;

            return new Iterator(new QueryScanItr(sp, className, predicate,
                    maxPreferenceRank)) ; // type number
        } finally { sp.unlockMonitor() ; }

    }
    
    public static Iterator execute(String className, long maxPreferenceRank)
    {
        Session sess = Session.getCurrent();
        if(sess == null)
        {
            //OBJY-20098 For a better, clearer error message throw TransactionNotInProgressException
            //when we can't get a session, since in order to be in a transaction you need a session.
            throw new TransactionNotInProgressException("There is no transaction in progress") ;
        }
        SessionPersistor sp = (SessionPersistor)sess.persistor();

        try 
        { 
            sp.lockMonitor() ;
            if (className == null)
                throw new ObjyRuntimeException(className + " must not be null") ;

            return new Iterator(new QueryScanItr(sp, className, null,
                    maxPreferenceRank)) ; // type number
        } finally { sp.unlockMonitor() ; }

    }
}
