/*
 * @(#)TransactionListener.java
 * 
 * Copyright (c) 2003 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Abstract superclass for all transaction-listener classes.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 * 
 * 
 * <p>An instance of a class derived from TransactionListener is called a <i>transaction listener</i>. 
 * An application-defined transaction listener can be added to a session 
 * to receive and respond to notifications of various events. 
 * Each event is either the initiation or the successful completion of a transaction-related action:
 * <ul type=disc>
 * <li> An initiation event occurs when a call is made to the method that performs the action. 
 * <li> A completion event occurs when the method that performs the action returns.
 *  <p><b>Note:</b>If the method that performs a transaction-related action throws an exception, 
 * the action is not completed and the corresponding completion event does not occur.
 * </ul></p>
 * 
 * <p>Any number of transaction listeners can be added to a particular session. The
 * session maintains a <i>registry</i> of the listeners. A session notifies each listener in its
 * registry when an event occurs. Each transaction listener has a <i>priority</i> that
 * controls the order in which it receives notifications, relative to other listeners in
 * the same registry. A transaction listener's priority is set by the constructor that
 * creates the listener and cannot be changed subsequently.
 * 
 * 
 * <p>You add a transaction listener to a session by calling
 * the session's
 * {@link Session#addTransactionListener <tt>addTransactionListener</tt>} method. 
 * Similarly, you remove a transaction listener from a session by calling
 * the session's
 * {@link Session#removeTransactionListener <tt>removeTransactionListener</tt>} method. 
 * 
 * 
 * <p>Because this class is abstract, you never instantiate it; instead,
 * you work with instances of its derived classes.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 * <TD><A HREF="#TransactionListener(int)">TransactionListener(int)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Processing&nbsp;Events</B></TD>
 * <TD><A HREF="#onTransactionBegin(int, int, int, int)">onTransactionBegin(int, int, int, int)</A><BR>
 *     <A HREF="#onTransactionBegun(long)">onTransactionBegun(long)</A><BR>
 *     <A HREF="#onOpenModeUpgrade(int, boolean)">onOpenModeUpgrade(int, boolean)</A><BR>
 *     <A HREF="#onOpenModeUpgraded()">onOpenModeUpgraded()</A><BR>
 *     <A HREF="#onTransactionCheckpoint(int, boolean, int)">onTransactionCheckpoint(int, boolean, int)</A><BR>
 *     <A HREF="#onTransactionCheckpointed()">onTransactionCheckpointed()</A><BR>
 *     <A HREF="#onTransactionCommit(int, boolean)">onTransactionCommit(int, boolean)</A><BR>
 *     <A HREF="#onTransactionCommitted()">onTransactionCommitted()</A><BR>
 *     <A HREF="#onTransactionAbort(int, boolean, int)">onTransactionAbort(int, boolean, int)</A><BR>
 *     <A HREF="#onTransactionAborted()">onTransactionAborted()</A><BR>
 *     <A HREF="#onTransactionFinished(boolean)">onTransactionFinished(boolean)</A><BR>
 *     <A HREF="#priority()">priority()</A>
 * </TD></TR>
 * </TABLE>
 */
abstract public class TransactionListener
{
    private int priority ;

    /**
     * Constructs a new transaction listener with the specified priority
     * (highest == 0). Higher priority listeners are notified first.
     *
     * @param 	 _priority	The desired priority of  this listener.
     */
    protected TransactionListener(int _priority)
        { priority = _priority ; }

    /**
     * Handles notification that the session's {@link Session#begin <tt>begin</tt>} method has been
     * called.</p>
     *
     * @param 	 nestCount	The nest count for this call to <tt>begin</tt> 
	 * (after <tt>begin</tt> increments 
	 * the nest count). If this is an unnested call, the nest count is 1.</p>
	 * 
     * @param 	 openMode	The open mode for the session, defined in 
	 * the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>openReadOnly</tt><dd>The session allows read-only access.</dd>
	 *  <dt><tt>openReadWrite</tt><dd>The session allows read/write access. </dd>
	 * </dd></dl></dl></p>
	 * 
     * @param 	 mrowMode	The MROW mode for the session;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>MROW</tt></dt>    <dd>The session uses the MROW concurrent-access policy.</dd>
     *  <dt> <tt>NO_MROW</tt></dt>  <dd>The session uses the standard (non-MROW) concurrent-access policy.</dd>
     * </dd></dl></dl></p></p>
	 * 
     * @param 	 indexMode	The index mode for the session; one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>INSENSITIVE</tt></dt> <dd>When the session's transaction is
	 * committed, indexes are updated automatically.</dd>
     *  <dt><tt>SENSITIVE</tt></dt> <dd>Indexes are updated automatically
     * during the transaction immediately after an indexed object is deleted
	 * or an object of the indexed class is made persistent.</dd>
     *  <dt><tt>EXPLICIT_UPDATE</tt></dt> <dd>The application must update
	 * indexes manually by explicit calls to the
	 * <a href="ooObj.html#updateIndexes()"><tt>updateIndexes</tt></a>
	 * method of each new object or modified indexed object.</dd>
     * </dd></dl></dl></p>
     */
    protected void onTransactionBegin(int nestCount, int openMode, int mrowMode, int indexMode) {}

    /**
     * Handles notification that the session has begun a transaction.</p>
     *
     * @param 	 transactionId	The lock server's transaction identifier 
	 * for the new transaction.
     */
    protected void onTransactionBegun(long transactionId) {}

    /**
     * Handles notification that an attempt has been made to upgrade the
     * session from read-only to read-write.</p>
     *
     * @param 	 nestCount	The session's current nest count.</p>
	 * 
     * @param 	 activeTransaction	True if the session is in a transaction; 
	 * otherwise false.
     */
    protected void onOpenModeUpgrade(int nestCount, boolean activeTransaction) {}

    /**
     * Handles notification that the session has been upgraded from read-only
     * to read-write.</p>
     */
    protected void onOpenModeUpgraded() {}

    /**
     * Handles notification that the session's {@link Session#checkpoint <tt>checkpoint</tt>} method
     * has been called.</p>
     *
     * @param 	 nestCount	The session's current nest count.</p>
     * @param 	 activeTransaction	True if the session is in a transaction; otherwise, false.</p>
     * @param 	 downgradeMode	The lock downgrade mode for the call to checkpoint;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>NO_DOWNGRADE</tt> <dd>Preserve all locks held by this
     * session.</dd>
     * <dt> <tt>DOWNGRADE_ALL</tt> <dd>Downgrade all locks to read locks.</dd>
     * </dd></dl></dl></p>
     */
    protected void onTransactionCheckpoint(int nestCount, 
				 boolean activeTransaction,
				 int downgradeMode) {}

    /**
     * Handles notification that the session has checkpointed a transaction.
     */
    protected void onTransactionCheckpointed() {}

    /**
     * Handles notification that the session's {@link Session#commit <tt>commit</tt>} method has
     * been called.</p>
     *
     * @param 	 nestCount	The nest count for this call to <tt>commit</tt> 
	 * (before <tt>commit</tt> decrements the nest count). This call to <tt>commit</tt> 
	 * matches the call to <tt>begin</tt> with the same nest count.</p>
	 * 
     * @param 	 activeTransaction	True if the session is in a transaction; 
	 * otherwise, false.
     */
    protected void onTransactionCommit(int nestCount, boolean activeTransaction) {}

    /**
     * Handles notification that the session has committed a transaction.
     */
    protected void onTransactionCommitted() {}

    /**
     * Handles notification that the session's {@link Session#abort <tt>abort</tt>} method has
     * been called.</p>
     *
     * @param 	 nestCount	The session's current nest count (before <tt>abort</tt> resets the 
	 * nest count to 0).</p>
	 * 
     * @param 	 activeTransaction	True if the session is in a transaction; 
	 * otherwise, false.</p>
	 * 
     * @param 	 mode	Reserved for internal use.
     */
    protected void onTransactionAbort(int nestCount,  
			    boolean activeTransaction, 
			    int mode) {}

    /**
     * Handles notification that the session has aborted a transaction.
     */
    protected void onTransactionAborted() {}

    /**
     * Handles notification that the session has finished an indivisible
     * unit of work in a transaction.</p>
     *
     * @param 	 committed	True if the transaction was committed or checkpointed; false if the transaction was aborted.
     */
    protected void onTransactionFinished(boolean committed) {}

    /**
     * Gets this transaction listener's priority.</p>
     *
     * @return		This transaction listener's priority.
     */
    public int priority()
        { return priority ; }
}
