package com.objy.query.expression;
/**
 * Represents an interval literal value node.
 *
 */
public class IntervalLiteralValueExpression extends LiteralValueExpression
{
    /**
     * Constructor.
     */
    public IntervalLiteralValueExpression() 
    {
        this(Binding.create());
    }
    
    /**
     * Constructor taking integers for the day, hours, minutes, and seconds.
     */
    
    public IntervalLiteralValueExpression(int day, int hours, int minutes, int seconds) 
    {
        this(Binding.create(day, hours, minutes, seconds));
    }
    
    /**
     * Constructor taking an ID.
     */  
	IntervalLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }
    
    /**
     * Constructor taking a string representation of an interval in the format of &lt;days&gt;:&lt;hours&gt;:&lt;minutes&gt;:&lt;seconds&gt;.
     */
    public IntervalLiteralValueExpression(String interval) 
    {
    	String[] tokens = Util.verifyIntervalArgument(interval);
    	
    	int day = Integer.parseInt(tokens[0]);
    	int hour = Integer.parseInt(tokens[1]);
    	int minute = Integer.parseInt(tokens[2]);
    	int second = Integer.parseInt(tokens[3]);
    	
        setIdAfterNullCheck(Binding.create(day, hour, minute, second));
    }
    
    /**
     * Returns a string representation of the interval literal value.
     */  

	public String getValue() 
    {
	    throwExceptionIfInvalidOrClosed(getId());
        return getPQLRepresentation();
    }
    
	@Override
	public String toString() 
    {
        return getValue();
    }
	
	@Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.IntervalLiteralValueExpression; 
    }
	
	@Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitIntervalLiteralValue(this);
    }
	
	static class Binding
	{
	    private static native long create();
	    private static native long create(int day, 
	            int hours, int minutes, int seconds);
	}
}
