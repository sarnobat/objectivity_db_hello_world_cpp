/*
 * @(#)Xid.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.ejb ;

import javax.transaction.xa.XAResource ;

import com.objy.db.ObjyRuntimeException ;

/**
 * Represents transaction-branch identifiers.  
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>A transaction with an Objectivity/DB federated database can be 
 * conducted as one of many <i>transaction branches</i> within a
 * global transaction.  Unlike local Objectivity/DB transactions, the global
 * transaction is under the control of a transaction manager. 
 *
 * <h2>Understanding Transaction-Branch Identifiers</h2>
 *
 * <p>Each transaction branch is identified by a <i>transaction-branch 
 * identifier</i>, which uniquely identifies both the global transaction and 
 * the branch within it. A transaction-branch identifier consists of three 
 * components: 
 *
 * <ul>
 * <li>A global-transaction identifier uniquely identifies a particular 
 * global transaction.</p>
 *
 * <li>A branch qualifier uniquely identifies a particular transaction branch 
 * within the global transaction.</p>
 *
 * <li>A format identifier indicates the format in which the 
 * transaction-branch identifier is encoded.
 * </ul>
 *
 * Each transaction branch in the global transaction is performed by a 
 * <i>resource manager</i>.  Your application interacts with the transaction 
 * manager, which calls methods of the various resource managers to start and 
 * end work in the transaction branchs, to prepare the work to be committed, 
 * and to commit or roll back the work at the end of the global transaction. 
 * 
 * <p>Typically, an application that accesses a federated database as part of a
 * global transactions does so through a <a href="UserConnection.html">
 * user connection</a>.

 * <p><b>Note:</b> Only a transaction manager should create a 
 * transaction-branch identifier or set its component parts.
 * You do not work directly with instances of this class unless 
 * you implement your own transaction manager.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER=1 CELLPADDING=3 CELLSPACING=0 WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 *     <td>
 *     <a href="#Xid(int, byte[], byte[])">Xid(int, byte[], byte[])</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 *     <td>
 *     <a href="#getGlobalTransactionId()">getGlobalTransactionId()</a><br>
 *     <a href="#getBranchQualifier()">getBranchQualifier()</a><br>
 *     <a href="#getFormatId()">getFormatId()</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Setting&nbsp;Information</b></td>
 *     <td>
 *     <a href="#setGlobalTransactionId(byte[])">setGlobalTransactionId(byte[])</a><br>
 *     <a href="#setBranchQualifier(byte[])">setBranchQualifier(byte[])<br>
 *     <a href="#setFormatId(int)">setFormatId(int)</a>
 *     </td></tr>
 * </table>
 *
 */
@Deprecated
final public class Xid implements javax.transaction.xa.Xid {
    
    private int formatId = 0 ;
    private byte[] globalTransactionId = null ;
    private byte[] branchQualifier = null ;
    
	/**
	 * Constructs a transaction-branch identifier.</p> 
	 *
	 * @param 	 formatId	The format identifier.
	 * 0 indicates the Open Systems Interconnection (OSI) Commitment, 
     * Concurrency, and Recovery (CCR) standard for atomic-action 
     * identifiers. -1 indicates a null transaction-branch identifier.</p> 
	 *
	 * @param 	 globalTransactionId	The 
     * global-transaction identifier.</p>
	 *
	 * @param 	 branchQualifier	The branch qualifier.</p>
	 */
    public Xid(int formatId, byte[] globalTransactionId, byte[] branchQualifier) {
        this.formatId = formatId ;
        this.globalTransactionId = globalTransactionId ;
        this.branchQualifier = branchQualifier ;
    }

    /**
     * Gets the format identifier in this transaction-branch identifier.</p>
     *
     * @return  The format identifier. 
	 * 0 indicates the Open Systems Interconnection (OSI) Commitment, 
     * Concurrency, and Recovery (CCR) standard for atomic-action 
     * identifiers. -1 indicates a null transaction-branch identifier.</p> 
     *
     * @see  #setFormatId
     */
    public int getFormatId() {
        return formatId ;
    }

    /**
     * Gets the global-transaction identifier in this transaction-branch 
     * identifier.</p> 
     *
     * @return  An array of bytes containing the global-transaction 
     * identifier.</p>
     *
     * @see  #setGlobalTransactionId
     */
    public byte[] getGlobalTransactionId() {
        return globalTransactionId ;
    }

    /**
     * Gets the branch qualifier in this transaction-branch identifier.</p>
     *
     * @return  An array of bytes containing the branch qualifier.</p>
     *
     * @see  #setBranchQualifier
     */
    public byte[] getBranchQualifier() {
        return branchQualifier ;
    }
    
    // additional setter methods
 
	/**
	 * Sets the format identifier in this transaction-branch identifier.</p>
	 *
	 * @param 	 _formatId	The format identifier.
	 * 0 indicates the Open Systems Interconnection (OSI) Commitment, 
     * Concurrency, and Recovery (CCR) standard for atomic-action 
     * identifiers. -1 indicates a null transaction-branch identifier.</p> 
     *
     * @see  #getFormatId
	 */
    public void setFormatId(int _formatId) {
        formatId = _formatId ;
    }
    
	/**
	 * Sets the global-transaction identifier in this transaction-branch 
     * identifier.</p> 
	 *
	 * @param 	 _globalTransactionId	An array of 
     * bytes containing the global-transaction identifier.</p>
     *
     * @see  #getGlobalTransactionId
	 */
    public void setGlobalTransactionId(byte[] _globalTransactionId) {
        globalTransactionId = _globalTransactionId ;
    }

	/**
	 * Sets the branch qualifier in this transaction-branch 
     * identifier.</p>
	 *
	 * @param 	 _branchQualifier	An array of 
     * bytes containing the branch qualifier. </p>
     *
     * @see  #getBranchQualifier
	 */
    public void setBranchQualifier(byte[] _branchQualifier) {
        branchQualifier = _branchQualifier ;
    }
    
    /** 
     * For internal use only; you should not call this method.
     */
    public void printXid() {
        System.out.println(" Xid : " + this.toString()) ;
        System.out.println("    format id  : " + this.getFormatId()) ;
        System.out.println("    global tid : " + new String(this.getGlobalTransactionId())) ;
        System.out.println("    branch qual: " + new String(this.getBranchQualifier())) ;
    }
    
}
