package com.objy.query.expression;
/**
 * Represents an expression node visitor.
 */
public abstract class ExpressionVisitor 
{
	/**
	 * Constructs an expression node visitor.
	 */
	public ExpressionVisitor() {}

    /**
     * Visits an attribute value expression node.
     */
    public void visitAttributeValue(AttributeValueExpression attributeValue) {
    }
    
    /**
     * Visits a literal value node.
     */

    public void visitLiteralValue(LiteralValueExpression literalValue) {
    }
    
    /**
     * Visits an operator expression node. If not overriden, returns true.
     */
    public boolean visitOperator(OperatorExpression op) {
        return false;
    }

    /**
     * Visits an operand list.
     */
    public void visitOperandList(OperandList operandList) {
    	int numberOfOperands = operandList.getNumberOfOperands();
		for (int i = 0; i< numberOfOperands; i++)
		{
			Expression operandExp = operandList.getOperand(i);
			operandExp.accept(this); 			
		}
    }
    
    /**
     * Visits a boolean literal value node.
     */
    public void visitBoolLiteralValue
       (BoolLiteralValueExpression booleanLiteralValue) {
    }

    /**
     * Visits a string literal value node.
     */
    public void visitStringLiteralValue
       (StringLiteralValueExpression stringLiteralValue) {
    }

    /**
     *  Visits an integer literal value node.
     */
    public void visitIntLiteralValue
       (IntLiteralValueExpression intLiteralValue) {
    }

    /**
     *  Visits an unsigned integer literal value node.
     */
    public void visitUIntLiteralValue
       (UIntLiteralValueExpression uintLiteralValue) {
    }

    /**
     *  Visits a float literal value node.
     */
    public void visitFloatLiteralValue
       (FloatLiteralValueExpression floatLiteralValue) {
    }

    /**
     *  Visits a Date literal value node.
     */
    public void visitDateLiteralValue
       (DateLiteralValueExpression dateLiteralValue) {
    }

    /**
     *  Visits a Time literal value node.
     */
    public void visitTimeLiteralValue
       (TimeLiteralValueExpression timeLiteralValue) {
    }

    /**
     * Visits a DateTime literal value node.
     */
    public void visitDateTimeLiteralValue
       (DateTimeLiteralValueExpression dateTimeLiteralValue) {
    }

    /**
     *  Visits an Interval literal value node.
     */
    public void visitIntervalLiteralValue
       (IntervalLiteralValueExpression intervalLiteralValue) {
    }

    /**
     *  Visits an ordered list literal value node.
     */
    public void visitOrderedListLiteralValue
       (OrderedListLiteralValueExpression orderedListLiteralValue) {
    }

    /**
     *  Visits a class type literal value node.
     */
    public void visitClassTypeLiteralValue
       (ClassTypeLiteralValueExpression classTypeLiteralValue) {
    }

    /**
     *  Visits an OID literal value node.
     */
    public void visitOidLiteralValue
       (OidLiteralValueExpression oidLiteralValue) {
    }
    
    /**
     *  Visits an object literal value node.
     */
    public void visitObjectLiteralValue
       (ObjectLiteralValueExpression objectLiteralValue) {
    }
}
