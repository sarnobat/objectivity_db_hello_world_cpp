/*
 * @(#)ObjyRuntimeException.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db ;

import com.objy.pm.Access;
import com.objy.pm.ExceptionInfo;

import java.util.Enumeration;
import java.util.Vector;

/**
 * Superclass for all Objectivity/DB unchecked exceptions.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class   ObjyRuntimeException
       extends RuntimeException
{
	/**
	 * @serial
	 */
    private Vector errors ;

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ObjyRuntimeException() {
        errors = new Vector() ;
	Access.resolveSnapShot() ;
    }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ObjyRuntimeException(String message) {
        super(message) ;
        errors = new Vector(1) ;
        errors.addElement(new ExceptionInfo(message)) ;
	Access.resolveSnapShot() ;
    }

    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ObjyRuntimeException(String message, Throwable cause) {
        super(message, cause) ;
        errors = new Vector(1) ;
        errors.addElement(new ExceptionInfo(message)) ;
    Access.resolveSnapShot() ;
    }
    
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ObjyRuntimeException(Throwable cause) {
        super(cause) ;
    Access.resolveSnapShot() ;
    }
    
	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ObjyRuntimeException(Vector errors) {
        super(((ExceptionInfo)errors.firstElement()).getMessage()) ;
        this.errors = errors ;
	Access.resolveSnapShot() ;
    }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ObjyRuntimeException(String message, Vector errors) {
        super(message) ;
        this.errors = errors ;
    }

	/**
	 * Gets this exception's
	 * <a href="./app/ExceptionInfo.html">exception information 
     * objects</a>.</p>
	 *
	 * @return		The information objects describing the
	 * Objectivity/DB errors that occurred, in the order in which the
	 * errors were reported, or null if no Objectivity/DB errors occurred.
	 */
    public Vector errors() {
	if (errors != null)
	    return((Vector)errors.clone()) ;
	else
	    return null ;
    }

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public void setErrors(Vector errors)
        { this.errors = errors ; }

	/**
	 * Prints information about the errors that occurred.
	 *
	 * <p>If this exception has
	 * <a href="./app/ExceptionInfo.html">exception information
	 * objects</a>, this method prints the ID and description of each
	 * error, in the order in which the errors were reported.
	 */
    public void reportErrors() {
        if (errors == null) {
            Access.getCurrentSessionErr().println("no errors for this exception") ;
            return ;
        }
        ExceptionInfo info ;
        Enumeration e = errors.elements();
        while (e.hasMoreElements()) {
            info = (ExceptionInfo)e.nextElement();
            Access.getCurrentSessionOut().println("Error Id{"+ info.getId()+ "} Level{" + info.getLevel()+ "} " + info.getMessage()) ;
        }
    }
}


