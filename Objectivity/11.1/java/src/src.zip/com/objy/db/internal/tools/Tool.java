package com.objy.db.internal.tools;

import com.objy.db.internal.configuration.ParameterValueGroup;
import com.objy.db.internal.configuration.Specification;

/**
 * Class representation of tool to be executed.  The tool can currently only be executed in 
 * process.  You specify the parameters for the tool, and method of which you want to 
 * obtain the output, and if specified obtain string representations of the output from
 * this class
 */
public class Tool {
    
    private long mToolPtr;
    private String mStandardOut;
    private String mStandardErr;
    private String mCombinedStream;
    
    static
    {
        ToolRegistry.init();
    }
    
    /**
     * STANDARD_OUTPUT tool execution out put goes to screen
     * STRING_OUTPUT tool execution output got to seperate strings for stdout
     * and stderr
     * COMBINED_OUTPUT tool execution output goes to a combined string
     * @author robertc
     *
     */
    public enum Output
    {
        STANDARD_OUTPUT,//tool execution out put goes to screen
        STRING_OUTPUT, //tool execution output got to seperate strings for 
        //stdout and stderr
        COMBINED_OUTPUT // tool execution output goes to a combined string
    }

    
   /* Currently only support in process execution 
     public enum ExecutionCapabilities
    {
        IN_PROCESS_EXECUTION,
        OUT_OF_PROCESS_EXECUTION
    };

    public enum ExecutionMode
    {
        IN_PROCESS,
        OUT_OF_PROCESS,
        NO_PREFERENCE
    };
    
    public int execute(
	    const objy::configuration::ParameterValueGroup& values,
	    objy::configuration::ParameterErrors& errors, 
	    ExecutionMode executionMode = NO_PREFERENCE,
	    ToolOutputSink* sink = 0
      );
     */
    
    /**
     * Executes the tool
     * @param values values to be passed to the tool execution
     * @param output method of which the tool should present output
     */
    public int execute(ParameterValueGroup values, Output output)
    {
        return Binding.execute(mToolPtr, values.getObject(), output.ordinal(),
                this);
    }

    /**
     * Gets the name of the tool.
     * @return Name of the tool.
     */
    public String getName()
    {
        return Binding.getName(mToolPtr);
    }

    /**
     * Gets the title output of the tool.
     * @return Title of the tool.
     */
    public String getTitle()
    {
        return Binding.getTitle(mToolPtr);
    }
    
    /**
     * Gets the description of the tool
     * @return Description of the tool.
     */
    public String getDescription()
    {
        return Binding.getDescription(mToolPtr);
    }
    
    /**
     * Gets description of the tool usage of the tool.
     * @return Usage message of the tool.
     */
    public String getUsageMessage()
    {
        return Binding.getUsageMessage(mToolPtr);
    }
    
    /**
     * Gets the help description of the tool.
     * @return Help message of the tool.
     */
    public String getHelpMessage()
    {
        return Binding.getHelpMessage(mToolPtr);
    }
    
    /**
     * Gets the banner of the tool.
     * @return Banner of the tool.
     */
    public String getBanner()
    {
        return Binding.getBanner(mToolPtr);
    }
    
    /**
     * Gets the specification of the tool.
     * @return Specification of the tool.
     */
    public  Specification getSpecification()
    {
        return new Specification(Binding.getSpecification(mToolPtr));
    }
    
    /**
     * Gets the standard output stream of tool execution.
     * @return String representation of the standard output stream of tool execution.
     */ 
    public String getStandardOutput()
    {
        return mStandardOut;
    }
    
    /**
     * Gets the standard error stream of tool execution.
     * @return String representation of the standard error stream of tool execution.
     */
    public String getStandardError()
    {
        return mStandardErr;
    }
    
    /**
     * Gets the standard output and error stream of tool execution in a combined string
     * @return String representation of combined standard output and error stream of
     * tool execution  
     */
    public String getCombinedOutput()
    {
        return mCombinedStream;
    }
    
    /*
     * DO NOT FINALIZE there is a registry of tools which is kept
     * on the C++ side so we are really only getting a pointer
     * from a registry which owns the tool.  
    protected void finalize() throws Throwable 
    {
        Binding.destruct(mToolPtr);

    }
    */
    
    private static class Binding
    {
        public static native String getName(long mToolPtr);
        public static native String getTitle(long mToolPtr);
        public static native String getDescription(long mToolPtr);
        public static native String getUsageMessage(long mToolPtr);
        public static native String getHelpMessage(long mToolPtr);
        public static native String getBanner(long mToolPtr);
        public static native int execute(long mToolPtr, 
                long parameterValueGroupPtr,
                int outputType,
                Tool tool
                );
        public static native long getSpecification(long mToolPtr);
        //public static native void destruct(long mToolPtr);
    }



    
    Tool(long toolptr)
    {
        mToolPtr = toolptr;
    }


    // Prevent copy construction or assignment
    private Tool(Tool other)
    {
    }
    
    
    // Prevent default constructor
    private Tool()
    {        
    }
    

    /*   
      
      
      public ExecutionCapabilities getExecutionCapabilities();

	      public  int executeInProcess(
	        const objy::configuration::ParameterValueGroup& values,
	        objy::configuration::ParameterErrors& errors,
	        ToolOutputSink* sink) = 0;

	      public  int executeOutOfProcess(
	        const objy::configuration::ParameterValueGroup& values,
	        objy::configuration::ParameterErrors& errors,
	        ToolOutputSink* sink);

	    protected:
	      Tool(const char* name, 
	           const char* title, 
	           const char* description, 
	           ExecutionCapabilities executionCapabilities,
	           const char* specificationName = 0, 
	           const char* scope = 0);

	      virtual void addDefaultParameters();*/

}
