package com.objy.db.iapp ;

import javax.transaction.xa.XAException ;
import javax.transaction.xa.XAResource ;
import javax.transaction.xa.Xid ;

import com.objy.db.app.Session ;

/**
 * Reserved for internal use.
 */
public interface PXATransaction  {

    void start(Xid xid, int flags) throws XAException ;

    void end(Xid xid, int flags) throws XAException ;
    
    int prepare(Xid xid) throws XAException ;
    
    Xid[] recover(int flag) throws XAException ;
    
    void commit(Xid xid, boolean onePhase) throws XAException ;

    void rollback(Xid xid) throws XAException ;
    
    void forget(Xid xid) throws XAException ;

    int getTransactionTimeout() ;

    // Session getSession() ;
    
    boolean isOpen() ;

    boolean setTransactionTimeout(int seconds) ;
    
    void end(int flags) throws XAException ;
}

