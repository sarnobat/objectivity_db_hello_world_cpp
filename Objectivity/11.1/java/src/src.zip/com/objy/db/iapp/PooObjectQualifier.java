//***************************************************************************//
//                                                                           //
//                Copyright � 2012 Objectivity Inc, USA.                     //
//                                                                           //
//    All Rights Reserved. Unauthorized use, duplication or distribution     //
//         of this software, or any portion of it, is prohibited.            //
//                                                                           //
//***************************************************************************//
package com.objy.db.iapp;

/**
 * The interface for ooObjectQualifier
 */
public interface PooObjectQualifier {

    long getId();
    
    boolean doesQualify(Persistent obj);
    
    long getExpressionTree();
    
    void close();

    void setBoolVarValue(String variableName, boolean value);
    
    void setIntVarValue(String variableName, long value);
    
    void setUIntVarValue(String variableName, long value);
    
    void setFloat64VarValue(String variableName, float value);
    
    void setStringVarValue(String variableName, String value);
    
    void setDateVarValue(String variableName, java.sql.Date value);
    
    void setTimeVarValue(String variableName, java.sql.Time value);
    
    void setDateTimeVarValue(String variableName, java.sql.Timestamp value);
    
    void setIntervalVarValue(String variableName, long value);
    
    void setRefVarValue(String variableName, Persistent refVal);
    
    void setClassVarValueByName(String variableName, String classValName);
    
    void setClassVarValueByType(String variableName, long classValType);
}
