package com.objy.query.expression;

/**
 * Represents an operand list, which is associated with an operator expression node.
 *
 */
public class OperandList extends AbstractExpression
{
    /**
     * Constructs an operand list with an ID.
     */
    OperandList(long id)
    {
        setIdAfterNullCheck(id);
    }

    /**
     * Adds the specified operand to the enclosing operator expression.
     */
    public void addOperand (Expression operand) throws ExpressionException
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (operand == null || operand.getId() == 0)
            return;
        addOperand(operand, null);
    }
    
    /**
     * Adds the specified operand to the enclosing operator expression
     * before the specified operand or at the end if the specified expression is null.
     */
    public void addOperand(Expression operand,  Expression before) throws ExpressionException
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (operand == null || operand.getId() == 0)
        return;
        if (before == null)
        {
            Binding.addOperandBefore(mId, operand.getId(), 0L);
        }
        else
        {
            Binding.addOperandBefore(mId, operand.getId(), before.getId());
        }
    }

    /**
     * Adds the specified operand to the enclosing operator expression
     * at the specified position. The list is expanded if needed.  If an
     * operand exists at the specified position, it and all subsequent ones
     * are moved down in the list by one.
     */
    public void addOperand(Expression operand, int position) throws ExpressionException
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (operand == null || operand.getId() == 0)
            return;
        Binding.addOperandAt(mId, operand.getId(), position);
    }

    /**
     * Sets the operand to the specified position.  The list is expanded
     * if needed.  If an operand exists at the specified position, it
     * is replaced.
     */
    public void setOperand(Expression operand, int position) throws ExpressionException
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (operand == null || operand.getId() == 0)
            return;
        Binding.setOperand(mId, operand.getId(), position);
    }


    /**
     * Returns the operand for the specified position, or null 
     * if none exists.
     */
    public Expression getOperand(int position) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Expression.getExpression(Binding.getOperand(mId, position));
    }

    /**
     * Removes the specified operand. 
     * The caller is responsible for deleting the operand if it is not
     * later made the head of an expression tree or added as an operand
     * of another operand list.
     */
    public void removeOperand(Expression operand) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (operand == null || operand.getId() == 0)
            return;
        Binding.removeOperand(mId, operand.getId());
    }

    /**
     * Returns the total number of operands.
     * @return The number of operands
     */
    public int getNumberOfOperands() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getNumberOfOperands(mId);
    }

    /**
     *  Returns the position of the operand within the list, or -1 if not 
     *  found.
     */
    public int getPositionOfOperand(Expression operand) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        if (operand == null || operand.getId() == 0)
            return -1;
        return Binding.getPositionOfOperand(mId, operand.getId());
    }

    /**
     * Returns the parent operator expression.
     */
    public OperatorExpression getParentOperatorExpression()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return new OperatorExpression(Binding.getParentOperatorExpression(mId));
    }
    
    static class Binding
    {
        private static native int getNumberOfOperands(long id);
        private static native long getOperand(long id, int position);
        
        // Adds the specified operand to the enclosing operator expression
        // before the specified operand.
        private static native void addOperandBefore(long id, long operandId, long beforeOperandId);
        
        // Adds the specified operand to the enclosing operator expression
        // before the specified operand or at the end if it is 0.
        private static native void addOperandAt(long id, long operandId, int position);
        
        // Sets the operand to the specified position.  The list is expanded
        // if needed.  If an operand exists at the specified position, it
        // is replaced.
        private static native void setOperand(long id, long operandId, int position);
        
        // Removes the specified operand. 
        // The caller is responsible for deleting the operand if it is not
        // later made the head of an expression tree or added as an operand
        // of another operand list.
        private static native void removeOperand(long id, long operandId);
        
        private static native int getPositionOfOperand(long id, long operandId);
        
        private static native long getParentOperatorExpression(long id);
    }
}
