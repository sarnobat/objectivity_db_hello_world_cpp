package com.objy.db.internal;

import com.objy.db.ObjyRuntimeException;
import com.objy.db.app.ooObj;
import com.objy.db.iapp.Persistent;
import com.objy.pm.SessionPersistor;
import com.objy.pm.ooId;

public class Ref<T extends Persistent>
{
    private ooObj mOwner;
    private String mAttribName;
    private long mClassMap = 0;
    SessionPersistor mSessionPersistor;
    
    //private T mRef;
    
    /**
     * Constructs a lazy reference with the owner object and the name of the attribute. 
     * If the attribute name is incorrect, a runtime exception will be thrown when 
     * getting/setting the lazy ref.
     * @param owner       The objects that owns the lazy reference.
     * @param attribName  The name of the reference attribute. 
     */
    public Ref(ooObj owner, String attributeName)
    {
        mOwner = owner;
        mAttribName = attributeName;
        //Note that owner probably hasn't been persisted yet so can't cache classMap or sessionpersistor yet
      
    }
    
    private SessionPersistor getSessionPersistor()
    {
        if(mSessionPersistor == null)
            mSessionPersistor = (SessionPersistor)mOwner.getPersistor().getSession().persistor();
        return mSessionPersistor;
    }
    
    private long getClassMap()
    {
        if(mClassMap == 0)
            mClassMap = mOwner.getPersistor().getClassMap();
        return mClassMap;            
    }
    
    /**
     * Gets the referenced object.
     */
    public T getObject()
    {
        //if (mRef == null)
        //{
            SessionPersistor sp = getSessionPersistor();
            try
            {
                sp.lockMonitor();      
                long ownerConnId = mOwner.getPersistor().connectionId();
                return (T)sp.connection().getObject(ownerConnId, getClassMap(), 
                        mAttribName, this, mOwner);
    
            }
            finally { sp.unlockMonitor() ; }   
        //}
        //return mRef;
    }
    
    /**
     * Gets the oid of the referenced object.
     */
    public com.objy.pm.ooId getOid()
    {        
        com.objy.pm.ooId oid = new ooId();
        SessionPersistor sp = getSessionPersistor();
        try 
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();
            sp.connection().getOid(ownerConnId, getClassMap(), 
                    mAttribName, oid, this);
            return oid;
        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Sets the given object as the reference.
     * @param obj The object to be set
     */
    public  void setObject(T obj) throws ObjyRuntimeException
    {        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();
            if (obj == null)
            {                
                sp.connection().setObject(ownerConnId, getClassMap(), mAttribName, 0, this, mOwner);
            }
            else if (obj.getPersistor() != null)
            {
                sp.connection().setObject(ownerConnId,getClassMap(), mAttribName, obj.getPersistor().connectionId(),
                        this, mOwner);
            }
            else
            {
                throw new ObjyRuntimeException("The object must be persistent before setting it to the reference.");
            }
        }
        finally { sp.unlockMonitor() ; }    
    }
    
    /**
     * Sets the given object as the reference.
     * @param obj The object to be set
     */
    public  void setOid(ooId oid) throws ObjyRuntimeException
    {        
        SessionPersistor sp = getSessionPersistor();
        try
        {
            sp.lockMonitor();
            long ownerConnId = mOwner.getPersistor().connectionId();
            if (oid != null)
            {                
                sp.connection().setOid(ownerConnId,getClassMap(), mAttribName, oid,
                        this, mOwner);
            }
            else
            {
                throw new ObjyRuntimeException("The oid is null.");
            }
        }
        finally { sp.unlockMonitor() ; }    
    }
}
