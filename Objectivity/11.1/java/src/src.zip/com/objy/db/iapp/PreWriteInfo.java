/*
 * @(#)PreWriteInfo.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.iapp ;

/**
 * Defines behavior shared by all pre-write information objects.
 *
 * <p>Before a persistent object is written to the database, a pre-write event 
 * occurs. The object's <tt>pre-write</tt> method handles 
 * the pre-write event; the parameter to that method is a pre-write 
 * information object specifying the reason why the object is being written.
 *
 * <p>You shouldn't need to implement this interface in any class you define.
 */
public interface PreWriteInfo
       extends   PersistentEventInfo
{
	/**
	 * Gets the reason why the pre-write event occurred.
	 *
	 * @return		The reason why the pre-write event occurred;
	 * one of the following constants defined in the <tt>PersistentEventInfo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>EVENT_WRITE</tt><dd>The object is being written by its <tt>write</tt> method.
     *
	 *  <dt><tt>EVENT_WRITE_BEFORE_COPY_OBJ</tt><dd>The object has to be 
	 * written before it can be copied.
     *
	 *  <dt><tt>EVENT_COMMIT</tt><dd>The object is being written during a 
	 * commit operation.
     *
	 *  <dt><tt>EVENT_CHECKPOINT</tt><dd>The object is being written during a 
	 * checkpoint operation with no downgrade of locks.
     *
	 *  <dt><tt>EVENT_CHECKPOINT_DOWNGRADE</tt><dd>The object is being written during a 
	 * checkpoint operation with write locks downgraded to read locks.
     *
	 *  <dt><tt>EVENT_FLUSH_FD</tt><dd>The object is being written during a 
	 * flush operation on the federated database.
     *
	 *  <dt><tt>EVENT_FLUSH_DB</tt><dd>The object is being written during a 
	 * flush operation on its database.
     *
	 *  <dt><tt>EVENT_FLUSH_CONTAINER</tt><dd>The object is being written during a 
	 * flush operation on its container.
	 * </dl></dl>
	 */
    int getReason() ;
}
