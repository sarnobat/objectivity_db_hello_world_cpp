/*
 * @(#)ObjectQualifier.java
 *
 * Copyright (c) 2012 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.query ;

import com.objy.db.ExpressionEvaluationException;
import com.objy.db.ExpressionSetupException;
import com.objy.db.ObjyRuntimeException ;

import com.objy.db.iapp.PooObjectQualifier ;
import com.objy.db.iapp.Persistent ;

import com.objy.pm.Access ;
import com.objy.query.expression.Expression;
import com.objy.query.expression.ExpressionSetupErrorHandler;
import com.objy.query.expression.ExpressionTree;

/**
 * Represents an object qualifier, which evaluates whether a persistent object
 * matches a given predicate string or predicate expression tree instance.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You use an object qualifier to filter arbitrary groups of objects that
 * cannot be scanned directly with a predicate string. For example, you can
 * use an object qualifier to perform a predicate query over the elements
 * in a persistent collection.
 * 
 *<p> An object qualifier's predicate string can optionally include a PQL variable
 * whose value can be changed between each object qualification. 
 * 
 * <p>For more information, see <a href="../../../../guide/jgdObjectQualification.html">Object Qualification</a>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 *<td VALIGN="top" WIDTH="17%"><B>Constructors</B></TD>
 *<TD width="83%"><A HREF="#ObjectQualifier(long, java.lang.String)">ObjectQualifier(long, String)</A><br />
 *<A HREF="#ObjectQualifier(long, com.objy.query.expression.Expression)">ObjectQualifier(long, Expression)</A><br />
 *<A HREF="#ObjectQualifier(java.lang.String, com.objy.query.expression.Expression)">ObjectQualifier(String, Expression)</A><br />
 *<A HREF="#ObjectQualifier(java.lang.String, java.lang.String)">ObjectQualifier(String, String)</A><br />

 *</TD></TR>
 *<TR>
 *<td VALIGN="top" WIDTH="17%"><B>Qualifying Objects</B></TD>
 *<TD><A HREF="#doesQualify(com.objy.db.iapp.Persistent)">doesQualify(Persistent)</A>
 *</TD></TR>
 *<TR>
 *  <td VALIGN="top"><strong>Using the Expression Tree</strong></TD>
 *<TD><A HREF="#doesQualify(com.objy.db.iapp.Persistent)">doesQualify(Persistent)</A><br />
 *  <A HREF="#getExpressionTree()">getExpressionTree()</A><br />
 *  <A HREF="#getTypeNumber()">getTypeNumber()</A><br />
 *  <A HREF="#getDefaultErrorHandler()">getDefaultErrorHandler()</A><br />
 *  <A HREF="#close()">close()</A><br /></TD>
 *</TR>
 *<TR>
 * <td VALIGN="top"><strong>Using PQL Variables</strong></TD>
 *  <TD><A HREF="#setBoolVarValue(java.lang.String, boolean)">setBoolVarValue(String, boolean)</A> <br />
 *    <A HREF="#setIntVarValue(java.lang.String, long)">setIntVarValue(String , long)</A> <br />
 *    <A HREF="#setUIntVarValue(java.lang.String, long)">setUIntVarValue(String , long)</A> <br />
 *    <A HREF="#setFloatVarValue(java.lang.String, float)">setFloatVarValue(String , float)</A> <br />
 *    <A HREF="#setStringVarValue(java.lang.String, java.lang.String)">setStringVarValue(String , String)</A><br />
 *    <A HREF="#setDateVarValue(java.lang.String, java.sql.Date)">setDateVarValue(String , java.sql.Date)</A> <br />
 *    <A HREF="#setTimeVarValue(java.lang.String, java.sql.Time)">setTimeVarValue(String , java.sql.Time)</A> <br />
 *    <A HREF="#setDateTimeVarValue(java.lang.String, java.sql.Timestamp)">setDateTimeVarValue(String , java.sql.Timestamp)</A><br />
 *    <A HREF="#setRefVarValue(java.lang.String, com.objy.db.iapp.Persistent)">setRefVarValue(String , Persistent)</A><br />
 *    <A HREF="#setClassVarValueByName(java.lang.String, java.lang.String)">setClassVarValueByName(String , String)</A><br />
 *   <A HREF="#setClassVarValueByType(java.lang.String, long)">setClassVarValueByType(String , long)</A></TD>
 *</TR>
 *</TABLE>
 */
public class ObjectQualifier //implements AutoCloseable JDK 7
{
    private transient PooObjectQualifier persistor ;

    private ExpressionTree mExpressionTree ;
    
    /**
     * Constructs an object qualifier without argument.</p>
     */
    private ObjectQualifier()
    {
        persistor = Access.new_ooObjectQualifierPersistor() ;
        getExpressionTree().setErrorHandler(new ExpressionSetupErrorHandler());
    }
    
    /**
     * Constructs an object qualifier to qualify objects of the specified type against the specified
     * predicate string.</p>
     *
     * @param    typeNumber Objectivity/DB type number of the class
     * whose instances are to be qualified.</p>
     *
     * @param    predicate  Condition that this query object will test,
     * expressed in the Objectivity/DB
     * <a href="../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
     *
     */
    public ObjectQualifier(long typeNumber, String predicate) throws ExpressionSetupException
    {
        persistor = Access.new_ooObjectQualifierPersistor(typeNumber, predicate) ;
        getExpressionTree().setErrorHandler(new ExpressionSetupErrorHandler());
    }

    /**
     * Constructs an object qualifier to qualify objects of the specified type against the specified
     * predicate string.</p>
     *
     * @param    className the name of the class
     * whose instances are to be qualified.</p>
     *
     * @param    predicate  Condition that this query object will test,
     * expressed in the Objectivity/DB
     * <a href="../../../../guide/jgdObjectQualification.html#Predicate Query Language">
     * predicate query language</A>.</p>
     *
     */
    public ObjectQualifier(String className, String predicate) throws ExpressionSetupException
    {
        persistor = Access.new_ooObjectQualifierPersistor(className, predicate) ;
        getExpressionTree().setErrorHandler(new ExpressionSetupErrorHandler());
    }

    /**
     * Constructs an object qualifier to qualify objects of the specified type against the specified
     * predicate expression tree instance.</p>
     *
     * @param    typeNumber Objectivity/DB type number of the class
     * whose instances are to be qualified.</p>
     *
     * @param    expression Predicate expression tree instance that this query object will test against.
     * @see <a href="{@docRoot}/com/objy/query/expression/Expression.html#completeSetup(long, com.objy.query.expression.ExpressionSetupErrorHandler, boolean)">
     * <tt>completeSetup(long, ExpressionSetupErrorHandler, boolean)</tt></a>
     * @see <a href="{@docRoot}/com/objy/query/expression/ExpressionTree.html#completeSetup()"
     * <tt>completeSetup()</tt></a>
     */

    public ObjectQualifier(long typeNumber, Expression expression) throws ExpressionSetupException
    { 
        persistor = Access.new_ooObjectQualifierPersistor(typeNumber, expression.getId()) ;
        getExpressionTree().setErrorHandler(new ExpressionSetupErrorHandler());
    }
    
    /**
     * Constructs an object qualifier to qualify objects of the specified type against the specified
     * predicate expression tree instance.</p>
     *
     * @param    className The name of the class
     * whose instances are to be qualified.</p>
     *
     * @param    expression Predicate expression tree instance that this query object will test against.
     *
     * @see <a href="{@docRoot}/com/objy/query/expression/Expression.html#completeSetup(long, com.objy.query.expression.ExpressionSetupErrorHandler, boolean)">
     * <tt>completeSetup(long, ExpressionSetupErrorHandler, boolean)</tt></a>
     *
     * @see <a href="{@docRoot}/com/objy/query/expression/ExpressionTree.html#completeSetup()"
     * <tt>completeSetup()</tt></a>
     */

    public ObjectQualifier(String className, Expression expression) throws ExpressionSetupException
    { 
        persistor = Access.new_ooObjectQualifierPersistor(className, expression.getId()) ;
        getExpressionTree().setErrorHandler(new ExpressionSetupErrorHandler());
    }
    
	/**
	 * Evaluates whether the specified persistent object matches this
     * object qualifier's predicate string or predicate expression tree instance.</p>
	 *
	 * @param 	 obj	The persistent object to be evaluated.</p>
	 *
	 * @return		True if the object matches the predicate string or expression tree
     * specified by the constructor that created this object qualifier; otherwise, false.</p>
     *
	 */
    public boolean doesQualify(Persistent obj) throws ExpressionSetupException, ExpressionEvaluationException
    {
        if (obj == null || obj.getPersistor() == null)
        {
            throw new ExpressionEvaluationException("Calling doesQualify() on NULL or transient object is not supported");
        }
        // doesQualify() may throw an ExpressionEvaluationException.
        boolean qualified = persistor().doesQualify(obj) ;
        
        // OBJY-19385: doesQualify() calls completeSetup() if setup is not completed. 
        // completeSetup() may have errors. We need to check the error handler 
        // (which should not be null) and throw an exception if an error is found. 
        ExpressionSetupErrorHandler errorHandler = getDefaultErrorHandler();
        if (errorHandler.getNumberOfErrors() > 0)
        {
            throw new ExpressionSetupException(errorHandler.getFirstError().getDescription(), 
                    errorHandler.getFirstError());
        }
        return qualified ; 
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized PooObjectQualifier persistor() {
        if (persistor == null)
            throw new ObjyRuntimeException("Attempted persistent operation on transient object") ;
        return persistor ;
    }
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    public long getId() 
    {
        return persistor().getId();
    }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized void setPersistor(PooObjectQualifier persistor)
        { this.persistor = persistor ; }

    /**
     * Returns the predicate expression tree instance associated with the object qualifier.
     */
    public ExpressionTree getExpressionTree()
    {
        if (mExpressionTree == null)
        {
            mExpressionTree = ExpressionTree.getExpressionTree(persistor().getExpressionTree(), this);
        }
        return mExpressionTree;
    }

    /**
     * Returns the error handler of the expression tree associated with this object qualifier.
     */
    public ExpressionSetupErrorHandler getDefaultErrorHandler()
    {
        return getExpressionTree().getErrorHandler();
    }
    /**
     *  Closes the internal expression tree, releasing the native resource.
     */
    //@Override JDK 7
    /*public void close()
    {
        if (mExpressionTree != null)
        {
            persistor().close();
            mExpressionTree = null;
        }
    }*/

    /**
     * Sets a boolean variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setBoolVarValue(String variableName, boolean value) throws ExpressionSetupException
    {
    	persistor().setBoolVarValue(variableName, value);
    }

    /**
     * Sets an Int variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setIntVarValue(String variableName, long value) throws ExpressionSetupException
    {
        persistor().setIntVarValue(variableName, value);
    }

    /**
     * Sets a UInt variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setUIntVarValue(String variableName, long value) throws ExpressionSetupException
    {
        persistor().setUIntVarValue(variableName, value);
    }

    /**
     * Sets a float variable value.
     */
    public void setFloatVarValue(String variableName, float value) throws ExpressionSetupException
    {
        persistor().setFloat64VarValue(variableName, value);
    }

    /**
     * Sets a String variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setStringVarValue(String variableName, String value) throws ExpressionSetupException
    {
    	persistor().setStringVarValue(variableName, value);
    }

    /**
     * Sets a Date variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setDateVarValue(String variableName, java.sql.Date value) throws ExpressionSetupException
    {
    	persistor().setDateVarValue(variableName, value);
    }

    /**
     * Sets a Time variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setTimeVarValue(String variableName, java.sql.Time value) throws ExpressionSetupException
    {
        persistor().setTimeVarValue(variableName, value);
    }

    /**
     * Sets a DateTime variable value. 
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setDateTimeVarValue(String variableName, java.sql.Timestamp value) throws ExpressionSetupException
    {
    	persistor().setDateTimeVarValue(variableName, value);
    }

    /**
     * Sets an interval variable value in milliseconds. 
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setIntervalVarValue(String variableName, long millisecs) throws ExpressionSetupException
    {
        persistor().setIntervalVarValue(variableName, millisecs);
    }
    
    /**
     * Sets an OID variable value.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setRefVarValue(String variableName, Persistent refVal) throws ExpressionSetupException
    {
        persistor().setRefVarValue(variableName, refVal);
    }

    /**
     * Sets a class type variable value by class name.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setClassVarValueByName(String variableName, String classValName) throws ExpressionSetupException
    {
        persistor().setClassVarValueByName(variableName, classValName);
    }

    /**
     * Sets a class type variable value by class type.
     * @throws ExpressionSetupException when the variable name is undefined in the associated expression. 
     */
    public void setClassVarValueByType(String variableName, long classValType) throws ExpressionSetupException
    {
        persistor().setClassVarValueByType(variableName, classValType);
    }
}
