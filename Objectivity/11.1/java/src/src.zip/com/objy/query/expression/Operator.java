package com.objy.query.expression;

/**
 * Represents an operator.
 *
 */
public class Operator extends AbstractExpression
{
    /**
     * Constructs an operator.
     */
    public Operator() {}

    /**
     * Constructs an operator with an ID.
     * 
     * @param id Id of the operator
     */
    private Operator(long id) 
    {
        setIdAfterNullCheck(id);
    }
    
    /**
     * Returns the operator identified by the ID.
     */
    public static Operator getOperator(long id)
    {
        return new Operator(id);
    }

    /**
     * Returns the name of the operator.
     */
    public String getName() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getName(mId);
    }

    /**
     * Returns the list of tokens for this operator.
     */
    public NameList getTokens()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return new NameList(Binding.getNameListId(mId));
    }

    /**
     * Returns the description of this operator.
     */
    public String getDescription() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getDescription(mId);
    }

    /**
     * Returns true if the operator changes the class context; false otherwise.
     */
    public boolean getDoesChangeClassContext() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getDoesChangeClassContext(mId);
    }

    /**
     * Returns the minimum number of operands required by the operator.
     */
    public int getMinNumberOfOperands() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getMinNumberOfOperands(mId);
    }

    /**
     * Returns the maximum number of operands for the operator,
     * or 0 for no limit.
     */
    public int getMaxNumberOfOperands() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getMaxNumberOfOperands(mId);
    }

    /**
     * Returns the result specification of the operator.
     */
    public ExpressionResultSpec getResultSpec() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return ExpressionResultSpec.getExpressionResultSpec(Binding.getResultSpec(mId));
    }

    static class Binding
    {
        // Returns the operator's name.
        private static native String getName(long id);
        private static native long getNameListId(long id); // just return the id
        // Returns the operator's description.
        private static native String getDescription(long id);
        // Returns true if the operator changes the class context; false otherwise.
        private static native boolean getDoesChangeClassContext(long id);
        // Returns the minimum number of operands the operator requires.
        private static native int getMinNumberOfOperands(long id);
        // Returns the maximum number of operands the operator can take,
        // or 0 for no limit.
        private static native int getMaxNumberOfOperands(long id);
        // Returns the result spec of the operator.
        private static native long getResultSpec(long id);
        
    }
}
