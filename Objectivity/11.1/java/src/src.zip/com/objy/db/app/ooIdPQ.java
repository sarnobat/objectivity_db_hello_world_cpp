/*
 * @(#)ooIdPQ.java
 * 
 * Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app;

/**
 * Extends the ooId interface to provide setters for object identifier
 * members, necessary for use in <a href="QuerySplitter.html">query splitters</a>.
 */
public interface ooIdPQ extends ooId
{
    /**
     * Sets the identifier of the database of this object identifier.</p>
     *
     * @param 	 db  The identifier of the database in which the
     * object with this object identifier is stored.
     */
    void setDB(int db) ;

    /**
     * Sets the identifier of the container of this object identifier.</p>
     *
     * @param 	 cont The identifier of the container in which the
     * object with this object identifier is stored.
     */
    void setOC(int cont) ;

    /**
     * Sets the identifier of the page of this object identifier.</p>
     *
     * @param 	 page  The identifier of the page in which the
     * object with this object identifier is stored.
     */
    void setPage(int page) ;

    /**
     * Sets the number of the slot of this object identifier.</p>
     *
     * @param 	 slot  The number of the slot in which the object
     * with this object identifier is stored.
     */
    void setSlot(int slot) ;

    /**
     * Sets the Objectivity/DB type number of this object identifier.
     *
     * <p>The type number uniquely identifies the object's class in the
     * federated database schema.</p>
     *
     * @param 	 typeN  The Objectivity/DB type number of the
     * class of the object with this object identifier.
     */
    void setTypeN(int typeN) ;
    
}


