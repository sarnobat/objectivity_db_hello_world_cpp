/*
 * @(#)Connection.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import java.util.HashMap ;
import java.util.Vector ;
import java.io.PrintStream;

import com.objy.db.DatabaseOpenException ;
import com.objy.db.DatabaseClosedException ;
import com.objy.db.DatabaseNotFoundException ;
import com.objy.db.ObjyRuntimeException ;

import com.objy.db.app.storage.ooDBObj;
import com.objy.db.iapp.PConnection ;

import com.objy.pm.Access ;

/**
 * Represents a connection to an Objectivity/DB federated database.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You create an instance of this class, called a <i>connection</i>,
 * by calling the
 * {@link #open <tt>Connection.open</tt>} static method
 * to open a connection to an Objectivity/DB federated database.
 * Making a connection indicates that the application intends to interact
 * with the federated database. An application typically works with a single
 * connected federated database, but working with multiple connected federated
 * databases that have the same schema is supported.
 *
 * An application maintains a single connection object for any connected
 * federated database. You can obtain the current connection object by
 * calling the static method {@link #current() <tt>Connection.current</tt>}.
 *
 * <p><b>Note: </b>If your application requires ODMG compliance, it should
 * open a connection by calling the
 * {@link Database#open <tt>Database.open</tt>} static
 * method. For additional information about ODMG applications, see
 * <A HREF="../../../../../guide/jgdODMGApplication.html#_top_">
 * Conforming to the ODMG Standard</A>.
 *
 * <p>Once you have opened a connection, you can call methods of the
 * connection object to set policies that
 * control the interaction between your application and the connected
 * federated database. See
 * <A HREF="../../../../../guide/jgdApplication.html#_top_">
 * Controlling Interaction With Objectivity/DB</A>.
 *
 * <p>You must create a
 * <a href="Session.html">session</a>
 * before you perform any Objectivity/DB operations.
 * An <i>Objectivity/DB operation</i> is one that affects
 * the objects maintained by the connected federated database--for example,
 * creating, retrieving, reading, modifying, or
 * deleting storage objects or persistent objects.
 * When you create a session, the session, in turn,
 * creates a local representation of the connected
 * <a href="ooFDObj.html">federated database</a>.
 * You perform Objectivity/DB operations by calling methods of persistent
 * objects and storage objects.
 *
 * <p>When you have finished interacting with the connected federated
 * database, you should call the {@link #close <tt>close</tt>} method
 * of the connection object.  Applications typically close a connection only
 * once, immediately before exiting.  However, you may reopen the connection
 * by calling the {@link #reopen() <tt>reopen</tt>} method of the
 * connection object.
 *
 * <p><b>Note: </b>The <tt>close</tt> method terminates all
 * sessions in a connection.  An exception is thrown if any of the
 * connection's sessions are in a transaction.  After you have closed
 * a connection, you should not use its sessions or any of the
 * objects that belong to them.  If you later reopen the connection, you
 * must create one or more new sessions.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr valign=top WIDTH="1%"><td><a name = "ooMode"><b>Open modes</b><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how a connection to the federated database is opened.</td>
 * <td VALIGN="top">
 *   <a href="#notOpen">notOpen</a><br>
 *   <a href="#openReadOnly">openReadOnly</a><br>
 *   <a href="#openReadWrite">openReadWrite</a>
 *   </td></tr>
 * </TABLE>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Opening&nbsp;and&nbsp;Closing Connections</B></TD>
 * <TD><A HREF="#open(java.lang.String, int)">open(String, int)</A><BR>
 *  <A HREF="#open(java.lang.String, int, int)">open(String, int, int)</A><BR>
 * 	<A HREF="#isOpen()">isOpen()</A><BR>
 *	<A HREF="#getOpenMode()">getOpenMode()</a><BR>
 * 	<A HREF="#setOpenMode(int)">setOpenMode(int)</A><BR>
 * 	<A HREF="#close()">close()</A><BR>
 *	<A HREF="#reopen()">reopen()</A><BR>
 *  <A HREF="#join()">join()</A><BR>
 *  <A HREF="#leave()">leave()</A>
 *
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information</B></TD>
 * <TD><A HREF="#current()">current()</A><BR>
 * 	<A HREF="#getOpenMode()">getOpenMode()</a><BR>
 * 	<A HREF="#getSchemaPolicy()">getSchemaPolicy()</A><BR>
 * 	<A HREF="#getThreadPolicy()">getThreadPolicy()</A><br>
 *	<A HREF="#getFileCount()">getFileCount()</A><br>
 * 	<A HREF="#sessions()">sessions()</A><br>
 * 	<A HREF="#oidFrom(java.lang.String)">oidFrom(String)</A><BR>
 * 	<A HREF="#getDatabase()">getDatabase()</A><br>
 * 	<A HREF="#getBootFilePath()">getBootFilePath()</A><br>
 * 	<A HREF="#printHandledSignals()">printHandledSignals()</A><br>
 * 	<A HREF="#getUniqueInternObjects()">getUniqueInternObjects()</A><br>
 * 	<A HREF="#getSchemaCacheMaximum()">getSchemaCacheMaximum()</A><br>
 *      <A HREF="#getObjectCreationDiskFormat()">getObjectCreationDiskFormat()</A><br>
 *      <A HREF="#getClientHostArch()">getClientHostArch()</A><br>
 *      <A HREF="#diskFormatFromString(java.lang.String)">diskFormatFromString(String)</A><br>
 *      <A HREF="#stringFromDiskFormat(int)">stringFromDiskFormat(int)</A><br>
 *      <A HREF="#diskFormatAddressSize(int)">diskFormatAddressSize(int)</A><br>
 *      <A HREF="#getLogSchemaModifications()">getLogSchemaModifications()</A><br>
 *  	<A HREF="#getPersistencePolicy()">getPersistencePolicy()</A><br>
  *  	<A HREF="#isPersistOnReachability()">isPersistOnReachability()</A> 
* </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 * <TD><A HREF="#isOpen()">isOpen()</A><BR>
 * <A HREF="#isPredicateScanAutoFlush()">isPredicateScanAutoFlush()</A><br>
 * <A HREF="#isDeploymentMode()">isDeploymentMode()</A><br>
 *  <A HREF="#checkLS()">checkLS()</A><br>
 *  <A HREF="#checkLS(java.lang.String)">checkLS(String)</A><br>
 * 	<A HREF="#containsHandledSignal(byte)">containsHandledSignal(byte)</A><br>
 *  <A HREF="#checkQueryServer(java.lang.String)">checkQueryServer(String)</A><br>
 *  <A HREF="#isMemoryCheckPolicy()">isMemoryCheckPolicy()</A><br>
 *  <A HREF="#isPermitReadAhead()">isPermitReadAhead()</A><br>
 *  <A HREF="#isPermitSparseDbFiles()">isPermitSparseDbFiles()</A><br>
 *  <A HREF="#haveSessionPool(java.lang.String)">haveSessionPool(String)</A>
 *  </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Using&nbsp;Logs</B></TD><BR>
 * <TD> <A HREF="#setLoggingOptions(int, boolean, boolean, java.lang.String, java.lang.String)">setLoggingOptions(int, boolean, boolean, String, String)</A><br>
 *      <A HREF="#addToMainLog(java.lang.String, java.lang.String)">addToMainLog(String, String)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Using&nbsp;Session&nbsp;Pools</B></TD><BR>
 * <TD> <A HREF="#createSessionPool(java.lang.String, int, int)">createSessionPool(String, int, int)</A><br>
 *      <A HREF="#createSessionPool(java.lang.String, int, int, int)">createSessionPool(String, int, int, int)</A><br>
 *      <A HREF="#createSessionPool(java.lang.String, int, int, int, int, int, boolean, int, int)">createSessionPool(String, int, int, int, int, int, boolean, int, int)</A><br>
 *      <A HREF="#getSessionFromPool(java.lang.String, java.lang.String)">getSessionFromPool(String, String)</A><br>
 *      <A HREF="#returnSessionToPool(com.objy.db.app.Session)">returnSessionToPool(Session)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Using&nbsp;Performance&nbsp;Tuners</B></TD><BR>
 * <TD> <A HREF="#setTuner()">setTuner()</A><br>
 *      <A HREF="#setTuner(com.objy.db.app.Tuner)">setTuner(Tuner)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Using&nbsp;Configuration&nbsp;Files</B></TD><BR>
 * <TD> <A HREF="#enableConfiguration()">enableConfiguration()</A><br>
 *      <A HREF="#enableConfiguration(boolean, String)">enableConfiguration(boolean)</A><br>
 *      <A HREF="#enableConfiguration(boolean)">enableConfiguration(boolean, String, String)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Using&nbsp;Log&nbsp;Listeners</B></TD><BR>
 * <TD> <A HREF="#setMainLogListener(com.objy.db.app.LogListener)">setMainLogListener(LogListener)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Using&nbsp;Shutdown&nbsp;Listeners</B></TD><BR>
 * <TD> <A HREF="#addShutdownHook(com.objy.db.app.ShutdownListener)">addShutdownHook(ShutdownListener)</A>
 * </TD></TR>
 * <TR><td VALIGN="top" WIDTH="1%"><B>Setting&nbsp;Properties</B></TD><BR>
 * <TD><A HREF="#setOpenMode(int)">setOpenMode(int)</A><br>
 * 	<A HREF="#setThreadPolicy(int)">setThreadPolicy(int)</A><br>
 * 	<A HREF="#setFileCount(int)">setFileCount(int)</A><BR>
 * 	<A HREF="#setAMSUsage(int)">setAMSUsage(int)</A><BR>
 * 	<A HREF="#setPredicateScanAutoFlush(boolean)">setPredicateScanAutoFlush(boolean)</A><BR>
 * 	<A HREF="#setDeploymentMode(boolean)">setDeploymentMode(boolean)</A><BR>
 * 	<A HREF="#setInstallSignalHandler(boolean)">setInstallSignalHandler(boolean)</A><br>
 * 	<A HREF="#addHandledSignal(byte)">addHandledSignal(byte)</A><br>
 * 	<A HREF="#removeHandledSignal(byte)">removeHandledSignal(byte)</A><br>
 * 	<A HREF="#setUserClassLoader(java.lang.ClassLoader)">setUserClassLoader(ClassLoader)</A><br>
 * 	<A HREF="#useContextClassLoader(boolean)">useContextClassLoader(boolean)</A><br>
 * 	<A HREF="#setUniqueInternObjects(boolean)">setUniqueInternObjects(boolean)</A><br>
 * 	<A HREF="#setObjectCreationDiskFormat(int)">setObjectCreationDiskFormat(int)</A><br>
 * 	<A HREF="#setErr(java.io.PrintStream)">setErr(PrintStream)</A><br>
 * 	<A HREF="#setOut(java.io.PrintStream)">setOut(PrintStream)</A><br>
 *  <A HREF="#setLogSchemaModifications(boolean)">setLogSchemaModifications(boolean)</A><br>
 *  <A HREF="#setPersistencePolicy(int)">setPersistencePolicy(int)</A><br>
 *  <A HREF="#setMemoryCheckPolicy(boolean)">setMemoryCheckPolicy(boolean)</A><br>
 *  <A HREF="#setPermitReadAhead(boolean)">setPermitReadAhead(boolean)</A><br>
 *  <A HREF="#setPermitSparseDbFiles(boolean)">setPermitSparseDbFiles(boolean)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Schema&nbsp;Management</B></TD>
 * <TD>
 * <A HREF="#registerClass(java.lang.String)">registerClass(String)</A><BR>
 * <A HREF="#registerClass(java.lang.String, java.util.HashMap)">registerClass(String, HashMap)</A><BR>
 * <A HREF="#setSchemaClassName(java.lang.String, java.lang.String)">setSchemaClassName(String, String)</A><br>
 * <A HREF="#getSchemaPolicy()">getSchemaPolicy()</A><br>
 * <A HREF="#dropClass(java.lang.String)">dropClass(String)</A><br>
 * <A HREF="#dropAllUserClasses(boolean)">dropAllUserClasses(boolean)</A><br>
 * <A HREF="#loadSchemaClasses()">loadSchemaClasses()</A><br>
 * <A HREF="#loadSchemaClasses(boolean)">loadSchemaClasses(boolean)</A><br>
 *  <A HREF="#open(java.lang.String, int, int)">open(String, int, int)</A><BR>
 * <A HREF="#getSchemaCacheMaximum()">getSchemaCacheMaximum()</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>In-Process&nbsp Lock&nbsp;Server</B> (<i>IPLS</i>)</TD>
 * <td><A HREF="#startInternalLS()">startInternalLS()</A><br>
 *  <A HREF="#stopInternalLS()">stopInternalLS()</A><br>
 *  <A HREF="#stopInternalLS(int, boolean)">stopInternalLS(int, boolean)</A><br>
 *  <A HREF="#checkLS()">checkLS()</A><br>
 *  <A HREF="#checkLS(java.lang.String)">checkLS(String)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Parallel Queries</B></TD>
 * <td><A HREF="#getTaskAssigner()">getTaskAssigner()</A><br>
 *  <A HREF="#setTaskAssigner(com.objy.db.app.TaskAssigner)">setTaskAssigner(TaskAssigner)</A><br>
 *  <A HREF="#checkQueryServer(java.lang.String)">checkQueryServer(String)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Controlling&nbsp;the
 * Objectivity/DB&nbsp;Signal&nbsp;Handler</B></TD>
 * 	<td><A HREF="#setInstallSignalHandler(boolean)">setInstallSignalHandler(boolean)</A><br>
 * 	<A HREF="#addHandledSignal(byte)">addHandledSignal(byte)</A><br>
 * 	<A HREF="#removeHandledSignal(byte)">removeHandledSignal(byte)</A><br>
 * 	<A HREF="#containsHandledSignal(byte)">containsHandledSignal(byte)</A><br>
 * 	<A HREF="#printHandledSignals()">printHandledSignals()</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Standalone Applications</B></TD>
 * <td><A HREF="#noLock()">noLock()</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Static&nbsp;Utilities</B></TD>
 * <td><A HREF="#open(java.lang.String, int)">open(String, int)</A><BR>
 *      <A HREF="#open(java.lang.String, int, int)">open(String, int, int)</A><BR>
 * 	<A HREF="#current()">current()<BR></A>
 * 	<A HREF="#oidFrom(java.lang.String)">oidFrom(String)</A><BR>
 * 	<A HREF="#getFileCount()">getFileCount()</A><br>
 * 	<A HREF="#setFileCount(int)">setFileCount(int)</A><br>
 * 	<A HREF="#setInstallSignalHandler(boolean)">setInstallSignalHandler(boolean)</A><br>
 * 	<A HREF="#addHandledSignal(byte)">addHandledSignal(byte)</A><br>
 * 	<A HREF="#removeHandledSignal(byte)">removeHandledSignal(byte)</A><br>
 * 	<A HREF="#containsHandledSignal(byte)">containsHandledSignal(byte)</A><br>
 * 	<A HREF="#printHandledSignals()">printHandledSignals()</A><br>
 *  <A HREF="#setLoggingOptions(int, boolean, boolean, java.lang.String, java.lang.String)">setLoggingOptions(int, boolean, boolean, String, String)</A><br>
 *  <A HREF="#addShutdownHook(com.objy.db.app.ShutdownListener)">addShutdownHook(ShutdownListener)</A>
 * </TD></TR></TABLE>
 */
final public class Connection
{
    private transient PConnection persistor ;

    private static int fileCount = 12 ;

	/** Open mode: The connection is not open; sessions may not be created. */
    public static final int notOpen       = oo.notOpen;

	/** Open mode: The connection is open for read-only access. */
    public static final int openReadOnly  = oo.openReadOnly;

	/** Open mode: The connection is open for read/write access. */
    public static final int openReadWrite = oo.openReadWrite ;

	/** Not supported. Do not use this constant. */
    public static final int openExclusive = oo.openExclusive ;

    //
    // Constructor
    //
    private Connection()
        { }

	/**
     * Reserved for internal use.
    */

    public Connection(PConnection _persistor)
        { persistor = _persistor ; }

    /**
     * Opens a connection to the specified federated database.
     *
     * <p> You must open a connection <i>before</i> creating any
     * <a href="Session.html">sessions</a> (or
     * <a href="Transaction.html">transactions</a>)
     * that interact with the federated database.
     *
     *
     * <p>This method creates an
 	 * <a href="Database.html">ODMG database</a>
	 * object associated with the new connection object. You can
	 * obtain the ODMG database object by calling the
	 * <a href ="#getDatabase()"><tt>getDatabase</tt></a> method of the
     * returned connection object.
	 *
	 * <p>This method sets the maximum cache capacity to 500 pages
     * for the session that performs schema evolution.</p>
     *
     * @param 	 bootFilePath The pathname of the
     * boot file of the federated database to which a connection is
     * being opened. If this parameter is an empty string (<tt>""</tt>) or
     * null,
     * the value of the <tt>OO_FD_BOOT</tt> environment variable is used
     * as the boot file path; however, using <tt>OO_FD_BOOT</tt> is not recommended because
     * doing so can lead to unexpected results.
     *
     * <p><i>(HA)</i> If the specified file is the boot file of an autonomous
	 * partition, that partition is the boot autonomous partition for the
	 * application.</p>
     *
     * @param 	 mode	The mode in which
     * to open the
     * connection; one of the following constants defined in this class
     * (and also in
	 * the <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
	 *  <dt><tt>openReadOnly</tt><dd>Open the connection for
	 * read-only access.</dd>
	 *  <dt><tt>openReadWrite</tt><dd>Open the connection for
	 * read/write access.</dd>
	 * </dd></dl></dl>
	 *
     * <p>The open mode of a connection limits the open mode of each
     * <a href="Session.html">session</a>
     * created after the connection is
	 * opened.  As a consequence, it also limits the lock modes of any
     * storage objects or persistent objects that belong to those sessions.
     * A connection whose open mode is <tt>openReadWrite</tt> permits session
	 * open modes of
     * <tt>openReadWrite</tt> or <tt>openReadOnly</tt>;
     * a connection whose open mode is <tt>openReadOnly</tt>
     * permits the session open mode <tt>openReadOnly</tt>.</p>
     *
     * @return		The newly created connection object.</p>
	 *
     * @exception	DatabaseOpenException   If attempting
     * to open the connection with an unsupported open mode.</p>
     *
	 * @exception	DatabaseNotFoundException If the federated database
     * doesn't exist.</p>
     *
     * @see #close
     * @see #isOpen
     * @see #reopen
     * @see #setOpenMode
     */
     public static Connection open(String bootFilePath, int mode)
        throws DatabaseOpenException, DatabaseNotFoundException
    {
        return Access.new_ConnectionPersistor(bootFilePath, mode, fileCount, 500).getTarget() ;
    }

    /**
     * Opens a connection to the specified federated database and sets the
	 * specified maximum cache capacity for the session that performs schema evolution.
     *
     * <p> You must open a connection <i>before</i> creating any
     * <a href="Session.html">sessions</a> (or
     * <a href="Transaction.html">transactions</a>)
     * that interact with the federated database.
     *
     *
     * <p>This method creates an
 	 * <a href="Database.html">ODMG database</a>
	 * object associated with the new connection object. You can
	 * obtain the ODMG database object by calling the
	 * <a href ="#getDatabase()"><tt>getDatabase</tt></a> method of the
     * returned connection object. </p>
	 *
	 * <p>This <tt>open</tt> method allows you to request more
	 * space in the Objectivity/DB cache of the schema manager's session,
	 * so that schema evolution can accommodate
	 * a large number of changed class definitions. By default, the maximum cache
	 * capacity for performing schema evolution is 500 (that is, 500 pages in
	 * the small-object buffer pool and 500 buffer entries in the large-object buffer pool).</p>
     *
     * @param 	 bootFilePath The pathname of the
     * boot file of the federated database to which a connection is
     * being opened. If this parameter is an empty string (<tt>""</tt>) or
     * null,
     * the value of the <tt>OO_FD_BOOT</tt> environment variable is used
     * as the boot file path; however, using <tt>OO_FD_BOOT</tt> is not recommended because
     * doing so can lead to unexpected results.
     *
     * <p><i>(HA)</i> If the specified file is the boot file of an autonomous
	 * partition, that partition is the boot autonomous partition for the
	 * application.</p>
     *
     * @param 	 mode	The mode in which
     * to open the
     * connection; one of the following constants defined in this class
     * (and also in
	 * the <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
	 *  <dt><tt>openReadOnly</tt><dd>Open the connection for
	 * read-only access.</dd>
	 *  <dt><tt>openReadWrite</tt><dd>Open the connection for
	 * read/write access.</dd>
	 * </dd></dl></dl>
	 *
     * <p>The open mode of the connection limits the open mode of each
     * <a href="Session.html">session</a>
     * created after the connection is
	 * opened.  As a consequence, it also limits the lock modes of any
     * storage objects or persistent objects that belong to those sessions.
     * A connection whose open mode is <tt>openReadWrite</tt> permits session
	 * open modes of
     * <tt>openReadWrite</tt> or <tt>openReadOnly</tt>;
     * a connection whose open mode is <tt>openReadOnly</tt>
     * permits the session open mode <tt>openReadOnly</tt>.</p>
     *
     * @param 	 schemaCacheMaximumPages	The maximum
     * capacity of the Objectivity/DB cache of the schema-management session
	 * (the session in which schema evolution is performed).
	 * The maximum cache capacity is an integer
	 * that specifies:
	 * <ul type=disc>
	 * <li>The maximum number of buffer pages
	 * that can be allocated for the session's small-object buffer pool.
     * <li>The maximum number of buffer entries that can be allocated in the session's
	 * large-object buffer pool.</ul></p>
     *
     * @return		The newly created connection object.</p>
	 *
     * @exception	DatabaseOpenException   If attempting
     * to open the connection with an unsupported open mode.</p>
     *
	 * @exception	DatabaseNotFoundException If the federated database
     * doesn't exist.</p>
     *
     * @see #close
     * @see #isOpen
     * @see #reopen
     * @see #setOpenMode
 	 * @see #getSchemaCacheMaximum
    */
     public static Connection open(String bootFilePath, int mode, int schemaCacheMaximumPages)
        throws DatabaseOpenException, DatabaseNotFoundException
    {
        return Access.new_ConnectionPersistor(bootFilePath, mode, fileCount, schemaCacheMaximumPages).getTarget() ;
    }

    /**
     * Tests whether the connection between this connection object
     * and the federated database is open.</p>
     *
     * @return         True if the connection is open; otherwise false.</p>
     *
     * @see #open(String, int)
     * @see #reopen
     * @see #close
     */
    public boolean isOpen()
        { return persistor().isOpen() ; }

    /**
     * Gets this application's current connection object.</p>
     *
     * @return The current connection object, or null if there is no
     * current connection object.
     */
    public static Connection current()
        { return Access.connection_getCurrent() ; }

    /**
     * Gets the pathname of the boot file of the current
	 * connected federated database.</p>
     * @return      The pathname of the boot file.
     *
     */
    public String getBootFilePath()
        { return persistor().getBootFilePath() ; }

	/**
	 * Gets the maximum number of active file descriptors allowed in any
     * session.</p>
	 *
	 * @return		The number of file descriptors reserved for
	 * use by each session object.</p>
	 *
	 * @see	#setFileCount
	 */
    public static int getFileCount()
        { return fileCount ; }

    /**
     * Gets the open mode of this connection.</p>
     *
     * @return  The open mode of the connection; one of the following
	 * constants defined in this class (and also in
	 * the <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
	 * <dt><tt>openReadOnly</tt><dd>The connection is open for
	 * read-only access.</dd>
	 * <dt><tt>openReadWrite</tt><dd>The connection is open for
	 * read/write access. </dd>
	 * <dt><tt>notOpen</tt><dd>The connection is closed.</dd>
     * </dd></dl></dl></p>
     *
     * @see #open(String, int)
     * @see #reopen
     * @see #setOpenMode
     */
    public int getOpenMode()
        { return persistor().getOpenMode() ; }

	/**
	 * Gets the individual or pooled <a href="Session.html">sessions</a> that interact with this connected federated
	 * database.</p>
	 *
	 * <p>An application normally holds a reference to any session it
	 * is using. In addition, Objectivity for Java maintains a weak reference
	 * to each session. If your application removes its reference
	 * to a session, the remaining weak reference makes the session
	 * eligible for  garbage collection.</p>
	 *
	 * <p>The returned vector contains a snapshot of currently available sessions.
	 * The vector does <i>not</i> include sessions that
	 * have already been terminated, because they are dead objects and cannot interact with the
	 * federated database. The returned vector can contain dead sessions
	 * if they are terminated after or during the call to this method.
	 * </p>
	 *
	 * <p>The returned vector is empty if there are no sessions.  </p>
	 *
	 * @return		A vector containing the sessions for this
	 * connection.
	 *
	 */
    public Vector sessions()
        { return persistor().sessions() ; }

	/**
	 * Sets the maximum number of active file descriptors allowed in any
     * session.
	 *
	 * <p>If this method is
	 * never called, each session can have a maximum of 12 active
     * file descriptors. If a session tries to open more that this number of
     * files, Objectivity/DB will be forced to close one file (for example, a
     * database file) before it can open another one.  You should consider
     * setting this property to be greater than the number of databases your
     * application will access through any individual session. For guidelines on selecting the
     * number of file descriptors, see
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Number of File Descriptors">
	 * Optimizing the Number of File Descriptors</a>.</p>
	 *
     * <p><b>Note: </b>You must call this static method <i>before</i> your first
     * call to the {@link Connection#open <tt>Connection.open</tt>} static
     * method. </p>
	 *
	 *
	 * @param 	 count	The number of file
	 * descriptors reserved for use by each session object. The minimum value is 8. </p>
	 *
	 * @see	#getFileCount
	 */
    public static void setFileCount(int count)
	{
        if (Access.connection_getCurrent() != null)
            throw new ObjyRuntimeException("Cannot change number of files after Connection.open()") ;
        fileCount = count ;
    }

    /**
     * Sets the level of access that this connection can have to the
     * federated database, either read/write or read-only.
     *
     * <p>Each session also has an open mode that limits the kinds of locks
     * its transactions can obtain. When a session is created, its open mode
     * is initialized to the open mode of the current connection object. The open
     * mode of the connection object also limits the open mode of any
     * sessions created by the application. A connection open mode of
     * read/write permits session open modes of read/write or read-only; a
     * connection open mode of read-only permits the session open mode
     * read-only.
     *
	 * <p>The new open mode set by this method affects any sessions that are
	 * created after this method is called. The open modes of existing
	 * sessions are not changed, but their open-mode <i>limit</i> is changed. This
	 * means that if a connection's open mode is changed from read/write to read-only,
	 * you cannot now change an existing session from read-only to read/write. Similarly,
	 * if a connection's open mode is changed from read-only to read/write, you can now
	 * change an existing session from read-only to read/write.
	 *
     * <p>If this connection is closed, you can set the open mode to either
	 * read-only or read/write; the new open mode will take effect when
	 * you reopen the connection. If this connection is open, you can change the
	 * current open mode from read-only to read/write.
	 *
	 * <p><b>Note: </b>This method throws an exception if you attempt to
	 * change an open connection from read/write to read-only if the connection
	 * is already open.</p>
	 *
     * @param 	 mode	  The open mode of this
	 * connection;
     * one of the following constants defined in this class (and also in
	 * the <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
	 *  <dt><tt>openReadOnly</tt><dd>Allow read-only
	 * access through this connection.</dd>
	 *  <dt><tt>openReadWrite</tt><dd>Allow
	 * read/write access through this connection.</dd>
     * </dd></dl></dl></p>
     *
     * @see #close
     * @see #open(String, int)
     * @see #reopen
     * @see #getOpenMode
     */
    public void setOpenMode(int mode)
        { persistor().setOpenMode(mode) ; }

    /**
     * Enables or disables installation of the
     * <A HREF="../../../../../guide/jgdApplication.html#SignalHandler">
     * Objectivity/DB signal handler</A>.
     *
     * <p>If this static method is never called, no Objectivity/DB signal
     * handler is installed when your application opens a
     * connection with a federated database.  If you call this static method,
     * passing true as the parameter,  the signal handler is installed.
     *
     * <p><b>Note: </b>You must call this static method <i>before</i> you
     * open the connection to which it will apply.</p>
     *
     * @param 	 installSignalHandler True to install the
     * Objectivity/DB signal handler when a connection is opened; false to
     * clear the set of signals to be handled by the Objectivity/DB signal handler.
     *
     * <p>After clearing the set of signals to be handled by the Objectivity/DB signal
     * handler by calling <tt>setInstalledSignalHandler(false)</tt>, you can
     * add selected signals one at a time with  <tt>addHandledSignal</tt>.
     *
     * <p>When you pass true as the parameter, if the set of signals to be
     * handled is empty (because you cleared the set or explicitly removed all
     * signals from it), this method reinitializes the set of signals to be
     * handled to a platform-specific default set of signals.</p>
     *
	 * @see	#addHandledSignal
	 * @see	#removeHandledSignal
	 * @see #open
     *
     */
    public static void setInstallSignalHandler(boolean installSignalHandler)
        { Access.setInstallSignalHandler(installSignalHandler) ; }


    /**
     * Enables or disables deployment mode for this connection.
     *
     * <p>If this method is never called, deployment mode is disabled by
     * default. The application may cause schema evolution.  That is, it may
     * use a definition of a new persistence-capable class that is not
     * already described in the schema of the federated database.  In
     * addition, it may use a definition of a persistence-capable class that
     * has been modified since the class description was added to the schema.
     * Objectivity for Java checks for such discrepancies between Java class
     * definitions and the schema. It evolves the schema, as necessary, to
     * make it consistent with new class definitions.
     *
     * <p>A deployed application can enable deployment mode by calling this
     * method, passing true as the parameter. An
     * application that enables deployment mode <i>guarantees</i> that it
     * will not cause schema evolution.  You should enable deployment mode
     * only if you are certain that the Java definitions of your
     * application's
     * persistence-capable classes are consistent with the existing
     * descriptions of those classes in the schema of the connected federated
     * database. Enabling deployment mode improves application performance
     * because it allows Objectivity for Java to bypass the schema
     * comparisons that are performed by default.
     *
     * <p>You should call this method immediately after opening a connection
     * to the federated database.  Once you enable deployment mode, you
     * should not call this method again to disable it.
     *
     * <p><b>Warning: </b>The federated database may be corrupted if your
     * application enables deployment mode and then causes schema
     * evolution.</p>
     *
     * @param 	 deploymentMode  True to enable deployment
     * mode, and false to disable it.</p>
     *
     * @see #isDeploymentMode
     *
     */
    public void setDeploymentMode(boolean deploymentMode)
        { persistor().setDeploymentMode(deploymentMode) ; }

    /**
     * Tests whether deployment mode is enabled for this connection.
     *
     * <p>Deployment mode is disabled by default.  An application that
     * enables deployment mode <i>guarantees</i> that it
     * will not cause schema evolution (because its definitions of
     * persistence-capable classes are consistent with the existing
     * schema class descriptions). Enabling deployment mode improves
     * application performance
     * because it allows Objectivity for Java to bypass the schema
     * comparisons that are performed by default.</p>
     *
     * @return  True if deployment mode is enabled; false if it is
     * disabled.</p>
     *
     * @see #setDeploymentMode
     */
    public boolean isDeploymentMode()
        { return persistor().isDeploymentMode() ; }

	/**
	 * Gets the ODMG database object associated with this connection.</p>
	 */
    public Database getDatabase()
        { return persistor().getDatabase() ; }

    /**
     * Closes the connection between this connection object and
     * the federated database.
     *
     * <p>This method terminates all sessions in the connection.
     * It should be called for each open connection before exiting from an
     * application. If any session in the connection is in a transaction, this
     * method throws a <tt>TransactionInProgressException</tt> immediately, that is,
	 * without terminating any sessions.
	 *
	 * <p><b>Note: </b>This method sets this connection object's open mode to
	 * <tt>notOpen</tt>.  If you plan to reopen the connection, you must
	 * call {@link #setOpenMode <tt>setOpenMode</tt>} before you call
	 * {@link #reopen <tt>reopen</tt>}.</p>
     *
     * @exception       DatabaseClosedException   If
     * this connection object is already closed.</p>
     *
     * @see #isOpen
     * @see #open(String, int)
     * @see #reopen
     */
    public void close() throws DatabaseClosedException  // ODMG
        { persistor().close() ; }

    /**
     * Reopens a connection to a federated database.
     *
     * <p>After a connection object has been closed, you can call this
	 * method to reopen it.
	 *
	 * <p>Before calling this method, you must reset the open mode with the
	 * {@link #setOpenMode <tt>setOpenMode</tt>} method.
	 * When a connection is closed, the open mode is set to <tt>notOpen</tt>.
	 * If you try to reopen the connection without
     * resetting the open mode, an exception will be thrown.</p>
     *
     * @exception       DatabaseOpenException   If attempting to open
     * the connection with an unsupported open mode. </p>
     *
     * @exception       DatabaseOpenException   If the open mode has not
     * been reset, or is set to an invalid value. </p>
     *
     * @exception       DatabaseNotFoundException If the federated database
     * doesn't exist.</p>
     *
     * @see #isOpen
     * @see #open(String, int)
     * @see #close
     */
    public void reopen() throws DatabaseOpenException, DatabaseNotFoundException
        { persistor().reopen() ; }

	/**
     * Sets this connection's policy for using the Advanced Multithreaded
     * Server (AMS).
     * <p>If this method is not called, AMS is used for remote data
     * access whenever it is available.</p>
	 *
     * @param 	 usage The policy for using the Advanced
	 * Multithreaded Server;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>AMS_PREFERRED</tt></dt><dd>Use AMS for remote data access
     * if it is available on the host that contains the requested data.</dd>
     *  <dt><tt>AMS_ONLY</tt></dt><dd>Use AMS exclusively.</dd>
     *  <dt><tt>NO_AMS</tt></dt><dd>Never use AMS.</dd>
     * </dd></dl></dl>
	 */
    public void setAMSUsage(int usage)
        { persistor().setAMSUsage(usage) ; }

	/**
	 * Registers the specified class in the schema of the
	 * connected federated database.
	 *
	 * <p>This method ensures that the schema contains descriptions of
	 * the specified class and all its superclasses.  It calls itself
	 * recursively
	 * to register any destination class referenced in a
	 * reference attribute
	 * of the specified class (and the superclasses of the referenced
	 * class), as well as any destination class to which it has relationships.
	 *
	 * <p>This method takes the following action for
	 * each class it registers:</p>
	 * <ul type=disc>
	 * <li>If no description for the class exists in the schema,
	 * this method adds the description to the schema.</p>
	 *
	 * <li>If the class description already exists in the schema, this
	 * method checks whether that existing description matches the Java class
	 * declaration.
	 * If so, no additional action is required; if not, the existing
	 * class description is replaced with a class description generated
	 * from the Java class declaration.
	 * </ul>
	 *
	 * <p><b>Note: </b>You should call
	 * {@link #setSchemaClassName <tt>setSchemaClassName</tt>}
	 * to register <i>all</i>
	 * <a href="../../../../../guide/jgdSchemaManagement.html#Schema Class Names">
	 * schema class names</a> for the application <i>before</i> you make any
	 * calls to this method or
	 * perform any operation that would add class descriptions to the
	 * schema.
	 *
	 * <p>This method throws an exception if any of its actions would
	 * violate the <a href="SchemaPolicy.html">schema policy</a>
	 * of this connection.</p>
	 *
	 * @param 	 className The package-qualified name of
     * the persistence-capable class to be registered.
	 */
    public void registerClass(String className)
        { persistor().registerClass(className) ; }

	/**
	 * Registers the specified class, along with its garbage-collectible fields,
	 * in the schema of the connected federated database.</p>
	 *
	 * <p>An application must use this method to register a class that defines one or more
	 * garbage-collectible reference fields (see <a href="ooReference.html"><tt>ooReference</tt></a>).
	 * To register such a class,
	 * the application must first create a hash map with an entry for
	 * each garbage-collectible reference field,
	 * where the key of each entry is the name of the corresponding field,
	 * and the value of each entry is the schema name of the class being registered.
	 * The application then  calls this method, passing the hash map
	 * and the schema class name as parameters.
	 *
	 * <p>This method ensures that the schema contains descriptions of
	 * the specified class and all its superclasses.  It calls itself
	 * recursively
	 * to register any destination class referenced in a
	 * reference attribute
	 * of the specified class (and the superclasses of the referenced
	 * class), as well as any destination class to which it has relationships.
	 *
	 * <p>This method takes the following action for
	 * each class it registers:</p>
	 * <ul type=disc>
	 * <li>If no description for the class exists in the schema,
	 * this method adds the description to the schema.</p>
	 *
	 * <li>If the class description already exists in the schema, this
	 * method checks whether that existing description matches the Java class
	 * declaration.
	 * If so, no additional action is required; if not, the existing
	 * class description is replaced with a class description generated
	 * from the Java class declaration.
	 * </ul>
	 *
	 * <p>The description created with this method is specific to the
	 * connected federated database only in regard to the schema class
	 * names of the fields.  Different applications can interchange
	 * actual references with garbage-collectible reference fields in their
	 * class descriptions without triggering schema evolution.
	 *
	 * <p><b>Note: </b>You should call
	 * {@link #setSchemaClassName <tt>setSchemaClassName</tt>}
	 * to register <i>all</i>
	 * <a href="../../../../../guide/jgdSchemaManagement.html#Schema Class Names">
	 * schema class names</a> for the application <i>before</i> you make any
	 * calls to this method or
	 * perform any operation that would add class descriptions to the
	 * schema.
	 *
	 * <p>This method throws an exception if any of its actions would
	 * violate the <a href="SchemaPolicy.html">schema policy</a>
	 * of this connection.</p>
	 *
	 * @param 	 className The package-qualified name of
	 * the persistence-capable class to be registered.</p>
	 *
	 * @param 	 memberMap A hash map containing one
	 * entry for each garbage-collectible field defined by the class being registered.
	 * Within each entry in the hash map, the key
	 * must be the name of a particular garbage-collectible field,
	 * and the value  must be the schema class name.
	 */
    public void registerClass(String className, HashMap memberMap)
        { persistor().registerClass(className, memberMap) ; }

    /**
     * Registers all class descriptions found in the schema of the connected
     * federated database for which there are corresponding java class definitions.
     *
     * @see #registerClass(String)
     */
    public void loadSchemaClasses()
        { persistor().loadSchemaClasses(false) ; }

    /**
     * Registers all class descriptions found in the schema of the connected
     * federated database for which there are corresponding java class definitions.
     *
     * @param 	 verbose If true, a message is printed for each
     * class description stating if registration was successful or not.
     * If false, no messages are printed.
     *
     * @see #registerClass(String)
     */
    public void loadSchemaClasses(boolean verbose)
        { persistor().loadSchemaClasses(verbose) ; }


	/**
	 * Sets the schema class name for the specified class during this
	 * connection.
	 *
	 * <p>This method provides a mapping between a Java class
	 * name and a
	 * <a href="../../../../../guide/jgdSchemaManagement.html#Schema Class Names">
	 * schema class name</a>; it does not directly modify the schema of the
	 * connected
	 * federated database.  In
	 * particular, the mapping remains in effect only during the current
	 * connection; it is never stored explicitly in
	 * the federated database.
	 *
	 * <p><b>Note: </b>You should call this method to register <i>all</i>
	 * schema class names for the application <i>before</i> you make any
	 * calls to <a href="#registerClass(java.lang.String)"><tt>registerClass</tt></a> or
	 * perform any operation that would add or modify class descriptions
	 * to the schema.</p>
	 *
	 * @param 	 javaClassName The package-qualified
	 * name of the persistence-capable class whose schema class name is to be set.
	 * This method throws an <tt>ObjySchemaException</tt>
	 * if you have already registered a schema class name for
	 * <i><tt>javaClassName</tt></i> with this connection.</p>
	 *
	 * @param 	 schemaClassName The custom schema
	 * class name for the specified class.</p>
	 *
	 * <p>You can specify an unqualified schema class name
	 * of the form <tt><i>className</i></tt>,
	 * where <tt><i>className</i></tt> contains no periods,
	 * although it may contain underscores.
	 * An unqualified schema class name typically designates the
	 * class description of a globally defined class.</p>
	 *
	 * <p>You can specify a qualified schema class name of the
	 * standard form
	 * <tt><i>qualifier</i></tt>[<tt><i>_qualifier</i></tt>].<tt><i>className</i></tt>,
	 * where <tt><i>className</i></tt>
	 * is separated from the qualifier(s) by a single period,
	 * and the qualifiers are separated from each other by underscores.
	 * A qualified schema class name typically designates
	 * the class description of a class that is defined in
	 * one or more nested Java packages or C++ namespaces. </p>
	 *
	 * For convenience, you can specify a qualified schema class name
	 * as a package-qualified Java name, in which a period replaces
	 * all separator characters.
	 * Similarly, you can specify a namespace-qualified classname
	 * in standard C++ notation, where a double colon (::) replaces
	 * all separator characters.
	 * (This format is convenient if you are specifying a
	 * custom schema class name that matches an existing class
	 * added to the schema by an Objectivity/C++ application.)
	 * Regardless of the format in which you specify a
	 * qualified schema class name, it is saved in the
	 * standard format (with underscores separating qualifiers
	 * from each other and a single period preceding the classname).</p>
	 *
	 */
    public void setSchemaClassName(String javaClassName, String schemaClassName)
        { persistor().setSchemaClassName(javaClassName, schemaClassName) ; }

	/**
	 * Drops the cached information for the specified class.
	 *
	 * <p>Objectivity for Java prohibits garbage collection of the class
	 * descriptions of a connection's registered classes.
	 * When you have finished using a particular class and want its
	 * class description to be
	 * available for garbage collection, you can call this
	 * method to release cached information for the class.
	 * Dropping a class:</p>
	 * <ul type=disc>
	 * <li>Removes its schema class description from application
     * memory (but not from the federated database). </p>
     *
	 * <li>Causes the local representations of all objects of that class to
     * be dropped from all sessions.   Dropping an object's local
     * representation removes all information about that object from the
     * session's internal cache. The session gives up ownership of the
     * object, and the object becomes a dead object. </p>
	 * </ul>
	 *
 	 * <p>If you want to create or find objects of a dropped class,
 	 * you are free to do so:</p>
	 * <ul type=disc>
 	 * <li>If your application uses the default
	 * <a href="../../../../../guide/jgdSchemaManagement.html#Schema Class Names">
	 * schema class name</a> for the dropped class, no additional steps
	 * are necessary.  When the application creates or finds objects
	 * of the dropped class, the schema description is retrieved from
	 * the federated database.</p>
	 *
	 * <li>If your application uses a custom schema class name for the
	 * dropped class, you must first call
	 * {@link #setSchemaClassName <tt>setSchemaClassName</tt>} to
	 * reset the schema class name, then call
	 * {@link #registerClass <tt>registerClass</tt>} to retrieve the
	 * schema description from the federated database.
	 * </ul>
	 *
	 * <p>After the schema class description is retrieved,
	 * it will not be garbage
	 * collected until you call <tt>dropClass</tt> again.</p>
	 *
	 * @param 	 className	The
	 * package-qualified name of
     * the persistence-capable class to be dropped.</p>
     *
     * @see     #dropAllUserClasses(boolean)
	 */
    public void dropClass(String className)
        { persistor().dropClass(className) ; }

	/**
	 * Drops the cached information for all application-defined classes.
	 *
	 * <p>Objectivity for Java prohibits garbage collection of the class
	 * descriptions of a connection's registered classes.
	 * If your application uses one group of classes for one operation
	 * and a different group of classes for the next operation, you
	 * can call this method after the first operation to make the
	 * class descriptions it uses available for garbage collection.  This
	 * method releases cached information for all application-defined classes.
	 * Dropping a class:</p>
	 * <ul type=disc>
	 * <li>Removes its schema class description from application
     * memory (but not from the federated database). </p>
     *
	 * <li>Causes the local representations of all objects of that class to
     * be dropped from all sessions.   Dropping an object's local
     * representation removes all information about that object from the
     * session's internal cache. The session gives up ownership of the
     * object, and the object becomes a dead object. </p>
	 * </ul>
	 *
 	 * <p>If you want to create or find objects of a dropped class,
 	 * you are free to do so:</p>
	 * <ul type=disc>
 	 * <li>If your application uses the default
	 * <a href="../../../../../guide/jgdSchemaManagement.html#Schema Class Names">
	 * schema class name</a> for the dropped class, no additional steps
	 * are necessary.  When the application creates or finds objects
	 * of the dropped class, the schema description is retrieved from
	 * the federated database.</p>
	 *
	 * <li>If your application uses a custom schema class name for the
	 * dropped class, you must first call
	 * {@link #setSchemaClassName <tt>setSchemaClassName</tt>} to
	 * reset the schema class name, then call
	 * {@link #registerClass <tt>registerClass</tt>} to retrieve the
	 * schema description from the federated database.
	 * </ul>
	 *
	 * <p>After the schema class description is retrieved,
	 * it will not be garbage
	 * collected until the next time you call this method or
	 * {@link #dropClass <tt>dropClass</tt>}.</p>
	 *
	 * The <tt><i>forceCacheRefresh</i></tt> parameter reads the current
	 * schema class descriptions from disk, allowing schema changes
	 * introduced by other applications to be seen.
	 *
	 * @param 	 forceCacheRefresh    True to load schema descriptions from disk;
	 * false to use existing schema descriptions.</P>
	 */
    public void dropAllUserClasses(boolean forceCacheRefresh)
        { persistor().dropAllUserClasses(forceCacheRefresh) ; }

	/**
	 * Reserved for internal use.
	 *
     */
    public void dropAllUnregisterableClasses()
        { persistor().dropAllUnregisterableClasses() ; }

	/**
	 * Gets the schema policy for the connected federated database.</p>
	 *
	 * @return		The schema policy for the connected
	 * federated database.
	 */
    public SchemaPolicy getSchemaPolicy()
        { return persistor().getSchemaPolicy() ; }

	/**
     * Sets the
	 * <a href="../../../../../guide/jgdSessions.html#Thread Policies">
     * thread policy</a> for this connection.
     *
	 * <p>A connection object uses the value of its thread policy to initialize the corresponding
	 * property of new sessions.
	 * This method affects the initialization of sessions created after this method is called;
	 * the thread policies of existing sessions are not changed.</p>
	 *
     * <p>If this method is never called, the restricted thread policy is
 	 * used by default.</p>
     *
     * @param 	 policy	The thread policy for this connection;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>THREAD_POLICY_RESTRICTED</tt></dt>     <dd>A thread must
	 * be joined
     * to a session before it can perform any Objectivity/DB operation with that
     * session or any objects belonging to that session.</dd>
     *  <dt> <tt>THREAD_POLICY_UNRESTRICTED</tt></dt>    <dd>Any thread can
	 * interact with any session or any objects belonging to that session. </dd>
     * </dd></dl></dl></p>
	 *
	 * @see #getThreadPolicy
	 */
    public void setThreadPolicy(int policy)
        { persistor().setThreadPolicy(policy) ; }

	/**
     * Gets the thread policy for this connection.</p>
     *
     * @return		The thread policy for this connection;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>THREAD_POLICY_RESTRICTED</tt></dt>     <dd>A thread must
	 * be joined
     * to a session before it can perform any Objectivity/DB operation with that
     * session or any objects belonging to that session.</dd>
     *  <dt> <tt>THREAD_POLICY_UNRESTRICTED</tt></dt>    <dd>Any thread can
	 * interact with any session or any objects belonging to that session. </dd>
     * </dd></dl></dl></p>
	 *
	 * @see #setThreadPolicy
	 */
    public int getThreadPolicy()
        { return persistor().getThreadPolicy() ; }

	/**
	 * Gets the object identifier with the specified string representation from the
	 * connected federated database.
	 *
   	 * <p>You can get the object identified by the returned object identifier by
	 * calling the {@link ooFDObj#objectFrom <tt>objectFrom</tt>}
     * method of the federated database.</p>
	 *
	 * @param 	 oidString	The string
	 * representation of the
     * desired object identifier. The string must be of the form returned by the
     * {@link ooId#getString <tt>getString</tt>}
     * method of an object identifier.</p>
	 *
     * @return		The object identifier with the specified string representation.
	 */
    public static ooId oidFrom(String oidString)
        { return com.objy.pm.ooId.oidFrom(oidString) ; }

	/**
	 * Gets the task assigner used for parallel queries
	 * performed in this connection.</p>
	 *
	 * @return  The current task assigner.
	 */
	public TaskAssigner getTaskAssigner()
        { return persistor().getTaskAssigner(); }

    /**
     * Sets the task assigner to be used for parallel queries performed in this
     * connection.</p>
     *
     * @param 	 ta  The desired task assigner.
     */
    public void setTaskAssigner(TaskAssigner ta)
        { persistor().setTaskAssigner(ta); }

	/**
	 * Reserved for future use; you should not call this method.</p>
	 */
    public static void setKernelOptions(int options)
        { Access.setKernelOptions(options) ; }

	/**
	 * Sets whether each session in this connection writes changes to
     * persistent objects to its Objectivity/DB cache before performing a
     * predicate scan.</p>
	 *
	 * <p>If this method is never called, each session updates its cache
     * before a predicate scan. For additional information, see
     * <a href="../../../../../guide/jgdCache.html#Controlling Automatic Updates Before Predicate Scans">
     * Controlling Automatic Updates Before Predicate Scans</a>.</P>
     *
	 * @param 	 autoFlush    True to cause changed persistent
     * objects to be written to the session's Objectivity/DB cache before
     * a predicate scan; false to perform a predicate scan without updating
     * the session's Objectivity/DB cache.</p>
	 *
	 * @see #isPredicateScanAutoFlush
	 *
	 */
    public void setPredicateScanAutoFlush(boolean autoFlush)
        { persistor().setPredicateScanAutoFlush(autoFlush) ; }

	/**
	 * Tests whether each session in this connection writes changes to
     * persistent objects to its Objectivity/DB cache before performing a
     * predicate scan. </p>
	 *
	 * @return      True if changed persistent
     * objects are written to the session's Objectivity/DB cache before
     * a predicate scan; false if a predicate scan is performed without updating
     * the session's Objectivity/DB cache.</p>
	 *
	 * @see #setPredicateScanAutoFlush
	 */
    public boolean isPredicateScanAutoFlush()
        { return persistor().isPredicateScanAutoFlush() ; }

    /**
     * (<i>IPLS</I>) Starts an in-process lock server
     * for the connected federated database.</p>
     *
     * <p>You must call this method before you start the first
     * transaction in this connection.
	 *
	 * <p>You can start an in-process lock server only if both of the following are true:
	 * <ul type=disc>
	 * <li>Your application is running on the lock-server host
	 * of the connected federated database.
	 * <li>No other lock server is currently running on this host.
	 * </ul></p>
     *
     * <p>If another
     * lock-server process is already running on the same host and the
     * application chooses to continue running, it will use the lock server
     * that is already running on that host. An application can call the
     * {@link #checkLS <tt>checkLS</tt>} method to test for a running
     * lock server.
     *
     * <p>After the in-process lock server is started,
	 * the application becomes the lock-server process for the
     * workstation on which it is running. If a federated database names that
     * workstation as its lock-server host, all applications accessing that
     * federated database will send their lock requests to the application
     * running the in-process lock server. The in-process lock server uses a
     * separate listener thread to service requests from external
     * applications. </p>
     *
     *
     * <p>An in-process lock server improves performance only if most or all
     * of the lock requests for a given federated database originate from a
     * single multithreaded application process. The in-process lock server
     * can then coordinate locking through simple method calls instead of
     * servicing lock requests over the network. </p>
     *
     * @return True if the in-process lock server was successfully
     * started; otherwise, false--for example, if a separate lock-server
     * process is already running on the same host machine, or if some
     * operating-system resource could not be obtained. </p>
     *
     * @see #stopInternalLS
     * @see #checkLS(String)
     */
    public boolean startInternalLS()
        { return persistor().startInternalLS() ; }

    /**
     * (<i>IPLS</I>) Shuts down this connection's in-process lock server
     * after all transactions have terminated.
     *
     * <p>This method safely shuts down an in-process lock server so that
     * you can terminate the application in which it is running without
     * harming any other applications that may be using the in-process lock
     * server.
     *
     * <p>This method should be called before terminating the application that is
     * running the in-process lock server, after the application has
     * committed or aborted all its transactions.
     *
     * <p>This method causes the in-process lock server to refuse any new
     * transactions from external client applications, and to wait
     * indefinitely for any transactions to finish. While waiting,
     * the in-process lock server may accept new client connections
     * (for example, to allow administration tools to run), but continues to
     * disallow new transactions. When all transactions have finished,
     * the in-process lock server is shut down. At this point, the application
     * may safely exit. </p>
     *
     * @return  True if the in-process lock server is successfully shut
     * down, or if it was not running; otherwise, false.</p>
     *
     * @see #startInternalLS
     * @see #stopInternalLS(int, boolean)
     */
    public boolean stopInternalLS()
        { return persistor().stopInternalLS(Integer.MAX_VALUE, false) ; }

    /**
     * (<i>IPLS</I>) Shuts down this connection's in-process lock server
     * after waiting a specified period of time for transactions
     * to terminate.
     *
     * <p>This method safely shuts down an in-process lock server so that
     * you can terminate the application  without harming any other
     * applications that may be using the in-process lock server.
     *
     * <p>This method should be called before terminating the application that is
     * running the in-process lock server, after the application has
     * committed or aborted all its transactions.
     *
     * <p>This method causes the in-process lock server to refuse any new
     * transactions from external client applications, and to wait for any
     * transactions to finish during the period specified by the
     * <tt><i>wait</tt></i> parameter. During the wait period, the in-process lock
     * server may accept new client connections (for example, to allow
     * administration tools to run), but continues to disallow new
     * transactions. When all transactions have finished, the
     * in-process lock server is shut down. At this point, the application
     * may safely exit.
     *
     * <p>If transactions do not finish and the wait period expires,
     * this function either shuts down the in-process lock server or allows
     * it to continue running, according to the <tt><i>force</i></tt>
     * parameter. If the in-process lock server continues running, the
     * application can repeat the attempted shutdown by calling this method
     * again later. </p>
     *
     * @param 	 wait Number of seconds to wait for active
     * transactions to terminate.  If transactions terminate within
     * the specified wait period, the in-process lock server is shut down.
     * Otherwise, if transactions are still active when the specified wait
     * period expires, this method takes the action specified by the
     * <tt><i>force</i></tt> parameter.  </p>
     *
     * @param 	 force Specifies whether to shut down the
     * in-process lock server if transactions have not yet terminated
     * by the end of the wait period:
	 * <ul type=disc>
     * <li>If you specify true, the in-process lock server is shut down,
     * even if transactions are active, and this method returns true.
     *
     * <li>If you specify false, the in-process lock server continues running
     * and this method returns false.
     * </ul></p>
     *
     * @return  True if the in-process lock server is successfully shut
     * down, or if it was not running; otherwise, false.</p>
     *
     * @see #startInternalLS
     */
    public boolean stopInternalLS(int wait, boolean force)
        { return persistor().stopInternalLS(wait, force) ; }

    /**
     * (<i>IPLS</i>) Tests whether a lock server is running on the specified host machine.
     *
     * <p>An application can call this method to decide
     * whether to start an in-process lock server. An in-process lock server
     * can be started only if no other lock-server process is running on the
     * same host as the application. The application could take various
     * actions based on the result of this method. For example, if another
     * lock server is running on the current host, the application could
     * report it and allow the user to choose whether to quit the application
     * or continue using the other lock server. </p>
     *
     * @param 	 host  Name of the host machine to be checked
     * for a running lock server. </p>
     *
     * @return  True if a lock server (internal or external) is running on
     * the specified host; otherwise, false. </p>
     *
     * @see #startInternalLS
     */
    public boolean checkLS(String host)
        { return persistor().checkLS(host) ; }

    /**
     * (<i>IPLS</i>) Tests whether a lock server for the connected federated database is running.
     *
     * <p>An application can call this method to decide
     * whether to start an in-process lock server. An in-process lock server
     * can be started only if no other lock-server process is running on the
     * same host as the application. The application could take various
     * actions based on the result of this method. For example, if another
     * lock server is running on the current host, the application could
     * report it and allow the user to choose whether to quit the application
     * or continue using the other lock server. </p>
     *
     * @return  True if a lock server (internal or external) is running on
     * the specified host; otherwise, false. </p>
     *
     * @see #startInternalLS
     */

    public boolean checkLS()
        { return persistor().checkLS() ; }

	/**
	 * Tests whether a query server is running on the specified host.</p>
	 *
	 * Before your application can start a parallel query that will assign a query task to a query server
	 * on a particular host, you must ensure that host has a running query server.
	 *  </p>
	 *
	 * @param 	 hostname Name of the host machine to be checked for a running query server.
	 * You can specify a null string to check the current host.</p>
	 *
	 * @return True if a query server is running on the specified host;
	 * otherwise, false.</p>
	 *
	 * @see ooFDObj#parallelScan(String, String)
	 * @see ooFDObj#parallelScan(String, ObjectQualifier)
	 */
	public boolean checkQueryServer(String hostname)
        { return persistor().checkQueryServer(hostname); }

    /**
     * Adds the specified signal to the set of signals to be handled by the
     * <A HREF="../../../../../guide/jgdApplication.html#SignalHandler">
     * Objectivity/DB signal handler</A>.
     *
     * <p><b>Note: </b>You must call this static method <i>before</i> you
     * open the connection to which it will apply.</p>
     *
     * @param 	 signal  The signal to be added; one of the
     * <a href="oo.html#Signals">signal constants</a> defined in the
     * <tt>com.objy.db.app.oo</tt> interface.</p>
     *
     * @return      True if the set of signals was modified; false if the set
     * already included <tt><i>signal</i></tt>.</p>
     *
	 * @see	#removeHandledSignal
	 * @see	#containsHandledSignal
	 * @see #setInstallSignalHandler
	 * @see #open
     */
    public static boolean addHandledSignal(byte signal)
        { return Access.addHandledSignal(signal) ; }

    /**
     * Removes the specified signal from the set of signals to be handled by
     * the <A HREF="../../../../../guide/jgdApplication.html#SignalHandler">
     * Objectivity/DB signal handler</A>.
     *
     * <p><b>Note: </b>You must call this static method <i>before</i> you
     * open the connection to which it will apply.</p>
     *
     * @param 	 signal  The signal to be removed; one of the
     * <a href="oo.html#Signals">signal constants</a> defined in the
     * <tt>com.objy.db.app.oo</tt> interface.</p>
     *
     * @return      True if the set of signals was modified; false if the set
     * did not include <tt><i>signal</i></tt>.</p>
     *
	 * @see	#addHandledSignal
	 * @see	#containsHandledSignal
	 * @see #setInstallSignalHandler
	 * @see #open
     */
    public static boolean removeHandledSignal(byte signal)
        { return Access.removeHandledSignal(signal) ; }

    /**
     * Tests whether the specified signal is in the set of signals to be
     * handled by the
     * <A HREF="../../../../../guide/jgdApplication.html#SignalHandler">
     * Objectivity/DB signal handler</A> in this connection.</p>
     *
     * @param 	 signal  The signal to be tested; one of the
     * <a href="oo.html#Signals">signal constants</a> defined in the
     * <tt>com.objy.db.app.oo</tt> interface.</p>
     *
     * @return      True if the set of signals contains
     * <tt><i>signal</i></tt>; otherwise, false.</p>
     *
	 * @see	#addHandledSignal
	 * @see	#removeHandledSignal
	 * @see #printHandledSignals
     */
    public static boolean containsHandledSignal(byte signal)
        { return Access.containsHandledSignal(signal) ; }

    /**
     * Prints to standard output the set of signals to be handled
     * by the
     * <A HREF="../../../../../guide/jgdApplication.html#SignalHandler">
     * Objectivity/DB signal handler</A> in this connection.</p>
     *
     * @see #containsHandledSignal
     */
    public static void printHandledSignals()
        { Access.printHandledSignals() ; }

    /**
     * Directs Objectivity for Java to attempt to load classes using
     * the specified user class loader.</p>
     *
     * <p>Class loading is attempted in the order:
     * <ul type=disc>
     * <li> User class loader (if specified)
     * <li> Context class loader (if recognition turned on)
     * <li> Current class loader
     * <li> System class loader
     * </ul></p>
     *
     * @see #useContextClassLoader
     */
    public void setUserClassLoader(ClassLoader userClassLoader)
        { persistor().setUserClassLoader(userClassLoader) ; }

    /**
     * Directs Objectivity for Java to preferentially recognize the context
     * class loader (otherwise ignored).</p>
     *
     * <p>Class loading is attempted in the order:
     * <ul type=disc>
     * <li> User class loader (if specified)
     * <li> Context class loader (if recognition turned on)
     * <li> Current class loader
     * <li> System class loader
     * </ul></p>
     *
     * @see #setUserClassLoader
     */
    public void useContextClassLoader(boolean useContextClassLoader)
        { persistor().useContextClassLoader(useContextClassLoader) ; }

    /**
     * Sets logging options for the application.</p>
     *
     * <p><b>Note: </b>You must call this static method <i>before</i> your
     * first call the the {@link Connection#open <tt>Connection.open</tt>} static
     * method.</p>
	 *
	 * <p>If you want a {@link Tuner performance tuner} to enable logging, your application must call
	 * <tt>setLoggingOptions</tt>. You can specify <tt>LogNone</tt> as the <tt><i>options</i></tt> parameter
	 * to leave logging disabled unless the tuner specifies another logging option.</p>
     *
     * @param 	 options	        The mode in which
     * to begin logging; one or more of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface.
     * <dl><dd><dl>
     * <dt><tt>LogNone</tt><dd>Logging is disabled.</dd>
     * <dt><tt>LogMain</tt><dd>Create the main log.</dd>
     * <dt><tt>LogSession</tt><dd>Create a log per session.</dd>
     * <dt><tt>LogTransactionStatistics</tt><dd>Log transaction statistics in session logs.</dd>
     * <dt><tt>LogTransactionTiming</tt><dd>Log transaction timing in session logs.</dd>
     * <dt><tt>LogOther</tt><dd>Enable application defined log items for all logs.</dd>
     * <dt><tt>LogAll</tt><dd>Enable all logging.</dd>
     * </dd></dl></dl>
	 *
	 * (You can enable multiple logging options by combining the corresponding
	 * logging-option constants with the Java bitwise OR
	 * operator |.
	 * See  <a href="../../../../../guide/jgdMonitoring.html#Selecting Logging Options">
	 * Selecting Logging Options</a>.)
	 * </p>
     * @param 	 logToFiles	Specifies whether to
     * write logged information to log files. Specify true to write
	 * logged information to the appropriate log file; specify false to suppress writing to log files.
	 * In either case, logged information is passed to any relevant log listener.</p>
     * @param 	 appendLogFiles	Specifies whether to
     * append new log items to the existing log files (if any).
	 * Specify true to append new log items to the existing log file;
	 * specify false to overwrite the existing log file with new log items.
	 * This parameter is relevant only if <tt><i>logToFiles</i></tt> is true.</p>
     * @param 	 logDirPath	Path of the directory in which log files
	 * should be written, or an empty string to use the current directory.
	 * This parameter is relevant only if <tt><i>logToFiles</i></tt> is true.
	 * A new log file is created only if a file with the appropriate name
	 * does not exist in this directory.</p>
     * @param 	 mainLogFileName	Name of the main log.
	 * This parameter is relevant only if <tt><i>logToFiles</i></tt> is true.
     */
    static public void setLoggingOptions(int options, boolean logToFiles, boolean appendLogFiles, String logDirPath, String mainLogFileName)
        { Access.setLoggingOptions(options, logToFiles, appendLogFiles, logDirPath, mainLogFileName) ; }

    /**
     * Adds an application-specific item to the main log.</p>
	 *
	 *
	 * <p>If logged information is being written to log files, an item with the specified
	 * label and text is added to the end of the main log file.
	 *
	 * <p>If a log listener is attached to the main  log, the specified log item is passed to
	 * the listener's {@link LogListener#onLogItem <tt>onLogItem</tt>} method.
	 *
	 * <p>This method is relevant only if logging to the main log and adding
	 * application-defined log items were both enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>}
	 * static method
	 * specifying either the logging option <tt>LogAll</tt> or both options <tt>LogMain</tt>
	 * and <tt>LogOther</tt>. </p>
     *
     * @param 	 label	Label for log item; specify null or an empty string
	 * for an item with no label.</p>
     *
     * @param 	 text	Text of log item; specify null or an empty string
	 * for an item with no text.</p>
	 *
	 * @see		Session#addToLog
	 *
     */
    public void addToMainLog(String label, String text)
        { persistor().addToMainLog(label, text) ; }

	 /**
	  * Sets this connection's output property for status messages generated by Objectivity for Java.</p>
	  *
	  * <p>A connection object uses the value of this output property to initialize the corresponding
	  * properties of new sessions.
	  * This method affects the initialization of sessions created after this method is called;
	  * the output properties of existing sessions are not changed.</p>
	  *
	  * If this method is never called, this connection initializes all new
	  * sessions so that Objectivity for Java status messages are directed to the standard
	  * output stream (<tt>System.out</tt>).</p>
	  *
	  * @param 	 outputStream	Print stream for Objectivity for Java status messages.</p>
	  *
	  * @see		Session#setOut
	  *
	  */
    public void setOut(PrintStream outputStream)
	{
	persistor().setOutStream(outputStream) ;
    }
	 /**
	  *
	  * Sets this connection's output property for error messages generated by Objectivity for Java.</p>
	  *
	  * <p>A connection object uses the value of this output property to initialize the corresponding
	  * properties of new sessions.
	  * This method affects the initialization of sessions created after this method is called;
	  * the output properties of existing sessions are not changed.</p>
	  *
	  * If this method is never called, this connection initializes all new
	  * sessions so that Objectivity for Java error messages are directed to
	  * the standard error-output stream (<tt>System.err</tt>).</p>
	  *
	  *
	  * @param 	 outputStream	Print stream for Objectivity for Java error messages.</p>
	  *
	  * @see		Session#setErr
	  */
    public void setErr(PrintStream outputStream)
	{
	persistor().setErrStream(outputStream) ;
    }

    /**
     * Gets this connection's policy for storing unique internal
     * persistent objects.</p>
     *
     * @return      True if internal persistent objects are unique;
     * false if they are shared.</p>
     */
    public boolean getUniqueInternObjects()
        { return persistor().getUniqueInternObjects() ; }

    /**
     * Sets this connection's policy for storing unique internal
     * persistent objects.</p>
	 *
	 * <p>If you set the
	 * policy to true, new persistent objects that set attributes to the same value
	 * will each reference a unique internal persistent object
	 * representing that particular attribute value.</p>
     *
	 *
	 * <p>If you do not call this method, or you call it and set the policy to false,
	 * two or more persistent objects that set attributes to the same value in the same transaction
	 * will all reference a single internal persistent object representing that
	 * value. (Persistent objects that set attributes to this value
	 * in a different transaction will reference a different internal
	 * persistent object representing the value.)
	 * </p>
	 *
     * <p>This method affects only
     * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
     * internal persistent objects</a> created after the method is called.
     * Existing objects are not changed.</p>
     *
     * <p><b>Note:</b> This method controls the uniqueness of
	 * internal persistent objects referenced by newly created
	 * objects.
	 * When you copy an object that has
     * internal persistent objects, the copy will reuse
     * the same internal persistent objects unless the <tt>copy</tt> method has been
     * overridden to perform a deep copy.</p>
     *
     * @param 	 internObjects	True if unique internal
     * persistent objects are to be used; otherwise, false.
     */
    public void setUniqueInternObjects(boolean internObjects)
        { persistor().setUniqueInternObjects(internObjects) ; }

    /**
     * Attaches the specified log listener to the main log.</p>
	 *
	 * <p>If the main log already has a listener, that listener is removed
	 * before the new listener is attached.</p>
	 *
	 * <p>After the log listener is attached, it is notified whenever the main log records
	 * a log item and whenever the application adds a log item to the main log.
	 *
	 * <p><b>Note:</b> You should not attach the same log listener to more than one log;
	 * any given log listener can receive notifications from at most one log (either the
	 * main log or a particular session's log).</p>
	 *
	 *
	 * <p>This method is relevant only if logging to the main log was enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method
	 * specifying either logging option <tt>LogAll</tt> or <tt>LogMain</tt>. </p>
     *
     * @param 	 listener	Log listener for
	 * the main log. A log listener is an instance of an application-defined
	 * class derived from the {@link LogListener <tt>LogListener</tt>} class.</p>
	 *
	 * @see		Session#setLogListener
	 *
     */
    public void setMainLogListener(LogListener listener)
        { persistor().setMainLogListener(listener) ; }

    /**
     * Creates a session pool with the specified session-pool properties.</p>
     *
     * <p>A session pool provides a reservoir of pooled sessions. An application can
     * obtain a session from the pool; when the session is no longer needed,
     * the application can return the session to the pool. For details, see
	 * <a href="../../../../../guide/jgdSessions.html#Understanding Session Pools">
	 * Understanding Session Pools</a>.
	 * </p>
	 *
	 * <p>Properties of a session pool control how many sessions it can create and how it behaves
     * when unable to fulfill a request for a session. This method creates a session pool with:
	 * <ul type=disc>
	 * <li>
	 * The specified soft and hard limits.
	 * <li>
	 * The default session-waiting timeout period (0). An exception is thrown
	 * immediately if the application requests a session from the session pool
	 * when the pool's hard limit has been reached and all sessions are in use.
	 * </ul></p>
	 *
	 * <p>You can create
     * as many session pools as you need. You typically create different
     * pools when you need to use sessions with different properties.
	 *
	 * <p>The new session pool creates each of its sessions with
	 * the following default session properties:
	 * <ul type=disc>
	 * <li>The initial cache capacity of the session's Objectivity/DB cache
	 * is 200 and the maximum cache capacity is 500.
	 * <li> The large object memory pool is the system database's storage-page size (in bytes) multiplied by 500.
	 * <li> Hot mode is enabled.
	 * <li> The lock-waiting option is not to wait for locks.
	 * </ul></p>
     *
     * @param 	 sessionPoolName	Name of
	 * the new session pool; must be unique among this connection's session pools.</p>
     *
     * @param 	 softLimit	Preferred number of sessions to
	 * be created by the new session pool.
	 * (If the application requests a session when the soft limit has been reached
	 * and all the sessions are active,
	 * the session pool will create additional sessions, up to its hard limit.)
	 * <tt><i>softLimit</i></tt> also specifies the maximum number of inactive sessions
	 * that the session pool can retain.
	 * </p>
     *
     * @param 	 hardLimit	Maximum number of sessions that the new session pool
	 * can create.</p>
     *
     * @exception	ooDuplicateSessionPoolName   If a session pool has already been
	 * created using the specified name.</p>
	 *
     * @exception	ooTooManySessions   If a session is requested from this
	 * session pool when all sessions are active and the pool's hard limit has been reached.</p>
     */
    public void createSessionPool(String sessionPoolName, int softLimit, int hardLimit)
        { persistor().createSessionPool(sessionPoolName, softLimit, hardLimit) ; }

    /**
     * Creates a session pool with the specified session-pool properties, including
	 * the session-waiting timeout period.</p>
     *
     * <p>A session pool provides a reservoir of pooled sessions. An application can
     * obtain a session from the pool; when the session is no longer needed,
     * the application can return the session to the pool. For details, see
	 * <a href="../../../../../guide/jgdSessions.html#Understanding Session Pools">
	 * Understanding Session Pools</a>.
	 *
	 * <p>Properties of a session pool control how many sessions it can create and how it behaves
     * when unable to fulfill a request for a session. This method creates a session pool with:
	 * <ul type=disc>
	 * <li>
	 * The specified soft and hard limits.
	 * <li>
	 * The specified session-waiting timeout period.
	 * </ul></p>
	 *
	 * <p>You can create
     * as many session pools as you need. You typically create different
     * pools when you need to use sessions with different properties.
	 *
	 * <p>The new session pool creates each of its sessions with
	 * the following default session properties:
	 * <ul type=disc>
	 * <li>The initial cache capacity of the session's Objectivity/DB cache
	 * is 200 and the maximum cache capacity is 500.
	 * <li> The large object memory pool is the system database's storage-page size (in bytes) multiplied by 500.
	 * <li> Hot mode is enabled.
	 * <li> The lock-waiting option is not to wait for locks.
	 * </ul></p>
     *
     * @param 	 sessionPoolName	Name of
	 * the new session pool; must be unique among this connection's session pools.</p>
	 *
     * @param 	 softLimit	Preferred number of sessions to
	 * be created by the new session pool.
	 * (If the application requests a session when the soft limit has been reached
	 * and all the sessions are active,
	 * the session pool will create additional sessions, up to its hard limit.)
	 * <tt><i>softLimit</i></tt> also specifies the maximum number of inactive sessions
	 * that the session pool can retain.
	 * </p>
     *
     * @param 	 hardLimit	Maximum number of sessions that the new session pool
	 * can create.</p>
     *
     * @param 	 sessionWait	Session-waiting timeout period,
	 * which determines the new session pool's behavior if an
	 * application requests a session when the pool's hard limit
	 * has been reached and all sessions are in use: </p>
	 * <dl><dd><dl>
     *  <dt>0</dt>    <dd>Do not wait for a session to be returned to the pool; throw an
	 *                 exception immediately. </dd></p>
	 *  <dt>-1</dt>   <dd>Wait indefinitely for a session to be returned to the pool.</dd></p>
     *  <dt><i><tt>n</tt></i> &gt;= 1</dt>   <dd>Wait for <tt><i>n</i></tt> seconds
	 *                 for a session to be returned to the pool before throwing an exception.</dd></p>
     * </dd></dl></dl></p>
     *
     * @exception	ooDuplicateSessionPoolName   If a session pool has already been
	 * created using the specified name.</p>
	 *
     * @exception	ooTooManySessions   If a session is requested from this
	 * session pool when all sessions are active, the pool's hard limit has been reached, and
	 * the pool's session-waiting timeout period has expired.</p>
     */
    public void createSessionPool(String sessionPoolName, int softLimit, int hardLimit, int sessionWait)
        { persistor().createSessionPool(sessionPoolName, softLimit, hardLimit, sessionWait) ; }

    /**
     * Creates a session pool with the specified session properties and session-pool properties.</p>
     *
     * <p>A session pool provides a reservoir of pooled sessions. An application can
     * obtain a session from the pool; when the session is no longer needed,
     * the application can return the session to the pool. For details, see
	 * <a href="../../../../../guide/jgdSessions.html#Understanding Session Pools">
	 * Understanding Session Pools</a>.
	 *
	 * <p>Properties of a session pool control how many sessions it can create and how it behaves
     * when unable to fulfill a request for a session. This method creates a session pool with:
	 * <ul type=disc>
	 * <li>
	 * The specified soft and hard limits.
	 * <li>
	 * The specified session-waiting timeout period.
	 * </ul></p>
	 *
	 * <p>The new session pool creates each of its sessions with the specified session properties.</p>
	 *
	 * <p>You can create
     * as many session pools as you need. You typically create different
     * pools when you need to use sessions with different properties, such
     * as different Objectivity/DB cache sizes. </p>
     *
     * @param 	 sessionPoolName	Name of
	 * the new session pool; must be unique among this connection's session pools.</p>
	 *
     * @param 	 softLimit	Preferred number of sessions to
	 * be created by the new session pool.
	 * (If the application requests a session when the soft limit has been reached
	 * and all the sessions are active,
	 * the session pool will create additional sessions, up to its hard limit.)
	 * <tt><i>softLimit</i></tt> also specifies the maximum number of inactive sessions
	 * that the session pool can retain.
	 * </p>
     *
     * @param 	 hardLimit	Maximum number of sessions that the new session pool
	 * can create.</p>
	 *
	 * @param 	 cacheInitialPages	The initial cache capacity
	 * for each session in the session pool:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in each session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's storage-page size),
	 * this value specifies:
	 * <ul type=circle>
	 * <li>
	 * The initial number of buffer pages allocated in each session's default
	 * small-object buffer pool.
	 * <li>
	 * The initial number of buffer entries allocated in each session's default
	 * large-object buffer pool (equivalently,
	 * the initial number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by each session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), this value specifies:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the initial number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The initial number of bytes is equal to the specified value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The initial number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the initial number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 *
	 * @param 	 cacheMaxPages	 The maximum cache capacity
	 * for each session in the session pool:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in each session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * this value specifies:
	 * <ul type=circle>
	 * <li>
	 * The maximum number of buffer pages allocated in each session's default
	 * small-object buffer pool.
	 * <li>
	 * The maximum number of buffer entries allocated in each session's default
	 * large-object buffer pool (equivalently,
	 * the maximum number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by each session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), this value specifies:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the maximum number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The maximum number of bytes is equal to the specified value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The maximum number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the maximum number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
     *
     * @param 	 largeObjectMemoryLimit  The suggested
     * maximum number of bytes in the large-object memory pool in the
     * Objectivity/DB cache of each session in the session pool.</p>
     *
     * @param 	 hotMode	         True to enable hot mode
	 * for each session in the session pool; false to disable hot mode.</p>
     *
     * @param 	 lockWait	The lock-waiting option
     * for each session in the session pool;
	 * one of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface:</p>
     * <dl><dd><dl>
     *  <dt> <tt>NO_WAIT</tt></dt>    <dd>Sessions in the pool do not wait for
     * locks.</dd>
     *  <dt> <tt>WAIT</tt></dt>       <dd>Sessions in the pool wait
     * indefinitely for locks.</dd>
     *  <dt> <i><tt>n</tt></i></dt>   <dd>Sessions in the pool wait for
     * <tt><i>n</i></tt> seconds, where 1 <= <tt><i>n</i></tt> <= 14400.
     * If <tt><i>n</i></tt> = 0, it is treated as <tt>NO_WAIT</tt>.
     * If <tt><i>n</i></tt> is less than 0 or greater than 14400,
     * it is treated as <tt>WAIT</tt>.</dd>
     * </dd></dl></dl></p>
     *
     * @param 	 sessionWait	Session-waiting timeout period,
	 * which determines the new session pool's behavior if an
	 * application requests a session when the pool's hard limit
	 * has been reached and all sessions are in use: </p>
	 * <dl><dd><dl>
     *  <dt>0</dt>    <dd>Do not wait for a session to be returned to the pool; throw an
	 *                 exception immediately. </dd></p>
	 *  <dt>-1</dt>   <dd>Wait indefinitely for a session to be returned to the pool.</dd></p>
     *  <dt><i><tt>n</tt></i> &gt;= 1</dt>   <dd>Wait for <tt><i>n</i></tt> seconds
	 *                 for a session to be returned to the pool before throwing an exception.</dd></p>
     * </dd></dl></dl></p>
	 *
     *
     * @exception	ooDuplicateSessionPoolName   If a session pool has already been
	 * created using the specified name.</p>
	 *
     * @exception	ooTooManySessions   If a session is requested from this
	 * session pool when all sessions are active, the pool's hard limit has been reached, and
	 * the pool's session-waiting timeout period has expired.</p>
	 *
     */
    public void createSessionPool(String sessionPoolName, int softLimit, int hardLimit, int cacheInitialPages, int cacheMaxPages, int largeObjectMemoryLimit, boolean hotMode, int lockWait, int sessionWait)
        { persistor().createSessionPool(sessionPoolName, softLimit, hardLimit, cacheInitialPages, cacheMaxPages, largeObjectMemoryLimit, hotMode, lockWait, sessionWait) ; }

    /**
     * Requests a session from the specified session pool.</p>
     *
     * <p>This method obtains a session from the pool, which is joined
     * to the current thread.
	 *
	 * <p>If a null tag is specified, the session pool chooses the session that was returned
	 * to the pool most recently.
	 * If no session is available, this method creates and returns a new session.
	 *
	 * <p>If a tag is specified, the session pool chooses an available session
     * to be returned as follows:</p>
	 *
	 * <ul type=disc>
	 * <li>If one or more available sessions in the pool have the same tag,
	 * the pool chooses the session
     * with a matching tag that was returned to the pool most recently.
     * <li>If no available session has the specified tag,
	 * the pool chooses the session that was returned to the pool most recently,
	 * and assigns the tag to it.
	 * <li>If no session is available, the pool creates a new session, chooses that session,
	 * and assigns the specified tag to it.
	 * </ul></p>
	 *
	 * <p>If no session is available, this function creates and returns
     * a new session. If a tag was specified, the session is given the
     * specified tag.</p>
     *
     * @param 	 sessionPoolName	The name of the session pool
	 * from which to obtain the session.</p>
     *
     * @param 	 tag	Tag that identifies the session for
	 * future use. Specify null to obtain a session with no tag.</p>
	 *
	 * @return		Session obtained from the pool.</p>
     *
     * @exception	ooSessionPoolNotFound   If the specified session pool cannot be
	 * found.</p>
     *
     * @exception	ooTooManySessions   If a session is requested from this
	 * session pool when all sessions are active, the pool's hard limit has been reached, and
	 * the pool's session-waiting timeout period has expired.</p>
	 *
     */
    public Session getSessionFromPool(String sessionPoolName, String tag)
        { return persistor().getSessionFromPool(sessionPoolName, tag) ; }
    
    /**
     * Tests to see if a session pool already exists
     * @param sessionPoolName Name of the session pool of which we are checking the 
     * existence.
     * @return True if the session pool already exists false if it does not.
     */
    public boolean haveSessionPool(String sessionPoolName)
    {
        return persistor().haveSessionPool(sessionPoolName);
    }

    /**
     * Returns the specified session to the session pool that created it.</p>
     *
     * <p>When you are finished using a session that you obtained from a pool,
     * you should return it to the pool. Doing so reduces the total number
     * of sessions needed and helps to prevent delays or exceptions that
     * occur if the pool reaches its hard limit of sessions. The session
     * leaves the current thread when it is returned to its session pool.</p>
     *
     * @param 	 session	Session to be returned to its pool.</p>
     *
     * @exception	ooReturningActiveSessionToPool   If the session is in a transaction.
     */
    public void returnSessionToPool(Session session)
        { persistor().returnSessionToPool(session) ; }

    /**
     * Creates and registers a default performance tuner for the application.</p>
     *
     * <p><b>Note: </b>You must call this static method <i>before</i> your first
     * call to the {@link Connection#open <tt>Connection.open</tt>} static
     * method. </p>
     *
     * <p>A default performance tuner obtains its values from various
     * environment variables; see <a href="../../../../../guide/jgdTuner.html#_top_">
     * Performance Tuners</a>.

     */
    static public void setTuner()
        { Access.setTuner() ; }

    /**
     * Registers the specified performance tuner for the application; see
     * <a href="../../../../../guide/jgdTuner.html#_top_">Performance Tuners</a>.</p>
     *
     * <p><b>Note: </b>You must call this static method <i>before</i> your first
     * call to the {@link Connection#open <tt>Connection.open</tt>} static
     * method. </p>
     *
     * @param 	 tuner	Performance tuner to be registered.
	 * A performance tuner is an instance of an application-defined
	 * class derived from the {@link Tuner <tt>Tuner</tt>} class.</p>
     *
     * @exception	ooTunerNotSetFirst   If logging has already been started or a connection
	 * has already been opened.
     */
    static public void setTuner(Tuner tuner)
        { Access.setTuner(tuner) ; }

    /**
     * Gets the maximum cache capacity for the session that performs
	 * schema evolution.</p>
     *
     * @return      The maximum
     * capacity of the Objectivity/DB cache of the schema-management session
	 * (the session in which schema evolution is performed).
	 * The maximum cache capacity is an integer
	 * that determines both of the following:
	 * <ul type=disc>
	 * <li>The maximum number of buffer pages
	 * that can be allocated for the session's small-object buffer pool.
     * <li>The maximum number of buffer entries that can be allocated in the session's
	 * large-object buffer pool.</ul></p>
	 *
	 * @see  #open(String, int, int)
     */
    public int getSchemaCacheMaximum()
        { return persistor().getSchemaCacheMaximum() ; }

    /**
     * Specifies the disk format of new storage pages created by the
	 * application in the connected federated database.</p>
	 *
	 * <p>If an application does not call this method,
	 * all new storage pages are
	 * created using the disk format of the client-host architecture
	 * (the architecture of the client host on which the application is running).
	 * Thus, by default, the disk format of a new storage page is optimized
	 * for access by applications running on the same client-host architecture
	 * as the application that created the page. You call this method
	 * to set the disk-format property to a nondefault architecture&#x2014;that is,
	 * to optimize for access by applications running on a different
	 * architecture than the creating application. </p>
	 *
	 * <p><b>Warning:</b> Unrebuilt legacy applications may not recognize architectures
	 * supported by later releases of Objectivity/DB. Be sure to specify
	 * an architecture that is recognized by <i>all</i> applications that will
	 * access the new storage pages.</p>
     *
     * @param 	 format Owning architecture of all
	 * newly created storage pages;
     * one of the 
	 * <a href="oo.html#ooDiskFormat"><b>disk-format architecture</b></a>
	 * constants defined in the
     * <a href="oo.html"><tt>com.objy.db.app.oo</tt></a> interface.
     */
    public void setObjectCreationDiskFormat(int format)
        { persistor().setObjectCreationDiskFormat(format) ; }

    /**
     * Gets the architecture for disk pages created with this connection.</p>
     *
     * @return		Owning architecture of any new storage
	 * pages created by the application in the connected federated database;
     * one of the 
	 * <a href="oo.html#ooDiskFormat"><b>disk-format architecture</b></a>
	 *  constants defined in the
     * <a href="oo.html"><tt>com.objy.db.app.oo</tt></a> interface.
     */
    public int getObjectCreationDiskFormat()
        { return persistor().getObjectCreationDiskFormat() ; }

    /**
     * Gets the client-host architecture.</p>
	 *
	 * You typically use the returned value in code that manages the
	 * disk format to be used when an application creates new storage pages.</p>
     *
     * @return		Architecture of the client host on which
	 * the application is currently running;
     * one of the 
	 * <a href="oo.html#ooDiskFormat"><b>disk-format architecture</b></a>
	 *  constants defined in the
     * <a href="oo.html"><tt>com.objy.db.app.oo</tt></a> interface.
	 *
	 * @see		#setObjectCreationDiskFormat
     */
    public int getClientHostArch()
        { return persistor().getClientHostArch() ; }

    /**
     * Gets the integer constant corresponding to the specified
     * string for a supported Objectivity/DB architecture.</p>
     *
     * @param 	 installation String name for a
	 * supported Objectivity/DB architecture. (The accepted string names
	 * are the same as the names of the corresponding constants.)
	 * (<b>Note:</b> For a current list of the
	 * recognized string names, you can run the tool <tt>ooconvertformat -help</tt>.)</p>
     *
     * @return		Integer constant corresponding to the specified
	 * string name; one of the 
	 * <a href="oo.html#ooDiskFormat"><b>disk-format architecture</b></a>
	 *  constants defined in the
     * <a href="oo.html"><tt>com.objy.db.app.oo</tt></a> interface.
	 *
	 * @see		#setObjectCreationDiskFormat
	 * @see		#stringFromDiskFormat
     */
    public int diskFormatFromString(String installation)
        { return persistor().diskFormatFromString(installation) ; }

    /**
     * Gets the string name corresponding to the specified integer constant
	 * for a supported Objectivity/DB architecture.</p>
     *
     * @param 	 format	One of the 
	 * <a href="oo.html#ooDiskFormat"><b>disk-format architecture</b></a>
	 *  constants defined in the
     * <a href="oo.html"><tt>com.objy.db.app.oo</tt></a> interface.

     *
     * @return  String name corresponding to the supported Objectivity/DB architecture.</p>
	 *
  	 * @see		#setObjectCreationDiskFormat
	 * @see		#diskFormatFromString
	 */
    public String stringFromDiskFormat(int format)
        { return persistor().stringFromDiskFormat(format) ; }

    /**
     * Gets the virtual-memory address size used by the disk format
	 * defined for the specified architecture.</p>
     *
     * @param 	 format Objectivity/DB architecture
	 * defining the disk format whose virtual-memory address size is to be returned;
     * one of the 
	 * <a href="oo.html#ooDiskFormat"><b>disk-format architecture</b></a>
	 *  constants defined in the
     * <a href="oo.html"><tt>com.objy.db.app.oo</tt></a> interface.
	 * 
     *
     * @return  32 if a 32-bit architecture or 64 if a 64-bit architecture.</p>
     */
    public int diskFormatAddressSize(int format)
        { return persistor().diskFormatAddressSize(format) ; }

    /**
     * Gets this connection's policy for logging attempted schema
     * modifications.</p>
     *
     * If this method returns true, all
     * attempts to modify the schema are logged to a file.</p>
     *
     * @return		True if attempted schema modifications are being logged;
     * otherwise, false.</p>
	 *
	 * @see	#setLogSchemaModifications
     */
    public boolean getLogSchemaModifications()
        { return persistor().getLogSchemaModifications() ; }

	/**
	 * Sets this connection's policy for logging attempted schema
	 * modifications.</p>
	 *
	 * <p>If you set this policy to true, an application's attempts to modify the schema
	 * are logged to a file called <tt>schemaMods</tt>.
	 * This file is created in the log directory, if any,
	 * that has been set up for use by a lock server or AMS
	 * on the client host running the application.
	 * An exception is thrown if no such directory has been set up on the client host.
	 * For information about setting up such a log directory,
	 * see <i>Objectivity/DB Administration</i>.
	 *
	 * <p>If you do not call this method, or you call it and set the policy to false,
	 * attempted schema modifications are not logged.</p>
	 *
	 *
	 *
	 * @param 	 log True to log attempted schema modifications;
	 * false to suppress this information.
	 */
	public void setLogSchemaModifications(boolean log)
        { persistor().setLogSchemaModifications(log) ; }

	/**
	 * Tests whether the memory-check policy has been set for this
	 * connection.</p>
	 *
	 * @return		True if an exception is thrown when used
	 * memory reaches 95% of available memory; false if it is not.</p>
	 *
	 * @see #setMemoryCheckPolicy
	 */
	public boolean isMemoryCheckPolicy()
	{ return persistor().isMemoryCheckPolicy() ; }

	/**
	 * Specifies whether to activate memory checking in this connection.</p>
	 *
	 * <p>
	 * If you activate memory checking for a connection,
	 * Objectivity for Java checks the application's total memory usage
	 * whenever certain operations occur in any of the connection's sessions.
	 * If the application's total memory usage (including non-persistence-related memory usage)
	 * exceeds 95% of the Java virtual machine's memory, an
	 * <a href="../ImpendingOutOfMemoryException.html"><tt>ImpendingOutOfMemoryException</tt></a>
	 * is thrown to signal that the application should reduce its overall memory usage
	 * before calling any more Objectivity for Java methods.
	 * Memory checking is performed each time a session commits or aborts a transaction,
	 * and each time an object is either made persistent or retrieved in a session.
	 * </p>
	 *
	 * <p>If you do not call this method, or if you call it with <tt><i>option</i></tt> set to false,
	 * unlimited memory usage will trigger an <tt>OutOfMemoryError</tt>,
	 * from which it may not be possible to recover.</p>
	 *
	 * @param 	 policy		True if an exception is
	 * to be thrown when memory usage exceeds 95% of the total virtual-machine memory;
	 * false if no such memory checking is to be performed.</p>
	 *
	 * @see #isMemoryCheckPolicy
	 */
	public void setMemoryCheckPolicy(boolean policy)
	{ persistor().setMemoryCheckPolicy(policy) ; }

	/**
	 * Tests whether database files are allowed to grow as sparse files or as nonsparse files.</p>
	 *
	 * @return		True  if database files are permitted to grow as sparse files; otherwise, false.</p>
	 *
	 * @see #setPermitSparseDbFiles
	 */
    public boolean isPermitSparseDbFiles()
	{ return persistor().isPermitSparseDbFiles() ; }

    /**
     * Specifies whether to allow database files to grow as sparse files or as nonsparse files.
     *
     * <p> This method affects how the application adds new storage pages
     * to a database file when extending a container in the database.
     *
     * The default value for this method is optimized for each supported Objectivity/DB
     * platform (most platforms default to <tt>false</tt>). To determine the current value for
     * your platform, use {@link #isPermitSparseDbFiles <tt>isPermitSparseDbFiles</tt>}.
     *
     * <ul type=disc>
     * <li>If <tt><i>sparse</i></tt> is set to <tt>true</tt>, database files grow as sparse
     * files. Sparse files can occupy less disk space than nonsparse files containing
     * the same application data, but are more likely to be fragmented on disk. If
     * your platform has the default value of <tt>true</tt> for sparse, you can consider
     * setting it to <tt>false</tt>, which might slow down the ingest of new data but
     * potentially increase lookup
     * speed.
     *
     * <li>If <tt><i>sparse</i></tt> is set to <tt>false</tt>, database files grow as
     * nonsparse files.  Nonsparse files are less likely than sparse files to be
     * fragmented on disk, and can therefore improve the runtime speed of operations
     * that find and access objects in the database. If your platform has a default
     * value of <tt>false</tt>, it is recommended that you retain this value.
     * </ul></p>
     *
     *<p>When a database file grows as a sparse file,
     * each newly added storage page is represented by file-system metadata
     * until it is used for storing new persistent objects.
     * A sparse database file with many unused pages therefore occupies less disk space
     * than it would if most or all of its pages contained persistent objects.
     * However, a sparse database file is likely to become fragmented
     * as applications write new persistent objects on unused storage pages over time,
     * especially when multiple transactions add objects to different containers
     * of the same database.
     *
     * <p>When a database file grows as a nonsparse file,
     * Objectivity/DB reserves space on disk for each newly added storage page.
     * This optimizes the file system's ability to allocate contiguous disk space
     * for newly added pages and reduces the likelihood that a database file will be fragmented.
     * Reducing file fragmentation, in turn, can significantly improve the runtime speed
     * of operations that access the database's persistent objects.
     *
     * <p>Calls to this method have no effect on container files, which are always grown
     * as nonsparse files.</p>
     *
     * <p><b>Note: </b> Prior to Release 10.0,  all database files were grown as sparse files.
     * You can eliminate any file-system metadata in a database file
     * by tidying it.
     * See <i>Objectivity/DB Administration</i> for information about tidying databases.</p>
     *
     *
     * @param 	 sparse	Specify <tt>true</tt> to
     * permit database files to grow as sparse files; specify <tt>false</tt> to grow them
     * as nonsparse files.
	 *
	 * @see #isPermitSparseDbFiles
     *
     */
    public void setPermitSparseDbFiles(boolean sparse)
	{ persistor().setPermitSparseDbFiles(sparse) ; }

    /**
     * Disables concurrent-access protection for the connected federated database.
     *
     * <p> If your application requires maximum performance
     * and is guaranteed exclusive access to the federated database,
     * you may consider disabling locking to remove the runtime overhead associated with managing locks.
     * For most applications, however, benefits such as data integrity and concurrent access
     * far outweigh the slight performance gain obtained by disabling locking.
     *
     * <p><b>Warning: </b> Do not disable locking
     * if your application uses different sessions in concurrent threads,
     * or if another process has concurrent access to the same data as your application.
     * Doing so may cause unpredictable results, including corruption of your data.
     *
     * <p> Use this method with caution.
     * If you use this method, you must call it before this connection object creates any sessions.
     *
     */
    public void noLock()
	{ persistor().noLock() ; }

    /**
     * Tests whether the system-managed creation of an I/O read-ahead thread has
     * been enabled.
     *
     * @return True if the I/0 read-ahead thread is enabled; otherwise, false.</p>
     *
     * @see #setPermitReadAhead
    */

    public boolean isPermitReadAhead()
	{ return persistor().isPermitReadAhead() ; }

    /**
     * Specifies whether to enable a system-managed I/O read-ahead thread that can improve
     * performance when using object iterators.</p>
     *
     * @param useReadAhead	True to enable a system-managed I/O read-ahead thread, and
     * false to disable it.</p>
     *
     * @see #isPermitReadAhead
    */

    public void setPermitReadAhead(boolean useReadAhead)
	{ persistor().setPermitReadAhead(useReadAhead) ; }

    /**
     * When working with multiple connections, this method joins the current
     * thread to a previously created connection to a federated database. Joining a
     * connection lets you create new sessions in that connection or even
     * change the connection's properties then create new sessions.<p>
     *
     * <b>Note:</b> Joining a new connection implicitly leaves the old one.<p>
     *
     *
     * @see #leave
     *
     * */
    public void join()
        { persistor().join() ; }


    /**
     * When working with multiple connections, this method explicitly
     * leaves this connection to a federated database. <p>
     *
     * <b>Note:</b> Joining a new connection implicitly leaves the old one.<p>
     *
     * @see #join
     *
     */
    public void leave()
        { persistor().leave() ; }

	/**
	 * Registers the specified shutdown listener with the application's Objectivity/DB shutdown hook.
	 * 
	 * <p>Registering a shutdown listener stores it in a vector maintained 
	 * by the Objectivity/DB shutdown hook.
	 * You can call this method multiple times to register multiple shutdown listeners.
	 * The order in which you register these shutdown listeners 
	 * is the order in which they are used during shutdown.
	 * 
     * <p><b>Note: </b>You should call this static method <i>before</i> your first
     * call to the {@link Connection#open <tt>Connection.open</tt>} static
     * method. </p>
	 */
    public static void addShutdownHook(ShutdownListener shutdownListener)
    {
        Access.addShutdownHook(shutdownListener);
    }
    
    public static ooId lockAny(ooId[] oidArray, int mode)
    {
        return Access.LockAny(oidArray, mode);	
    }
    
    
    
	/**
     * Reserved for internal use.
    */

    private synchronized PConnection persistor()
        { return persistor ; }

	/**
     * Reserved for internal use.
    */

    private synchronized void setPersistor(PConnection persistor)
        { this.persistor = persistor ; }
    

    /**
     * Specifies the persistence policy of this connection. By default, the persistence policy is set to <tt>oo.Reachability</tt>.
     * 
     * <p>A connection's persistence policy determines whether transient objects are to be made persistent 
     * when they are linked through relationships in this connection's sessions; see <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.</p>
     * 
     * <p>If you never call this method, or if you call it and set the value to <tt>oo.Reachability</tt>, all sessions in this connection use the <i>reachability policy</i>.
     * Under the reachability policy, a transient object in a relationship becomes persistent automatically only if it is <i>reachable</i> from a persistent object&#x2014;that is, 
     * if one or more links can be followed from a persistent source object to the transient destination object. 
     * Otherwise, the transient object remains transient, enabling you to create graphs of transient objects that you can optionally make persistent at a later time.
     * 
     * <p>More specifically, the following actions make a transient object <i>reachable</i> from a persistent object, 
     * and therefore cause the transient object to become persistent immediately: 
     * 
     * <ul type=disc>
	 * <li>
	 * Forming a unidirectional relationship from a persistent source object to the transient destination object.
     * <li>
     * Forming a bidirectional relationship between the transient object and a persistent object.
     * </ul></p>
     * 
     * <p>Furthermore, the following actions leave the transient objects <i>unreachable</i> from any persistent object, 
     * and therefore allow these objects to remain transient:
     * <ul type=disc>
	 * <li>
	 * Forming a unidirectional relationship from a transient source object to any destination object.
     * <li>
     * Forming either a unidirectional or a bidirectional relationship between two transient objects.
     * </ul></p>
     * 
     * <p>The reachability policy is equivalent to the pre-Release 11.0 nondefault <i>transient-relationships policy</i>, which was set by calling a session's
     * {@link Session#setFormTransientRelationships <tt>setFormTransientRelationships</tt>} method and passing the value <tt>true</tt>.
     * 
     * <p>The <tt>setFormTransientRelationships</tt> method and the methods related to it have been deprecated.
     * If you want to continue using any of the deprecated session methods, 
     * or if you need to preserve the pre-Release&nbsp;11.0 default policy in one or more sessions, 
     * you must call the connection's <tt>setPersistencePolicy</tt> with the value <tt>oo.PreRelease11Behavior</tt>.
     * 
     * <p><b>Note: </b> If you need to call the <tt>setPersistencePolicy</tt> method, you must do so before the application starts the first transaction;
     * otherwise, an exception is thrown. 
     * 
     * @param persistencePolicy  The persistence policy; one of the
     * <a href="oo.html#PersistencePolicy">persistence-policy constants</a> defined in the
     * <tt>com.objy.db.app.oo</tt> interface.
     */
	public void setPersistencePolicy(int persistencePolicy) {
		this.persistor.setPersistencePolicy(persistencePolicy);
	}
	

	/**
	 * Returns the persistence policy of this connection. 
	 * 
	 * @return   The persistence policy; one of the
     * <a href="oo.html#PersistencePolicy">persistence-policy constants</a> defined in the
     * <tt>com.objy.db.app.oo</tt> interface.
	 */
	public int getPersistencePolicy() {
		return this.persistor.getPersistencePolicy();
	}
	

	/**
	 * @return Returns true if this connection uses the <tt>oo.Reachability</tt> persistence policy; otherwise, false.
	 */
	public boolean isPersistOnReachability()
    {
    	return this.persistor.isPersistOnReachability();
    }
	
	/**
	 * Enables the use of the machine-wide configuration file to control certain aspects of the application's behavior.</p>
	 * 
	 * <p>
	 * This static method enables the application to load the configuration settings, if any, that are currently in the machine-wide configuration file 
	 * that is installed with Objectivity/DB.
	 * This file is empty at installation time, and is located in
	 * <tt><i>installDir</i>/config/Machine.config</tt>, where <tt><i>installDir</i></tt> is the Objectivity/DB installation directory. 
	 * No error is reported if this file is empty or cannot be found.</p>
	 * 
	 * 
	 * <p>A typical configuration file contains settings that specify the storage-location preferences 
	 * for data files created according to the federated database's placement model.</p>
	 * 
	 * <p>The machine-wide configuration file may be enabled by multiple applications running on the same computer.
	 * You can add or change settings in the configuration file at any time; 
	 * however, doing so does not affect any application that has already enabled the file (and loaded its settings).</p>
	 * 
	 */
	public static void enableConfiguration()
	{
	    Access.enableConfiguration();
	}
	
	/**
	 * Enables the use of configuration files to control certain aspects of the application's behavior.</p>
	 * 
	 * <p>This static method enables the application to load the configuration settings, if any, that are currently in the machine-wide configuration file,
	 * in an application-specific configuration file, or both. 
	 * If settings from both kinds of configuration file are loaded, the application-specific settings take precedence over the machine-wide settings.</p>
	 * 
	 * <p>A configuration file must have a <tt>.config</tt> filename extension, and must be a valid XML document describing Objectivity/DB configuration settings. 
     * A typical configuration file contains settings that specify the storage-location preferences 
	 * for data files created according to the federated database's placement model.</p>
     * 
     * <p>Enabling a configuration file loads the settings that are currently in it.
     * You can add or change settings in a configuration file at any time; 
     * however, doing so does not affect any application that has already enabled the file (and loaded its settings).
     *  
     *  
     *  @param	allowMachineConfig    	Specifies whether to enable the use of the machine-wide configuration file 
     *  <tt><i>installDir</i>/config/Machine.config</tt>, where <tt><i>installDir</i></tt> is the Objectivity/DB installation directory.
     *  <ul>
     *  <li>Specify true to load the configuration settings, if any, that are currently in the machine-wide configuration file. 
     *  No error is reported if this file is empty or cannot be found.
     *  <li>Specify false to ignore the machine-wide configuration file.
     *  </ul>
     *  
     *  @param applicationConfig Specifies the path (including the filename) of the application-specific configuration file to be enabled. 
     *  If you specify a filename without a path, the file must reside in the application's current directory 
     *  or in the <tt><i>installDir</i>/config</tt> directory, where <tt><i>installDir</i></tt> is the Objectivity/DB installation directory.  
     *  An exception is thrown if the specified file is not found or cannot be loaded.</p>
     * 
     */
	public static void enableConfiguration(boolean allowMachineConfig, 
	        String applicationConfig)
	{
	    Access.enableConfiguration(allowMachineConfig, applicationConfig);
	}
	
	/**
 	 * Enables the use of command-line options to specify configuration files to control certain aspects of the application's behavior.</p>
 	 * 
 	 * 
 	 * <p>This static method enables the application to load the configuration settings from one or more configuration files.
 	 * A configuration file must have a <tt>.config</tt> filename extension, and must be a valid XML document describing Objectivity/DB configuration settings.
     * A typical configuration file contains settings that specify the storage-location preferences 
	 * for data files created according to the federated database's placement model.</p>
 	 * 
 	 *  This static method enables the application to load any combination of machine-wide settings, application-specific settings, 
 	 *  and settings from configuration files that are specified to the application through command-line options of the form:</p>
 	 *  
 	 *  <p><tt>-loadconfiguration <i>configFileName</i>.config </tt>
 	 * 
 	 * <p> If any conflicts exist among corresponding settings from different configuration files, these conflicts are resolved as follows: 
 	 * <ul>
	 * <li>If machine-wide settings and application-specific settings are loaded,
	 * the application-specific settings take precedence over the machine-wide settings.</p>
	 * <li> If settings are loaded from configuration files specified through a <tt>-loadconfiguration</tt> option, 
	 * these settings take precedence over any application-wide or machine wide settings. 
	 * <li> If multiple <tt>-loadconfiguration</tt> options specify multiple configuration files, 
	 * the priority of these files is determined from left to right. 
	 * That is, the settings of the first configuration file to be specified take precedence over any corresponding settings in the subsequently specified files.
	 * </ul>
	 * 
     * 
     * <p>Enabling a configuration file loads the settings that are currently in it.
     * You can add or change settings in a configuration file at any time; 
     * however, doing so does not affect any application that has already enabled the file (and loaded its settings).
 	 * 
 	 * <p><b>Example: </b>
 	 * The following call enables configuration files to be specified through command-line options on the application:</p>
 	 * <ul><code>
 	 * public static void main(String args[]) { </br>
 	 * &nbsp;&nbsp;&nbsp;&nbsp;... </br>
 	 * &nbsp;&nbsp;&nbsp;&nbsp;Connection.enableConfiguration(false, null, args);</br>
 	 * &nbsp;&nbsp;&nbsp;&nbsp;...</br>
 	 * }
 	 * </code></ul></p>
 	 * <p> If the name of the application is <tt>myApp</tt>, 
 	 * you could run the application from a command line as follows, to specify two configuration files: 
 	 * </p>
 	 * 
	 * <ul><code>
 	 * myApp ... -loadconfiguration preferences1.config ... -loadconfiguration preferences2.config ... </br>
 	 * </code>
 	 * </ul></p>
 	 * 
 	 *  <p> In this example, "..." indicates any other arguments the application may recognize.</p>
 	 * 
 	 * 
    *  @param	allowMachineConfig    	Specifies whether to enable the use of the machine-wide configuration file 
     *  <tt><i>installDir</i>/config/Machine.config</tt>, where <tt><i>installDir</i></tt> is the Objectivity/DB installation directory.
     *  <ul>
     *  <li>Specify true to load the configuration settings, if any, that are currently in the machine-wide configuration file. 
     *  No error is reported if this file is empty or cannot be found.
     *  <li>Specify false to ignore the machine-wide configuration file.
     *  </ul>
     *  
     *  @param applicationConfig Specifies the path (including the filename) of the application-specific configuration file to be enabled. 
     *  If you specify a filename without a path, the file must reside in the application's current directory 
     *  or in the <tt><i>installDir</i>/config</tt> directory, where <tt><i>installDir</i></tt> is the Objectivity/DB installation directory.  
     *  An exception is thrown if the specified file cannot be found or loaded.</p>
     *  
     *  @param args  Command-line arguments of the application's main function. 
     *  This static method ignores any arguments other than <tt>-loadconfiguration</tt>.
     *  An exception is thrown if a configuration file specified through a <tt>-loadconfiguration</tt> option cannot be found or loaded. 
     *  
     */
	public static void enableConfiguration(boolean allowMachineConfig, 
            String applicationConfig, String [] args)
    {
        Access.enableConfiguration(allowMachineConfig, applicationConfig, args);
    }
}
