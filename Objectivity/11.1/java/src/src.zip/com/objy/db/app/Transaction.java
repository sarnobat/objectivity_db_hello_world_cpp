/*
 * @(#)Transaction.java
 * 
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

import com.objy.db.ObjyRuntimeException ;

import com.objy.db.iapp.PTransaction ;

import com.objy.pm.Access ;

/**
 * <p>Represents an ODMG transaction.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>An ODMG transaction object provides the
 * <A HREF="../../../../../guide/jgdODMGApplication.html#ODMG Transactions">transaction services</a>
 * for ODMG applications.
 *
 * <p><b>Note: </b>Your application should work with an instance of this class <i>only</i> if
 * it requires ODMG compliance; otherwise, it should work with a
 * <a href="Session.html">session</a> instead.
 * For additional information about ODMG applications, see
 * <A HREF="../../../../../guide/jgdODMGApplication.html">
 * Conforming to the ODMG Standard.</A>.
 *
 * <p>After you have obtained an ODMG
 * <a href="Database.html">database</a> object,
 * you can create an ODMG transaction and use it to interact with the connected
 * federated database.
 * Your application can create multiple ODMG transaction objects, each corresponding to a
 * particular subtask that your application performs.
 *
 * <p>An Objectivity for Java application can use multiple Java threads to
 * execute concurrent Objectivity/DB operations. However, Objectivity/DB operations
 * performed while a given ODMG transaction object is open are treated
 * serially by Objectivity/DB.  To
 * obtain truly concurrent operations, each of several concurrent threads
 * must have its own ODMG transaction object.
 *
 * <p>ODMG transactions are long-lived objects which can be used for many
 * <a href="#begin()"><tt>begin()</tt></a>, <a href="#commit()"><tt>commit()</tt></a>,
 * <a href="#abort()"><tt>abort()</tt></a> sequences.
 *
 * <p>A
 * <A HREF="../../../../../guide/jgdODMGApplication.html#Transactions and Threads">thread policy</a>
 * governs the interaction between threads and
 * ODMG transaction objects. Objectivity for Java provides two different thread
 * policies: unrestricted and restricted.
 * ODMG applications use the restricted thread policy.
 *
 * <h2>Associated Objects</h2>
 *
 * <p>When you create an ODMG transaction object, its
 * <a href="Session.html">session</a> is created automatically.
 * The session, in turn, creates a local representation of the connected
 * <a href="ooFDObj.html">federated database</a>, a
 * <a href="storage/ClusterStrategy.html">clustering strategy</a>, and an
 * <a href="../../ejb/XATransaction.html">
 * Objectivity/DB transaction resource manager</a>.  
 *
 * <p>The ODMG transaction, federated-database, and resource-manager objects 
 * <i>belong to</i> their associated session object; in
 * addition, the local representation of every persistent object and
 * storage object that you retrieve or create while a particular ODMG transaction
 * object is open belongs to that ODMG transaction's session.
 * Objectivity for Java does not allow a ODMG transaction object
 * to interact with any object that belongs to a different session; see
 * <A HREF="../../../../../guide/jgdSessions.html#Isolation">
 * Object Isolation</A>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr valign=top WIDTH="1%"><td><a name = "ooLockMode"><b>Lock modes</b> <i>(ODMG)</I><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Control how to lock a persistent
 * object.</td>
 * <td VALIGN="top">
 *     <a href="#READ">READ</a><br>
 *     <a href="#WRITE">WRITE</a><br>
 *     <a href="#NONE">NONE</a>
 *     </td>
 * </TABLE></p>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 *
 * <TR><td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 * 	<td><A HREF="#Transaction()">Transaction()</A> <i>(ODMG)</I>
 * </TD></TR>
 *
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Controlling&nbsp;Transactions</B></TD>
 *
 * <TD><A HREF="#begin()">begin()</A> <i>(ODMG)</I><BR>
 * <A HREF="#checkpoint()">checkpoint()</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#checkpoint(int)">checkpoint(int)</A><BR>
 * 	<A HREF="#commit()">commit()</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#abort()">abort()</A> <i>(ODMG)</I>
 * </TD></TR>
 *
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information</B></TD>
 *
 * <TD><A HREF="#getSession()">getSession()</A><br>
 * 	<A HREF="#current()">current()</A> <i>(ODMG)</I>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 *
 * <TD><A HREF="#isOpen()">isOpen()</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#isJoined()">isJoined()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Interactions With&nbsp;Threads</B></TD>
 *
 * <TD><A HREF="#join()">join()</A> <i>(ODMG)</I><BR>
 * 	<A HREF="#isJoined()">isJoined()</A><BR>
 * 	<A HREF="#leave()">leave()</A> <i>(ODMG)</I></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Locking&nbsp;Objects</B></TD>
 * <TD><A HREF="#lock(java.lang.Object, int)">lock(Object, int)</A> <i>(ODMG)</I>
 * </TD></TR>
 * <TR>
 *
 * <TD><B>Static&nbsp;Utilities</B></TD>
 * <TD><A HREF="#current()">current()</A> <i>(ODMG)</I></TD>
 * </TR>
 *
 * </TABLE>
 *
 */
final public class Transaction
{
    private transient PTransaction persistor ;
    
	/**
	 * <i>(ODMG)</I> Lock mode: The persistent object is locked for read.
	 */
    public static final int READ    = oo.READ ;

	/**
	 * <i>(ODMG)</I> Lock mode: The persistent object is locked for write.
	 */
    public static final int WRITE   = oo.WRITE ;

    /**
	 * <i>(ODMG)</I> Lock mode: The Objectivity/DB object is locked for 
     * exclusive write.
     */
    /*SPR 15900 -- support for exclusive update lock on database*/
    public static final int EXCLUSIVE_WRITE = oo.EXCLUSIVE_WRITE ;

	/**
	 * <i>(ODMG)</I> Not supported. Do not use this constant.
	 */
    public static final int UPGRADE = oo.UPGRADE ;

	/** Lock mode: The persistent object is not locked. */
    public static final int NONE    = oo.NONE ;     // Objy extension
    
	/**
	 * <i>(ODMG)</I> Constructs an ODMG transaction object and creates its
	 * associated session and federated-database object.
	 *
 	 * <p>The newly created ODMG transaction interacts with the connected federated
	 * database.
	 *
	 * <p><b>Note: </b>The constructor throws an
	 * <tt>ObjyRuntimeException</tt> if there is no open
	 * connection.
	 *
	 * <p>The constructor joins the current thread to the newly
	 * created ODMG transaction.
	 */
    public Transaction()
        { persistor = Access.new_TransactionPersistor(this) ; }
    
	/**
	 * Reserved for internal use.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public Transaction(PTransaction persistor)
        { this.persistor = persistor ; }

    /**
     * <i>(ODMG)</I> Gets the ODMG transaction joined with the currently active 
     * Java thread.</p>
     *
     * @return  The ODMG transaction object joined with the currently active Java thread,
	 * or null if the current thread is not joined to any ODMG transaction object.
     */
    public static Transaction current() {  // can answer null
        Session s = Access.session_getCurrent() ;
        return (s == null) ? null : s.getTransaction() ;
    }

    /**
     * <i>(ODMG)</I> Begins a transaction.
     *
     * <p>This ODMG transaction object must be closed when you call this method.
     * The thread that calls
	 * this method must be joined to this ODMG transaction object.
     *
     * <p>This method begins a transaction; when the method returns,
     * this ODMG transaction object is open.
     *
     * <p><b>Note:</b> You may not call this method if the Objectivity/DB 
     * transaction resource manager of this ODMG transaction's session
     * is in a global transaction.
     */
    public void begin() 
        { persistor().begin() ; }
        
    /**
     * <i>(ODMG)</I> Aborts the current transaction.
     *
     * <p>This ODMG transaction object must be open when you call this method.
     * The thread that calls
	 * this method must be joined to this ODMG transaction object.
     *
     * <p>This method aborts the transaction started by the most recent
	 * call to <a href="#begin()"><tt>begin</tt></a> and releases all locks
	 * held by this ODMG transaction object.  Any Objectivity/DB operations
     * executed since the last checkpoint are undone; if the 
     * <a href="#checkpoint()"><tt>checkpoint</tt></a> method was not 
     * called during the current transaction, 
     * this method undoes all Objectivity/DB operations executed since the 
     * beginning of the transaction.  The effects of any 
	 * "undone" operations do not appear in the connected federated
	 * database.
     *
     * <p>All the objects that belong to this ODMG transaction's session
	 * are marked as needing to have their data fetched, 
	 * and those objects are no longer marked as modified.
	 * Before you can access one of these objects in a subsequent ODMG transaction,
	 * you must call the object's <a href="ooObj.html#fetch()"><tt>fetch</tt></a> method
	 * to ensure that you have its most current persistent data. 
     *
     * <p>When the method returns, this ODMG transaction object is 
     * closed. 
     *
     */
    public void abort()
        { persistor().abort() ; }
        
    /**
     * <i>(ODMG)</I> Commits the current transaction.
     *
     * <p>This ODMG transaction object must be open when you call this method.
     * The thread that calls
	 * this method must be joined to this ODMG transaction object.
     *
     * <p>This method terminates the transaction started by the most recent
	 * call to <a href="#begin()"><tt>begin</tt></a> and releases all locks
	 * held by this ODMG transaction object.  All Objectivity/DB operations
	 * executed since the most recent call to
     * <tt>begin</tt> or <a href="#checkpoint()"><tt>checkpoint</tt></a> are
	 * reflected in the connected federated database.
     *
     * <p>The objects that belong to this ODMG transaction's session are no
	 * longer marked as modified.
	 * Because these objects are no longer locked,
	 * they are available for other applications to modify. 
	 * Before you access one of these objects in a subsequent transaction,
	 * you should call the object's <a href="ooObj.html#fetch()"><tt>fetch</tt></a> method
	 * to ensure that you have its most current persistent data. 
	 * 
     * <p>When the method returns, this ODMG transaction object will be closed.
     */
    public void commit() 
        { persistor().commit() ; }
        
	/**
     * <i>(ODMG)</I> Commits all Objectivity/DB operations executed since the last checkpoint,
     * retaining all locks acquired during the current transaction.
     *
     * <p>This ODMG transaction object must be open when you call this method.
     * The thread that calls
	 * this method must be joined to this ODMG transaction object.
     *
     * <p>All Objectivity/DB operations executed since the most recent call to
     * <a href="#begin()"><tt>begin</tt></a> or <tt>checkpoint</tt> are
	 * reflected in the connected federated database.
     * The objects that belong to this ODMG transaction's session
     * are no longer marked as modified.
     *
     * <p>When the method returns, this ODMG transaction object will still be
	 * open.</p>
     *
     * @see #commit
	 */
    public void checkpoint()
        { persistor().checkpoint() ; }

	/**
     * Commits all Objectivity/DB operations executed since the last checkpoint and
     * potentially downgrades all locks acquired during the current transaction.
     *
     * <p>This ODMG transaction object must be open when you call this method.
     * The thread that calls
	 * this method must be joined to this ODMG transaction object.
     *
     * <p>All Objectivity/DB operations executed since the most recent call to
     * <a href="#begin()"><tt>begin</tt></a> or <tt>checkpoint</tt> are
	 * reflected in the connected federated database.
     * The objects that belong to this ODMG transaction's session
     * are no longer marked as modified.
	 *
     * <p>When the method returns, this ODMG transaction object will still be
	 * open.</p>
     *
     * @param 	 downGradeMode   The lock downgrade mode;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>NO_DOWNGRADE</tt> <dd>Preserve all locks held by this
     * ODMG transaction object.</dd>
     * <dt> <tt>DOWNGRADE_ALL</tt> <dd>Downgrade all locks to read locks.</dd>
     * </dd></dl></dl></p>
     *
     * @see #commit
	 */
    public void checkpoint(int downGradeMode)   // Objy extension
        { persistor().checkpoint(downGradeMode) ; }

    /**
     * <i>(ODMG)</I> Tests whether this ODMG transaction is open.
	 *
     * <p>A ODMG transaction is open once
     * <a href="#begin()"><tt>begin</tt></a> is called and until
     * <a href="#commit()"><tt>commit</tt></a> or
     * <a href="#abort()"><tt>abort</tt></a> is called.</p>
	 *
     * @return	True if this ODMG transaction is open; otherwise, false.
	 */
    public boolean isOpen()
        { return persistor().isOpen() ; }
        
	/**
     * <i>(ODMG)</I> Joins the currently active Java thread with this ODMG transaction.
     *
     * <p>If the thread is already joined with this ODMG transaction,
     * then this method has no effect. If the thread was joined
     * with another ODMG transaction, it leaves that ODMG transaction and joins
     * this ODMG transaction.</p>
     *
     * @see #isJoined()
     * @see #leave()
	 */
    public void join() 
        { persistor().join() ; }
        
	/**
     * <i>(ODMG)</I> Causes the currently active Java thread to leave this ODMG transaction.
     *
     * <p>Threads should call this method before terminating.
     *
     * <p>This method will throw a <tt>NotJoinedException</tt> if the thread is
     * not joined with this ODMG transaction. You can call
     * <a href="#isJoined()"><tt>isJoined</tt></a> to test whether the
     * thread is joined with this ODMG transaction.</p>
     *
     * @see #join()
	 */
    public void leave() 
        { persistor().leave() ; }
        
	/**
     * Tests whether the currently active Java thread is joined with this
	 * ODMG transaction.</p>
	 *
	 * @return		True if the currently active thread is joined with this
	 * ODMG transaction; otherwise, false.
	 */
    public boolean isJoined() 
        { return persistor().isJoined() ; }

	/**
	 * <i>(ODMG)</I> Explicitly locks the specified object for the specified access and
	 * propagates the lock to related objects.
	 *
     * <p>This ODMG transaction object must be open when you call this method.
     * The thread that calls
	 * this method must be joined to this ODMG transaction object.</p>
     *
	 * @param 	 object	The object to be locked.  The
	 * object must be a persistent basic object or a persistent container, and
	 * it must belong to this ODMG transaction's session.  If
	 * <tt><i>object</i></tt> is a basic object, this method implicitly locks that object's
	 * container.  If <tt><i>object</i></tt> is a container, this method
	 * implicitly locks all basic objects in that container.
	 *
	 * <p>This method propagates the lock to any objects associated to
	 * the specified object through relationships for which lock
	 * propagation is enabled.</p>
	 *
	 * @param 	 mode	The type of lock to obtain for
	 * the specified object; one of the following constants defined in this class
	 * (and also in the <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
     * <p>The lock mode is limited by the open mode of the
     * ODMG database object</a>.
     * If you try to set the lock mode to <tt>WRITE</tt>
	 * when the open mode of the database object is <tt>openReadOnly</tt>,
	 * this method throws a runtime exception.
	 *
	 * <p>If <tt><i>object</i></tt> is already locked, you can call this method to upgrade a
	 * read lock to a write lock, but not to downgrade a write lock to a read lock.
	 */
    public void lock(Object object, int mode)
        { persistor().lock(object, mode) ; }
        
	/**
	 * Gets the session that owns this ODMG transaction.</p>
	 *
	 * @return		The session that owns this ODMG transaction.
	 */
    public Session getSession()
        { return persistor().getSession() ; }
    
	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized void setPersistor(PTransaction persistor)
        { this.persistor = persistor ; }
    
    private synchronized PTransaction persistor() { 
        if (persistor == null)
            throw new ObjyRuntimeException("Can not access this object.  It's session was previously terminated.") ;
        return persistor ; 
    }
}



