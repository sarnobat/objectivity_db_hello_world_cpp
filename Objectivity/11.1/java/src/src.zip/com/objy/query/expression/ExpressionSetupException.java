package com.objy.query.expression;

/**
 * Represents an expression setup exception.
 */

@SuppressWarnings("serial")
public class ExpressionSetupException extends ExpressionException
{
    private ExpressionSetupError mExpressionSetupError;
    
    /**
     * Constructs an expression setup exception with a message.
     * @param message
     */
    public ExpressionSetupException(String message) 
    {
        super(message);
    }
    
    /**
     * Constructs an expression setup exception with a message and an expression setup error.
     */
    public ExpressionSetupException(String message, ExpressionSetupError error) 
    {
        super(message);
        mExpressionSetupError = error; 
    }
    /**
     * Returns the expression setup error.
     * @return An instance of ooExpressionSetupError
     */
    public ExpressionSetupError getError()
    {
        return mExpressionSetupError;
    }
}
