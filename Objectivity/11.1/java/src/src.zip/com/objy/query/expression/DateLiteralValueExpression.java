package com.objy.query.expression;
/**
 * Represents a Date literal value node.
 *
 */
public class DateLiteralValueExpression extends  LiteralValueExpression 
{	
	/**
	 * Constructs a Date literal value node.
	 */
    public DateLiteralValueExpression() 
    {
        this(Binding.create());
    }
    
    /**
     * Constructs a Date literal node with a Date object.
     */
    public DateLiteralValueExpression(java.sql.Date value) 
    {
        this(value.toString());
    }
    
    /**
     * Constructs a Date literal node with an ID.
     * @param id
     */
	DateLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }
	
    /**
	 * Constructs a Date literal node with a Date string.
	 */
    private DateLiteralValueExpression(String date)
    {
    	int endOfYear = date.indexOf("-");
    	String year = date.substring(0, endOfYear);
    	int endOfMonth = date.indexOf("-", endOfYear+1);
    	String month = date.substring(endOfYear+1, endOfMonth);
    	String day = date.substring(endOfMonth+1);
    	setIdAfterNullCheck(Binding.create(Integer.parseInt(year), 
        	Integer.parseInt(month), Integer.parseInt(day)));
    }
    
	@Override
	/**
	 * Returns the type of the expression (oocDateLiteralValueExpression).
	 */
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.DateLiteralValueExpression; 
    }
	
	/**
	 * Sets the Date literal value.
	 */
    public void setValue(java.sql.Date value)
    {
        throwExceptionIfInvalidOrClosed(getId());
    	String date = value.toString();
    	int endOfYear = date.indexOf("-");
    	String year = date.substring(0, endOfYear);
    	int endOfMonth = date.indexOf("-", endOfYear+1);
    	String month = date.substring(endOfYear+1, endOfMonth);
    	String day = date.substring(endOfMonth+1);
        Binding.setValue(getId(), 
        	Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day));
    }
	
    @Override
    public String toString() 
    {
        return getPQLRepresentation();
    }
    
	@Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitDateLiteralValue(this);
    }
	
	static class Binding
	{
	    private static native long create();
	    private static native long create(int year, int month, int day);
	    private static native void setValue(long id, int year, int month, int day) ;
	    
	}
}
