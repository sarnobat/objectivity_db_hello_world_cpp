/*
 * @(#)ooTreeList.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.Collection;
import java.util.List;
import java.util.Iterator;
import java.util.ListIterator;
import com.objy.db.app.ooObj;
import com.objy.db.app.storage.ooContObj;
import com.objy.pm.ooTreeListPersistor;

/**
 * Persistence-capable class for lists of persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Lists</h2>
 *
 * <p>A <i>list</i> is a scalable ordered collection; unlike a set, a list
 * can contain duplicate elements and null elements.
 * An element of a list can be located by position, given as
 * a zero-based index.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Scalable Ordered Collections">
 * Scalable Ordered Collections</a>.
 *
 * <p>This class overrides the inherited <tt>add</tt> and <tt>addAll</tt>
 * methods to add
 * elements to the end of the list.  Methods defined in this class add
 * elements to the list, or insert elements into it, at an indicated
 * position.  The elements of a
 * list are kept in the order in which they were added or inserted.
 * Note, however, that an element's index may change as
 * elements are inserted in front of it in the list. For example, the element 
 * that was at 
 * index 2 will be at index 4 after two elements are added to the front of 
 * the list. 
 *
 * <p><h2>Working With a List</h2>
 *
 * <P>A list is transient when it is created; you can make it persistent
 * in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created an unordered set, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a List">
 * Building a List</a></p>
 *
 * <li>Look up particular elements in the list as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Lists">
 * Individual Lookup in Lists</a></p>
 *
 * <li>Iterate over the list as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Elements of a List or Set">
 * Finding the Elements of a List or Set</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make a list persistent before you call
 * any methods defined by the <tt>ooTreeList</tt>, <tt>ooBTree</tt>, or 
 * <tt>ooCollection</tt> 
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of persistent 
 * objects: 
 
 * <ul>
 * <li><a href="ooHashSet.html"><tt>ooHashSet</tt></a> represents
 * an <i>unordered</i> collection of persistent objects <i>with no duplicate 
 * elements</i>.</p>
 *
 * <li><a href="ooTreeSet.html"><tt>ooTreeSet</tt></a> represents
 * a <i>sorted</i> collection of persistent objects <i>with no duplicate 
 * elements</i>. 
 * </ul>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 		<td>
 *     	<a href="#ooTreeList()">ooTreeList()</a><br>
 *     	<a href="#ooTreeList(com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeList(ooContObj, ooContObj)</a><br>
 *     	<a href="#ooTreeList(int)">ooTreeList(int)</a><br>
 *     	<a href="#ooTreeList(int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeList(int, ooContObj, ooContObj)</a>
 * 		</td></tr>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Adding,&nbsp;Removing,&nbsp;and Changing&nbsp;Elements</b></td>
 * 	   	<td>
 *     	<a href="#add(int, java.lang.Object)">add(int, Object)</a><br>
 *     	<a href="#addFirst(java.lang.Object)">addFirst(Object)</a><br>
 *     	<a href="#addAll(java.util.Collection)">addAll(Collection)</a><br>
 *     	<a href="#addAll(int, java.util.Collection)">addAll(int, Collection)</a><br>
 *     	<a href="#remove(int)">remove(int)</a><br>
 *     	<a href="#remove(java.lang.Object)">remove(Object)</a><br>
 *     	<a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     	<a href="#removeAll(java.util.Collection)">removeAll(Collection)</a><br>
 *     	<a href="#removeRange(int, int)">removeRange(int, int)</a><br>
 *     	<a href="#retainAll(java.util.Collection)">retainAll(Collection)</a><br>
 *     	<a href="#set(int, java.lang.Object)">set(int, Object)</a>
 * 		</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 * 	   	<td>
 *     	<a href="#listIterator()">listIterator()</a><br>
 *     	<a href="#listIterator(int)">listIterator(int)</a><br>
 * 	   	<a href="#iterator()">iterator()</a>
 * 		</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	   <td>
 * 	   <a href="#containsAll(java.util.Collection)">containsAll(Collection)</a><br>
 * 	   </td></tr>
 * </table>
 */
final public class ooTreeList extends ooBTree implements List
{
 	/**
	 * Reserved for internal use.
	 */
    public transient int _maxUsedSizePerNode;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _adminContainer;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _arrayContainer;

	/**
	 * Constructs an empty list with
	 * the default 
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>. </p>
	 */
    public ooTreeList()
     {}

	/**
	 * Constructs an empty list with the default 
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a> and the
	 * specified containers for internal objects. </p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new list. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new list. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeList(ooContObj adminContainer, ooContObj arrayContainer)
    {
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty list with
	 * the specified node size. </p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new list's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.
	 */
    public ooTreeList(int maxNodeSize)
    {
        _maxUsedSizePerNode = maxNodeSize;
    }

	/**
	 * Constructs an empty list with the specified node size and
	 * containers for internal objects. </p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new list's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 *
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new list. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new list. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
     public ooTreeList(int maxNodeSize, ooContObj adminContainer, ooContObj arrayContainer)
    {
        _maxUsedSizePerNode = maxNodeSize;
        _adminContainer = adminContainer;
        _arrayContainer = arrayContainer;
    }

  	/**
	 * Initializes a scalable-collection iterator to find the elements of this
	 * list. </p>
	 *
	 * @return		A scalable-collection iterator for finding the elements of this
	 * list. The iterator finds the
	 * elements in their order in the list.
	 *
	 * <p>If you want to call any methods that are specific to Objectivity
	 * for Java scalable-collection iterators, you should cast the returned iterator
	 * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
	 */
    public ListIterator listIterator()
    {
        return getCollectionPersistor().iterator();
    }

	/**
	 * Initializes a scalable-collection iterator to find the elements of this
	 * list, starting at the specified index. </p>
	 *
	 * @param		<tt><i>index</i></tt>	The index of the first element to
	 * be found by the returned iterator.</p>
	 *
	 * @return		A scalable-collection iterator for finding the elements of this
	 * list, starting at <tt><i>index</i></tt>. The iterator finds the
	 * elements in their order in the list.
	 *
	 * <p>If you want to call any methods that are specific to Objectivity
	 * for Java scalable-collection iterators, you should cast the returned iterator
	 * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
	 */
    public ListIterator listIterator(int index)
    {
        ooCollectionIterator itr = (ooCollectionIterator) getCollectionPersistor().iterator();
        itr.goToIndex(index);
        return itr;
    }

	/**
	 * Inserts the specified object into this list at the specified index.
	 *
	 * <p>This method inserts the new element, increasing the size of the list by one and
	 * effectively incrementing the indexes of all subsequent elements.  For example, if
	 * <tt><i>index</i></tt> is 2, this method inserts the new element before the third
	 * existing element.  The new element now has index 2, and what used to be the third
	 * element is now the fourth element (and has index 3). </p>
	 *
	 * @param		<tt><i>index</i></tt>	The index where the new element
	 * is to be inserted.</p>
	 *
	 * @param		<tt><i>element</i></tt>	The object to be inserted at the specified index;
	 * must be an instance of a persistence-capable class.
	 * If <tt><i>element</i></tt> is transient, this method makes it
	 * persistent.</p>
	 *
	 * @see 		#addFirst(Object)
	 * @see 		#addAll(Collection)
	 * @see 		#set(int, Object)
	 * @see 		#remove(int)
	 */
   public void add(int index, Object element)
   {
       ((ooTreeListPersistor)getCollectionPersistor()).add(index, element);
   }

	/**
	 * Adds all elements in the specified collection to the end of this
	 * list. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection
	 * whose elements are to be added to this list. Every element of
	 * <tt><i>collection</i></tt> must be an instance of a
	 * persistence-capable class. If any element is transient, this
	 * method makes it persistent.  Note: <tt><i>collection</i></tt> must not
	 * be this list; that is, you cannot use this method to add another copy
	 * of this list's elements to this list.</p>
	 *
	 * @return		True if any elements were added; otherwise, false.
	 */
    public boolean addAll(Collection collection)
    {
        Iterator itr;
    	if (collection instanceof ooCollection)
    	    itr = (Iterator) ((ooCollection)collection).keyIterator();
    	else
    	    itr = collection.iterator();
        boolean mod = false;

        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

	/**
	 * Inserts all elements in the specified collection of objects into this list
	 * at the specified index.
	 *
	 * <p>This method inserts the new element, increasing the size of the list and
	 * effectively incrementing the indexes of all subsequent elements. </p>
	 *
	 * @param		<tt><i>index</i></tt>	The index where the first of the
	 * new elements is to be inserted.</p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements are to
	 * be added to this list.  Every element of
	 * <tt><i>collection</i></tt> must be an instance of a
	 * persistence-capable class. If any element is transient, this
	 * method makes it persistent. Note: <tt><i>collection</i></tt> must not
	 * be this list; that is, you cannot use this method to insert another copy
	 * of this list's elements into this list.</p>
	 *
	 * @return		True if any elements were added; otherwise, false.</p>
	 *
	 * @see 		#add(int, Object)
	 * @see 		#addFirst(Object)
	 */
   public boolean addAll(int index, Collection collection)
   {
        Iterator itr = (ooCollectionIterator) collection.iterator();
        int stop = collection.size() + index;
        int i;

        for (i = index; i < stop; i++)
            add(i, itr.next());
        return true;
   }

	/**
	 * Adds the specified object to the beginning of this list.
	 *
	 * <p>The new element becomes the first element of this list,
	 * effectively incrementing the indexes of all existing elements. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be added;
	 * must be an instance of a persistence-capable class.
	 * If <tt><i>object</i></tt> is transient, this method makes it
	 * persistent.</p>
	 *
	 * @see 		#add(int, Object)
	 * @see 		#addAll(Collection)
	 */
   public void addFirst(Object element)
   {
        add(0, element);
   }

	/**
	 * Tests whether this list contains all elements in the
	 * specified collection. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements 
     * are to be tested for containment in this list.
     * If <tt><i>collection</i></tt> is not a persistent collection, it 
     * should contain only persistent objects.  If it 
     * contains any transient object, this method returns false.</p>
	 *
	 * @return		True if this list contains elements equal to
	 * each element of <tt><i>collection</i></tt>; otherwise, false.
	 *
	 * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the 
     * <tt>equals</tt> method.  Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object identifiers.
     *
	 */
    public boolean containsAll(Collection collection) {
        if (collection instanceof ooCollection)
            return getCollectionPersistor().containsAll((ooCollection) collection);
        else
        {
            Iterator itr = collection.iterator();
    	    while (itr.hasNext())
    	        if (!contains(itr.next()))
    	            return false;
    	    return true;
        }
    }

	/**
	 * Initializes a scalable-collection iterator to find the elements of this
	 * list.
	 *
	 * <p>This method is equivalent to
	 * {@link #listIterator <tt>listIterator</tt>}. </p>
	 *
	 * @return		A scalable-collection iterator for finding the elements of this
	 * list. The returned iterator finds the
	 * elements in their order in the list.
	 *
	 * <p>If you want to call any methods that are specific to Objectivity
	 * for Java scalable-collection iterators, you should cast the returned iterator
	 * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
	 */
   public Iterator iterator()
    {
        return getCollectionPersistor().iterator();
    }

	/**
	 * Removes the first occurrence of the specified object from this list.
	 *
	 * <p>This method is equivalent to
	 * {@link #remove <tt>remove</tt>}. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be removed.</p>
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 */
   public boolean ooRemove(Object object)
   {
        return remove(object);
   }

	/**
	 * Removes from this list the first occurrence of each element of the 
     * specified collection. </p>
	 *
	 * <p>This method compares each persistent object in the specified 
     * collection with the elements of this list.  Any element of this list 
     * that is equal to an element of the specified collection is 
     * removed from this list.
     *
	 * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the <tt>equals</tt> method.  
     * Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object 
     * identifiers.</p>
     *
	 * @param		<tt><i>collection</i></tt>	The collection
	 * whose elements are to be removed from this list.
     * If <tt><i>collection</i></tt> is not a persistent collection, any 
     * transient objects it contains are ignored; only persistent objects 
     * are compared with elements of this list.</p>
	 *
	 * @return		True if any elements were removed; otherwise, false.</p>
	 *
	 * @see #remove(int)
	 * @see #remove(Object)
	 * @see #removeRange(int, int)
	 * @see #retainAll(Collection)
	 */
    public boolean removeAll(Collection collection)
    {
        return getCollectionPersistor().removeAll((ooCollection) collection);
    }

	/**
	 * Removes from this list all elements with indexes in the specified
	 * range. </p>
	 *
	 * @param		<tt><i>fromIndex</i></tt>	The index of the first
	 * element to be removed.</p>
	 *
	 * @param		<tt><i>toIndex</i></tt>	The index of the last element to
	 * be removed.</p>
	 *
	 * @see #remove(int)
	 * @see #remove(Object)
	 * @see #removeAll(Collection)
	 */
   public void removeRange(int fromIndex, int toIndex)
   {
        ooCollectionIterator itr = ooIterator();
        itr.goToIndex(fromIndex);
        for (int i = 0; i < toIndex - fromIndex; i++)
        {
            itr.remove();
            itr.next();
        }
   }

	/**
	 * Removes the element at the specified index from this list.
	 *
	 * <p>This method removes the specified element, reducing the size of the list
	 * and effectively reducing the indexes of all subsequent elements.  For example, if
	 * <tt><i>index</i></tt> is 2, this method removes the third
	 * element.  The new element that used to be the fourth element (with index 3)
	 * is now the third element (and has index 2). </p>
	 *
	 * @param		<tt><i>index</i></tt>	The zero-based index of the element
	 * to be removed.</p>
	 *
	 * @return		The object that was removed from this list.
	 */
   public Object remove(int index)
   {
       Object old = get(index);
       ((ooTreeListPersistor)getCollectionPersistor()).remove(index);
       return old;
   }

	/**
	 * Removes the first occurrence of the specified persistent object from 
     * this list. </p>
	 *
	 * <p>This method compares the specified object to the elements of this 
     * list; the first element that is equal to the specified object is 
     * removed from this list.
     *
	 * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the 
     * <tt>equals</tt> method.  Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object 
     * identifiers.</p>
     *
	 * @param		<tt><i>object</i></tt>	The persistent object to be 
     * removed from this list. Because 
     * all elements of the list are persistent objects, this method returns 
     * false if <tt><i>object</i></tt> is transient.</p>
	 *
	 * @return		True if an element was removed; otherwise, false. </p>
	 *
	 * @see #remove(int)
	 * @see #removeAll(Collection)
	 * @see #removeRange
	 * @see #retainAll(Collection)
	 */
    public boolean remove(Object object) {
        return getCollectionPersistor().remove(object);
    }

	/**
	 * Retains all elements of this list that are also in the
	 * specified collection, deleting all other elements. </p>
	 *
	 * <p>This method compares each element of this list with the persistent 
     * objects in the specified collection. Any element of  
     * this list that is equal to an element of the specified collection is 
     * retained in this list; other elements of this list are removed.
     *
	 * <p><b>Note:</b> Because the elements of this list are persistent 
     * objects, the test for equality compares the object 
     * identifiers; it does <i>not</i> call the 
     * <tt>equals</tt> method.  Thus, two different persistent 
     * objects with the same data may be considered equal by the 
     * <tt>equals</tt> method; however, they are considered different by 
     * Objectivity for Java because they have different object 
     * identifiers.</p>
     *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements
	 * are to be retained in this list.
     * If <tt><i>collection</i></tt> is not a persistent collection, any 
     * transient objects it contains are ignored; only persistent objects 
     * are compared with elements of this list.</p>
	 *
	 * @return		True if any elements were removed; otherwise, false.</p>
	 *
	 * @see #remove(int)
	 * @see #remove(Object)
	 * @see #removeAll(Collection)
	 */
    public boolean retainAll(Collection collection) {
        if (collection instanceof ooCollection && ((ooCollection) collection).comparator() == null)
            return getCollectionPersistor().retainAll((ooCollection) collection);
        else
        {
        	boolean changed = false;
	        Iterator itr = keyIterator();
        	while (itr.hasNext())
		        if (!collection.contains(itr.next()))
		{
			itr.remove();
			changed = true;
		}
	    return changed;
	    }
    }

	/**
	 * Replaces the element at the specified index with the specified object.
	 *
	 * <p>Replacing an element does not change the size of this list.</p>
	 *
	 * @param		<tt><i>index</i></tt>	The index of the element
	 * to be replaced.</p>
	 *
	 * @param		<tt><i>element</i></tt>	The object that is to replace
	 * the existing element at
	 * the specified index; must be an instance of a persistence-capable class.
	 * If <tt><i>element</i></tt> is transient, this method makes it
	 * persistent.</p>
	 *
	 * @return		The element previously at the specified index.</p>
	 *
	 * @see			#add(int, Object)
	 * @see 		#get
	 * @see 		#remove(int)
	 */
    public Object set(int index, Object element)
    {
       Object old = get(index);
       ((ooTreeListPersistor)getCollectionPersistor()).set(index, element);
       return old;
   }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
   public List subList(int fromIndex, int toIndex)
   {
       throw new UnsupportedOperationException(); // We may implement later, need new class
   }
 }
