package com.objy.query.expression;
/**
 * Represents a DateTime literal value node.
 *
 */
public class DateTimeLiteralValueExpression extends LiteralValueExpression
{	
	/**
	 * Constructor.
	 */
    public DateTimeLiteralValueExpression() 
    {
        this(Binding.create());
    }
    /**
     * Constructor taking an ID
     */
	DateTimeLiteralValueExpression(long id) 
    {
	    setIdAfterNullCheck(id);
    }
	
	/**
	 * Constructor taking a date/time value.
	 */
    public DateTimeLiteralValueExpression(java.sql.Timestamp value) 
    {
    	this(value.toString());
    }
    
    /**
	 * Constructor taking a date/time string.
	 */
    private DateTimeLiteralValueExpression(String datetime) 
    {
    	int endOfYear = datetime.indexOf("-");
    	String year = datetime.substring(0, endOfYear);
    	int endOfMonth = datetime.indexOf("-", endOfYear+1);
    	String month = datetime.substring(endOfYear+1, endOfMonth);
    	int endOfDay = datetime.indexOf(" ", endOfMonth+1);
    	String day = datetime.substring(endOfMonth+1, endOfDay);
    	
    	int endOfHours = datetime.indexOf(":", endOfDay+1);
    	String hours = datetime.substring(endOfDay+1, endOfHours);
    	int endOfMinutes = datetime.indexOf(":", endOfHours+1);
    	String minutes = datetime.substring(endOfHours+1, endOfMinutes);
    	int endOfSeconds = datetime.indexOf(".", endOfMinutes+1);
    	String seconds = datetime.substring(endOfMinutes+1, endOfSeconds);
    	
    	setIdAfterNullCheck(Binding.create(
        	Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day), 
        	Integer.parseInt(hours), Integer.parseInt(minutes), Integer.parseInt(seconds), 0));
    }
	
    /**
     * Sets the date/time literal value.
     */
    public void setValue(java.sql.Timestamp value)
    {
        throwExceptionIfInvalidOrClosed(getId());
        
    	String datetime = value.toString();
    	int endOfYear = datetime.indexOf("-");
    	String year = datetime.substring(0, endOfYear);
    	int endOfMonth = datetime.indexOf("-", endOfYear+1);
    	String month = datetime.substring(endOfYear+1, endOfMonth);
    	int endOfDay = datetime.indexOf(" ", endOfMonth+1);
    	String day = datetime.substring(endOfMonth+1);
    	
    	int endOfHours = datetime.indexOf(":", endOfDay+1);
    	String hours = datetime.substring(endOfDay+1, endOfHours);
    	int endOfMinutes = datetime.indexOf(":", endOfHours+1);
    	String minutes = datetime.substring(endOfHours+1, endOfMinutes);
    	String seconds = datetime.substring(endOfMinutes+1);
    	
        Binding.setValue(getId(), 
        	Integer.parseInt(year), Integer.parseInt(month), Integer.parseInt(day),
        	Integer.parseInt(hours), Integer.parseInt(minutes), Integer.parseInt(seconds), 0);
    }
    
    @Override
    public String toString() 
    {
        return getPQLRepresentation();
    }
    
    /**
     * Returns the type of the expression (oocDateTimeLiteralValueExpression).
     */
	@Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.DateTimeLiteralValueExpression; 
    }
	
	@Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitDateTimeLiteralValue(this);
    }
	
	static class Binding
	{
	    private static native long create();
	    private static native long create(int year, int month, int day, 
	            int hours, int minutes, int seconds, int millisecs);
	    private static native void setValue(long id, int year, int month, int day,
	            int hours, int minutes, int seconds, int millisecs) ;
	}
}
