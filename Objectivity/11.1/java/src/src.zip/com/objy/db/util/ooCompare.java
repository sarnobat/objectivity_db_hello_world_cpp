/*
 * @(#)ooCompare.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.Comparator;

import com.objy.db.ObjyRuntimeException;
import com.objy.db.app.ooObj;
import com.objy.db.iapp.Persistent;

/**
 * Abstract superclass for all comparator classes.</p>
 * 
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>Because this class is abstract, you never instantiate it; instead, you
 * work with instances of its concrete derived classes.
 *
 * <p><h2>About Comparators</h2>
 *
 * <p>A <i>comparator</i> is an object of a concrete descendant class of 
 * <tt>ooCompare</tt>. 
 * It provides:
 * <ul>
 * <li>A comparison method for ordering elements of scalable sorted 
 * collections.</p>
 * <li>A hashing method for computing the hash values for 
 * elements of scalable unordered collections. </p>
 * <li>Methods that support <i>comparison</i> arrays 
 * (a performance optimization that can be implemented for sorted collections). </p>
 * </ul>
 * 
 * Lists and name maps do not use comparators. </p>
 *
 * <p>When you create a set or object map, a comparator is assigned to the
 * the new collection.  You can specify a comparator in the constructor that 
 * created the collection. If you do not, the collection is assigned a 
 * default comparator.
 * <ul>
 * <li>The comparator of a <a href="ooTreeSetX.html">sorted set</a> or a
 * <a href="ooTreeMapX.html">sorted object map</a>
 * defines a total ordering to be used by the sorted collection's
 * underlying B-tree. The comparator's
 * <a href="#compare(java.lang.Object, java.lang.Object)">
 * <tt>compare</tt></a> method
 * is used to compare two persistent objects and indicate their relative position
 * in the total ordering. 
 * A sorted collection with a default comparator sorts
 * persistent objects by increasing object identifier. 
 * A comparator for a sorted collection can optionally support the use of comparison arrays 
 * to optimize the collection's performance.
 * The comparator�s {@link #comparisonArraySize <tt>comparisonArraySize</tt>} method 
 * sets the size of the comparison arrays to be used in the collection. 
 * The arrays are populated by the comparator�s 
 * <a href="#setComparisonArrayFromObject(java.lang.Object, int[])">
 * <tt>setComparisonArrayFromObject</tt></a> method.</p>
 *
 * <li>The comparator of an <a href="ooHashSetX.html">unordered set</a> or an
 * <a href="ooHashMapX.html">unordered object map</a>
 * is used by the unordered collection's
 * underlying extendible hash table
 * The comparator's <a href="#hash(java.lang.Object)"><tt>hash</tt></a>
 * method computes the hash value for a persistent object;
 * its <a href="#compare(java.lang.Object, java.lang.Object)">
 * <tt>compare</tt></a> method tests two
 * persistent objects for equality.  An unordered collection with a
 * default comparator
 * computes hash values for persistent objects from their object identifiers
 * and compares
 * objects for equality by comparing their object identifiers.
 * </ul>
 *
 * <p>The comparator for a set compares elements of the set an 
 * computes hash values from the elements;
 * the comparator for an object map compares the elements' keys and
 * computes hash values from keys.
 * 
 * <p>You can define your own subclasses of <tt>ooCompare</tt>.  A
 * custom comparator class can optionally provide the
 * ability to identify an element (or key) based on class-specific
 * data. For
 * details, see
 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
 * Defining a Custom Comparator Class</a>.
 *
 * <p><h2>Working With a Comparator</h2>
 *
 * <p>If your application uses a custom comparator class, you
 * can instantiate the class to create comparators for your
 * collections.  
 * A comparator is transient when it is created; you can make 
 * it persistent in any of the ways that you make any basic object
 * persistent. See
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a> and
 * <a href="../../../../../guide/jgdCollections.html#Using a Custom Comparator">
 * Using a Custom Comparator</a>.
 * You should arrange for the comparator to be placed with the collection to which it will be assigned.
 *
 * <p>Once you have assigned a comparator to a collection, the collection 
 * uses the comparator. You do not access a collection's comparator or 
 * call a comparator's methods explicitly.
 * 
 * 
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER=1 CELLPADDING=3 CELLSPACING=0 WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Comparing&nbsp;Objects</b></td>
 *     <td>
 *     <a href="#compare(java.lang.Object, java.lang.Object)">compare(Object, Object)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Computing&nbsp;Hash&nbsp;Values&nbsp;for Unordered&nbsp;Collections</b></td>
 *     <td>
 *     <a href="#hash(java.lang.Object)">hash(Object)</a><br>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Optimizing&nbsp;Sorted&nbsp;Collections</b></td>
 *     <td>
 *     <a href="#comparisonArraySize()">comparisonArraySize()</a><br>
 *     <a href="#setComparisonArrayFromObject(java.lang.Object, int[])">setComparisonArrayFromObject(Object, int[])</a><br>
 *     </td></tr>
 * </table>
 * 
 *
 */
abstract public class ooCompare extends ooObj implements Comparator
{
	/**
	 * Reserved for internal use.
	 */
	protected ooCompare() {}
    
    // signals error if number returned is > 250
	/**
	 * Sets the size of a comparison array in a sorted collection that uses this comparator.</p>
	 * 
	 * An application can define a 
	 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
 	 * custom comparator class</a>
	 * that supports the use of
	 * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">
	 * comparison arrays</a>
	 * as a performance optimization. Such a class must override
	 * this method to return a comparison-array size greater than 0. </p>
	 * 
	 * @return	Number of elements in each comparison array stored by the sorted collection.
	 * 
	 */
	public int comparisonArraySize () 
    { 
        return 0;
    }
    
    // fills in data for compareArray for a given lookupKey. 
    // ooCompare::setComparisonArray base class definition just signals 
    // an error if called. compareArray is not initialized by the caller.
	/**
	 * Populates a comparison array with data from the specified object.</p>
	 * 
	 * The default implementation of this method throws an exception if the
	 * {@link #comparisonArraySize <tt>comparisonArraySize</tt>} method returns a number greater than 0.</p>
	 * 
	 * An application can define a 
	 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
 	 * custom comparator class</a>
	 * that supports the use of
	 * <a href="../../../../../guide/jgdCollections.html#OptimizingCompArrays">
	 * comparison arrays</a>
	 * as a performance optimization for sorted collections. Such a class must override this method
	 * to return a comparison array containing a representation of the specified 
	 * comparison data.</p>
	 * 
	 * 
	 * @param 	 key	The object from which to obtain the data for the comparison array.</p>
	 * 
	 * <p>Typically, <tt><i>key</i></tt> is an element or key
	 * of a sorted collection that uses this comparator. 
	 * 
	 * If this comparator is an instance of a
	 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
 	 * custom comparator class</a>
	 * that can identify persistent objects based on their persistent data,
	 * <tt><i>key</i></tt> can instead be a transient object
	 * that contains the identifying data to be represented as an array. </p>
	 * 
	 * @param 	 compArray	Array to be populated.</p>
	 * 
	 */
	public void setComparisonArrayFromObject(Object key, int[] compArray)
    {
        { if (comparisonArraySize ()> 0) 
            throw new ObjyRuntimeException("Must override ooCompare::setComparisonArray when ooCompare::comparisonArraySize() is overriden"); }
    }

    /**
	 * Compares the two persistent objects.
	 *
	 * <p>The default implementation for this method compares the object identifiers of the
	 * two specified persistent objects. </p>
	 *
	 * @param 	 obj1	The first of the persistent objects to be
	 * compared.  This object is an element (or key) of a
	 * persistent collection that uses this comparator.</p>
	 *
	 * @param 	 obj2	The second of the objects to be
	 * compared.
	 *
	 * <p>Typically, <tt><i>obj2</i></tt> is the persistent object to be
	 * compared with <tt><i>obj1</i></tt>.  If this is an instance of a
	 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
 	 * custom comparator class</a>
	 * that can identify persistent objects based on
	 * their persistent data,
	 * <tt><i>obj2</i></tt> can instead be a transient object
	 * that identifies the persistent object to be compared with
	 * <tt><i>obj1</i></tt>.</p>
	 *
	 * @return		A negative integer if the first object is less than
	 * (sorts before) the second object; zero if the two objects are
	 * equal; a positive integer if the first object is
	 * greater than (sorts after) the second object.
	 */
    public int compare(Object obj1, Object obj2)
    {
        return ((Persistent) obj1).getPersistor().compareOoId(((Persistent) obj2).getPersistor());
    }

	/**
	 * Computes the hash value for a persistent object.
	 *
	 * <p>The default implementation for this method computes the hash
	 * value from the object identifier of the persistent object. </p>
	 *
	 * @param 	 object	The object from which to calculate
	 * the hash value.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is an element or key
	 * of a persistent collection that uses this comparator. If this
	 * comparator is an instance of a
	 * <a href="../../../../../guide/jgdCollections.html#Defining a Custom Comparator Class">
 	 * custom comparator class</a>
	 * that can identify persistent objects based on
	 * their persistent data,
	 * <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the persistent object whose hash value is to be
	 * computed.</p>
	 *
	 * @return		The hash value for the specified object.
	 */
    public int hash(Object object)
    {
	if (((Persistent) object).getPersistor() == null)
	    return 0;
	else
	    return ((Persistent) object).getPersistor().hashOoId();
    }
}
