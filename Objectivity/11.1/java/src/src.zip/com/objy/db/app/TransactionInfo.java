/*
 * @(#)TransactionInfo.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

/**
 * <p>Represents a transaction-information object, which contains information
 * about a transaction involved in a lock conflict.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>A lock request fails because of a <i>lock conflict</i>; namely, one or
 * more other clients already hold locks that are inconsistent with a
 * simultaneous lock of the kind that was requested. If you enable the
 * collection of lock-conflict information, then when a subsequent lock
 * conflict occurs,
 * the lock server creates transaction-information objects describing the
 * transactions that hold conflicting locks.
 *
 * <p>To enable the collection of lock-conflict information,
 * call the session's
 * <a href="./Session.html#setLockConflictInfo(boolean)">
 * <tt>setLockConflictInfo</tt></a> method.  After doing so, if a lock
 * conflict occurs, you can obtain the relevant transaction-information
 * objects by catching the <tt>LockNotGrantedException</tt> and calling its
 * <a href="../LockNotGrantedException.html#getTransactions()">
 * <tt>getTransactions</tt></a> method.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information About the
 * Transaction</B></TD>
 *
 * <TD><A HREF="#getTransactionID()">getTransactionID()</A><BR>
 *     <A HREF="#getOID()">getOID()</A><BR>
 *     <A HREF="#getLockMode()">getLockMode()</A><BR>
 *     <A HREF="#getProcessID()">getProcessID()</A><BR>
 *     <A HREF="#getUserID()">getUserID()</A><BR>
 *     <A HREF="#getHostName()">getHostName()</A><BR>
 * </TD></TR>
 *
 * </TABLE>
 *
 */

public class TransactionInfo
{
    private String hid;
    private int uid, pid;
    private long tid;
    private ooId oid;
    private int Mode;

    /**
	 * Reserved for internal use; you obtain an instance of this class
	 * by calling the
	 * <a href="../LockNotGrantedException.html#getTransactions()">
     * <tt>getTransactions</tt></a> method of the
	 * <tt>LockNotGrantedException</tt> that is thrown when a lock conflict
     * occurs.
	 *
	 * <p>You should not use this constructor directly.
     */
    public TransactionInfo() {}

    /**
     * Gets the transaction ID for the described transaction.
     *
     * <p>As soon as a session begins a transaction, it
     * accesses the federated database to specify whether it will conduct a
     * read transaction or an update transaction. At that time, the lock
     * server assigns a unique ID to the transaction.</p>
     *
	 * @return      The transaction ID of the transaction that this
     * transaction-information object describes.
     */
    public long getTransactionID()
        { return tid; }

    /**
     * Gets the object identifier of the object locked by the described
     * transaction.
     *
     * <p>The locked object is either a container or a special resource, so
     * the page number and the slot number of the returned object identifier
     * will always be 0.
     *
     * <p><b>Note:</b> The database and container components of the
     * returned object identifier could be different from the corresponding
     * components in the object identifier returned by the
     * <a href="../LockNotGrantedException.html#getOID()">
     * <tt>getOID</tt></a> method of the
	 * <tt>LockNotGrantedException</tt> from which this
     * transaction-information object was obtained. This situation indicates
     * that there was contention for some internal resource before the lock
     * server got to the requested container lock.</p>
     *
	 * @return      The object identifier of the container or special resource locked by
     * the transaction that this
     * transaction-information object describes.
     */
    public ooId getOID()
        { return oid; }

    /**
	 * Gets the internal lock mode indicating the kind of lock held by
	 * the described transaction.</p>
	 *
	 * @return      The internal lock mode that the described transaction
     * holds on the container or special resource; one of the following
     * constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>olmIS</tt><dd>Read intention lock.
     *
	 *  <dt><tt>olmIC</tt><dd>Write intention lock.
     *
	 *  <dt><tt>olmIX</tt><dd>Exclusive intention lock.
     *
	 *  <dt><tt>olmS</tt><dd>MROW read lock.
     *
	 *  <dt><tt>olmR</tt><dd>Non-MROW read lock lock.
     *
	 *  <dt><tt>olmC</tt><dd>Write lock.
     *
	 *  <dt><tt>olmX</tt><dd>Exclusive lock.
     *
	 *  <dt><tt>olmLastX</tt><dd>Exclusive lock; no more lock requests allowed.
	 * </dl></dl>
     */
    public int getLockMode() {
	    switch (Mode) {
	        case 0: return oo.olmNL;
	        case 1: return oo.olmIS;
	        case 2: return oo.olmIC;
	        case 3: return oo.olmS;
	        case 4: return oo.olmR;
	        case 5: return oo.olmC;
	        case 6: return oo.olmIX;
	        case 7: return oo.olmX;
	        case 8: return oo.olmLastX;
	        default: return Mode;
	    }
    }

    /**
     * Gets the process ID of the process in which the described transaction
     * is running.</p>
     *
	 * @return      The process ID of the transaction that this
     * transaction-information object describes.
     */
    public int getProcessID()
        { return pid; }

    /**
	 * Gets the UNIX or Macintosh user ID under which the process of the described
     * transaction is running.</p>
     *
	 * @return      The UNIX or Macintosh user ID, or 0 if the described transaction is
     * running on a Windows platform.
     */
    public int getUserID()
        { return uid; }

    /**
     * Gets the name of the host on which the described transaction
     * is running.</p>
     *
	 * @return      The host name of the transaction that this
     * transaction-information object describes.
     */
    public String getHostName()
        { return hid; }
}
