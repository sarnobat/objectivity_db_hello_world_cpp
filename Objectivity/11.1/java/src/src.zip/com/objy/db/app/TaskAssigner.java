/*
 * @(#)ooTaskAssigner.java
 *
 * Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app;

/**
 * Defines behavior shared by all task assigners.
 *  <p>
 *  <b>Note:</b> <i>For backward compatibility only. </i>A TaskAssigner
 * should be used only in an application that performs explicit 
 * placement. Do not use a TaskAssigner in an application that 
 * accesses a placement-managed federated database. 
 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
 * </p>
 * When you start a <a href="../../../../../guide/jgdPQE.html"> parallel query</A>  
 * to find persistent objects in a federated database or a database, 
 * the query manager of the parallel query uses a <i>task assigner</i> to assign each of the query
 * subtasks to the query server that is to perform it.
 * </p>
 * 
 * A standard parallel query uses default task assignment, which causes each database of interest (and the individual containers in it)
 * to be scanned by the query server running locally on the database's data-server host.</p>
 * 
 * A custom parallel query can redistribute the processing burden by using a custom task assigner 
 * to assign each query task to whichever query server best suits the processing resources.
 * For example, if most of the databases to be searched reside on the same host, you could use a custom task assigner to 
 * divide the work among query servers running on several different hosts.
 * </p>
 * 
 * A custom task assigner is an instance of an application-defined class that implements the <tt>TaskAssigner</tt> interface.
 * You invoke a custom query splitter for a connection by calling the 
 * connection's <a href="Connection.html#setTaskAssigner(com.objy.db.app.TaskAssigner)"><tt>setTaskAssigner</tt></a> method.
 * 
 */
public interface TaskAssigner {
    /**
	 * Selects the query server that is to perform the specified query task.</p>
     *
     * @param 	 oid The query task to be assigned, specified as the object identifier of a database or container.</p>
     *
     * @return The name of the host running the query server that is to scan the specified database or container.
     */
    String assignTask(ooId oid);
}
