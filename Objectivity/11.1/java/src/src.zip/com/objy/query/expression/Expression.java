package com.objy.query.expression;

import java.io.PrintStream;

import com.objy.pm.Configuration;

/**
 * Represents an expression node, which can be generated from 
 * a given predicate string.
 */
public class Expression extends Closable //implements AutoCloseable   JDK 7
{
    
    private static PrintStream ooInitErr = System.err;
    private static final String queryLibWindows = "oojquery" + com.objy.pm.Configuration.INTERFACE_VERSION;
    private static final String queryLibUnix = "oojquery" + "." + Configuration.RELEASE_MAJOR + "." + Configuration.RELEASE_MINOR;
    
    private ExpressionSetupErrorHandler mDefaultErrorHandler = null;
    
    static 
    {
        init();
    }
    
    static void init() 
    {
        String queryLib=null;
        if (!System.getProperty("os.name").startsWith("Win"))
        {
            queryLib=queryLibUnix;
        }
        else
        {
            queryLib=queryLibWindows;
        }
        try { 
            System.loadLibrary(queryLib) ;
        }
        catch(UnsatisfiedLinkError e1) {
            ooInitErr.println("UnsatisfiedLinkError loading library " + System.mapLibraryName(queryLib) + ". " + e1.getMessage()) ;
            System.exit(-1) ;
        }
        catch(SecurityException e2) {
            ooInitErr.println("Security exception loading library: " + System.mapLibraryName(queryLib) + ". " + e2.getMessage()) ;
            System.exit(-1) ;
        }
    }
    
    /**
     * Constructs an expression node.
     */
    public Expression(){}
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    Expression(long id)
    {
        setId(id);
    }
     
    /**
     * Generates the expression tree using the given predicate string, 
     * using the default error handler of the object qualifier. The default error handler 
     * throws an exception on the first error encountered. </p>
     * 
     * @return Expression
     */
    public static Expression generateExpressionTreeFromPQL(String predicate) 
        throws ExpressionSetupException
    {
        ExpressionSetupErrorHandler errorHandler = new ExpressionSetupErrorHandler();
    	long id = Binding.generateExpressionTreeFromPQL(predicate, errorHandler.getId());
    	if (errorHandler.getNumberOfErrors() > 0) 
        {
            ExpressionSetupError error = errorHandler.getFirstError();
            throw new ExpressionSetupException(error.getDescription(), error);
        }
        return getExpression(id);
    }
     
    /**
     * Returns the PQL string for the expression tree rooted from this expression node, 
     * using the default error handler of the object qualifier. The default error handler 
     * throws an exception on the first error encountered. </p> 
     * 
     * @return String The PQL string, or null if the setup of the expression is not completed. 
     */
    public String getPQLRepresentation() 
    {
        ExpressionSetupErrorHandler errorHandler = getDefaultErrorHandler();
    	String pqlRepresentation = Binding.getPQLRepresentation(getId(), errorHandler.getId());
    	if (errorHandler.getNumberOfErrors() > 0) 
        {
            ExpressionSetupError error = errorHandler.getFirstError();
            throw new ExpressionSetupException(error.getDescription(), error);
        }
    	return pqlRepresentation;
    }
    
    /**
     * Reserved for internal use; you should not call this method.
     */
    public static Expression getExpression(long id)
    {
        Expression ex = null;
        ExpressionType type = Expression.getType(id);
        switch (type)
        {
        case OperatorExpression:
            ex = new OperatorExpression(id);
            break;
        case AttributeValueExpression:
            ex = new AttributeValueExpression(id);
            break;
        case IntLiteralValueExpression:
            ex = new IntLiteralValueExpression(id);
            break;
        case UIntLiteralValueExpression:
            ex = new UIntLiteralValueExpression(id, true);
            break;
        case FloatLiteralValueExpression:
            ex = new FloatLiteralValueExpression(id);
            break;
        case BoolLiteralValueExpression:
            ex = new BoolLiteralValueExpression(id);
            break;
        case StringLiteralValueExpression:
            ex = new StringLiteralValueExpression(id);
            break;
        case DateLiteralValueExpression:
        	ex = new DateLiteralValueExpression(id);
            break;
        case TimeLiteralValueExpression:
        	ex = new TimeLiteralValueExpression(id);
            break;
        case DateTimeLiteralValueExpression:
        	ex = new DateTimeLiteralValueExpression(id);
            break;
        case IntervalLiteralValueExpression:
        	ex = new IntervalLiteralValueExpression(id);
            break;
        case OrderedListLiteralValueExpression:
        	ex = new OrderedListLiteralValueExpression(id);
            break;
        case ClassTypeLiteralValueExpression:
        	ex = new ClassTypeLiteralValueExpression(id);
            break;
        case OidLiteralValueExpression:
        	ex = new OidLiteralValueExpression(id);
            break;
        case ObjectLiteralValueExpression:
        	ex = new ObjectLiteralValueExpression(id);
            break;
        default:
            ex = new Expression(0);
            break;
        }
        return ex;
    }
    
    private static ExpressionType getType(long id) 
    {
    	if (id == 0)
    	{
    		return ExpressionType.InvalidExpression;
    	}
        return ExpressionType.values()[Binding.getExpressionType(id)];
    }

    /**
     * Gets the expression type.
     * @return ExpressionType
     */
    public ExpressionType getExpressionType() 
    {
        return getType(getId());
    }

    /**
     * Returns the specification of the result that this expression node produces.
     * @return ExpressionResultSpec
     */
    public ExpressionResultSpec getResultSpec() 
    {
        throwExceptionIfInvalidOrClosed(mId);
    	return ExpressionResultSpec.getExpressionResultSpec(Binding.getResultSpec(mId)); 
    }

    /** 
     * Causes specific derived expression node types to call the 
     * corresponding visit method on the passed-in visitor. 
     */
    public void accept(ExpressionVisitor visitor) 
    {
    }

    /**
     * Completes expression setup against a given context, using the specified error handler. 
     * With an error handler, no exceptions are thrown. The passed-in error handler
     * collects all the errors. If the passed-in handler is null, an exception is thrown 
     * on the first error. The setup happens after the expression tree 
     * is constructed and before it is used for evaluating objects. 
     */
    public synchronized void completeSetup(long typeNumber, ExpressionSetupErrorHandler errorHandler, 
            boolean isClassContextChanged) throws ExpressionException
    {
        throwExceptionIfInvalidOrClosed(mId);
	    boolean throwEx = false;
	    if (errorHandler == null)
	    {
	        errorHandler = new ExpressionSetupErrorHandler();
	        throwEx = true;
	    }
	    Binding.completeSetup(mId, typeNumber, 
			errorHandler.getId(), isClassContextChanged);
	    if (throwEx && errorHandler.getNumberOfErrors() > 0)
	    {
	        throw new ExpressionSetupException(errorHandler.getFirstError().getDescription(), 
	                errorHandler.getFirstError());
	    }
    }
    
    /** 
     * Returns true if setup has been completed for this expression node;
     * false otherwise.
     */
    public boolean setupCompleted() 
    {
        throwExceptionIfInvalidOrClosed(mId);
    	return Binding.setupCompleted(mId);
    }

    /** 
     * Returns the parent operator, or null if there is none.
     */
    public OperatorExpression getParentOperatorExpression() 
    {
        throwExceptionIfInvalidOrClosed(mId);
    	long id = Binding.getParentOperatorExpression(mId);
        if (id == 0)
            return null;
        return (OperatorExpression) Expression.getExpression(id);
    }


    /**
     * Returns true if the expression tree associated with this expression node 
     * is identical to the expression tree associated with the other specified expression node.
     */
    public boolean isEqualTo(Expression other)
    {
        if (mId != 0 && other != null && other.getId() != 0)
        {
            return Binding.isEqualTo(mId, other.getId());
        }
        else if (mId == 0 && other != null && other.getId() == 0)
        {
            return true;
        }
        return false;
    }
    
    /**
     * Returns the clone of this expression node.
     */
    public Expression clone()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return getExpression(Binding.clone(mId));
    }
    
    /**
     * Returns the default error handler of the expressions.
     */
    public synchronized ExpressionSetupErrorHandler getDefaultErrorHandler() 
    {
    	if (mDefaultErrorHandler == null)
    	{
    		mDefaultErrorHandler = new ExpressionSetupErrorHandler();
    	}
        return mDefaultErrorHandler;
    }

    @Override
    final synchronized void closeNative()
    {
        Binding.close(getId());
    }
    
    @Override
    protected void finalize()
    {
        close();
    }
    
    static class Binding
    {
        private static native long generateExpressionTreeFromPQL(String predicate, long errorHandleId) ;   
        private static native String getPQLRepresentation(long exprId, long errorHandlerId) ; 
        private static native int getExpressionType(long id) ;
        private static native long getResultSpec(long id);
        private static native void completeSetup(long expId, long shapeNumber, 
                long errorHandlerId, boolean isClassContextChanged);
        private static native boolean setupCompleted(long id);
        private static native long getParentOperatorExpression(long id);
        private static native boolean isEqualTo(long id, long otherId);
        private static native long clone(long id);
        private static native void close(long id);
    }
}
