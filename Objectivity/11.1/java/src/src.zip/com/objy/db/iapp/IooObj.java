/*
 * @(#)IooObj.java *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved. *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.iapp ;

import com.objy.db.app.Iterator ;
import com.objy.db.app.PlacementConditions;
import com.objy.db.app.ooId ;
import com.objy.db.app.ooObj;
import com.objy.db.app.ooReferenceData ;
import com.objy.db.app.Session ;
import com.objy.db.app.storage.ClusterStrategy;
import com.objy.db.app.storage.ooContObj;

/**
 * Defines the persistence behavior available to persistence-capable
 * classes.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>To define a persistence-capable class that supports all Objectivity/DB
 * operations without restrictions on its place in your application's
 * inheritance hierarchy,
 * you define a class that implements the <tt>IooObj</tt>
 * interface. Your class must define methods that provide
 * <a href="../../../../../guide/jgdDefiningClasses.html#Implementing Persistence Behavior">
 * persistence behavior</a>.</p>
 *
 * <p><b>Warning: </b>The <tt>IooObj</tt> interface defines the
 * persistence behavior that is available to persistence-capable
 * classes.  As such, it may change from release to release.  If you
 * define classes that implement <tt>IooObj</tt>, future releases of
 * Objectivity for Java might require you to make code changes. For
 * example, if a new method is added to the interface, you would need to
 * implement that method for your classes.
 *
 * <h2>Related Classes and Interfaces</h2>
 *
 * <p>Alternative ways to define a persistence-capable class are:
 * <ul type=disc>
 * <li>Define a descendant class of
 * <a href="../app/ooObj.html"><tt>ooObj</tt></a>.
 * The class inherits default implementations for public methods that get
 * and set an object's persistor, that perform Objectivity/DB operations
 * explicitly, and that handle persistent events. You do not need to
 * implement any persistentce behavior unless you want to modify the default
 * implementation.</P>
 *
 * <li>Implement the
 * <a href="PersistentEvents.html"><tt>PersistentEvents</tt></a>
 * interface, which has public methods to get and set the persistor and
 * to handle persistent events; you need to implement those methods. If you
 * desire, you can also implement public or private methods to perform
 * Objectivity/DB operations explicitly.</p>
 *
 * <li>Implement the
 * <a href="Persistent.html"><tt>Persistent</tt></a>
 * interface, which
 * has public methods to get and set the persistor; you
 * need to implement those methods. If you desire, you can also implement
 * public or private methods to perform Objectivity/DB operations
 * explicitly.</p>
 * </ul>
 *
 * <p>For additional information, see
 * <a href="../../../../../guide/jgdDefiningClasses.html#_top_">
 * Defining Persistence-Capable Classes</a>.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr><td VALIGN="top" WIDTH="1%"><B>Locking</b></td><td>
 * 	<a href="#lock(int)">lock(int)</a><br>
 * 	<a href="#lockNoProp(int)">lockNoProp(int)</a><br>
 *  <a href="#refreshOpenContainer(int)">refreshOpenContainer(int)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Fetching&nbsp;Persistent&nbsp;Data</b></td><td>
 * 	<a href="#fetch()">fetch()</a><br>
 * 	<a href="#fetch(java.lang.String)">fetch(String)</a><br>
 * 	<a href="#fetch(java.lang.String, boolean)">fetch(String, boolean)</a><br>
 * 	<a href="#fetch(int)">fetch(int)</a><br>
 * 	<a href="#fetch(java.lang.String, int)">fetch(String, int)</a><br>
 * 	<a href="#fetch(java.lang.String, int, boolean)">fetch(String, int, boolean)</a><br>
 * 	<a href="#markModified()">markModified()</a><br>
 * 	<a href="#clearModified()">clearModified()</a><br>
 * 	<a href="#markFetchRequired()">markFetchRequired()</a><br>
 * 	<a href="#isFetchRequired()">isFetchRequired()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Modifying</b></td><td>
 * 	<a href="#markModified()">markModified()</a><br>
 * 	<a href="#delete()">delete()</A><br>
 * 	<a href="#deleteNoProp()">deleteNoProp()</A><br>
 * 	<a href="#clearModified()">clearModified()</a><br>
 * 	<a href="#write()">write()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td><td>
 * 	<a href="#getSession()">getSession()</a><br>
 * 	<a href="#getOid()">getOid()</A><br>
 * 	<a href="#getOid(boolean)">getOid(boolean)</A><br>
 * 	<a href="#getReferenceOids()">getReferenceOids()</A><br>
 *  <a href="#getReferenceData()">getReferenceData()</A>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td><td>
 * 	<a href="#isPersistent()">isPersistent()</a><br>
 * 	<a href="#isModified()">isModified()</a><br>
 * 	<a href="#isFetchRequired()">isFetchRequired()</a><br>
 * 	<a href="#isValid()">isValid()</a><br>
 *  <a href="#isContainerUpdated()">isContainerUpdated()</a><br>
 * 	<a href="#isDead()">isDead()</a>
 * 	</td></tr>
  * <tr><td VALIGN="top" WIDTH="1%"><B>Making Persistent</b></td><td>
 * 	<a href="#persist()">persist()</a><br>
 * 	<a href="#persist(com.objy.db.app.PlacementConditions)">persist(PlacementConditions)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With Scope-Named&nbsp;Objects</b></td><td>
 * 	<a href="#nameObj(java.lang.Object, java.lang.String)">nameObj(Object, String)</a><br>
 * 	<a href="#unnameObj(java.lang.Object)">unnameObj(Object)</a><br>
 * 	<a href="#lookupObj(java.lang.String)">lookupObj(String)</a><br>
 * 	<a href="#lookupObj(java.lang.String, int)">lookupObj(String, int)</a><br>
 * 	<a href="#lookupObjName(java.lang.Object)">lookupObjName(Object)</a><br>
 * 	<a href="#scopedObjects()">scopedObjects()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Scope&nbsp;Objects</b></td><td>
 * 	<a href="#scopedBy()">scopedBy()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Working&nbsp;With&nbsp;Indexes</b></td><td>
 * 	<a href="#updateIndexes()">updateIndexes()</a>
 * 	</td></tr>
 * 
 * <tr><td VALIGN="top" WIDTH="1%"><b>Managing&nbsp;Default&nbsp;Association&nbsp;Arrays</b></td><td>
 * 	<a href="#size()">size()</a><br>
 * 	<a href="#trimToSize()">trimToSize()</a><br>
 * 	<a href="#ensureCapacity(int)">ensureCapacity(int)</a>
 * 	</td></tr>
 * 
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Internal Persistent&nbsp;Objects</B></TD>
 * <TD>
 *   	<A HREF="#deleteReference(java.lang.Object)">deleteReference(Object)</A><BR>
 *   	<A HREF="#dropCachedReference(java.lang.Object)">dropCachedReference(Object)</A><BR>
 * 	<a href="#getReferenceOids()">getReferenceOids()</A>
 * </TD></TR>
  * <tr><td VALIGN="top" WIDTH="1%"><b>Backward Compatibility</b></td><td>
 * 	<a href="#getContainer()">getContainer()</a><br>
 * 	<a href="#move(java.lang.Object)">move(Object)</A><br>
 *  <a href="#copy(java.lang.Object)">copy(Object)</a><br>
 *  <a href="#cluster(java.lang.Object)">cluster(Object)</a><br>
 * 	<a href="#cluster(java.lang.Object, com.objy.db.app.storage.ClusterStrategy)">cluster(Object, ClusterStrategy)</a>
 * 	</td></tr>
 * </table>
 */
public interface IooObj
       extends   PersistentEvents
{
    //
    // Accessing
    //

	/**
	 * Gets the session in which this object was made persistent or
	 * retrieved.</p>
	 *
	 * @return	The session to which this object belongs, or null
	 * if this object is transient.
	 */
    Session getSession() ;

	/**
	 * Finds the container in which this object is stored.</p>
	 * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * @return	The container in which this object is stored.
     */
    ooContObj getContainer() ;

	/**
	 * Gets the object identifier of this object.</p>
	 *
	 * @return		The object identifier of this persistent object.
     */
    ooId getOid() ;

	/**
	 * Gets the object identifier of this object, optionally looking up the type
	 * number for the object's class.</p>
	 * 
	 * <p>The <tt><i>getTypeNumber</i></tt> parameter controls whether this method
	 * gets just this object's location in the federated database or both its
	 * location and the type number of its class.
	 * 
	 * <p><ul type=disc>
	 * <li>Pass true as the parameter to get
	 * a complete object identifier, which specifies both the object's
	 * location and the type number of its class.
	 * (This is equivalent to the default <a href="#getOid()">
	 * <tt>getOid</tt></a> method.) The session must
	 * obtain a read lock on this object to look up the type number. </p>
	 * 
	 * <li>Pass false as the parameter to avoid locking this object.
	 * In that case, this method does not look up the type number.
	 * It returns a partial object identifier, which specifies the object's
	 * location, but not the type number of its class.
	 * </ul></p>
	 *
	 * @param 	 getTypeNumber	True to get both this object's
     * location and the type number of its class; false to get just its
     * location.</p>
     *
	 * @return		The object identifier of this persistent object.</p>
	 */
    ooId getOid(boolean getTypeNumber) ;

    //
    // Testing
    //

	/**
	 * Tests whether this object is
     * <a href="../../../../../guide/jgdPersistence.html#Dead Persistent Objects">
	 * dead</a>.</p>
	 *
	 * @return	    True if this object is dead; otherwise, false.
	 */
    boolean isDead() ;

	/**
	 * Tests whether this object's persistent data needs to be fetched.
	 * 
     * <p>You can call this method if you want to explicitly test 
	 * whether this object contains its most recent persistent data. 
	 * In most situations, however, it is more efficient 
	 * to simply call the <a href="#fetch()"><tt>fetch</tt></a> method,
	 * which implicitly tests this object's persistent data
	 * and then transfers the current persistent data as necessary.</p>
	 * 
	 * <p>The <tt>isFetchRequired</tt> method checks whether any updates 
	 * have occurred in this object's container 
	 * since the last transaction in which this object's data was fetched. 
	 * If so, this method returns true, and a subsequent fetch operation 
	 * will actually transfer the object's data.
	 * If no objects in the container have been modified since the 
	 * last time this object's data was fetched, this method will
	 * return false.</p>
	 *
	 * <p>This method should be called only while the session owning this object is in a transaction;
	 * otherwise, this method returns true, regardless of the actual state of the object.</p>
	 *
	 * @return		True if this object's persistent data must be fetched; false
	 * if this object already contains its most recent persistent data.
	 * True is the only return value while the session is not in a transaction. 
	 */
    boolean isFetchRequired() ;

	/**
	 * Tests whether this object has been marked as modified.
	 *
	 * <p>A persistent object that is marked as modified will be written to the
	 * federated database when the transaction is committed.</p>
	 *
	 * <p>This method should be called only while the session owning this object is in a transaction;
	 * otherwise, this method returns false, regardless of the actual state of the object.</p>
	 *
	 * @return	    True if this object is persistent and marked as modified;
	 * otherwise, false.
	 * False is the only return value while the session is not in a transaction. </p>
	 *
	 * @see     #markModified
	 */
    boolean isModified() ;

	/**
	 * Tests whether this object is persistent.</p>
	 *
	 * @return	    True if this object is persistent and false if it is
	 * transient.
	 */
    boolean isPersistent() ;

	/**
	 * Tests whether this object represents a valid persistent object.
	 *
	 * <p>An object is a valid persistent object if it is
	 * neither dead nor transient. When you retrieve a persistent object,
	 * the retrieved object is
	 * guaranteed to reference a valid persistent object.  However, if some
	 * other session then deletes or moves the object from the federated
	 * database, the retrieved object becomes invalid.
	 *
	 * <p><b>Implementation note:</b> If, for some reason, the session
	 * cannot access this object for read, this method should return
	 * false.</p>
	 *
	 * @return		True if this object represents a valid persistent object;
	 * otherwise, false.
	 */
    boolean isValid() ;

    //
    // Persistence
    //

	/**
	 * Marks this object as needing to have its persistent data <a href="#fetch()">fetched</a>.
	 *
     * <p>Applications typically do not need to call this method explicitly.
     *
	 * <p>If you modify an object and then want to force
	 * its definition to be reread from the federated database (overwriting your
 	 * modifications), you should first call
	 * the <a href="#clearModified()"><tt>clearModified</tt></a> method, then call
	 * this method.</p>
     *
	 * @see #clearModified
	 */
    void markFetchRequired() ;

	/**
	 * Locks this object for write, fetches its persistent data if it is not
	 * already fetched, and marks it as modified.
	 *
	 * <p>You must call this method whenever you make
     * changes to this object's attributes; typically, you call this
	 * method from every access method that sets the value of an
	 * attribute of your class that implements
	 * <tt>IooObj</tt>.  Only objects that are marked as modified
	 * are written to the federated database when the transaction is committed.
	 *
 	 * <p> The modified mark is removed at the end of
     * the current transaction or by an explicit call to the
     * <a href="#write()"><tt>write</tt></a> method.
	 *
	 * <p><b>Implementation notes:</b>
	 * <p><ul type=disc>
	 * <li>If this object is not currently locked for write,
	 * this method should lock it for write.  The
	 * write lock should not be propagated along assocation links to
     * destination objects.</p>
	 *
	 * <li>If, and only if, this object does not contain its most recent persistent data,
	 * this method should fetch that data.</p>
	 *
	 * <li>This method should do nothing if this object is transient.
	 * </ul></p>
     *
	 * @see     #isModified
	 */
    void markModified() ;



    /**
     * Removes the modified mark from this object.
     *
     * <p>The modified mark indicates that this object needs to be written to
     * the federated database.  You can call this method if you want to prevent your
	 * changes to this object from being written to the federated database.
	 *
	 * <p>If you want to prevent a newly persistent object from being written to the
	 * federated database, you should either abort the transaction, or call the object's
	 * <a href="#delete()"><tt>delete</tt></a> method.
     */
    void clearModified() ;

	/**
	 * Locks this object for read and fetches its persistent data.
	 *
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
     * attributes and relationships.
	 *
	 * <p>If this object is not currently locked,
	 * this method locks it for read
	 * before fetching its data.
	 * This method fetches all the persistent data and marks this object as
     * not needing to have its data fetched.
	 * 
	 * <p>If this object has reference attributes, this method also locks every destination for read,
	 * but does not fetch the data of these objects. The read lock is not
	 * propagated to related objects.
	 *
	 * <p><b>Implementation note:</b> This method should do nothing in
	 * either of the following circumstances:
	 * <ul type=disc>
	 * <li>This object is transient.
	 *
	 * <li>This object is already locked and its persistent data
	 * is current.
	 * </ul></p>
	 *
	 */
    void fetch() ;

	/**
	 * Locks this object for read and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the named reference attributes.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked,
	 * this method locks it for read
	 * before fetching its data; the read lock is not
	 * propagated to related objects.
	 * This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p><b>Implementation note:</b> This method should do nothing in
	 * either of the following circumstances:
	 * <ul type=disc>
	 * <li>This object is transient.
	 * 
	 * <li>This object is already locked and its persistent data
	 * is current.
	 * </ul></p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names. Any reference attributes named in the string are
     * fetched; other reference attributes are not fetched.
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
	 */
    void fetch(String references) ;

	/**
	 * Locks this object for read and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the reference attributes
	 * specified by name or regular expression.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked,
	 * this method locks it for read
	 * before fetching its data; the read lock is not
	 * propagated to related objects. This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p><b>Implementation note:</b> This method should do nothing in
	 * either of the following circumstances:
	 * <ul type=disc>
	 * <li>This object is transient.
	 * 
	 * <li>This object is already locked and its persistent data
	 * is current.
	 * </ul></p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names or regular expressions (as indicated by the
     * <tt><i>regexp</i></tt> parameter). Any reference attributes named in
     * the string (or whose names match a regular expression in the string)
     * are fetched; other reference attributes are not fetched. 
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
	 *
	 * @param 	 regexp  True if the
     * <tt><i>references</i></tt> string may contain regular expressions;
     * false if it must contain attribute names.
	 */
    void fetch(String references, boolean regexp) ;

	/**
	 * Fetches this object's persistent data after obtaining the specified lock.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching this object's data; the lock is not
	 * propagated to related destination objects.
	 * This method fetches all the persistent data and marks this object as
	 * not needing to have its data fetched.
	 * 
	 * <p><b>Implementation note:</b> This method should do nothing in
	 * either of the following circumstances:
	 * <ul type=disc>
	 * <li>This object is transient.
	 * 
	 * <li>This object is already locked and its persistent data
	 * is current.
	 * </ul></p>
	 *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl>
	 *
	 */
    void fetch(int mode) ;

	/**
	 * Obtains the specified lock on this object and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the named reference attributes.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching this object's data; the lock is not
	 * propagated to related destination objects. This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p><b>Implementation note:</b> This method should do nothing in
	 * either of the following circumstances:
	 * <ul type=disc>
	 * <li>This object is transient.
	 * 
	 * <li>This object is already locked and its persistent data
	 * is current.
	 * </ul></p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names. Any reference attributes named in the string are
     * fetched; other reference attributes are not fetched.  
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
     *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 */
    void fetch(String references, int mode) ;

	/**
	 * Obtains the specified lock on this object and performs a
	 * <a href="../../../../../guide/jgdPersistence.html#PartialFetch">
	 * partial fetch</a> that includes the reference attributes
	 * specified by name or regular expression.
	 * 
	 * <p>When an object is first brought into memory,
	 * its persistent fields are left empty.  You must fetch
	 * the object's persistent data before you can safely access its
	 * attributes and relationships.
	 * 
	 * <p>If this object is not currently locked as specified,
	 * this method obtains the specified lock
	 * before fetching this object's data; the lock is not
	 * propagated to related destination objects. This method fetches:</p>
	 * <ul type=disc>
	 * <li>All relationship fields, array attributes, and
	 * attributes of primitive types, string classes, and date and time
	 * classes.</p>
	 * 
	 * <li>Those reference attributes that are specified by the
	 * <tt><i>references</i></tt> parameter.
	 * </ul>
	 * 
	 * <p><b>Note:</b> After this method is executed, this object is still
	 * marked as needing to have its data fetched.
	 * 
	 * <p><b>Implementation note:</b> This method should do nothing in
	 * either of the following circumstances:
	 * <ul type=disc>
	 * <li>This object is transient.
	 * 
	 * <li>This object is already locked and its persistent data
	 * is current.
	 * </ul></p>
	 *
	 * @param 	 references  Colon-separated list of
     * attribute names or regular expressions (as indicated by the
     * <tt><i>regexp</i></tt> parameter). Any reference attributes named in
     * the string (or whose names match a regular expression in the string)
     * are fetched; other reference attributes are not fetched.  
     * If you specify null, no reference attributes are fetched. 
     * If you specify an empty string, all reference attributes are fetched.</p>
     *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @param 	 regexp  True if the
     * <tt><i>references</i></tt> string may contain regular expressions;
     * false if it must contain attribute names.
	 */
    void fetch(String references, int mode, boolean regexp) ;

	/**
	 * Transfers this object's data to the session's Objectivity/DB cache.
	 *
	 * <p>This method writes the object's data to its session's
     * Objectivity/DB cache.  Each session has its own Objectivity/DB cache,
     * so the written data will not be visible to
     * other sessions or processes. The changes will be transferred to the
     * federated database when you commit or checkpoint the current
	 * transaction.  If the transaction is aborted, the changes are never
	 * transferred to the federated database.
	 *
	 * <p>You typically do not call this method.  Instead, you call the
	 * session's
	 * <a href="../app/Session.html#checkpoint()"><tt>checkpoint</tt></a>
	 * method, which writes all changes to the federated database.  The
	 * <tt>checkpoint</tt> method makes changes accessible to <i>all</i>
	 * other clients, not just to other transactions of your process.
	 *
	 * <p><b>Implementation note:</b> This method should remove any
	 * modified mark from this object.</p>
	 */
    void write() ;

    //
    // Locking
    //

	/**
     * Explicitly locks this object and propagates the
     * lock to related destination objects.
     * 
     * <p>This method locks this object for the specified access and
     * propagates the lock
     * to any destination objects linked to
     * this object through relationships for which lock
     * propagation is enabled.
     * 
     * <p>Locking a basic object implicitly locks the object's container. Locking
     * a container implicitly  locks all basic objects in the container.
     * 
     * <p><b>Implementation note:</b> This method should limit the
     * acceptable lock modes according to the open mode of this object's
     * session</a>.
     * It should not set the lock mode to <tt>WRITE</tt>
     * when the session's open mode is <tt>openReadOnly</tt>.</p>
     *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @see      #lockNoProp
	 */
    void lock(int mode) ;

	/**
	 * Explicitly locks this object for the specified access.
	 * 
	 * <p>Unlike the <a href="#lock(int)"><tt>lock</tt></a>
	 * method, this method does not propagate the lock to related destination objects.
	 * 
	 * <p>Locking a basic object implicitly locks the object's container. Locking
	 * a container implicitly  locks all basic objects in the container.
	 * 
	 * <p><b>Implementation note:</b> This method should limit the
	 * acceptable lock modes according to the open mode of this object's
	 * session</a>.
	 * It should not set the lock mode to <tt>WRITE</tt>
	 * when the session's open mode is <tt>openReadOnly</tt>.</p>
	 *
	 * @param 	 mode	The type of lock to obtain for this object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 */
    void lockNoProp(int mode) ;

    //
    // Deleting
    //

	/**
	 * Deletes this object from the federated database and propagates the deletion
	 * operation to related destination objects.
	 *
	 * <p>This method propagates the deletion operation to any destination objects
	 * linked to this object through relationships for which deletion
	 * propagation is enabled.
	 *
	 * <p>Until the current transaction is committed, this object
	 * continues to
     * exist in your application's memory, but it is marked dead.
     *
     * <p>Each deleted object is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
     * write a persistent object that references a dead object.</p>
     *
     * @see     #deleteNoProp
     * @see     #isDead
	 */
    void delete() ;

	/**
	 * Deletes this object from the federated database.
	 *
	 * <p>Until the current transaction is committed, this object continues to
     * exist in your application's memory, but it is marked dead.
     *
     * <p>The deleted object is removed from any
	 * bidirectional relationships in which it is involved.
	 * However, if another persistent object references the
	 * deleted object in a unidirectional relationship or
	 * directly in one of its reference attributes, you are responsible
	 * for removing that reference. An exception is thrown if you attempt to
     * write a persistent object that references a dead object.</p>
	 *
 	 * <p>Unlike the <a href="#delete()"><tt>delete</tt></a>
	 * method, this method does not propagate the deletion operation
	 * to related destination objects.</p>
	 *
     * @see     #isDead
     * @see     #delete
	 */
    void deleteNoProp() ;

    //
    // Clustering
    //

	/**
     * Makes the specified object persistent, clustering it with this
     * object, subject to the session's clustering strategy.</p>
     *
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.
	 * The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The session's
	 * clustering strategy determines where to locate the object relative
	 * to this object. See
     * <a href="../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
	 *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this object's database, adding it to that database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
	 * @see     <a 
     * href="../app/storage/ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>ooDBObj.addContainer(ooContObj, int, String, long, long)</tt></a>
	 */
    void cluster(Object object) ;

	/**
	 * Makes the specified object persistent, clustering it with this
	 * object, subject to the specified clustering strategy.</p>
	 * 
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * @param 	 object	The transient object to be made
	 * persistent.
	 * The object to be clustered must be an instance of a
	 * persistence-capable class.
     * <dl><dd><dl>
	 * <dt>If <tt><i>object</i></tt> is a basic object:<dd>The specified
	 * clustering strategy determines where to locate the object relative
	 * to this object. See
     * <a href="../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
     * Controlling the Placement of Basic Objects</a>.
     *
	 * <dt>If <tt><i>object</i></tt> is a container:<dd> This method assigns
	 * it a location in this object's database, adding it to that database
	 * as a container with no system name, 5 initial pages, and a growth factor of 10%. </dd>
	 * </dd></dl></dl></p>
	 *
     * @param 	 strategy    Clustering strategy to determine 
     * the location of a basic object.
     * This parameter is ignored if
     * <tt><i>object</i></tt> is a container.</p>
     *
	 * @see     <a 
     * href="../app/storage/ooDBObj.html#addContainer(com.objy.db.app.storage.ooContObj, int, java.lang.String, long, long)">
	 * <tt>ooDBObj.addContainer(ooContObj, int, String, long, long)</tt></a>
	 */
    void cluster(Object object, ClusterStrategy strategy) ;

    /**
     * Makes this object persistent, and places it according to the federated database's placement model.
     * 
     * 
     * <p>
     * <i>Limitation:</i> You may not call this overload on an instance of any of the following persistence-capable system classes:
     * <a href="../util/ooMap.html"><tt>ooMap</tt></a>, <a href="../util/ooHashSetX.html"><tt>ooHashSetX</tt></a>, <a href="../util/ooHashMapX.html"><tt>ooHashMapX</tt></a>,
     * <a href="../util/ooTreeSetX.html"><tt>ooTreeSetX</tt></a>, <a href="../util/ooTreeMapX.html"><tt>ooTreeMapX</tt></a>, <a href="../util/ooTreeListX.html"><tt>ooTreelistX</tt></a>.
     * You must call <a href="#persist(com.objy.db.app.PlacementConditions)"><tt>persist(PlacementConditions)</tt></a> instead. 
     * 
     */
    void persist();   
    
    /**
     * Makes this object persistent, and places it according to the federated database's placement model.
     *
      *
     * @param placementConditions Additional information that the placement model can be configured to use.
     * 
      * <p>
     * <i>Restriction: </i>If the object being persisted is an instance of a persistence-capable system class
     * (<a href="../util/ooMap.html"><tt>ooMap</tt></a>, <a href="../util/ooHashSetX.html"><tt>ooHashSetX</tt></a>, <a href="../util/ooHashMapX.html"><tt>ooHashMapX</tt></a>,
     * <a href="../util/ooTreeSetX.html"><tt>ooTreeSetX</tt></a>, <a href="../util/ooTreeMapX.html"><tt>ooTreeMapX</tt></a>, <a href="../util/ooTreeListX.html"><tt>ooTreelistX</tt></a>),
     * the specified placement-conditions object <i>must</i> be configured to provide an existing persistent object as a placement guide;
     * a purpose indicator may also be provided, but it will be ignored. 
     * This is necessary to satisfy the special internal placement rule that applies to objects of these system classes.
     * The existing persistent object may be of any persistence-capable class, and is normally the intended owner of the collection.
     * An exception is thrown if you specify a placement-conditions object that is empty or that provides only a purpose indicator.</p>
     *  
     * @see PlacementConditions
     */
    void persist(PlacementConditions placementConditions);
  
    //
    // Copying
    //

	/**
     * <a href="../../../../../guide/jgdPersistence.html#Copying a Basic Object">
     * Copies</a> this basic object, clustering
     * the new object with the specified object.</p>
     * 
 	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>You should call this method for persistent objects only.
     * 
     * <p><b>Implementation note:</b> If this
     * object is not locked, this method should lock its container for
     * read-only access. </p>
     *
	 * @param 	 near The object with which to cluster the
	 * new copy.  The <tt><i>near</i></tt> object must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>near</i></tt> is a database:<dd>The new copy is stored in
	 * the default container of that database.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent container:<dd>The new copy is
	 * stored in that container.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent basic object:<dd>The new copy is
	 * stored in the same container as <tt><i>near</i></tt>.
	 * The object is put on the same logical page as <tt><i>near</i></tt>, if the page has enough space. 
	 * Otherwise, the object is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl></p>
	 * </p>
	 *
	 * @return		A new object with the same attribute values as this object.
	 * The returned object is persistent. If the transaction is aborted, the new
     * object becomes a dead object and is not stored persistently.
	 */
    Object copy(Object near) ;

    //
    // Moving
    //

    /**
     * Moves this basic object, clustering it with the specified object.</p>
     * 
 	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 * 
     * <p>You should call this method for persistent basic objects only.</p>
     * 
	 * 
     * <p><b>Warning: </b>This method changes the object identifier of this object.
     * When you move an object you should, within the same transaction, update references to the object within all relevant
     * relationships, collections (including root-name maps), scope names, and
     * indexes. In the case of a reference within a name map or root name,
     * corruption the federated database could result if the reference is not updated. See
     * <a href="../../../../../guide/jgdPersistence.html#Moving a Basic Object">
     * Moving a Basic Object</a> for additional information.
     * 
     * <p><b>Implementation note:</b> If this
     * object is not locked, this method should lock both its current
     * container and
     * its destination container for read/write access.</p>
     *
	 * @param 	 near The object with which to cluster this
	 * object; must be a database, a
	 * persistent container, or a persistent basic object.
     * <dl><dd><dl>
	 * <dt>If <tt><i>near</i></tt> is a database:<dd>This object is moved to
	 * the default container of that database.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent container:<dd>This object is
	 * moved to that container.
	 * The object is put on an existing logical page, 
	 * if there is one with enough space, or else on a new logical page added to that container.</dd>
	 * 
	 * <dt>If <tt><i>near</i></tt> is a persistent basic object:<dd>This object is
	 * moved to the container in which <tt><i>near</i></tt> is stored.
	 * The object is put on the same logical page as <tt><i>near</i></tt>, if the page has enough space. 
	 * Otherwise, the object is put on another existing logical page in the same container, 
	 * or, if necessary, on a new logical page added to that container.</dd>
	 * </dd></dl></dl>
	 */
	 void move(Object near) ;

    //
    // Scope Names/Objects
    //

	/**
     * Names the specified scope object in the scope of this object.
     * 
     * <p>If the specified object is transient, this method makes it persistent.
     * If the specified object is already persistent, this method locks its
     * container for write.
     * 
     * <p>This method obtains a write lock on the name map in which this
     * object stores its scope names.</p>
     *
	 * @param 	 object	The object to be named.</p>
	 *
	 * @param 	 scopeName	The name for the specified
	 * object in the scope of this object.
     * This name can be any valid Java string and must be unique
	 * within this object's name scope.  </p>
     *
     * @see     #lookupObj(String)
     * @see     #unnameObj(Object)
	 */
    void nameObj(Object object, String scopeName) ;

	/**
	 * Removes the specified object's name from this object's
	 * name scope.
	 * 
	 * <p><b>Implementation note:</b> This method should lock both this
	 * object and <tt><i>object</i></tt> for write access.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * removed.</p>
     *
     * @see     #lookupObj(String)
     * @see     #nameObj(Object, String)
	 */
    void unnameObj(Object object) ;

	/**
	 * Finds the object with the specified scope name in the scope defined
	 * by this object.</p>
	 *
	 * @param 	 scopeName	The scope name to look up.</p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this object.</p>
     *
	 * @see     #lookupObjName(Object)
	 * @see     #nameObj(Object, String)
	 */
    Object lookupObj(String scopeName) ;

	/**
	 * Finds the object with the specified scope name in the scope defined
	 * by this object, locking the
	 * found object as specified.</p>
	 *
	 * @param 	 scopeName	The scope name to look up.</p>
	 *
	 * @param 	 lockMode	The type of lock to obtain for the object;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>READ</tt><dd>Obtain a read lock.
     *
	 *  <dt><tt>WRITE</tt><dd>Obtain a write lock.
	 * </dl></dl></p>
	 *
	 * @return		The object with the specified scope name in the scope of
     * this object; the returned object
	 * is locked as specified by <tt><i>lockMode</i></tt>.</p>
     *
	 * @see     #lookupObjName(Object)
	 * @see     #nameObj(Object, String)
	 */
    Object lookupObj(String scopeName, int lockMode) ;

	/**
	 * Looks up the name of the specified object in the scope defined
	 * by this persistent object.</p>
	 *
	 * @param 	 object	The object whose name is to be
	 * looked up.</p>
     *
	 * @return		The scope name of the specified object in this object's
	 * name scope.</p>
	 *
	 * @see     #lookupObj(String)
	 */
    String lookupObjName(Object object) ;

	/**
	 * Initializes an object iterator to find all objects named in the
	 * name scope of this object.</p>
	 *
	 * @return		An object iterator that finds the named objects.
	 */
    Iterator scopedObjects() ;  // Objects that I provide a scope for

	/**
	 * Initializes an object iterator to find all scope objects that define
	 * scope names for this object.</p>
	 *
	 * @return		An object iterator that finds the scope objects.
	 */
    Iterator scopedBy() ;       // Objects that provide a scope for me

	/**
	 * Removes this persistent object's reference to the specified internal
	 * persistent object and deletes that object.</p>
	 * 
	 * <p>
	 * <b>Note:</b> You should delete an internal persistent object
	 * <i>only</i>
	 * if you also plan to delete the persistent object that referenced it.
	 * </p>
	 *
	 * @param 	 object	The
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> to be deleted. This object must 
     * reference <tt><i>object</i></tt> and <tt><i>object</i></tt> 
	 * must be an array, a string element of an
	 * array, or a date or time type that is stored in the
	 * federated database as an internal persistent object
	 * (<tt>java.util.Date</tt>, <tt>java.sql.Date</tt>, or
     * <tt>java.sql.Time</tt>,
	 * <tt>java.sql.Timestamp</tt>).
	 */
    void deleteReference(Object object) ;

	/**
	 * Drops the specified internal persistent object from the
	 * internal session cache.</p>
	 * 
	 * <p>The object to be released is an
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent object</a> that is referenced by some persistent
	 * object.
	 * 
	 * <p><b>Note: </b> You should call this method only if the memory
	 * consumed by Objectivity for Java prevents your application from
	 * running to completion. In that situation, you
	 * should call this method only when the persistent object
	 * that references <tt><i>object</i></tt> has
	 * itself been released and is waiting to be garbage collected.</p>
	 *
	 * @param 	 object	The
	 * internal persistent object to be deleted; must be an instance of
	 * <tt>java.util.Date</tt>, <tt>java.sql.Date</tt>,
     * <tt>java.sql.Time</tt>, or <tt>java.sql.Timestamp</tt>.
	 *
	 */
    void dropCachedReference(Object object) ;

    //
    // Indexes
    //

	/**
	 * Updates the indexes that include this object.
	 *
	 * <p>If a session's index mode is <tt>EXPLICIT_UPDATE</tt>,
     * indexes are not updated automatically to reflect changes to indexed
     * attributes.
     * You must call this method after creating an object and initializing
     * its indexed attributes, and after modifying the indexed attributes of an
     * existing object.</p>
	 */
    void updateIndexes() ;

	/**
	 * Resizes the default association array for this object to be
	 * able to hold the indicated number of relationships.
	 *
	 */
    void ensureCapacity(int minCapacity) ;

	/**
	 * Returns the number of relationships for this object currently
	 * in the default association array.
	 *
	 * @return	The size of the default association array for this object.</p>
	 */
    int size() ;

	/**
	 * Resizes the default association array for this object to the
	 * defined number of relationships.
	 */
    void trimToSize() ;

    /**
     * Gets the object identifiers of 
     * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
     * internal persistent objects</a> referenced by this object.</p>
     *
     * @return		An array of object identifiers of
     * internal persistent objects referenced by this object.</p>
     */
    ooId[] getReferenceOids() ;

	/**
	 * Gets the information used to create a garbage-collectible reference object for
	 * this object.</p>
	 *
	 * This method must be implemented in a persistence-capable class that defines
	 * one or more garbage-collectible reference fields,
	 * where each such field holds a weak or soft reference to some other persistent object.</p>
	 * 
	 * 
	 * Your definition of this method 
	 * must create and return a <a href="../app/ooReferenceData.html">reference-data object</a>
	 * appropriate for each of the garbage-collectible reference fields in the class.
	 * When the data of a persistent object of the class 
	 * is  fetched, the fetch operation checks each of the object's 
	 * garbage-collectible reference fields to determine whether the field 
	 * currently holds a reference object. 
	 * If it does not (for example, because its referent has been garbage collected), 
	 * the fetch operation calls this method
	 * to obtain the reference data needed for
	 * constructing an appropriate garbage-collectible reference object for the field.</p>
	 * 
	 * Although you can define this method to return different reference data
	 * for different fields, you normally use either all soft references or all weak references
	 * within the same persistent object.
	 * Furthermore, if a reference queue is to be used, all reference objects 
	 * in the same persistent object normally use the same one.</p>
	 *
	 * @return	The information used to create a garbage-collectible reference object
	 * for this object.</p>
	 */
    ooReferenceData getReferenceData() ;
    
    /**
     * Reopens this object's container, refreshing the session's view of 
     * the container in the MROW transaction reading it. 
     * 
     * <p>You should call this method only during an MROW session and
     * only if you locked this object's container for read, and another session
     * subsequently updated some object in the container.  You can
     * call the <a href="#isContainerUpdated()"><tt>isContainerUpdated</tt></a> method to
     * check whether another session has made updates in this container since you
     * locked it.
     *
     * <p>Note that this method does not automatically refetch any existing
     * fetched object in the container.</p>
     *
     * <p> This method throws an exception if the container being refreshed
     * no longer exists. </p>
     * 
     * @param mode The intended level of access to the reopened container;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>READ</tt><dd>Obtain a read lock on the container.
     *
     *  <dt><tt>WRITE</tt><dd>Obtain a write lock on the container.
     * </dl></dl></p>
     */
    void refreshOpenContainer(int mode);
    
    /**
     * Tests whether this object's container has already been 
     * updated and committed or checkpointed by another session.
     * 
     * <p>You should call this method only during an MROW session in
     * which you locked this object's container for read. If this method
     * returns true, your application's copies of the container and its
     * objects are out of date, because an MROW update session has concurrently accessed an object in the same container and then committed.  
     * You can call the
     * <a href="#refreshOpenContainer(int)"><tt>refreshOpenContainer</tt></a> method to
     * update the session's copy of this container and its objects.</p>
     * 
     * @return      True if the container has been updated and committed by another 
     * session since being locked for read by the current MROW session; 
     * otherwise, false. </p>
     */
    boolean isContainerUpdated();
    
}
