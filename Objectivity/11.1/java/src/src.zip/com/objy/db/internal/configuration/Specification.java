package com.objy.db.internal.configuration;


public class Specification 
{
    long mSpecificationPtr;
    
    /**
     * Reserved for internal use
     * @param specificationPtr
     */
    public Specification(long specificationPtr)
    {
        mSpecificationPtr = specificationPtr;
    }
    
    
   /**
    * Gets the Id of the parameter group for the tools specification
    * @return String paramter group id
    */
    public String getId()
    {
        return Binding.getId(mSpecificationPtr);
    }
    
    /**
     * Gets the description of the specification
     * @return String description of specification
     */
    public String getDescription()
    {
        return Binding.getDescription(mSpecificationPtr);
    }
    
    /*do not finalize this is owned by the manager
    
    protected void finalize() throws Throwable 
    {
        Binding.destruct(mSpecificationPtr);
    }
    */
    
    private static class Binding
    {
        public static native String getId(long mSpecificationPtr);
        public static native String getDescription(long mSpecificationPtr);
    }


}
