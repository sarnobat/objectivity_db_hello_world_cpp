/*
 * @(#)ooTreeSet.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Comparator;
import java.util.Iterator;
import java.util.NoSuchElementException;
import java.util.SortedSet;
import com.objy.db.ObjectNotPersistentException;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.iapp.PooObj;
import com.objy.db.iapp.Persistent;
import com.objy.pm.ooScalableCollectionsPersistor;
import com.objy.pm.ooCollectionIterator;

/**
 * Persistence-capable class for sorted sets of persistent objects.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Sorted Sets</h2>
 *
 * <p>A <i>sorted set</i> is a scalable ordered collection of persistent 
 * objects with no duplicate elements.
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Scalable Ordered Collections">
 * Scalable Ordered Collections</a>.
 *
 * <p><h2>Working With a Sorted Set</h2>
 *
 * <P>A sorted set is transient when it is created; you can make it
 * persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 *
 * <p>After you have created a sorted set, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building a Set">
 * Building a Set</a></p>
 *
 * <li>Look up particular elements in the sorted set as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Sets">
 * Individual Lookup in Sets</a></p> 
 *
 * <li>Iterate over the sorted set as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Elements of a List or Set">
 * Finding the Elements of a List or Set</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make a sorted set persistent before you call
 * any methods defined by the <tt>ooTreeSet</tt>, <tt>ooBTree</tt>, or
 * <tt>ooCollection</tt>
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of persistent objects:
 * <ul>
 * <li><a href="ooHashSet.html"><tt>ooHashSet</tt></a> represents
 * an <i>unordered</i> collection of persistent objects with no duplicate 
 * elements. </p>
 *
 * <li><a href="ooTreeList.html"><tt>ooTreeList</tt></a> represents an
 * <i>ordered</i> collection of persistent objects that <i>can contain 
 * duplicate elements</i>.</p> 
 * </ul>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 		<td>
 *     	<a href="#ooTreeSet()">ooTreeSet()</a><br>
 *     	<a href="#ooTreeSet(com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeSet(ooContObj, ooContObj)</a><br>
 *     	<a href="#ooTreeSet(int)">ooTreeSet(int)</a><br>
 *     	<a href="#ooTreeSet(int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeSet(int, ooContObj, ooContObj)</a><br>
 *     	<a href="#ooTreeSet(com.objy.db.util.ooCompare)">ooTreeSet(ooCompare)</a><br>
 *     	<a href="#ooTreeSet(com.objy.db.util.ooCompare, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeSet(ooCompare, ooContObj, ooContObj)</a><br>
 *     	<a href="#ooTreeSet(com.objy.db.util.ooCompare, int)">ooTreeSet(ooCompare, int)</a><br>
 *     	<a href="#ooTreeSet(com.objy.db.util.ooCompare, int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooTreeSet(ooCompare, int, ooContObj, ooContObj)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Adding&nbsp;and&nbsp;Removing&nbsp;Elements</b></td>
 * 	   <td>
 *     <a href="#addAll(java.util.Collection)">addAll(Collection)</a><br>
 *     <a href="#remove(java.lang.Object)">remove(Object)</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#removeAll(java.util.Collection)">removeAll(Collection)</a><br>
 *     <a href="#retainAll(java.util.Collection)">retainAll(Collection)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 * 	   <td>
 * 	   <a href="#iterator()">iterator()</a><br>
 * 	   <a href="#get(java.lang.Object)">get(Object)</a><br>
 * 	   <a href="#get(int)">get(int)</a>
 *     </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Indexes</b></td>
 * 	   <td>
 * 	   <a href="#indexOf(java.lang.Object, int)">indexOf(Object, int)</a>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	   <td>
 * 	   <a href="#containsAll(java.util.Collection)">containsAll(Collection)</a><br>
 * 	   </td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting Views of the Object Set</b></td>
 * 	   <td>
 *         <a href="#headSet(java.lang.Object)">headSet(Object)</a><br>
 *         <a href="#subSet(java.lang.Object, java.lang.Object)">subSet(Object, Object)</a><br>
 *         <a href="#tailSet(java.lang.Object)">tailSet(Object)</a>
 * 	</td></tr>
 * </table>
 *
 */
final public class ooTreeSet extends ooBTree implements SortedSet
{
 	/**
	 * Reserved for internal use.
	 */
    public transient int _maxUsedSizePerNode;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _adminContainer;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _arrayContainer;

  	/**
	 * Constructs an empty sorted set with a default comparator and the 
     * default 
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>. </p>
	 */
    public ooTreeSet()
    {}

  	/**
	 * Constructs an empty sorted set with a default comparator, the default
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>, and the specified containers for internal objects. </p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeSet(ooContObj adminContainer, ooContObj arrayContainer)
    {
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty sorted set with the specified comparator
	 * and the default 
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted set; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.
	 */
    public ooTreeSet(ooCompare compare)
    {
        _comparator = compare;
    }

	/**
	 * Constructs an empty sorted set with the specified comparator,
	 * the default 
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
	 * node size</a>, and the specified containers for internal
	 * objects. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted set; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.
	 * </p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
     public ooTreeSet(ooCompare compare, ooContObj adminContainer, ooContObj arrayContainer)
    {
      _comparator = compare;
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty sorted set with a default comparator and the
	 * specified node size. </p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted set's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 */
    public ooTreeSet(int maxNodeSize)
    {
      _maxUsedSizePerNode = maxNodeSize;
    }

	/**
	 * Constructs an empty sorted set with a default comparator, the
	 * specified node size, and the specified containers for internal
	 * objects. </p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted set's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeSet(int maxNodeSize, ooContObj adminContainer, ooContObj arrayContainer)
    {
      _maxUsedSizePerNode = maxNodeSize;
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Constructs an empty sorted set with the specified comparator
	 * and node size. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted set; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted set's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 */
    public ooTreeSet(ooCompare compare, int maxNodeSize)
    {
      _comparator = compare;
      _maxUsedSizePerNode = maxNodeSize;
    }

	/**
	 * Constructs an empty sorted set with the specified comparator,
	 * node size, and containers for internal
	 * objects. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new
	 * sorted set; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>maxNodeSize</i></tt>	The node size for the
 	 * new sorted set's B-tree. See
 	 * <a href="../../../../../guide/jgdCollections.html#NodeSize">
 	 * Node Size</a>.</p>
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in
	 * which to store the tree administrator for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#TreeAdministrator">
	 * Tree Administrator</a>.
	 * </p>
	 *
	 * @param		<tt><i>arrayContainer</i></tt>	The initial array container
	 * for the new sorted set. See
	 * <a href="../../../../../guide/jgdCollections.html#ArrayContainers">
	 * Array Containers</a>.
	 */
    public ooTreeSet(ooCompare compare, int maxNodeSize, ooContObj adminContainer, ooContObj arrayContainer)
    {
      _comparator = compare;
      _maxUsedSizePerNode = maxNodeSize;
      _adminContainer = adminContainer;
      _arrayContainer = arrayContainer;
    }

	/**
	 * Adds all elements in the specified collection to this sorted set. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection
	 * whose elements are to be added to this sorted set. Every element
	 * of <tt><i>collection</i></tt> must be an instance of a
	 * persistence-capable class. If any element is transient, this
	 * method makes it persistent.</p>
	 *
	 * @return		True if any elements were added; otherwise, false.
	 *
	 * <p>This method returns false if this sorted set already contains
 	 * all the elements of <tt><i>collection</i></tt>.
	 */
    public boolean addAll(Collection collection)
    {
        Iterator itr;
    	if (collection instanceof ooCollection)
    	    itr = (Iterator) ((ooCollection)collection).keyIterator();
    	else
    	    itr = collection.iterator();
        boolean mod = false;

        while (itr.hasNext())
            if (add(itr.next()))
                mod = true;
       return mod;
    }

	/**
	 * Tests whether this sorted set contains all elements in the
	 * specified collection. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements are
	 * to be tested for containment in this sorted set.</p>
	 *
	 * @return		True if this sorted set contains elements equal to
	 * each element of <tt><i>collection</i></tt>; otherwise, false.
	 */
    public boolean containsAll(Collection collection) {
        if (comparator() == null)
            return getCollectionPersistor().containsAll((ooCollection) collection);
        else
        {
            Iterator itr;
    	    if (collection instanceof ooCollection)
    	        itr = ((ooCollection)collection).keyIterator();
    	    else
    	        itr = collection.iterator();
    	    while (itr.hasNext())
    	        if (!contains(itr.next()))
    	            return false;
    	    return true;
        }
    }

	/**
	 * Finds the element (or key) of this ordered collection at the specified
	 * index. </p>
	 *
	 * @param		<tt><i>index</i></tt>	The zero-based index of the 
     * element to find.</p> 
	 *
	 * @return		If the elements of this ordered collection are persistent objects,
	 * the element whose index is <tt><i>index</i></tt>; if the elements are
	 * key-value pairs, the key of the element whose index is
	 * <tt><i>index</i></tt>.</p>
	 *
	 * @see #first
	 * @see #last
	 */
    public Object get(int index)
    {
        return getCollectionPersistor().get(index);
    }

    /**
     * Gets the element of this sorted set that is equal to the
	 * specified lookup data, as determined by the comparator for this
	 * sorted set.
	 *
	 * <p><b>Note: </b>This sorted set must have an application-defined
	 * comparator that can identify an element based on class-specific
	 * data.  See
	 * <a href="../../../../../guide/jgdCollections.fm.html#CompSorted">
	 * <i>Defining a Comparator Class for Sorted Collections</i></a>.</p>
	 *
	 * @@param		<tt><i>lookupValue</i></tt>	The object that identifies
	 * the desired element.
	 *
	 * @exception   com.objy.db.ObjyRuntimeException  If this
	 * sorted set has no application-defined comparator.</p>
	 *
	 * @@return		The element found equal to <tt><i>lookupValue</i></tt>, or null
	 * if this sorted set does not contain such an element.
	 */
    public Object get(Object lookupValue)
    {
       return getCollectionPersistor().get(lookupValue);
    }

	/**
	 * Gets a view of the beginning of this sorted object set up to, 
	 * but not including, the specified element.
         *
         * <p>The returned sorted set contains all elements of this object set
         * whose elements sort before the specified element, 
         * according to this object set's comparator. If you want a view that 
         * includes a particular element, specify as your parameter 
         * an element that sorts after the desired element. 
         *
         * <p>The returned sorted set is backed by this object set, so changes 
         * in the returned sorted set are reflected in this object set, and 
         * vice-versa. 
         *
         * <p>The returned sorted set throws an 
         * <tt>IllegalArgumentException</tt> if an attempt is made to
         * insert a new element that is equal to, or sorts after,
         * <tt><i>toElement</i></tt>.</p>
         *
         * @param   <tt><i>toElement</i></tt>   An object specifying the 
         * (exclusive) upper limit for elements in the returned set.</p>
         *
         * @return  A view of the specified initial range of this sorted object 
         * set. </p>
         *
         * @see	#subSet(Object, Object)
         * @see	#tailSet(Object)
         */
    public SortedSet headSet(Object toElement) {
	return new SubSet(getCollectionPersistor(), toElement, true);
    }

	/**
	 * Searches forward in this sorted set, starting at the specified index, for
	 * the first element that is equal to the specified object.
	 *
	 * This method compares
	 * each element with <tt><i>object</i></tt>. Search stops when a matching element is found;
	 * if more than one element matches, this method finds the one closest to the
	 * beginning (but at or after the starting index). </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object whose index is to be
	 * found.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is the persistent object to be
	 * found.  If this sorted set has an application-defined
	 * comparator that can identify an element based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the element to be found. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @param		<tt><i>index</i></tt>	The zero-based index at which search should
	 * start.</p>
	 *
	 * @return		The index of the first element in this sorted set
	 * at or after the index <tt><i>index</i></tt>, that is equal to
 	 * <tt><i>object</i></tt>. If no such element is found, this method
	 * returns -1.</p>
	 */
   public int indexOf(Object object, int index)
   {
      if (comparator() == null)
        return super.indexOf(object, index);
      else
      {
         ooCollectionIterator itr = (ooCollectionIterator) keyIterator();
         int i = -1;
         if (itr.goTo(object))
         {
            i = itr.previousIndex() + 1;
            if (i < index)
            {
              itr.goToIndex(index);
              i = -1;
              Object tObj;
              Comparator comp = comparator();
              while ((tObj = itr.next()) != null &&  comp.compare(tObj, object) != 0);
              if (tObj == null)
                i = itr.previousIndex() + 1;
             }
          }
          itr.close();
          return i;
      }
   }

	/**
	 * Initializes a scalable-collection iterator to find the elements of this
	 * sorted set. </p>
	 *
	 * @return		A scalable-collection iterator for finding the elements of this
	 * sorted set. The iterator finds the
	 * elements in their sorted order.
	 *
	 * <p>If you want to call any methods that are specific to Objectivity
	 * for Java scalable-collection iterators, you should cast the returned iterator
	 * to {@link ooCollectionIterator <tt>ooCollectionIterator</tt>}.
	 */
    public Iterator iterator()
    {
        return getCollectionPersistor().iterator();
    }

	/**
	 * Removes the specified object from this sorted set.
	 *
	 * <p>This method is equivalent to {@link #remove <tt>remove</tt>}.</p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be removed.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is the persistent object to be
	 * removed from this sorted set.  If this sorted set has an
	 * application-defined
	 * comparator that can identify an element based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the element to be removed. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 */
   public boolean ooRemove(Object object)
   {
        return remove(object);
   }

	/**
	 * Removes the specified object from this sorted set. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be removed.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is the persistent object to be
	 * removed from this sorted set.  If this sorted set has an
	 * application-defined
	 * comparator that can identify an element based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the element to be removed. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Sorted Collections">
	 * Comparator Class for Sorted Collections</a>.</p>
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 *
	 * @see #removeAll(Collection)
	 * @see #retainAll(Collection)
	 */
    public boolean remove(Object object) {
        return getCollectionPersistor().remove(object);
    }

	/**
	 * Removes all elements of the specified collection from this
	 * sorted set. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements are to be
	 * removed from this sorted set.</p>
	 *
	 * @return		True if any elements were removed; otherwise, false.</p>
	 *
	 * @see #remove(Object)
	 * @see #retainAll(Collection)
	 */
    public boolean removeAll(Collection collection)
    {
        Object obj;
        if (collection == this)
        {
            if (isEmpty())
            return false;
            else
            return getCollectionPersistor().removeAll((ooCollection) collection);
            }

    	boolean changed = false;
    	Iterator itr;

    	if (collection instanceof ooCollection)
    	    itr = ((ooCollection)collection).keyIterator();
    	else
    	    itr = collection.iterator();
    	while ((obj = itr.next()) != null)
    	{
    		if (ooRemove(obj))
    			changed = true;
    	}
    	return changed;
   }

	/**
	 * Retains all elements of this sorted set that are also in the
	 * specified collection, deleting all other elements. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection whose elements
	 * are to be retained in this sorted set.</p>
	 *
	 * @return		True if any elements were removed; otherwise, false.</p>
	 *
	 * @see #remove(Object)
	 * @see #removeAll(Collection)
	 */
    public boolean retainAll(Collection collection) {
        if (collection instanceof ooCollection && ((ooCollection) collection).comparator() == null)
            return getCollectionPersistor().retainAll((ooCollection) collection);
        else
        {
        	boolean changed = false;
	        Iterator itr = keyIterator();
        	while (itr.hasNext())
		        if (!collection.contains(itr.next()))
		{
			itr.remove();
			changed = true;
		}
	    return changed;
	    }
    }

        /**
         * Gets a view of the portion of this sorted object set
         * whose elements are in the specified range.
         *
         * <p>The returned sorted set contains all elements of this object set
         * that are equal to, or sort after, <tt><i>fromElement</i></tt>
         * and sort before <tt><i>toElement</i></tt>, 
         * according to this object set's comparator. 
         *
         * <p>The returned sorted set is backed by this object set, so changes 
         * in the returned sorted set are reflected in this object set, and 
         * vice-versa. 
         *
         * <p>The returned sorted set throws an 
         * <tt>IllegalArgumentException</tt> if an attempt is made to
         * insert an element that sorts before 
         * <tt><i>fromElement</i></tt> or is equal to, or sorts after,
         * <tt><i>toElement</i></tt>.</p>
         *
         * @param   <tt><i>fromElement</i></tt>   An object specifying the 
         * (inclusive) lower limit for elements in the returned set.</p> 
         *
         * @param   <tt><i>toElement</i></tt>   An object specifying the 
         * (exclusive) upper limit for elements in the returned set.</p>  
         *
         * @return  A view of the specified range of this sorted object set.</p> 
         *
	 * @see	#headSet(Object)
	 * @see	#tailSet(Object)
	 */
    public SortedSet subSet(Object fromElement, Object toElement) {
        return new SubSet(getCollectionPersistor(), fromElement, toElement);
    }

	/**
         * Gets a view of the end of this sorted object set, starting with
         * the specified set.
         *
         * <p>The returned sorted set contains all elements of this object set
         * that are equal to, or sort after, <tt><i>fromElement</i></tt>
         * according to this object set's comparator. 
         *
         * <p>The returned sorted set is backed by this object set, so changes 
         * in the returned sorted set are reflected in this object set, and 
         * vice-versa. 
         *
         * <p>The returned sorted set throws an 
         * <tt>IllegalArgumentException</tt> if an attempt is made to
         * insert a new element that sorts before 
         * <tt><i>fromElement</i></tt>.</p>
         *
         * @param   <tt><i>fromElement</i></tt>   An object specifying the 
         * (inclusive) lower limit for elements in the returned set.</p>  
         *
         * @return  A view of the specified final range of this sorted object 
         * set.</p> 
         *
         * @see	#subSet(Object, Object)
         * @see	#headSet(Object)
         */
    public SortedSet tailSet(Object fromElement) {
        return new SubSet(getCollectionPersistor(), fromElement, false);
    }

    private class SubSet implements SortedSet {

	private transient PooObj superPersistor;
	private transient Object lowRange;
	private transient Object highRange;

	private SubSet(PooObj persistor, Object fromElement, Object toElement)
	{
	    superPersistor = persistor;
	    if (fromElement != null && toElement != null && compare(fromElement, toElement) > 0)
		throw new IllegalArgumentException("fromElement > toElement");
	    lowRange = fromElement;
	    highRange = toElement;
	}

	private SubSet(PooObj persistor, Object element, boolean headSet)
	{
	    superPersistor = persistor;
	    if (headSet) {
		lowRange = null;
		highRange = element;
	    }
	    else {
		lowRange = element;
		highRange = null;
	    }
	}

	public boolean addAll(Collection collection) {
	    return ooTreeSet.this.addAll(collection);
	}

	public boolean containsAll(Collection collection) {
	    Iterator itr;
	    if (collection instanceof ooCollection)
		itr = ((ooCollection)collection).keyIterator();
	    else
		itr = collection.iterator();
	    while (itr.hasNext())
		if (!contains(itr.next()))
		    return false;
	    return true;
	}

	public SortedSet headSet(Object toElement) {
            if (!inRange2(toElement))
                throw new IllegalArgumentException("toElement out of range");
	    return new SubSet(getSuperPersistor(), lowRange, toElement);
	}

	public Iterator iterator() {
	    ooCollectionIterator itr = (ooCollectionIterator)getCollectionPersistor().iterator();
	    return new SubSetIterator(itr, lowRange, highRange, inTreeRange(lowRange));
	}

	public boolean remove(Object element) {
	    if (contains(element))
		return ooTreeSet.this.remove(element);
	    else return false;
	}

	public boolean removeAll(Collection collection) {
	    Object obj;
	    boolean changed = false;
	    Iterator itr;

	    if (collection instanceof ooCollection)
		itr = ((ooCollection)collection).keyIterator();
	    else
		itr = collection.iterator();
	    while ((obj = itr.next()) != null) {
		if (remove(obj))
		    changed = true;
	    }
	    return changed;
	}

	public boolean retainAll(Collection collection) {
	    boolean changed = false;
	    Iterator itr = keyIterator();
	    while (itr.hasNext())
		if (!collection.contains(itr.next())) {
		    itr.remove();
		    changed = true;
		}
	    return changed;
	}

	public SortedSet subSet(Object fromElement, Object toElement) {
            if (!inRange(fromElement))
		throw new IllegalArgumentException("fromElement out of range");
            if (!inRange2(toElement))
                throw new IllegalArgumentException("toElement out of range");
	    return new SubSet(getSuperPersistor(), fromElement, toElement);
	}

	public SortedSet tailSet(Object fromElement) {
            if (!inRange(fromElement))
                throw new IllegalArgumentException("fromElement out of range");
	    return new SubSet(getSuperPersistor(), fromElement, highRange);
	}

	public boolean add(Object element) {
	    if (!inRange(element))
		throw new IllegalArgumentException("element out of range");
	    return ooTreeSet.this.add(element);
	}

	public void clear() {
	    Iterator itr = iterator();
	    while (itr.hasNext()) {
		itr.next();
		itr.remove();
	    }
	}

	public Comparator comparator() {
	    return ooTreeSet.this.comparator();
	}

	public boolean contains(Object element) {
	    if (!inRange(element))
		return false;
	    else {
		ooCollectionIterator itr = (ooCollectionIterator)getCollectionPersistor().iterator();
		return itr.goTo(element);
	    }
	}

	public Object first() {
	    Iterator itr = iterator();
	    if (itr.hasNext())
		return itr.next();
	    else
		return null;
	}

	public boolean isEmpty() {
	    if (ooTreeSet.this.isEmpty())
		return true;
	    else {
		Iterator itr = iterator();
		return !itr.hasNext();
	    }
	}

	public Object last() {
	    Iterator itr = iterator();
	    Object current = null;
	    while (itr.hasNext())
		current = itr.next();
	    return current;
	}

	public int size() {
	    Iterator itr = iterator();
	    Object current;
	    int i = 0;
	    while (itr.hasNext()) {
		i++;
		current = itr.next();
	    }
	    return i;
	}

	public Object[] toArray() {
	    Object answer[] ;
	    answer = (Object[])Array.newInstance(java.lang.Object.class, size()) ;
	    Iterator itr = iterator();
	    int i = 0;
	    while (itr.hasNext())
		answer[i++] = itr.next();
	    return answer ;
	}

	public Object[] toArray(Object[] a) {
	    int size = size();
	    if (a.length < size)
		a = (Object[])Array.newInstance(a.getClass().getComponentType(), size);
	    Iterator itr = iterator();
	    for (int i=0; i<size; i++)
		a[i] = itr.next();

	    if (a.length > size)
		a[size] = null;
	    return a;
	}

	// Compares two keys using the correct comparison method
	private int compare(Object k1, Object k2) {
        int returnVal = 0;
        if (comparator() == null) {
            returnVal = ((Persistent) k1).getPersistor().compareOoId(((Persistent) k2).getPersistor());
        } else {
            returnVal = comparator().compare(k1, k2);
        }
        return returnVal;
	}

	private boolean inRange(Object element) {
	    return (lowRange == null ? true : compare(element, lowRange) >= 0) && (highRange == null ? true : compare(element, highRange) < 0);
	}

    // This form allows the high endpoint (as well as all legit elements)
	private boolean inRange2(Object element) {
	    return (lowRange == null ? true : compare(element, lowRange) >= 0) && (highRange == null ? true : compare(element, highRange) <= 0);
    }
    
    // This form checks if the element is in the Tree, excepting null elements
    private int inTreeRange(Object element) {
        if (element == null)  return 0;
        if (compare(element, ooTreeSet.this.first()) < 0) return -1;
        if (compare(element, ooTreeSet.this.last()) > 0) return 1;
        return 0;
    }

	protected PooObj getSuperPersistor()
            { return superPersistor ; }

	protected ooScalableCollectionsPersistor getCollectionPersistor() {
	    if (getSuperPersistor() != null)
		return (ooScalableCollectionsPersistor) getSuperPersistor() ;
	    else
		throw new ObjectNotPersistentException("Attempted persistence operation on transient object") ;
	}
    }

    private class SubSetIterator implements Iterator {
	private ooCollectionIterator itr;
	private Object first;
	private Object firstExcluded;
	private Object firstVal = null;

	SubSetIterator(ooCollectionIterator _itr, Object _first, Object _firstExcluded, int inRangeFirst) {
	    itr = _itr;
	    first = _first;
	    firstExcluded = _firstExcluded;
        if (inRangeFirst<=0)
        {
            if (first != null && ( itr.goTo(first) || (firstExcluded!=null && ooTreeSet.this.comparator().compare(itr.current(),firstExcluded) < 0)))
    	        firstVal = itr.current();
            else
            {
                try {itr.previous();}
                catch(NoSuchElementException ex) {}
            }                
    	    if ((firstExcluded != null) && (indexOf(firstExcluded) == -1)) {
    	        Object restore = itr.current();
    	        itr.goTo(firstExcluded);
    	        firstExcluded = itr.current();
    	        if (restore != null)
    	            itr.goTo(restore);
    	        else
    	            itr.reset();
    	    }
        }
        else
            itr.goTo(first);
	}

	public boolean hasNext() {
	    if (firstVal != null) return true ;
	    return itr.hasNext() && (firstExcluded == null || itr.nextIndex() < indexOf(firstExcluded));
	}

	public Object next() {
	    Object value;
	    if (firstVal != null) {
		value = firstVal;
		firstVal = null;
	    }
	    else {
		if (!hasNext())
		    return null;
		value = itr.next();
	    }
	    return value;
	}

	public void remove() {
	    itr.remove();
	}
    }
}
