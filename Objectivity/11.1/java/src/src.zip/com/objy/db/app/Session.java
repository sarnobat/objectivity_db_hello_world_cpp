/*
 * @(#)Session.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import java.io.PrintStream;
import java.util.Vector ;

import com.objy.db.ObjyRuntimeException ;

import com.objy.db.app.storage.ClusterReason;
import com.objy.db.app.storage.ClusterStrategy;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.app.storage.ooDBObj;
import com.objy.db.iapp.PSession ;
import com.objy.db.iapp.PToManyTransientRelationshipManager ;
import com.objy.db.iapp.PToOneTransientRelationshipManager ;

import com.objy.ejb.XATransaction ;

import com.objy.pm.Access ;

/**
 * Represents an extended interaction between an application and a connected
 * federated database.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr> <td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>After you have opened a
 * <a href="Connection.html">connection</a>,
 * you can create a session and use it to interact with the connected
 * federated database.  A session provides the
 * <a href="../../../../../guide/jgdTransactions.html#_top_">transaction services</a>
 * that enable you to perform Objectivity/DB operations. See
 * <a href="../../../../../guide/jgdSessions.html#_top_">
 * Sessions</a>.
 *
 * <p>Your application can create multiple sessions, each corresponding to a
 * particular subtask that your application performs. Sessions serve
 * to isolate the operations performed in the different subtasks of an
 * application. If more than one  session uses a given Objectivity/DB
 * object, each session has its own
 * local representation of that object.  Each session locks and unlocks the
 * object as necessary.  The session ensures that all Objectivity/DB
 * operations on its local representation objects are valid.
 * For additional
 * information, see
 * <a href="../../../../../guide/jgdSessions.html#Sessions and Objectivity/DB Objects">
 * Sessions and Objectivity/DB Objects</a>.
 *
 * <p>A session has a number of
 * <a href="../../../../../guide/jgdSessions.html#Session Properties">properties</a> that
 * govern its interaction with Objectivity/DB. An application can also define and store
 * additional properties using <a href="SessionData.html">session-data objects</a>.
 *
 * <p>You can use a {@link #Session() <tt>Session</tt>} class constructor
 * to create an <i>individual session</i>,
 * or you can call a connection's {@link Connection#createSessionPool <tt>createSessionPool</tt>}
 * method to create a session pool that contains
 * a number of similar <i>pooled sessions</i>. To obtain a pooled session,
 * you call a connection's {@link Connection#getSessionFromPool <tt>getSessionFromPool</tt>}
 * method.
 *
 * <p><b>Note: </b>If your application requires ODMG compliance, it should
 * create ODMG transaction objects
 * instead of sessions. For additional information about ODMG applications, see
 * <A HREF="../../../../../guide/jgdODMGApplication.html#_top_">
 * Conforming to the ODMG Standard</A>.
 *
 * <h2>Associated Objects</h2>
 *
 * <p>When you create a session, the session automatically creates three additional objects:
 * <ul type=disc>
 * <li>A local representation of the connected
 * <a href="ooFDObj.html">federated database</a>.</p>
 *
 * <li>A
 * <a href="storage/ClusterStrategy.html">clustering strategy</a>, which assists with
 * <a href="../../../../../guide/jgdClustering.html#_top_">clustering</a>
 * objects that are made persistent when that session is in a
 * transaction.</p>
 *
 *<li>An <a href="Transaction.html">ODMG transaction</a> object. Your
 * application does not work directly with the transaction object unless it
 * requires ODMG compliance.
 *
 * <p>For ODMG compliance, you can create an ODMG transaction
 * object instead of creating a session directly. When you create
 * an ODMG transaction object, its session and that session's
 * other associated objects are created automatically.</p>
 *
 * </ul>
 *
 * <p> For performance monitoring purposes, you may optionally add one or more
 * <a href="TransactionListener.html">transaction listeners</a>
 * or attach a <a href="LogListener.html">log listener</a> to a session.
 *
 * <h2>Terminating Sessions</h2>
 *
 * <p>When you have finished
 * the subtask corresponding to a particular session, you
 * can call the session's <a href="#terminate()"><tt>terminate</tt></a> method to terminate it,
 * which releases all the resources associated with the session.
 *
 * <p>Closing a connection automatically terminates any of its remaining open sessions.
 *
 * <p>When a session is terminated, the session and all objects that belong to
 * it are no longer valid for Objectivity/DB operations.  Attempting to terminate
 * a session with an open transaction throws a
 * {@link com.objy.db.TransactionInProgressException <tt>TransactionInProgressException</tt>}.
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 *
 * <TD><A HREF="#Session()">Session()</A><br>
 * 	<A HREF="#Session(java.lang.String)">Session(String)</A><br>
 * 	<A HREF="#Session(int, int)">Session(int, int)</A><br>
 * 	<A HREF="#Session(int, int, java.lang.String)">Session(int, int, String)</A></TD>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Controlling&nbsp;Transactions</B></TD>
 *
 * <TD><A HREF="#begin()">begin()</A><BR>
 * 	<A HREF="#checkpoint()">checkpoint()</A><BR>
 * 	<A HREF="#checkpoint(int)">checkpoint(int)</A><BR>
 * 	<A HREF="#commit()">commit()</A><BR>
 * 	<A HREF="#abort()">abort()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Associated&nbsp;Objects</B></TD>
 * <TD><A HREF="#getConnection()">getConnection()</A><BR>
 * 	<A HREF="#getFD()">getFD()</A><BR>
 * 	<A HREF="#getTransaction()">getTransaction()</A><BR>
 * 	<A HREF="#getClusterStrategy()">getClusterStrategy()</A><BR>
 * 	<A HREF="#getXAResource()">getXAResource()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Clearing&nbsp;Resources</B></TD>
 * <td><A HREF="#terminate()">terminate()</A><br>
 * 	<A HREF="#isTerminated()">isTerminated()</A><br>
 * 	<A HREF="#releaseFiles()">releaseFiles()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Session&nbsp;Properties</B></TD>
 *
 * <TD><A HREF="#getCacheInitialPages()">getCacheInitialPages()</A><BR>
 * 	<A HREF="#getCacheMaximumPages()">getCacheMaximumPages()</A><br>
 * 	<A HREF="#getOpenMode()">getOpenMode()</A><BR>
 * 	<A HREF="#getMrowMode()">getMrowMode()</A><BR>
 * 	<A HREF="#getWaitOption()">getWaitOption()</A><BR>
 * 	<A HREF="#getIndexMode()">getIndexMode()</A><BR>
 * 	<A HREF="#getThreadPolicy()">getThreadPolicy()</A><BR>
 * 	<A HREF="#getOfflineMode()">getOfflineMode()</A><BR>
 * 	<A HREF="#getAllowUnregisterableTypes()">getAllowUnregisterableTypes()</A><br>
 * 	<A HREF="#getTransactionID()">getTransactionID()</A><BR>
 * 	<A HREF="#nestCount()">nestCount()</A><BR>
 *  	<A HREF="#getContainerRefetch()">getContainerRefetch()</A><BR>
 *  	<A HREF="#getSessionData(java.lang.String)">getSessionData(String)</A><BR>
 *  	<A HREF="#getIteratorPolicy()">getIteratorPolicy()</A><BR>
 *      <A HREF="#obtainedFromSessionPool()">obtainedFromSessionPool()</A><BR>
 *      <A HREF="#poolName()">poolName()</A><BR>
 *  	<A HREF="#getSafeIteratorPolicy()">getSafeIteratorPolicy()</A><BR>
 *  	<A HREF="#getAutoFlushThreshold()">getAutoFlushThreshold()</A><BR>
 *  	<A HREF="#getReturn_Class_Object()">getReturn_Class_Object()</A><br>
 *  	<A HREF="#getValidateReferencesDuringFetch()">getValidateReferencesDuringFetch()</A>
 * </td></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Setting&nbsp;Session&nbsp;Properties</B></TD>
 * <TD><A HREF="#setOpenMode(int)">setOpenMode(int)</A><BR>
 * 	<A HREF="#setMrowMode(int)">setMrowMode(int)</A><BR>
 * 	<A HREF="#setWaitOption(int)">setWaitOption(int)</A><BR>
 * 	<A HREF="#setIndexMode(int)">setIndexMode(int)</A><BR>
 * 	<A HREF="#setUseIndex(boolean)">setUseIndex(boolean)</A><br>
 * 	<A HREF="#setLargeObjectMemoryLimit(long)">setLargeObjectMemoryLimit(long)<BR></A>
 * 	<A HREF="#setBufferSpace(int, int, int, int, int)">setBufferSpace(int, int, int, int, int)</A><BR>
 * 	<A HREF="#setHotMode(boolean)">setHotMode(boolean)</A></A><BR>
 * 	<A HREF="#setThreadPolicy(int)">setThreadPolicy(int)</A><br>
 * 	<A HREF="#setRecoveryAutomatic(boolean)">setRecoveryAutomatic(boolean)</A><br>
 * 	<A HREF="#setOfflineMode(int)">setOfflineMode(int)</A><br>
 * 	<A HREF="#setRPCTimeout(long)">setRPCTimeout(long)</A><br>
 *	<A HREF="#setConnectRetries(int)">setConnectRetries(int)</A><br>
 * 	<A HREF="#setFetchErrorFormat(int)">setFetchErrorFormat(int)</A><br>
 * 	<A HREF="#setDeadenObjectsAfterCommit(boolean)">setDeadenObjectsAfterCommit(boolean)</A><br>
 *  <A HREF="#setDeadenObjectsInExternallyModifiedContainers(boolean)">setDeadenObjectsInExternallyModifiedContainers(boolean)</A><br>
 * 	<A HREF="#setIteratorSkipInternal(boolean)">setIteratorSkipInternal(boolean)</A><br>
 * 	<A HREF="#setAllowUnregisterableTypes(boolean)">setAllowUnregisterableTypes(boolean)</A><br>
 * 	<A HREF="#setLockConflictInfo(boolean)">setLockConflictInfo(boolean)</A><BR>
 *  	<A HREF="#upgrade()">upgrade()</A><BR>
 *  	<A HREF="#setContainerRefetch(boolean)">setContainerRefetch(boolean)</A><BR>
 *  	<A HREF="#setSessionData(java.lang.String, com.objy.db.app.SessionData)">setSessionData(String, SessionData)</A><BR>
 *  	<A HREF="#setIteratorPolicy(int)">setIteratorPolicy(int)</A><BR>
 *  	<A HREF="#setAllowNonQuorumRead()">setAllowNonQuorumRead()</A><br>
 * 	<A HREF="#setErr(java.io.PrintStream)">setErr(PrintStream)</A><br>
 * 	<A HREF="#setOut(java.io.PrintStream)">setOut(PrintStream)</A><br>
 *  	<A HREF="#setOptimizeScanOrder(boolean)">setOptimizeScanOrder(boolean)</A><br>
 *  	<A HREF="#setSafeIteratorPolicy(boolean)">setSafeIteratorPolicy(boolean)</A><br>
 *  	<A HREF="#setAutoFlushThreshold(int)">setAutoFlushThreshold(int)</A><br>
 *  	<A HREF="#ignoreAutoFlushThreshold()">ignoreAutoFlushThreshold()</A><br>
 *  	<A HREF="#setReturn_Class_Object(boolean)">setReturn_Class_Object(boolean)</A><br>
 *  </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 *
 * <TD>
 * 	<A HREF="#isOpen()">isOpen()</A><br>
 *	<A HREF="#isTerminated()">isTerminated()</A><BR>
 * 	<A HREF="#isJoined()">isJoined()</A><BR>
 * 	<A HREF="#isJoined(java.lang.Thread)">isJoined(Thread)</A><BR>
 * 	<A HREF="#isRecoveryAutomatic()">isRecoveryAutomatic()</A><BR>
 *  	<A HREF="#isDeadenObjectsInExternallyModifiedContainers()">isDeadenObjectsInExternallyModifiedContainers()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Interactions With&nbsp;Threads</B></TD>
 *
 * <TD><A HREF="#join()">join()</A><BR>
 * 	<A HREF="#isJoined()">isJoined()</A><BR>
 * 	<A HREF="#isJoined(java.lang.Thread)">isJoined(Thread)</A><BR>
 * 	<A HREF="#leave()">leave()</A><br>
 * 	<A HREF="#threads()">threads()</A><br>
 * 	<A HREF="#getThreadPolicy()">getThreadPolicy()</A><br>
 * 	<A HREF="#setThreadPolicy(int)">setThreadPolicy(int)</A><br>
 * 	<A HREF="#getCurrent()">getCurrent()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Efficient&nbsp;Container&nbsp;Access</B></TD>
 *
 *  <TD><A HREF="#getContainerRefetch()">getContainerRefetch()</A><BR>
 *  <A HREF="#setContainerRefetch(boolean)">setContainerRefetch(boolean)</A><BR>
 * 	<A HREF="#openContainers(com.objy.db.app.ooId[], int)">openContainers(ooId[], int)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Logging</B></TD>
 * <TD> <A HREF="#addToLog(java.lang.String, java.lang.String)">addToLog(String, String)</A><BR>
 *      <A HREF="#startTimer()">startTimer()</A><BR>
 *      <A HREF="#stopTimer()">stopTimer()</A><BR>
 *      <A HREF="#startStatistics()">startStatistics()</A><BR>
 *      <A HREF="#stopStatistics()">stopStatistics()</A><BR>
 *      <A HREF="#setLogListener(com.objy.db.app.LogListener)">setLogListener(LogListener)</A><BR>
 *      <A HREF="#snapShot(int, int, java.lang.String, boolean, int, com.objy.db.app.ooId)">snapShot(int, int, String, boolean, int, ooId)</A><BR>
 *      <A HREF="#snapShot(int, int, java.lang.String, boolean, int)">snapShot(int, int, String, boolean, int)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Session&nbsp;Pools</B></TD>
 * <TD> <A HREF="#obtainedFromSessionPool()">obtainedFromSessionPool()</A><BR>
 *      <A HREF="#poolName()">poolName()</A><BR>
 *      <A HREF="#returnSessionToPool()">returnSessionToPool()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Clustering</B></TD>
 * <TD><A HREF="#getClusterStrategy()">getClusterStrategy()</A><BR>
 * 	<A HREF="#setClusterStrategy(com.objy.db.app.storage.ClusterStrategy)">setClusterStrategy(ClusterStrategy)</A><BR>
 * 	<A HREF="#requestCluster(java.lang.Object, com.objy.db.app.storage.ClusterReason, java.lang.Object)">requestCluster(Object, ClusterReason, Object)</A>
 * </TD></TR>
 *
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Monitoring&nbsp;Runtime Performance</B></TD>
 * <TD VALIGN = "top"><A HREF="#printRunStatus()">printRunStatus()</A><BR>
 *      <A HREF="#addToLog(java.lang.String, java.lang.String)">addToLog(String, String)</A><BR>
 *      <A HREF="#startTimer()">startTimer()</A><BR>
 *      <A HREF="#stopTimer()">stopTimer()</A><BR>
 *      <A HREF="#startStatistics()">startStatistics()</A><BR>
 *      <A HREF="#stopStatistics()">stopStatistics()</A><BR>
 *      <A HREF="#setLogListener(com.objy.db.app.LogListener)">setLogListener(LogListener)</A><BR>
 *      <A HREF="#addTransactionListener(com.objy.db.app.TransactionListener)">addTransactionListener(TransactionListener)</A><BR>
 *      <A HREF="#removeTransactionListener(com.objy.db.app.TransactionListener)">removeTransactionListener(TransactionListener)</A><BR>
 *      <A HREF="#snapShot(int, int, java.lang.String, boolean, int, com.objy.db.app.ooId)">snapShot(int, int, String, boolean, int, ooId)</A><BR>
 *      <A HREF="#snapShot(int, int, java.lang.String, boolean, int)">snapShot(int, int, String, boolean, int)</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing Cached Information</B></TD>
 * <TD><A HREF="#dropCachedObject(java.lang.Object)">dropCachedObject(Object)</A><br>
 *  <A HREF="#reloadCachedObject(java.lang.Object)">reloadCachedObject(Object)</A><br>
 * 	<A HREF="#setDeadenObjectsAfterCommit(boolean)">setDeadenObjectsAfterCommit(boolean)</A><br>
 *  <A HREF="#setDeadenObjectsInExternallyModifiedContainers(boolean)">setDeadenObjectsInExternallyModifiedContainers(boolean)</A>
 * </TD></TR>
 *
 * <TR>
 * <TD><B>Static Utilities</B></TD>
 * <TD><A HREF="#getCurrent()">getCurrent()</A></TD>
 * </TR>
 * </TABLE>
 *
 *
 */
public class Session
{
    private transient PSession persistor ;

	/**
	 * Constructs a session with a Objectivity/DB cache of the default size.
 	 *
 	 * <p>The newly created session interacts with the connected federated
	 * database. The initial cache capacity of the session's
	 * Objectivity/DB cache is 200
	 * and the maximum cache capacity is 500.
	 *
	 * <p><b>Note: </b>The constructor throws an
	 * <tt>ObjyRuntimeException</tt> if there is no open
	 * connection.
	 *
	 * <p>The constructor also creates the ODMG transaction object
	 * associated with the new session.  If the connection is
	 * using the restricted thread policy,
	 * the constructor joins the current thread to the new session.</p>
	 *
	 */
    public Session()
        { persistor = Access.new_SessionPersistor(this, null) ; }

	/**
	 * Constructs a session with a Objectivity/DB cache of the default
	 * size and the specified name.
 	 *
 	 * <p>The newly created session interacts with the connected federated
	 * database. The initial cache capacity of the session's
	 * Objectivity/DB cache is 200
	 * and the maximum cache capacity is 500.
	 *
	 * <p><b>Note: </b>The constructor throws an
	 * <tt>ObjyRuntimeException</tt> if there is no open
	 * connection.
	 *
	 * <p>The constructor also creates the ODMG transaction object
	 * associated with the new session.  If the connection is
	 * using the restricted thread policy,
	 * the constructor joins the current thread to the new session.</p>
	 *
	 * @param 	 name	Name for the new session.
	 */
    public Session(String name)
        { persistor = Access.new_SessionPersistor(this, name) ; }

	/**
	 * Constructs a session with the specified initial and maximum
	 * Objectivity/DB cache capacities.
	 *
 	 * <p>The newly created session interacts with the connected federated
	 * database.
	 *
	 * <p><b>Note: </b>The constructor throws an
	 * <tt>ObjyRuntimeException</tt> if there is no open
	 * connection.
	 *
	 * <p>The constructor also creates the ODMG transaction object and the federated database
	 * object associated with the new session. If the connection's thread
	 * policy is restricted,
	 * the constructor joins the current thread to the new session.</p>
	 *
	 * @param 	 cacheInitialPages	The initial cache capacity
	 * for this session's Objectivity/DB cache:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in this session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * this value specifies:
	 * <ul type=circle>
	 * <li>
	 * The initial number of buffer pages allocated in the session's default
	 * small-object buffer pool.
	 * <li>
	 * The initial number of buffer entries allocated in the session's default
	 * large-object buffer pool (equivalently,
	 * the initial number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by this session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), this value specifies:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the initial number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The initial number of bytes is equal to the specified value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The initial number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the initial number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 *
	 * @param 	 cacheMaximumPages	 The maximum cache capacity
	 * for this session's Objectivity/DB cache:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in this session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * this value specifies:
	 * <ul type=circle>
	 * <li>
	 * The maximum number of buffer pages allocated in the session's default
	 * small-object buffer pool.
	 * <li>
	 * The maximum number of buffer entries allocated in the session's default
	 * large-object buffer pool (equivalently,
	 * the maximum number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by this session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), this value specifies:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the maximum number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The maximum number of bytes is equal to the specified value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The maximum number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the maximum number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 */
    public Session (int cacheInitialPages, int cacheMaximumPages)
        { persistor = Access.new_SessionPersistor(this, cacheInitialPages, cacheMaximumPages, null) ; }

	/**
	 * Constructs a session with the specified number of initial and maximum
	 * pages in its Objectivity/DB cache and the specified name.
	 *
 	 * <p>The newly created session interacts with the connected federated
	 * database.
	 *
	 * <p><b>Note: </b>The constructor throws an
	 * <tt>ObjyRuntimeException</tt> if there is no open
	 * connection.
	 *
	 * <p>The constructor also creates the ODMG transaction object and the federated database
	 * object associated with the new session. If the connection's thread
	 * policy is restricted,
	 * the constructor joins the current thread to the new session.</p>
	 *
	 * @param 	 cacheInitialPages	The initial cache capacity
	 * for this session's Objectivity/DB cache:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in this session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * this value specifies:
	 * <ul type=circle>
	 * <li>
	 * The initial number of buffer pages allocated in the session's default
	 * small-object buffer pool.
	 * <li>
	 * The initial number of buffer entries allocated in the session's default
	 * large-object buffer pool (equivalently,
	 * the initial number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by this session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), this value specifies:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the initial number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The initial number of bytes is equal to the specified value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The initial number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the initial number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 *
	 * @param 	 cacheMaximumPages	 The maximum cache capacity
	 * for this session's Objectivity/DB cache:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in this session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * this value specifies:
	 * <ul type=circle>
	 * <li>
	 * The maximum number of buffer pages allocated in the session's default
	 * small-object buffer pool.
	 * <li>
	 * The maximum number of buffer entries allocated in the session's default
	 * large-object buffer pool (equivalently,
	 * the maximum number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by this session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), this value specifies:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the maximum number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The maximum number of bytes is equal to the specified value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The maximum number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the maximum number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 *
	 * @param 	 name	Name for the new session.
	 */
    public Session (int cacheInitialPages, int cacheMaximumPages, String name)
        { persistor = Access.new_SessionPersistor(this, cacheInitialPages, cacheMaximumPages, name) ; }

	/**
	 * Reserved for internal use.
	 *
	 * <p>You should not use this constructor directly.</p>
	 */
    public Session(PSession persistor)
        { this.persistor = persistor ; }

	/**
	 * Gets the session of the current thread.</p>
	 *
	 * @return		The session of the current thread, or null if the current
	 * thread is not joined to any session. If the thread policy of the
	 * connection is unrestricted, this method returns null.
	 */
    public static Session getCurrent()
        { return Access.session_getCurrent() ; }

	/**
	 * Gets the connection object through which this session
	 * interacts with the federated database.</p>
	 *
	 * @return		The connection object for this session
	 */
    public Connection getConnection()
        { return persistor().getConnection() ; }

	/**
	 * Gets this session's ODMG transaction object.</p>
	 *
	 * @return		This session's ODMG transaction object.
	 */
    public Transaction getTransaction()
        { return persistor().getTransaction() ; }

    /**
	 * Gets the transaction ID for this session.
	 *
     * <p>As soon as a session begins a transaction, it
     * accesses the federated database to specify whether it will conduct a
     * read transaction or an update transaction. At that time, the lock
     * server assigns a unique ID to the transaction.</p>
	 *
	 * @return      The lock server transaction ID for this session, or 0 if
     * the session is not within a transaction or if it has just begun a
     * transaction but not yet accessed the federated database to request a
     * read or update transaction.
	 */
    public long getTransactionID()
        { return persistor().getTransactionID() ; }

	/**
	 * Gets this session's
     * <a href="../../ejb/XATransaction.html">
     * Objectivity/DB transaction resource manager</a>.</p>
	 *
	 * @return		This session's Objectivity/DB transaction resource manager.
	 */
    public XATransaction getXAResource()
	{ return persistor().getXAResource() ; }

	/**
	 * Enables or disables the collection of lock-conflict information.
	 *
     * <p>A lock request fails because one
     * or more other clients already hold locks that are inconsistent with a
     * simultaneous lock of the kind that was requested by this session.
     * After you enable the collection of lock-conflict information, if a
     * lock request by this session fails, the lock server creates
     * <a href="./TransactionInfo.html">transaction-information objects</a>
     * describing the transactions that hold conflicting locks.
     *
	 * <p>Enabling the collection of lock-conflict information may adversely
     * affect runtime performance, so you should enable it only when you need
     * lock-conflict details.
	 *
     * <p>If this method is not called, the collection of lock-conflict
     * information is disabled.</p>
     *
	 * @param 	 mode	True to enable the collection of
     * lock-conflict information; false to disable it.
	 */
    public void setLockConflictInfo(boolean mode)
        { persistor().setLockConflictInfo(mode) ; }

	/**
	 * Gets this session's federated database object.</p>
	 *
	 * <p>This method may be called either inside or outside a transaction.</p>
	 *
	 * @return		This session's federated database object.
	 */
    public ooFDObj getFD()
        { return persistor().getFD() ; }

	/**
     * Terminates this session.
     *
     * <p>Terminating a session releases its Objectivity/DB cache
     * and all other resources
     * associated with the session.  All the objects that belong to the
     * session become dead objects.
     *
	 * <p><b>Note: </b>After terminating a session, you should not use any objects
	 * that belong to the session.
	 *
     * <p>Once a session is terminated, the only method that can be
     * called for that session is <a href="#isTerminated()"><tt>isTerminated</tt></a>.
     *
     * <p>If this session is in a transaction, this method throws a
     * <tt>TransactionInProgressException</tt>.</p>
     *
     * @see #isTerminated
	 */
    public synchronized void terminate()
        { persistor().terminate(); }

	/**
     * Tests whether automatic recovery on the local host is enabled.</p>
	 *
     * @return		True if automatic recovery is enabled;
     * false if it is disabled.</p>
     *
     * @see #setRecoveryAutomatic
	 */
    public boolean isRecoveryAutomatic()
        { return persistor().isRecoveryAutomatic() ; }

    /**
     * Tests whether this session has been terminated.</p>
     *
     * @return	True if this session has been terminated; otherwise,
	 * false.</p>
     *
     * @see #terminate
     */
    public boolean isTerminated()
       { return persistor == null ; }

    /**
     * Tests whether this session is open.
	 *
     * <p>A session is open (or in a transaction) once
     * <a href="#begin()"><tt>begin</tt></a> is called and until
     * <a href="#commit()"><tt>commit</tt></a> or
     * <a href="#abort()"><tt>abort</tt></a> is called.</p>
	 *
     * @return	True if this session is in a transaction; otherwise, false.
	 */
    public boolean isOpen()
        { return persistor().isOpen() ; }

	/**
     * Gets the initial capacity of
     * this session's Objectivity/DB cache.</p>
     *
     * @return  The initial capacity of this session's Objectivity/DB cache:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in this session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * the returned value is:
	 * <ul type=circle>
	 * <li>
	 * The initial number of buffer pages allocated in the session's default
	 * small-object buffer pool.
	 * <li>
	 * The initial number of buffer entries allocated in the session's default
	 * large-object buffer pool (equivalently,
	 * the initial number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by this session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), the returned value is:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the initial number of bytes allocated in
	 * each nondefault small-object buffer pool.
	 * The initial number of bytes is equal to the returned value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The initial number of buffer entries allocated in each nondefault
	 * large-object buffer pool (equivalently, the initial number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 */
    public int getCacheInitialPages()
        { return persistor().getCacheInitialPages() ; }

	/**
     * Gets the maximum capacity of
     * this session's Objectivity/DB cache.</p>
	 *
     * @return      The maximum capacity of this session's Objectivity/DB cache:
	 * <ul type=disc>
	 * <li>
	 * For the default buffer pools in this session's Objectivity/DB cache
	 * (the pools accommodating pages of the system database's page size),
	 * the returned value is:
	 * <ul type=circle>
	 * <li>
	 * The maximum number of buffer pages that can be allocated in the session's default
	 * small-object buffer pool.
	 * <li>
	 * The maximum number of buffer entries that can be allocated in the session's default
	 * large-object buffer pool (equivalently,
	 * the maximum number of large objects to be accommodated by the pool).
	 * </ul>
	 * <li>
	 * For any nondefault buffer pools created by this session's Objectivity/DB cache
	 * (pools accommodating pages of a nondefault size), the returned value is:
	 * <ul type=circle>
	 * <li>
	 * A factor for computing the maximum number of bytes that can be allocated in
	 * each nondefault small-object buffer pool.
	 * The maximum number of bytes is equal to the returned value
	 * multiplied by the system database's storage-page size.
	 * <li>
	 * The maximum number of buffer entries that can be allocated in each nondefault
	 * large-object buffer pool (equivalently, the maximum number of large
	 * objects to be accommodated by each pool).
	 * </ul>
	 * </ul></p>
	 */
    public int getCacheMaximumPages()
        { return persistor().getCacheMaximumPages() ; }

	/**
	 * Gets the threads that are joined to this session.</p>
	 *
	 * @return		A vector containing the threads joined to this session. The
	 * returned vector is empty if no threads are joined to this session.
	 */
    public Vector threads()
        { return persistor().threads() ; }

    /**
     * Begins a transaction.
     *
     * <p>
     * If this session's thread policy is restricted, the thread that calls
	 * this method must be joined to this session.
     *
	 * <p>Although this session's transactions cannot be nested, calls to this session's
	 * <tt>begin</tt> method can be nested (called from within a transaction).
     * The first (unnested) call to <tt>begin</tt> starts the transaction,
	 * causing this session to be in a new transaction when the call returns.
	 * This call also sets this session's nest count to 1.
	 * Any subsequent (nested) calls to <tt>begin</tt> during the same transaction
	 * simply increment this session's nest count.
	 * If the transaction is to be committed,
	 * each call to <tt>begin</tt> must have a matching call to {@link #commit <tt>commit</tt>},
	 * where each call to <tt>commit</tt> is paired with the most recently executed <tt>begin</tt>.
	 * If the transaction is to be aborted, a single call to {@link #abort <tt>abort</tt>} is sufficient,
	 * regardless of the number of calls to <tt>begin</tt>.
     *
     * <p><b>Note:</b> You may not call this method if this session's
     * Objectivity/DB transaction resource manager
     * is in a global transaction.</p>
     */
    public void begin()
        { persistor().begin() ; }

    /**
     * Aborts this session's current transaction.
     *
     * <p>This session must be in a transaction when you call this method.
     * If this session's thread policy is restricted, the thread that calls
	 * this method must be joined to this session.
     *
     * <p>This method terminates the current transaction
	 * regardless of the number of nested calls to {@link #begin <tt>begin</tt>}, and
	 * discards (rolls back) any modifications that were made by
	 * Objectivity/DB update operations
     * executed since the last checkpoint
	 * or since the beginning of the transaction, if
     * {@link #checkpoint <tt>checkpoint</tt>} was not
     * called during the transaction.
     * The connected federated
	 * database is left in the logical state it was in before
	 * the rolled-back operations were performed.
	 *
	 * <p>Aborting a transaction releases all locks
	 * held by this session, and resets the session's nest count to
	 * zero so that a subsequent call to <tt>begin</tt> will start a new transaction.
	 *
     * <p>All the objects that belong to this session
	 * are marked as needing to have their data fetched,
	 * and those objects are no longer marked as modified.
	 * Before you can access one of these objects in a subsequent transaction,
	 * you must call the object's <a href="ooObj.html#fetch()"><tt>fetch</tt></a> method
	 * to ensure that you have its most current persistent data.
     *
     * <p>An exception is thrown if an abort operation cannot be completed --
     * for example because the failure of a data-server host prevents
     * access to a database file in which updates must be rolled back.  In
     * this case, the transaction's locks and journal files are left as is,
     * and the transaction must be recovered later.
     *
     * <p>Whether successful or not, aborting resets the session's
     * transaction open mode to indicate that the session is not in an
     * active transaction.</p>
     */
    public void abort()
        { persistor().abort() ; }

    /**
     * Commits this session's current transaction.
     *
     * <p>This session must be in a transaction when you call this method.
     * If this session's thread policy is restricted, the thread that calls
	 * this method must be joined to this session.
	 *
	 *
	 * <p>If the call to <tt>commit</tt> is unnested (that is, if the nest count is 1 and
	 * the call matches an unnested call to {@link #begin <tt>begin</tt>}), the transaction is committed.
	 * Otherwise, if the call to <tt>commit</tt> is nested,
	 * it decrements this session's nest count
	 * <i>without</i> committing the transaction.
	 *
	 * <p>Committing a transaction
	 * terminates it and saves modifications made by any Objectivity/DB
	 * update operations that were executed since the last checkpoint
	 * or since the beginning of the transaction,
	 * if {@link #checkpoint <tt>checkpoint</tt>} was not
     * called during the transaction.
     * When modifications are saved in the connected federated database,
	 * they become visible to other transactions.
	 * The objects that belong to this session are no
	 * longer marked as modified.
	 *
	 * <p>Committing the transaction resets the session's nest count to 0 so that a subsequent call
	 * to <tt>begin</tt> will start a new transaction.
	 *
     * <p>Committing the transaction releases all locks held by this session.
	 * Because these objects are no longer locked,
	 * they are available for a different session to modify.
	 * Before you access one of these objects in a subsequent transaction,
	 * you should call the object's <a href="ooObj.html#fetch()"><tt>fetch</tt></a> method
	 * to ensure that you have its most current persistent data.
	 *
	 * <p>When the call returns,
	 * this session will be outside a transaction.
	 *
	 * <p>After a transaction is committed, you can call the
     * session's {@link #terminate <tt>terminate</tt>} method if you want to
     * release the session's Objectivity/DB cache and other resources
     * immediately.  If
     * you do not call <tt>terminate</tt>, the session's resources are
     * released automatically when the session goes out of scope.</p>
     *
     * @see #checkpoint
	 * @see #nestCount
	 *
     */
    public void commit()
        { persistor().commit() ; }

	/**
     * Commits all Objectivity/DB operations executed since the last checkpoint,
     * retaining all locks acquired during the current transaction.
     *
     * <p>This session must be in a transaction when you call this method.
     * If this session's thread policy is restricted, the thread that calls
	 * this method must be joined to this session.
     *
     * <p>All Objectivity/DB operations executed since the most recent call to
     * <a href="#begin()"><tt>begin</tt></a> or <tt>checkpoint</tt> are
	 * reflected in the connected federated database.
	 * The objects that belong to this session
     * are no longer marked as modified.
     *
     * <p>When the method returns, this session will still be in a
	 * transaction.</p>
     *
     * @see #commit
	 */
    public void checkpoint()
        { persistor().checkpoint(oo.NO_DOWNGRADE) ; }

	/**
     * Commits all Objectivity/DB operations executed since the last checkpoint and
     * potentially downgrades all locks acquired during the current transaction.
     *
     * <p>This session must be in a transaction when you call this method.
     * If this session's thread policy is restricted, the thread that calls
	 * this method must be joined to this session.
     *
     * <p>All Objectivity/DB operations executed since the most recent call to
     * <a href="#begin()"><tt>begin</tt></a> or <tt>checkpoint</tt> are
	 * reflected in the connected federated database.
     * The objects that belong to this session
     * are no longer marked as modified.
	 *
     * <p>When the method returns, this session will still be in a
	 * transaction.</p>
     *
     * @param 	 downGradeMode   The lock downgrade mode;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>NO_DOWNGRADE</tt> <dd>Preserve all locks held by this
     * session.</dd>
     * <dt> <tt>DOWNGRADE_ALL</tt> <dd>Downgrade all locks to read locks.</dd>
     * </dd></dl></dl></p>
     *
     * @see #commit
	 */
    public void checkpoint(int downGradeMode)   // Objy extension
        { persistor().checkpoint(downGradeMode) ; }

	/**
     * Identifies the application containing this session object as a
     *  special-purpose upgrade application for converting objects after
     * schema evolution.
     *
     * <p>This method is included for interoperability.  Changes to Java
     * class definitions never leave the federated database schema in a state
     * that requires an upgrade application. However, changes to the schema
     * made by the Objectivity/C++ DDL processor can require an
     * upgrade application to convert objects of the modified class before
     * any of those objects can be accessed. Typically, a C++ developer who
     * makes such modifications to the schema also runs an Objectivity/C++
     * upgrade application.  This method makes it possible to run an
     * Objectivity for Java upgrade application instead.
     *
     * <p>To run an upgrade application, the open mode of this session must
     * be read/write. You must call this method before
     * calling {@link #begin <tt>begin</tt>} to begin the first and only
     * transaction.  You can call the {@link #getFD <tt>getFD</tt>} method to
     * get a federated-database object representing the connected database.
     * The single transaction of this application must call the
     * {@link ooFDObj#upgradeObjects <tt>upgradeObjects</tt>} method
     * of the federated-database object.  That method
     * initiates the upgrade process.  Objectivity/DB
     * will issue an error if the federated database schema does not
     * include any pending changes that require an upgrade
     * application.
     *
     * <p>For additional information about upgrade applications, refer to the
     * Objectivity/C++ product documentation.</p>
     */
    public void upgrade()
        { persistor().upgrade() ; }

    /**
     * Sets how long this session is to wait for an Objectivity server to
     * respond before signaling a timeout error.
     *
     * <p>By default, a session waits 25 seconds for the lock server or
     * AMS to respond to a request. However, an Objectivity server running on
     * a busy host machine may need more time to respond. If your application
     * consistently signals a lock-server or AMS timeout error, you can call
     * this method to increase the timeout period; alternatively, you can
     * consider running the Objectivity server on a less congested host.
	 *
	 * <p><b>Note:</b> On Windows, the operating system limits the network
	 * timeout period to 20 seconds, even if your application sets a higher value for a session.
	 * </p>
     *
     * @param 	 time Number of seconds to wait before signaling
     * a timeout error.
     */
    public void setRPCTimeout(long time)
        { persistor().setRPCTimeout(time) ; }

    /**
     * Sets the number of times this session should retry to connect to an
     * Objectivity server before reporting a connection error.
     *
     * <p>An application may fail to connect to an Objectivity server either
     * because that server is unavailable or because the network connection
     * to the server is heavily loaded. If your application occasionally
     * signals a lock server or AMS connection error when you know that these
     * Objectivity servers are running, you may want to configure your
     * sessions to repeat a connection attempt that fails.
     *
     * <p>If this method is never called, the session uses the number of
     * retries specified in the <tt>OO_CONNECT_RETRIES</tt> environment
     * variable.  If the environment variable is not set, it uses
     * a default value of 0 if the application is running on a UNIX or Macintosh platform,
     * and a default value of 2 if the application is running on a Windows
     * platform.</p>
     *
     * @param 	 retries Number of additional attempts to
     * connect to an Objectivity server, after an initial unsuccessful
     * attempt. Specify 0 to make no further attempts after an initial
     * attempt fails.
     */
    public void setConnectRetries(int retries)
	{ persistor().setConnectRetries(retries) ; }


    /**
     * Gets the index mode for this session.</p>
     *
     * @return The index mode; one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>INSENSITIVE</tt></dt> <dd>When this session's transaction is
	 * committed, indexes are updated automatically.</dd>
     *  <dt><tt>SENSITIVE</tt></dt> <dd>Indexes are updated automatically
     * during the transaction immediately after  an indexed object is deleted
	 * or an object of the indexed class is made persistent.</dd>
     *  <dt><tt>EXPLICIT_UPDATE</tt></dt> <dd>The application must update
	 * indexes manually by explicit calls to the
	 * <a href="ooObj.html#updateIndexes()"><tt>updateIndexes</tt></a>
	 * method of each new object or modified indexed object.</dd>
     * </dd></dl></dl></p>
     *
     * @see #setIndexMode
     */
    public int getIndexMode()
        { return persistor().getIndexMode() ; }

    /**
     * Gets the MROW mode for this session.</p>
     *
     * @return	<tt>MROW</tt> if this session has
 	 * MROW (Multiple Readers, One Writer) enabled;
     * otherwise, <tt>NO_MROW</tt>.</P>
     *
     * @see #setMrowMode
     *
     */
    public int getMrowMode()
        { return persistor().getMrowMode() ; }

	/**
     * Gets the open mode of this session.</p>
	 *
     * @return  The open mode of this session; one of the following constants defined
	 * in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 * <dt><tt>openReadOnly</tt><dd>This session allows
	 * read-only access.</dd>
	 * <dt><tt>openReadWrite</tt><dd>This session allows
	 * read/write access. </dd>
     * </dd></dl></dl></p>
     *
     * @see #setOpenMode
	 */
    public int getOpenMode()
        { return persistor().getOpenMode() ; }

	/**
     * Gets the thread policy for this session.</p>
     *
     * @return		The thread policy for this session;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>THREAD_POLICY_RESTRICTED</tt></dt>     <dd>A thread must be joined
     * to this session before it can perform any Objectivity/DB operation on this
     * session and its objects.</dd>
     *  <dt> <tt>THREAD_POLICY_UNRESTRICTED</tt></dt>    <dd>Any thread can
	 * interact with this session and its objects. </dd>
     * </dd></dl></dl></p>
	 *
	 * @see #setThreadPolicy
	 */
    public int getThreadPolicy()
        { return persistor().getThreadPolicy() ; }

    /**
     * Gets the lock-waiting option for this session.</p>
     *
     * @return      The lock-waiting option for this session; one of the following
	 * constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>NO_WAIT</tt></dt>    <dd>The session does not wait for
     * locks.</dd>
     *  <dt> <tt>WAIT</tt></dt>       <dd>The session waits indefinitely for
     * locks.</dd>
     *  <dt> <i><tt>n</tt></i></dt>   <dd>The session waits for <tt><i>n</i></tt> seconds,
     * where 1 <= <tt><i>n</i></tt> <= 14400. If <tt><i>n</i></tt> = 0, it is treated as
     * <tt>NO_WAIT</tt>. If <tt><i>n</i></tt> is less than 0 or greater than 14400,
     * it is treated as <tt>WAIT</tt>.</dd>
     * </dd></dl></dl></p>
     *
     * @see #setWaitOption
     */
    public int getWaitOption()
        { return persistor().getWaitOption() ;}

	/**
	 * Tests whether this session can create local representations for persistent
	 * objects for which no class definition is available.
	 *
	 * <p>If this method returns true, you can iterate over all objects in a container,
	 * even if some of those objects are of classes that are not defined in your application
	 * (perhaps because they were added to the schema by Objectivity/C++).  
	 * </p>
	 *
	 * @return	True if this session can access persistent objects without a corresponding class
	 * definition; false if this session throws an exception when it tries to access such
	 * an object.</p>
	 *
	 * @see     #setAllowUnregisterableTypes
	 */
    public boolean getAllowUnregisterableTypes()
        { return persistor().getAllowUnregisterableTypes() ; }

    /**
     * Tests whether where this session's object iterators will return
     * local representations of persistent objects or
	 * <a href="../../as/app/package-summary.html">Active Schema</a> objects.</p>
     *
     * <p>If this method returns true, calls to an object iterator's
     * <a href="Iterator.html#next()">next</a> method will return instances of
	 * <a href="../../as/app/Class_Object.html">
     * <tt>com.objy.as.app.Class_Object</tt></a>.
	 * Otherwise such calls return
     * persistent objects that inherit from the <a href="ooObj.html"><tt>ooObj</tt></a> class or
	 * implement the <a href="../iapp/Persistent.html"><tt>Persistent</tt></a> interface.</p>
     *
     * @return     True if object iterators in this session
     * return <tt>Class_Object</tt> instances; false if they return
     * local representations of persistent objects.</p>
     *
     * @see     #setReturn_Class_Object
     */
    public boolean getReturn_Class_Object()
        { return persistor().getReturn_Class_Object() ; }

    /**
     * Gets whether automatic container refetch has been enabled for this session.</p>
     *
     * @return	True if automatic container refetch has been enabled;
     * otherwise, false.</p>
     *
     * @see #setContainerRefetch
     */
    public boolean getContainerRefetch()
        { return persistor().getContainerRefetch() ; }

    /**
     * Gets the iterator policy for this session.</p>
     *
     * @return		The iterator policy for this session;
     * one of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>CLOSE_ITR</tt></dt>     <dd>After checkpoint is called all
     * open iterators are closed.</dd>
     *  <dt> <tt>KEEP_ITR</tt></dt>    <dd>After checkpoint is called all
     * open iterators are kept with their state preserved for use in
     * subsequent transactions.</dd>
     * </dd></dl></dl></p>
     *
     * @see #setIteratorPolicy
     */
    public int getIteratorPolicy()
        { return persistor().getIteratorPolicy() ; }



	/**
	 * @deprecated    See {@link Connection#setPersistencePolicy <tt>Connection.setPersistencePolicy</tt>}
	 * 
	 * <p>Gets whether this session can form relationships between
	 * transient objects or work with a transient <a href="../util/ooMap.html"> name map</a>.</p>
	 *
	 * @return True if this session can form relationships between
	 * transient objects or add elements to a transient name map; otherwise, false.</p>
	 *
	 */
    @Deprecated // OBJY-17572
	public boolean getFormTransientRelationships()
        { return persistor().getFormTransientRelationships() ; }

    /**
     * Specifies when indexes are updated
     * relative to when indexed objects are updated.
	 *
     * <p>If this method is not called, automatic updating of indexes
     * will occur when this session's transaction is committed.
	 *
	 * <p>For guidelines on selecting a value for the index mode, see
	 * <a href="../../../../../guide/jgdIndexes.html#Updating Indexes">
	 * Updating Indexes</a>.
	 * </p>
     *
     * <p>This method throws an exception if this session is in a
	 * transaction.</p>
     *
     * @param 	 mode The index mode; one of the following constants
	 * defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>INSENSITIVE</tt></dt> <dd>When this session's transaction is
	 * committed, indexes are updated automatically.</dd>
     *  <dt><tt>SENSITIVE</tt></dt> <dd>Indexes are updated automatically
     * during the transaction immediately after  an indexed object is deleted
	 * or an object of the indexed class is made persistent.
     * Immediate updates ensure that you do not have to wait until commit for changes to be
     * reflected in the index. </dd>
     *  <dt><tt>EXPLICIT_UPDATE</tt></dt> <dd>The application must update
	 * indexes manually by explicit calls to the
	 * <a href="ooObj.html#updateIndexes()"><tt>updateIndexes</tt></a>
	 * method of each new object or modified indexed object.</dd>
     * </dd></dl></dl></p>
     *
     * @see #getIndexMode
     */
    public void setIndexMode(int mode)
        { persistor().setIndexMode(mode) ; }

    /**
     * Specifies whether object iterators initialized by this session should
     * skip internal persistent objects.
     *
     * <p>Typically, when you initialize an object iterator to find
     * persistent objects, you are interested in objects of
     * persistence-capable classes only, <i>not</i>
	 * <a href="../../../../../guide/jgdOrganization.html#Internal Persistent Objects">
	 * internal persistent objects</a>.
     * You can call this method to control whether object iterators skip
     * or include internal persistent objects.
     *
     * <p>If this method is never called, the object iterators initialized
     * by this session always skip internal persistent objects and find only
     * objects of persistence-capable classes.</p>
     *
     * @param 	 skipFlag    True to skip internal persistent
     * objects and false to include them.
     *
     */
    public void setIteratorSkipInternal(boolean skipFlag)
        { persistor().setIteratorSkipInternal(skipFlag) ; }

	/**
	 * Sets whether this session can create local representations for persistent
     * objects for which no class definition is available.
     *
     * <p>By default, a session throws an exception when it finds a persistent object
     * of a class that is not defined in the application.  
	 * You can change this behavior
	 * by calling this method with <tt><i>option</i></tt> set to true.  
	 * Doing so enables the session to iterate over all objects in a container,
	 * even if some of those objects are of classes that are not defined in the application
	 * (for example, because they were added to the schema by Objectivity/C++).  
	 * 
	 * <p> When the session 
	 * encounters an object of a class without an available definition,
	 * Objectivity/DB checks whether the application has a definition for a superclass of the object's class.
	 * If so, the session can treat the object as an instance of that superclass,
	 * and can access the methods or fields defined by that superclass and its superclasses (if any). 
	 * Otherwise, the session can treat the object as an instance of <tt>ooObj</tt>.
	 * The session should not attempt to access any methods or fields
	 * of classes that are not available to the application.
	 * (If the application is an
	 * <a href="../../as/app/package-summary.html">Active Schema</a> application, 
	 * it can access the object's persistent data, however.)
	 * </p>
	 *
     * @param 	 option  True to allow this session to access persistent objects
     * without a corresponding class definition; false to have this session throw an exception
     * when it tries to access such an object.</p>
     *
	 * @see     #getAllowUnregisterableTypes
	 */
    public void setAllowUnregisterableTypes(boolean option)
        { persistor().setAllowUnregisterableTypes(option) ; }

    /**
     * Specifies whether this session's object iterators will return local representations
     * of persistent objects or <a href="../../as/app/package-summary.html">Active Schema</a> objects.</p>
     *
     * <p>If you never call this method, or you call it with <tt>option</tt> set to false,
	 * then calls to the <a href="Iterator.html#next()">next</a> method during iteration will return
     * persistent objects
	 * as instances of classes that inherit from the <a href="ooObj.html"><tt>ooObj</tt></a> class or
	 * implement the <a href="../iapp/Persistent.html"><tt>Persistent</tt></a> interface.</p>
	 *
	 * <p>You can call <tt>setReturn_Class_Object</tt> to change this behavior,
	 * so that calls to <tt>next</tt> will return instances of
	 * <a href="../../as/app/Class_Object.html"><tt>com.objy.as.app.Class_Object</tt></a>.
	 * Such objects are used in Active Schema applications where the class definition is not
     * available.</p>
     *
     * @param 	 option  True to cause object iterators in this
     * session to return found persistent objects as <tt>Class_Object</tt> instances;
	 * false to cause object iterators to return
     * local representations of found persistent objects.</p>
     *
     * @see     #getReturn_Class_Object
     */
    public void setReturn_Class_Object(boolean option)
        { persistor().setReturn_Class_Object(option) ; }

    /**
     * Specifies whether to enable or disable MROW for this session.
     *
	 * <p>When MROW is enabled, this session can obtain a read lock
	 * on an object even if another client has a write lock on the object.
	 * This session can obtain a write lock on an object if any client that has
	 * a read lock on this object obtained that read lock in a session with
	 * MROW enabled.
	 *
     * <p>If this method is not called, MROW is disabled for this session.
     *
     * <p>This method throws an exception if this session is in a
	 * transaction.</p>
     *
     * @param 	 mode  The MROW mode for this session;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>MROW</tt></dt>    <dd>Enable MROW.</dd>
     *  <dt> <tt>NO_MROW</tt></dt>  <dd>Disable MROW.</dd>
     * </dd></dl></dl></p>
     *
     * @see #getMrowMode
     */
    public void setMrowMode(int mode)
        { persistor().setMrowMode(mode) ; }

	/**
     * Sets the open mode of this session.
	 *
     * <p>The open mode limits the kinds of locks this session can obtain
     * on the storage objects and persistent objects.
	 * An open mode of <tt>openReadWrite</tt> permits this session to obtain
	 * read or write locks; an open mode of <tt>openReadOnly</tt>
	 * permits it to obtain read locks only.</p>
     *
     * <p>If this method is never called, the default value of the open mode
     * for a session is the open mode of its connection object.
	 *
     * <p>If this session is in a transaction, you can change the
	 * current open mode from read-only to read/write. If this session is
	 * outside a transaction, you can set the open mode to either
	 * read-only or read/write.
	 *
	 * <p><b>Note: </b>This method throws an exception if you attempt to
	 * change the open mode from read/write to read-only while the
	 * session is in a transaction.</p>
	 *
     * @param 	 mode	The open mode for this
     * session; one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
	 *  <dt><tt>openReadOnly</tt><dd>This session allows
	 * read-only access.</dd>
	 *  <dt><tt>openReadWrite</tt><dd>This session allows
	 * read/write access. </dd>
	 * </dd></dl></dl>
	 *
     * <p>The open mode is limited by the open mode of the
     * <a href="Connection.html">connection</a>.
     * If you try to set the session open mode to <tt>openReadWrite</tt>
	 * when its connection open mode is <tt>openReadOnly</tt>,
     * an <tt>ObjyRuntimeException</tt> will be thrown when the session
	 * begins a transaction.</P>
	 *
     * @see #getOpenMode
	 */
    public void setOpenMode(int mode)
        { persistor().setOpenMode(mode) ; }

	/**
     * Specifies whether automatic recovery on the local host should be
     * enabled.
     *
     * <p>If automatic recovery is enabled, the next time this session begins
     * a transaction, Objectivity/DB will roll back
     * any incomplete transactions started by other applications that are no
     * longer active, provided the inactive status of these applications can
     * be verified. In general, Objectivity/DB can directly verify the status
     * of other applications running on the local host; however, the status
     * of a remote application cannot be verified if the remote host or its
     * network link has failed.
     *
     * <p>Checking whether automatic recovery is needed can be a time-consuming
     * process.  After any necessary recovery has been
	 * performed, automatic recovery will be
     * disabled so that the process isn't repeated
	 * each time this session begins a transaction.
     *
     * <p>Automatic recovery is disabled by default.
	 *
     * <p>This method throws an exception if this session is in a
	 * transaction.</p>
     *
     * @param 	 automatic    True to enable automatic recovery;
     * false to disable automatic recovery.</P>
     *
     * @see #isRecoveryAutomatic
	 */
    public void setRecoveryAutomatic(boolean automatic)
        { persistor().setRecoveryAutomatic(automatic) ; }

	/**
     * Sets the thread policy for this session.</p>
     *
     * @param 	 policy	The thread policy for this session;
	 * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>THREAD_POLICY_RESTRICTED</tt></dt>     <dd>A thread must be joined
     * to this session before it can perform any Objectivity/DB operation with this
     * session and its objects.</dd>
     *  <dt> <tt>THREAD_POLICY_UNRESTRICTED</tt></dt>    <dd>Any thread can
	 * interact with this session and its objects. </dd>
     * </dd></dl></dl></p>
	 *
	 * @see #getThreadPolicy
	 */
    public void setThreadPolicy(int policy)
        { persistor().setThreadPolicy(policy) ; }

    /**
     * Specifies whether this session should wait for
     * locks held by other sessions.
     *
     * <p>If this method is not called, the
     * session will not wait for locks.
     *
	 * <p>A session's lock-waiting timeout period is ignored whenever an MROW
     * transaction attempts to upgrade a read lock to a write lock on
     * potentially stale data.  For example, if an MROW transaction locks a
     * container for read, and then a concurrent transaction updates the
     * container (or simply locks it for write), a subsequent attempt by the
     * MROW transaction to upgrade its read lock fails immediately.
     *
     * <p>This method throws an exception if this session is in a
	 * transaction.</p>
	 *
	 * <p>For additional information, see
	 * <a href="../../../../../guide/jgdLocking.html#Lock Waiting">
	 * Lock Waiting</a>.</p>
     *
     * @param 	 option  The lock-waiting option
	 * to be used by this session;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>NO_WAIT</tt></dt>      <dd>Do not wait for locks.</dd>
     *  <dt> <tt>WAIT</tt></dt>         <dd>Wait indefinitely for locks.</dd>
     *  <dt> <i><tt>n</tt></i></dt>     <dd>Wait for <tt><i>n</i></tt> seconds,
     * where 1 <= <tt><i>n</i></tt> <= 14400. If <tt><i>n</i></tt> = 0, it is treated as
     * <tt>NO_WAIT</tt>. If <tt><i>n</i></tt> is less than 0 or greater than 14400,
     * it is treated as <tt>WAIT</tt>.</dd>
     * </dd></dl></dl></p>
     *
     * @see #getWaitOption
     * @see #getMrowMode
     * @see #setMrowMode
     */
    public void setWaitOption(int option)
        { persistor().setWaitOption(option) ; }

    /**
     * Specifies how errors are reported when a source object is fetched but
     * errors occur trying to fetch its referenced destination
     * objects.
     *
     * <p>If this method is not called, a
	 * <a href="../FetchCompletedWithErrors.html">
	 * <tt>FetchCompletedWithErrors</tt></a> exception is thrown for each
     * destination object that could not be found or locked.</p>
     *
     * @param 	 option  The fetch-error reporting option
	 * to be used by this session;
     * one of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>ALL_ERRORS</tt></dt>      <dd>Throw a
	 * <tt>FetchCompletedWithErrors</tt></a> exception for each
     * destination object that could not be found or locked. </dd>
     *  <dt> <tt>INDIVIDUAL_ERROR</tt></dt>         <dd>Throw a single
	 * <tt>ObjyRuntimeException</tt>
     * for the first destination object that cannot be found or accessed,
     * and terminate the fetch operation immediately.  The
     * <tt>ObjyRuntimeException</tt> has more specific error information
     * than a <tt>FetchCompletedWithErrors</tt> exception.</dd>
     * </dd></dl></dl></p>
     */

    public void setFetchErrorFormat(int option)
        { persistor().setFetchErrorFormat(option) ; }

    /**
     * Specifies whether to enable automatic container refetch for this session.
     *
     * <p>Enabling automatic container refetch allows you to quickly
	 * refetch objects from the same container
	 * in subsequent transactions of this session.
	 * After you enable automatic container refetch,
	 * fetching one object from a container
     * automatically refetches any object (from the same container) that
     * was fetched in a previous transaction of this session. Refetching
     * is performed only as necessary (that is, only if the container has been
	 * updated since the last time one of its objects was fetched).</p>
     *
     * <p>For each chained fetch operation, the object is not checked
     * to see whether fetch is required, and all persistent data is read.</p>
     *
     * @param 	 option    True to enable automatic
     * container refetch; false to disable automatic container
     * refetch.</P>
     *
     * @see #getContainerRefetch
     */
    public void setContainerRefetch(boolean option)
        { persistor().setContainerRefetch(option) ; }

    /**
     * Specifies whether iterators are kept open after checkpointing.
	 *
     * <p>If you do not call this method,
	 * iterators are closed when you checkpoint a transaction.
     * (Iterators are always closed after commit or abort.)</p>
     *
     * @param 	 policy	The iterator policy for this session;
     * one of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt> <tt>CLOSE_ITR</tt></dt>     <dd>Closes all open iterators
	 * when the session's <tt>checkpoint</tt> method is called.</dd>
     *  <dt> <tt>KEEP_ITR</tt></dt>    <dd>Causes the session's
	 * <tt>checkpoint</tt> method to preserve the state of all
     * open iterators for use in subsequent transactions.</dd>
     * </dd></dl></dl></p>
     *
     * @see #getIteratorPolicy
     */
    public void setIteratorPolicy(int policy)
        { persistor().setIteratorPolicy(policy) ; }

	/**
	 * @deprecated    See {@link Connection#setPersistencePolicy <tt>Connection.setPersistencePolicy</tt>}
	 * 
	 * <p>Specifies whether this session can work with relationships between
	 * transient objects;
	 * also specifies whether this session can work with transient <a href="../util/ooMap.html">name maps</a>.</p>
	 *
	 * <p>This method sets the relationship-persistence policy for this session.</p>
	 *
	 * <p>If you do not call this method, or if you call it with <tt><i>option</i></tt> set to false,
	 * the session uses the <i>standard relationship-persistence policy</i>. Under this policy:
	 * <ul type=disc>
	 * <li>Any relationship formed between two transient objects in this session
	 * will cause those objects to be made persistent immediately.
	 *
	 * <li>Any name map created in the session must be persistent before you can add elements to it.
	 * An attempt to add an element to a transient name map throws an <tt>ObjyNotPersistentException</tt>.
	 * </ul>
	 *
	 * <p>If you call this method with <tt><i>option</i></tt> set to true,
	 * this session uses the <i>transient-relationships policy</i>.
	 * Under this policy,
	 * you can delay the persistence of transient objects linked by relationships,
	 * and you can add elements to transient name maps.
	 *
	 *
	 * <p>You normally change the relationship-persistence policy for a transaction
	 * by calling this method at the beginning of the transaction. Switching this policy
	 * back and forth in the same transaction is not recommended.</p>
	 *
	 * <p>Regardless of the policy you set, a transient source object can be made persistent implicitly
	 * only if its class
	 * <a href="../../../../../guide/jgdDefiningClasses.html#Implementing Automatic Persistence With Relationships">
	 * implements automatic persistence with relationships</a>.</p>
	 *
	 *
	 * @param 	 option    True to set the transient-relationships policy for this session;
	 * false to set the standard relationship-persistence policy.</P>
	 *
     * @exception   com.objy.db.ObjyRuntimeException
     * If you try to set the transient-relationships policy in this session
	 * after {@link #setAllowTransientRelationships disallowing} it, or if you try to set the standard relationship-persistence policy when the connection's
	 * {@link Connection#setPersistencePolicy persistence policy} is set to <tt>oo.Reachability</tt>.
	 * </p>
	 *
	 */
    @Deprecated // OBJY-17572
    public void setFormTransientRelationships(boolean option)
        { persistor().setFormTransientRelationships(option) ; }

	/**
	 * @deprecated    See {@link Connection#setPersistencePolicy <tt>Connection.setPersistencePolicy</tt>}
	 * 
	 * <p>Specifies whether to allow the transient-relationships policy to be set in this session,
	 * or to enforce the standard relationship-persistence policy for lifetime of this session.</p>
	 *
	 * <p>Any call to this method must occur before the session begins its first transaction.
	 *
	 * <p>If you never call this method, or if you call it with <tt><i>option</i></tt> set to true,
	 * this session can change its
	 * relationship-persistence policy.
	 * That is, you can call
	 * {@link #setFormTransientRelationships <tt>setFormTransientRelationships</tt>}
	 * any number of times in the session, setting the policy differently
	 * for different transactions.
	 *
	 * <p>If you call this method with <tt><i>option</i></tt> set to false,
	 * this session must use the standard relationship-persistence policy in all of its transactions.
	 * Attempting to set the transient-relationships policy in this session
	 * will cause an <tt>ObjyRuntimeException</tt> to be thrown.
	 *
	 *
	 * <p>Enforcing the standard relationship-persistence policy for an entire session
	 * can improve the runtime speed of certain operations.
	 * In particular, when objects of persistence-capable classes are created in such a session,
	 * they are created without the overhead that enables them
	 * to remain transient in relationships and name maps.
	 * Omitting this overhead can improve the speed of object-creation operations.
	 * However, you should request such enforcement
	 * only if you know you will never need to develop graphs of related transient objects
	 * or add elements to a transient name map
	 * in any transaction of the session.
	 * </p>
	 *
	 * @param 	 option    True to allow the transient-relationships policy
	 * to be set in this session;
	 * false to enforce the standard relationship-persistence policy for the entire session.</P>
	 * 
	  * @exception   com.objy.db.ObjyRuntimeException
     * If you try to enforce the standard relationship-persistence policy when the connection's
	 * {@link Connection#setPersistencePolicy persistence policy} is set to <tt>oo.Reachability</tt>.
	 *
	 */
    @Deprecated // OBJY-17572
    public void setAllowTransientRelationships(boolean option)
	{ persistor().setAllowTransientRelationships(option) ; }

    @Deprecated // OBJY-17572
	public void setPersistUnreachableTransientsWithRelationshipToPersistent(boolean persist)
	{
		persistor().setPersistUnreachableTransientsWithRelationshipToPersistent(persist);
	}
	
    @Deprecated // OBJY-17572
	public boolean getPersistUnreachableTransientsWithRelationshipToPersistent()
	{
		return persistor().getPersistUnreachableTransientsWithRelationshipToPersistent();
	}
	
	/**
     * Joins the currently active Java thread with this session.
     *
     * <p>If the thread is already joined with this session,
     * then this method has no effect. If the thread was joined
     * with another session, it leaves that session and joins
     * this session.</p>
     *
     * @see #isJoined()
     * @see #leave()
	 */
    public void join()          // ODMG
        { persistor().join() ; }

    /**
     * Causes the currently active Java thread to leave this session.
     *
     * <p>Threads should call this method before terminating.
     *
     * <p>This method will throw a <tt>NotJoinedException</tt> if the thread is
     * not joined with this session. You can call
     * <a href="#isJoined()"><tt>isJoined</tt></a> to test whether the
     * thread is joined with this session.</p>
     *
     * @see #join()
     * @see #isJoined()
	 */
    public void leave()         // ODMG
        { persistor().leave() ; }

	/**
     * Tests whether the currently active Java thread is joined with this
	 * session.</p>
	 *
	 * @return		True if the currently active thread is joined with this
	 * session; otherwise, false.</P>
	 *
     * @see #join()
	 */
    public boolean isJoined()   // ODMG
        { return persistor().isJoined() ; }

	/**
     * Tests whether the specified Java thread is joined with this
	 * session.</p>
	 *
	 * @param 	 thread	The thread to be tested.</P>
	 *
	 * @return		True if the specified thread is joined with this
	 * session; otherwise, false.
	 */
    public boolean isJoined(Thread thread)
        { return persistor().isJoined(thread) ; }

	/**
   	 * Gets the currently installed clustering strategy for this
	 * session.</p>
	 *
	 * <p>
	  * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * @return		The currently installed clustering strategy.</P>
	 *
	 * @see	#setClusterStrategy(ClusterStrategy)
	 */
    public ClusterStrategy getClusterStrategy()
        { return persistor().getClusterStrategy() ; }

	/**
   	 * Sets the clustering strategy for objects belonging to this session.
	 *
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
   	 * <p>All operations that cluster an object implicitly
   	 * call the session's
     * clustering strategy to determine how the object should be clustered.
     * Applications can also explicitly request
     * that an object be clustered by calling a session's
     * <a href="#requestCluster(java.lang.Object, com.objy.db.app.storage.ClusterReason, java.lang.Object)"><tt>requestCluster</tt></a> method.
     *
     * <p>An object that is clustered explicitly (by a direct call to
     * the
     * <tt>cluster</tt> method of a database, persistent container, or
	 * persistent basic object) is not subject to the clustering strategy.
     *
     * <p>If this method is not called, an instance of
     * <a href="storage/ClusterStrategy.html"><tt>ClusterStrategy</tt></a>
     * is installed as the clustering strategy.<p>
	 *
   	 * @param 	 clusterStrategy	The new clustering strategy
   	 * to be used by objects belonging to this session. To reinstall a
	 * standard clustering strategy, set this parameter to
	 * null.</P>
	 *
	 * @return		The previously installed clustering strategy.</P>
	 *
	 * @see	#getClusterStrategy
	 */
    public ClusterStrategy setClusterStrategy(ClusterStrategy clusterStrategy)
        { return persistor().setClusterStrategy(clusterStrategy) ; }

	/**
	 * Makes the specified object persistent and assigns it to the container
	 * or database selected by this session's clustering strategy.
	 *
	 * <p>If <tt><i>object</i></tt> is a basic object, this method assigns it
	 * to a container; if <tt><i>object</i></tt> is a container, this method assigns
	 * it to a database.</p>
	 *
	 * <p>
	 * <b>Note:</b> <i>For backward compatibility only. </i>This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. 
	 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
	 * </p>
	 *
	 * @param 	 requestObject	The object requesting
	 * that <tt><i>object</i></tt> be made persistent.</P>
	 *
	 * @param 	 reason	The reason for making
	 * <tt><i>object</i></tt> persistent.
	 * This parameter may be null if you are calling this method explicitly,
	 * and you are not using clustering reasons.</P>
	 *
	 * @param 	 object	The object being made persistent. If
	 * <tt><i>object</i></tt> is already persistent, this method throws an
	 * <tt>ObjyRuntimeException</tt>.
	 */
    public void requestCluster(Object requestObject, ClusterReason reason, Object object)
        { persistor().getClusterStrategy().requestCluster(requestObject, reason, object) ; }

	/**
     * Prints a summary of Objectivity/DB internal statistics to the
     * standard output stream (<tt>System.out</tt>);
     * used primarily for performance tuning.</p>
	 */
    public void printRunStatus()
        { persistor().printRunStatus() ; }

	/**
     * Enables or disables hot mode for this session.
     *
     * <p>Enabling hot mode causes Objectivity/DB
     * to delay performing certain overhead operations for frequently accessed
     * objects until they are no longer being accessed.
     *
     * <p>If this method is not called, hot mode is enabled for this session.</p>
	 *
	 * <p>For guidelines on selecting a value for hot mode,
	 * see
	 * <a href="../../../../../guide/jgdPerformance.html#Delaying Format Conversions in the Objectivity/DB Cache">
	 * Delaying Format Conversions in the Objectivity/DB Cache</a>.</p>
	 *
     * @param 	 mode     True to enable hot mode; false to disable it.
	 */
    public void setHotMode(boolean mode)
        { persistor().setHotMode(mode) ; }

	/**
     * Sets the suggested maximum number of bytes in the large-object
     * memory pool in this session's Objectivity/DB cache.
     *
     * <p>If this method is not called, the default size of the
     * large-object memory pool is <tt><i>cacheMaximumPages</i>*<i>pageSize</i></tt>,
     * where <tt><i>cacheMaximumPages</i></tt>
     * is the maximum number of buffer entries allowed for
     * the large-object buffer pool (set when the session was
	 * created) and
     * <tt><i>pageSize</i></tt> is the  storage-page size for the federated database's system database.
	 *
	 * <p>For additional information, see
     * <a href="../../../../../guide/jgdCache.html#Controlling the Objectivity/DB Cache's Size">
     * Controlling the Objectivity/DB Cache's Size</a>.</p>
	 *
     * @param 	 size    The suggested maximum number of
     * bytes in the large-object
     * memory pool in this session's Objectivity/DB cache.
	 */
    public void setLargeObjectMemoryLimit(long size)
        { persistor().setLargeObjectMemoryLimit(size) ; }

	/**
     * Enables or disables deaden-objects commit mode.
     *
     * <p>When the deaden-objects commit mode is enabled, all local representation objects
     * belonging to this session are made dead objects when a
     * transaction is committed. The dead objects are no longer valid for any
     * Objectivity/DB operations, so they cannot cause stale cache errors.
     *
     * <p>If this method is not called,  this session continues to own its
	 * local representation objects after a transaction is committed, provided
	 * the application retains references to them.
     *
     * <p>For additional information, see
     * <a href="../../../../../guide/jgdPersistence.html#Longevity of Local Representations">
     * Longevity of Local Representations</a>.</p>
	 *
     * @param 	 mode     True to enable
     * deaden-objects commit mode;
	 * false to disable deaden-objects commit mode
	 * so that committing a transaction does not affect the session's local representation objects.
	 *
	 * @see #setDeadenObjectsInExternallyModifiedContainers
	 */
    public void setDeadenObjectsAfterCommit(boolean mode)
        { persistor().setDeadenObjectsAfterCommit(mode) ; }

	/**
     * Enables or disables the use of indexes by predicate queries.

	 * <p>
	 * <b>Note:</b> For backward compatibility only. This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. <br/>
	 * See: 
	 * <a href="../internal/package.html#Placement">
     * Controlling the Placement of Basic Objects</a>.
	 * </p>
	 *
     * <p>Indexes are used to optimize certain kinds of predicate queries.
     * Disabling the use of indexes may be desirable in either of the
	 * following circumstances:
	 * <P><ul type=disc>
	 * <li> You are scanning for objects with values in the entire range of
	 * the key fields and sorting is not necessary. In such a case, indexes
	 * do not speed up the query.</p>
	 *
	 * <li> You are scanning for objects of a particular class and some
	 * objects of that class have been created or modified since the last
	 * time indexes were updated.
	 * </ul>
     *
     * <p>If this method is not called, indexes are not used.</p>
	 *
	 * <p>For guidelines on selecting a value for the index-usage policy, see
	 * <a href="../../../../../guide/jgdIndexes.html#Enabling and Disabling Indexes">
	 * Enabling and Disabling Indexes</a>.</p>
	 *
     * @param 	 useIndex  True to enable the use of indexes
	 * during scans;  false to disable their use.
	 */
    public void setUseIndex(boolean useIndex)
        { persistor().setUseIndex(useIndex) ; }

	/**
     * <i>(HA)</i> Gets whether the offline status for all autonomous partitions
     * should be ignored or enforced.</p>
     * 
	 * <p>
	 * <b>Note:</b> For backward compatibility only. This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. <br/>
	 * See: 
	 * <a href="../internal/package.html#Placement">
     * Controlling the Placement of Basic Objects</a>.
	 * </p>
	 * 
     * @return  The offline mode; one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>IGNORE</tt></dt>  <dd>The offline status of
     * autonomous partitions is being ignored.</dd>
     *  <dt><tt>ENFORCE</tt></dt> <dd>The offline status of
     * autonomous partitions is being enforced.</dd>
     * </dd></dl></dl>
     *
     * @see #setOfflineMode(int)
	 */
    public int getOfflineMode()
        { return persistor().getOfflineMode() ; }

	/**
	 * <i>(HA)</i> Sets the offline mode to either ignore the offline
	 * status of all autonomous partitions or to enforce it.
	 * 
	 * <p>
	 * <b>Note:</b> For backward compatibility only. This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. <br/>
	 * See: 
	 * <a href="../internal/package.html#Placement">
     * Controlling the Placement of Basic Objects</a>.
	 * </p>
     * <p>If this method is not called, the offline status of autonomous
	 * partitions is enforced.</p>
	 *
	 * @param 	 mode	The offline mode; one of the following
	 * constants defined in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     *  <dt><tt>IGNORE</tt></dt>  <dd>Ignore the offline status of
     * autonomous partitions.</dd>
     *  <dt><tt>ENFORCE</tt></dt> <dd>Enforce the offline status of
     * autonomous partitions.</dd>
     * </dd></dl></dl>
     *
     * @see #getOfflineMode
     */
    public void setOfflineMode(int mode)
        { persistor().setOfflineMode(mode) ; }

    /**
     * Drops the specified persistent object object from this session.
     *
     * <P>This method removes all information about the object from this
     * session's internal cache. This session gives up ownership of the
     * object, and the object becomes a dead object.
	 *
	 * <p>This method is useful when the persistent object has been deleted
	 * or moved by another process, making its cached information stale.
	 * For additional information, see
	 * <a href="../../../../../guide/jgdSessionCache.html#Explicitly Managing Local Representations">
	 * Explicitly Managing Local Representations</a>.</p>
	 *
	 * @param 	 object	The persistent object whose
	 * cached information is to be removed; must be an object that
	 * belongs to this session.
     */
    public void dropCachedObject(Object object)
        { persistor().dropCachedObject(object) ; }

    /**
     * Reloads a persistent object, obtaining a new local representation
     * object for this session.
	 *
	 * <p>This method first removes all information about the object from the
     * session's internal cache and makes the object a dead object. It then
     * uses the object identifier from the old local representation to find
     * the object in the federated database. It retrieves that object and
     * returns a new local representation object. You must refetch the object's data
	 * before accessing its persistent attributes.
     *
	 * <p>This method is useful when the persistent object has been deleted
	 * or moved by another process and its object identifier has been
     * reassigned to an object of
	 * a different class.  If that has happened, this method returns the new
	 * persistent object with the object identifier that formerly identified
	 * <tt><i>object</i></tt>.
	 * For additional information, see
	 * <a href="../../../../../guide/jgdSessionCache.html#Explicitly Managing Local Representations">
	 * Explicitly Managing Local Representations</a>.</p>
	 *
	 * @param 	 object	The persistent object whose
	 * cached information is to be reloaded; must be an object that
	 * belongs to this session.</p>
	 *
	 * @return		A new local representation object whose object identifier
     * is the same as the object identifier of
	 * <tt><i>object</i></tt>.
     */
    public Object reloadCachedObject(Object object)
        { return persistor().reloadCachedObject(object) ; }

	/**
	 * Sets this session's output property for status messages generated by Objectivity for Java.</p>
	 *
	 * <p>If this method is never called, this session uses the value set for it by its
	 * connection object. By default,
	 * Objectivity for Java status messages are directed to the standard
	 * output stream (<tt>System.out</tt>).</p>
	 *
	 * @param 	 outputStream	Print stream for this session's
	 * Objectivity for Java status messages.</p>
	 *
	 * @see		Connection#setOut
	 */
    public void setOut(PrintStream outputStream)
	{
        persistor().setOut(outputStream);
    }

	/**
	 * Sets this session's output property for error messages generated by Objectivity for Java.</p>
	 *
	 * <p>If this method is never called, this session uses the value set for it by its
	 * connection object. By default,
	 * Objectivity for Java error messages are directed to the standard
	 * error-output stream (<tt>System.err</tt>).</p>
	 *
	 * @param 	 outputStream	Print stream for this session's
	 * Objectivity for Java error messages.</p>
	 *
	 * @see		Connection#setErr
	 *
	 */
    public void setErr(PrintStream outputStream)
	{
        persistor().setErr(outputStream);
    }

    /**
     * Adds an application-specific item to this session's log.
	 *
	 *
	 * <p>If logged information is being written to log files, an item with the specified
	 * label and text is added to the end of this session's log file.
	 *
	 * <p>If a log listener is attached to this session's log, the specified log item is passed to
	 * the listener's {@link LogListener#onLogItem <tt>onLogItem</tt>} method.
	 *
	 * <p>This method is relevant only if standard session logging and adding
	 * application-defined log items were both enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>}
	 * static method
	 * specifying either the logging option <tt>LogAll</tt> or both options <tt>LogSession</tt>
	 * and <tt>LogOther</tt>. </p>
     *
     * @param 	 label	Label for log item; specify null or an empty string
	 * for an item with no label.</p>
     *
     * @param 	 text	Text of log item; specify null or an empty string
	 * for an item with no text.</p>
	 *
	 * @see		Connection#addToMainLog
	 *
     */
    public void addToLog(String label, String text)
        { persistor().addToLog(label, text) ; }

    /**
     * Starts this session's timer and adds an item to this session's log indicating
     * the start of general-purpose timing.
	 *
	 * <p><b>Note:</b> Each session has a single timer, so you should not nest calls to <tt>startTimer</tt>,
	 * because doing so restarts the timer.
	 * After calling <tt>startTimer</tt>, you should call <tt>stopTimer</tt> before making another call
	 * to <tt>startTimer</tt>.</p>
	 *
	 * <p>This method is relevant only if standard session logging was enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method
	 * specifying either logging option <tt>LogAll</tt> or <tt>LogSession</tt>. (It does not
	 * matter whether logging of transaction statistics is enabled.)</p>
	 *
	 * @see		#stopTimer
	 *
     */
    public void startTimer()
        { persistor().startTimer() ; }

    /**
     * Stops this session's timer and adds an item to this session's log
	 * that reports the elapsed time since the last call to <tt>startTimer</tt>.
	 *
	 *
	 * <p>This method is relevant only if standard session logging was enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method
	 * specifying either logging option <tt>LogAll</tt> or <tt>LogSession</tt>. (It does not
	 * matter whether logging of transaction statistics is enabled.)</p>
	 *
	 * @see		#startTimer
	 *
     */
    public void stopTimer()
        { persistor().stopTimer() ; }

    /**
     * Starts a new interval for collecting statistics on operations performed by this session,
	 * and adds an item to this session's log that indicates the start of
	 * general-purpose statistics.
	 *
	 * <p><b>Note:</b> Each session has a single statistics counter, so you should not nest calls
	 * to <tt>startStatistics</tt>,
	 * because doing so restarts the counter.
	 * After calling <tt>startStatistics</tt>, you should call <tt>stopStatistics</tt> before making another call
	 * to <tt>startStatistics</tt>.</p>
	 *
	 * <p>This method is relevant only if standard session logging was enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method
	 * specifying either logging option <tt>LogAll</tt> or <tt>LogSession</tt>. (It does not
	 * matter whether logging of transaction statistics is enabled.)</p>
	 *
	 * @see		#stopStatistics
	 *
	 *
     */
    public void startStatistics()
        { persistor().startStatistics() ; }

    /**
     * Stops the current statistics-collection interval for this session, and
	 * adds an item to this session's log that reports general-purpose statistics on
	 * the operations performed by this session since the last call to <tt>startStatistics</tt>.</p>
	 *
	 * <p>This method is relevant only if standard session logging was enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method
	 * specifying either logging option <tt>LogAll</tt> or <tt>LogSession</tt>. (It does not
	 * matter whether logging of transaction statistics is enabled.)</p>
	 *
	 * @see		#startStatistics
	 *
     */
    public void stopStatistics()
        { persistor().stopStatistics() ; }

    /**
     * Gets the value of the specified application-defined property of
     * this session.</p>
     *
     * @param 	 name	Name of the property.</p>
	 *
	 * @return		Session-data object that was saved as the value for the
	 * specified property.
     */
    public SessionData getSessionData(String name)
        { return persistor().getSessionData(name) ; }

    /**
     * Sets the value of the specified application-defined property for
     * this session.</p>
     *
     * @param 	 name	Name of the property to be set.</p>
     *
     * @param 	 data	Session-data object to be saved
	 * as the value for the specified property.
     */
    public void setSessionData(String name, SessionData data)
        { persistor().setSessionData(name, data) ; }

    /**
     * Adds the specified transaction listener to this session.
	 *
	 * <p>After a transaction listener is added to this session, that listener is notified
	 * whenever calls are made to the session's transaction-related methods and
	 * when those calls complete.</p>
     *
     * @param 	 listener	Transaction listener to be added.
     *
     * @see #removeTransactionListener(TransactionListener)
     */
    public void addTransactionListener(TransactionListener listener)
        { persistor().addTransactionListener(listener) ; }

    /**
     * Removes the specified transaction listener from this session.</p>
	 *
	 * <p>After a transaction listener is removed from this session, that listener is no longer
	 * notified when calls are made to the session's transaction-related methods.</p>
     *
     * @param 	 listener	Transaction listener to be removed.
	 *
	 * @exception		<tt>ooTransactionListenerNotFound</tt>	If the specified transaction listener is not in this
	 * session's registry of transaction listeners.
     *
     * @see #addTransactionListener(TransactionListener)
     */
    public void removeTransactionListener(TransactionListener listener)
        { persistor().removeTransactionListener(listener) ; }

    /**
     * Attaches the specified log listener to this session's log.</p>
	 *
	 * <p>This method attaches the specified log listener to this session's log.
	 * If the session log already has a listener, that listener is removed
	 * before the new listener is attached.
	 *
	 * <p>After the log listener is attached, it is notified whenever this session's log records
	 * a log item and whenever the application adds a log item to this session's log.
	 *
	 * <p><b>Note:</b> You should not attach the same log listener to more than one log;
	 * any given log listener can receive notifications from at most one log (either the
	 * main log or a particular session's log).</p>
	 *
	 *
	 * <p>This method is relevant only if standard session logging was enabled
	 * by a call to the {@link Connection#setLoggingOptions <tt>Connection.setLoggingOptions</tt>} static method
	 * specifying either logging option <tt>LogAll</tt> or <tt>LogSession</tt>. </p>
     *
     * @param 	 listener	Log listener for this session.  A log listener is an instance of an application-defined
	 * class derived from the {@link LogListener <tt>LogListener</tt>} class.</p>
	 *
	 * @see		Connection#setMainLogListener
     */
    public void setLogListener(LogListener listener)
        { persistor().setLogListener(listener) ; }

    /**
     * Tests whether this session is a pooled session.</p>
     *
     * @return True if this session was created by a session pool and false
     * if it was created individually.
     */
    public boolean obtainedFromSessionPool()
        { return persistor().obtainedFromSessionPool() ; }

    /**
     * Gets the name of this session's pool.</p>
     *
     * @return Name of the session pool that created this session, or
     * a null string if this session was created individually.
     */
    public String poolName()
        { return persistor().poolName() ; }

    /**
     * Returns this session to the session pool that created it.</p>
     *
     * When you are finished using a session that you obtained from a pool,
     * you should return it to the pool. Doing so reduces the total number
     * of sessions needed and helps to prevent delays or exceptions that
     * occur if the pool reaches its hard limit of sessions. The session
     * leaves the current thread when it is returned to its session pool.
     *
     * @exception	ooReturningActiveSessionToPool   If the session is in a transaction.
     */
    public void returnSessionToPool()
        { persistor().returnSessionToPool() ; }

    /**
     * Opens all of the containers of the objects whose object identifiers
     * are referenced in the array, in such a way as to maintain consistency
     * between the containers in an MROW transaction.  Any null OIDs in the
     * array will be ignored.
     *
     * If it is not possible to open all of the containers an exception will
     * be thrown without having opened any of them (other than any that may
     * have already been open.  An exception will also be thrown if an MROW
     * transaction was already in progress and one of the containers was
     * already open using a version that is not the most recent.
     *
     * Opening moved containers is not supported.
     *
     * @param 	 objects	An array of object
     * identifiers representing objects whose containers should be opened.
     *
     * @param 	 openMode The open mode to use when
     * opening each container; one of the following constants defined
     * in the <tt>com.objy.db.app.oo</tt> interface:
     * <dl><dd><dl>
     * <dt><tt>openReadOnly</tt><dd>The containers will be opened to allow
     * read-only access.</dd>
     * <dt><tt>openReadWrite</tt><dd>The containers will be opened to allow
     * read/write access. </dd>
     * </dd></dl></dl></p>
     */
    public void openContainers (ooId[] objects, int openMode)
        { persistor().openContainers(objects, openMode) ; }

    /**
	 * @deprecated    See {@link Connection#setPersistencePolicy <tt>Connection.setPersistencePolicy</tt>}
     * 
     * <p>Persists all transient objects within this session that have formed
     * relationships.</p>
     *
     * <p>All transient objects that have formed relationships in this session's
     * transactions are made persistent. If this session uses a standard clustering strategy,
	 * these objects are clustered
     * in the default database with the clustering reason
     * <a href="storage/ClusterReason.html#RELATE_TO_TRANSIENT">RELATE_TO_TRANSIENT</a>.
	 *
	 *
	 * <p> When a large number of transient objects are linked together,
	 * explicitly persisting them is more efficient than allowing them
	 * to be made persistent implicitly (by clustering one of them and
	 * then committing or checkpointing the transaction).
     */
    @Deprecated // OBJY-17572
    public void persistTransientRelationships()
        { persistor().persistTransientRelationships() ; }

    /**
  	 * @deprecated    See {@link Connection#setPersistencePolicy <tt>Connection.setPersistencePolicy</tt>}
     * 
     * <p>Persists all transient objects within this session that have formed
     * relationships.
     *
     * <p>All transient objects that have formed relationships in this session's
     * transactions are made persistent in the specified
     * location with the specified cluster reason.
	 *
	 * <p> When a large number of transient objects are linked together,
	 * explicitly persisting them is more efficient than allowing them
	 * to be made persistent implicitly (by clustering one of them and
	 * then committing or checkpointing the transaction). </p>
     *
	 * @param 	 requestObj The object that serves as the
	 * requesting object for the clustering operation.
	 * <tt><i>requestObj</i></tt> may be a database,
	 * a persistent container, or a persistent basic object; it must belong to this
     * session.
	 * If this session uses a standard clustering strategy,
	 * <tt><i>requestObj</i></tt> serves as the clustering object
	 * for all of the objects being made persistent.
	 * See <a href="../../../../../guide/jgdClustering.html#Delayed Persistence of Related Objects">
	 * Delayed Persistence of Related Objects</a>.
	 * </p>
	 *
     * @param 	 reason The reason for making the objects
     * persistent. This parameter may be null if you are not using clustering reasons.</p>
     */
    @Deprecated // OBJY-17572
    public void persistTransientRelationships(Object requestObj, ClusterReason reason)
        { persistor().persistTransientRelationships(requestObj, reason) ; }

    /**
     * Sets this session's buffer-pool properties for the specified page size.</p>
     *
     * <p>When a session accesses data on storage pages of different sizes,
	 * its cache allocates pairs of small- and large-object buffer pools
	 * to accommodate pages of each size. A session maintains four properties
	 * per page size to control the allocation of these buffer pools: the
	 * initial and maximum allocation for the small-object buffer pool, and the
	 * initial and maximum allocation for the large-object buffer pool.
	 * These properties determine the initial sizes of the buffer pools when
	 * they are first allocated, and the maximum sizes to which they can grow before
	 * buffer pages must be swapped out of the session's cache.
	 *
	 * <p>This method sets the four properties for the specified page
	 * size. If you do not call this method for a particular page size,
	 * its initial and maximum allocations are controlled by the
	 * session's cache-capacity properties, which are set when the session is created.
     *
     * <p>You typically call this method before beginning the first
     * transaction&#x2014;that is, before any buffer pools have been allocated.
	 * A later call affects only the allocations that have not
	 * yet taken place. Thus, a call to this method has no effect on the initial size
     * of any buffer pool that has already been created, although the call
	 * can change the maximum value of the pool to affect future use.
	 * Once a buffer pool exists, you can use this method to increase
	 * its maximum size, but not to shrink it.
     * </p>
	 *
	 *
	 * <p>For additional information about setting buffer-pool properties, see
     * <a href="../../../../../guide/jgdCache.html#Controlling Pool Allocation for a Complex Objectivity/DB Cache">
     * Controlling Pool Allocation for a Complex Objectivity/DB Cache</a>.
	 * For guidelines on selecting values for buffer-pool properties,
	 * see
	 * <a href="../../../../../guide/jgdPerformance.html#Optimizing the Objectivity/DB Cache Size">
	 * Optimizing the Objectivity/DB Cache's Size</a>.</p>
     *
     * @param 	 page_size The size of database pages in bytes.
	 * Specify 0 to override this session's initial and maximum cache-capacity
	 * properties (set when this session was created).</p>
     *
     * @param 	 initial_page_space The initial space in the
     * small-object buffer pool in this session's Objectivity/DB cache. Specify a value
	 * greater than <tt><i>page_size</i></tt> to set the property as a number of bytes.
	 * Specify a value less than <tt><i>page_size</i></tt> to set the property as a number of
	 * buffer pages, where the number of pages multiplied by <tt><i>page_size</i></tt> is the
	 * number of bytes.</p>
     *
     * @param 	 maximum_page_space The maximum space that
     * can be allocated in the small-object buffer pool in this session's
     * Objectivity/DB cache. Specify a value
	 * greater than <tt><i>page_size</i></tt> to set the property as a number of bytes.
	 * Specify a value less than <tt><i>page_size</i></tt> to set the property as a number of
	 * buffer pages, where the number of pages multiplied by <tt><i>page_size</i></tt> is the
	 * number of bytes.</p>
     *
     * @param 	 initial_large_objects The initial number of buffer entries
	 * in the large-object buffer pool in this session's Objectivity/DB cache.</p>
     *
     * @param 	 maximum_large_objects  The maximum number of buffer entries that
     * can be allocated in the large-object buffer pool in this session's
     * Objectivity/DB cache.
     *
     */
    public void setBufferSpace(int page_size, int initial_page_space, int maximum_page_space, int initial_large_objects, int maximum_large_objects)
        { persistor().setBufferSpace(page_size, initial_page_space, maximum_page_space, initial_large_objects, maximum_large_objects) ; }

    /**
     * Explicitly closes data files and journal files no longer needed by a
     * transaction and closes the connection to the lock server if called
     * from outside a transaction.
	 *
	 * <p>You can call this method in a UNIX or Macintosh application to explicitly close a
	 * session's unneeded files. This is one of several techniques for limiting an
	 * application's total number of open files so it stays within the operating
	 * system's per-process file-descriptor limit.
	 *
	 * <p>Note: On Windows, the files used in a session are automatically closed
	 * at the end of every transaction.
	 *
     */
    public void releaseFiles()
        { persistor().releaseFiles() ; }

    /**
     * <I>(HA)</I> Enables nonquorum reading for all databases in this
     * session's current transaction.
     * 
	 * <p>
	 * <b>Note:</b> For backward compatibility only. This method 
	 * should be used only in an application that performs explicit 
	 * placement. Do not use this method in an application that 
	 * accesses a placement-managed federated database. <br/>
	 * See: 
	 * <a href="../internal/package.html#Placement">
     * Controlling the Placement of Basic Objects</a>.
	 * </p>
	 * 
     * <p>Calling this method is equivalent to enabling nonquorum
     * reading for each individual database subsequently read in the
     * current transaction. Once nonquorum reading is enabled
     * for a transaction, it cannot be disabled for any particular
     * database, and calling a database's <tt>setNonQuorumReadAllowed</tt> method
     * will have no effect for the duration of the transaction.
	 *
	 * <p>If this
     * session is not in a transaction, nonquorum reading affects
     * the next transaction. Nonquorum reading is automatically disabled
     * at the end of the transaction in which this method is
     * called.
     *
     * <p><b>Warning: </b>If you enable nonquorum reading, your
     * application may read stale data from this database.</p>
     *
     * @see ooDBObj#isNonQuorumReadAllowed
     * @see ooDBObj#isNonQuorumRead
     * @see ooDBObj#setNonQuorumReadAllowed
     */
    public void setAllowNonQuorumRead()
        { persistor().setAllowNonQuorumRead() ; }

	/**
	 * Gets the nest count for this session's current transaction.
	 *
	 * <p>The nest count is 1 if no nested calls to {@link #begin <tt>begin</tt>}
	 * have been made since the
	 * start of the current transaction. </p>
	 *
	 * @return		The number of times <tt>begin</tt> has been called
	 * during the current transaction, or 0 if this session is not in a transaction.
	 *
	 */
    public int nestCount()
	{ return persistor().nestCount() ; }

    /**
     * Gets this session's policy for releasing the native memory resources on
     * finalization of its object iterators.</p>
     *
     * <b>Warning:</b>If this session's safe-iterator policy is set to
     * false, any object iterator that is garbage collected before the end of the transaction will
     * leave native memory leaks.</p>
     *
     * @return		True if this session's safe-iterator policy causes object iterators to release their native memory resources
     * on finalization; otherwise, false.
     */
    public boolean getSafeIteratorPolicy()
	{ return persistor().getSafeIteratorPolicy() ; }

    /**
     * Sets this session's policy for releasing the native memory resources on
     * finalization of its object iterators.</p>
	 *
	 * <p>If you never call this method, or you call it and set the policy to true,
	 * each open object iterator implicitly releases its memory resources
	 * if it is garbage collected before the end of the transaction in which it was initialized.</p>
	 *
	 * <p>If you set a session's
	 * safe-iterator policy to false, the memory resources of an open object iterator are released
	 * only if you explicitly close the iterator or if it remains open until the transaction ends.</p>
	 *
     *
     * <b>Warning:</b>Objectivity strongly recommends that you leave a session's safe-iterator policy
	 * set to true. When a session's safe-iterator policy is
     * false, you must explicitly close unneeded object iterators to prevent
     * native memory leaks. These memory leaks remain even when the session is terminated
	 * either implicitly or explicitly.</p>
     *
     * @param 	 policy	True if this session's
     * object iterators are to release their native memory resources on finalization; otherwise, false.
     */
    public void setSafeIteratorPolicy(boolean policy)
	{ persistor().setSafeIteratorPolicy(policy) ; }



	/**
	 * Gets this session's threshold for automatic flushing.</p>
	 *
	 * A session updates its Objectivity/DB cache whenever the session accumulates
	 * a certain number of objects that have either been made persistent or marked as modified
	 * since the last time the cache was updated--for example,
	 * as a result of committing the transaction or calling a storage object's
	 * <tt>flush</tt> method.
	 * This number is the session's <i>autoflush threshold</i>; by default, this threshold is 10000.</p>
	 *
	 * @return		The session's threshold for automatic flushing.
	 *
	 * @see ooObj#write
	 * @see ooContObj#flush
	 * @see ooDBObj#flush
	 * @see ooFDObj#flush
	 */

	public int getAutoFlushThreshold()
	{ return persistor().getAutoFlushThreshold() ; }



	/**
	 * Sets this session's threshold for automatic flushing.</p>
	 *
	 * A session updates its Objectivity/DB cache whenever the session accumulates
	 * a certain number of objects that have either been made persistent or marked as modified
	 * since the last time its Objectivity/DB cache was updated--for example,
	 * as a result of committing the transaction or calling a storage object's
	 * <tt>flush</tt> method.
	 * This number is the session's <i>autoflush threshold</i>; by default, this threshold is 10000.</p>
	 *
	 * Lowering the threshold can be helpful when memory resources are limited. This is because
	 * a session maintains strong references to
	 * any objects that have been created or marked modified during an
	 * update transaction; updating the Objectivity/DB cache causes the session
	 * to release these strong references, so the objects can be garbage collected.</p>
	 *
	 * Note, however that lowering the autoflush threshold is not recommended
	 * if multiple threads are joined concurrently to the same session.
	 * A lower threshold increases the chance that operations in one thread
	 * could trigger automatic update of the Objectivity/DB cache
	 * while it is being accessed by operations in the other threads,
	 * which can cause the Java virtual machine to deadlock.</p>
	 *
	 *
	 * @param 	 threshold  The session's
	 * threshold for automatic flushing.
	 *
	 * @see ooObj#write
	 * @see ooContObj#flush
	 * @see ooDBObj#flush
	 * @see ooFDObj#flush
	 */

	public void setAutoFlushThreshold(int threshold)
	{ persistor().setAutoFlushThreshold(threshold) ; }


	/**
	 * Sets the maximum number of 
	 * active <a href="../../as/app/package-summary.html">Active Schema</a> objects 
	 * in this session's Objectivity/DB cache.
	 * 
	 * <p> Once this limit is reached, adding another active object to the cache causes
	 * the oldest object in the cache to be deactivated.
	 * This pool mechanism for Active Schema objects prevents the cache from becoming full.
	 * 
	 * <p>If you never call this method, the default value is 1000. 
	 * 
	 * <p> The default value is appropriate for a session that is ingesting, but not using,
	 * very large numbers of objects through instances of <a href="../../as/app/Class_Object.html">
     * <tt>com.objy.as.app.Class_Object</tt></a>.
	 * 
	 * <p>If a session will need frequent, repeated access to a particular set of such objects,
	 * you can call this method to adjust the pool size up or down, as appropriate.
	 * The pool size should be slightly greater than the number of objects to be accessed repeatedly. 
	 * For performance purposes, 
	 * it is recommended that you reduce the pool size for a session  
	 * that will repeatedly access a very small number of Active Schema objects in very short transactions.
	 * 
	 * @param 	 size  The session's
	 * limit for the class-object pool.
	 */
	public void setClassObjectPoolSize(int size)
	{ persistor().setClassObjectPoolSize(size) ; }

	/**
	 * Gets the maximum number of 
	 * active <a href="../../as/app/package-summary.html">Active Schema</a> objects 
	 * in this session's Objectivity/DB cache.
	 * 
	 * @return	This session's limit for the class-object pool.
	 * 
	 * @see #setClassObjectPoolSize
	 * 
	 */
	public int getClassObjectPoolSize()
	{ return persistor().getClassObjectPoolSize() ; }

	/**
	 * Turns off automatic flushing for this session.</p>
	 *
	 * <p>Calling this method stops this session from automatically
	 * updating the Objectivity/DB cache with modified persistent data
	 * flushed from this session's local representations.
	 * To restore automatic flushing, call
	 * {@link #setAutoFlushThreshold <tt>setAutoFlushThreshold</tt>}
	 * with a non-zero value.
	 * </p>
	 *
	 * @see #setAutoFlushThreshold
	 */
	public void ignoreAutoFlushThreshold()
	{ persistor().setAutoFlushThreshold(0) ; }

	/**
	 * Tests whether the selective deaden-objects policy has been set for this session.</p>
	 *
	 * @return		True if objects in an externally modified
	 * container are made dead upon detection through a fetch
	 * operation; false if they are not.</p>
	 *
	 * @see #setDeadenObjectsInExternallyModifiedContainers
	 */
	public boolean isDeadenObjectsInExternallyModifiedContainers()
	{ return persistor().isDeadenObjectsInExternallyModifiedContainers() ; }

	/**
	 * Specifies whether to set the selective deaden-objects policy for this session.</p>
	 *
	 * <p>
	 * When the selective deaden-objects policy is set for this session,
	 * fetching an object's persistent data causes Objectivity/DB to check
	 * whether the object's container has been updated
	 * by some other session since the last time the object was retrieved in this session.
	 * If the container or any object in it has been updated outside this session,
	 * the local representation being used for the fetch operation is presumed stale.
	 * The local representation is automatically made dead
	 * (along with this session's local representations of any other objects
	 * belonging to the same container)
	 * and the fetch operation returns <tt>ObjectIsDeadException</tt>.
	 * </p>
	 *
	 * <p>
	 * Setting this policy is useful
	 * if a session is likely to own any stale local representations of persistent objects&#x2014;that is,
	 * if the application might continue to hold a reference to a local representation
	 * owned by this session
	 * while another session deletes or moves the corresponding persistent object.
	 * For example, this session could commit a transaction in which it retrieved a persistent object,
	 * making the object available for another session to delete or move.
	 * Similarly, this session (in an MROW transaction) could refresh the container of
	 * a retrieved persistent object
	 * after a concurrent transaction in another session has deleted or moved that object.
	 * In either case, the OID held by the local representation object
	 * no longer corresponds to any persistent object,
	 * or else it corresponds to a different persistent object than was originally retrieved
	 * (if the OID has been reassigned to a new object).
	 * Setting this policy prevents the reuse of stale local representations,
	 * either in a subsequent transaction of the same session,
	 * or after refreshing a container in the same MROW transaction.
	 * </p>
	 *
	 * <p>
	 * By deadening only those objects that reside in containers
	 * known to have been updated by other sessions,
	 * this policy is more selective than using deaden-objects commit mode,
	 * and typically results in fewer objects that need to be retrieved (looked up) again
	 * before they can be used.
	 * Furthermore,
	 * this policy can prevent the use of local representations that might have become stale
	 * after an MROW transaction refreshes its view of a concurrently updated container.
	 * </p>
	 *
     * <p>If this method is not called,  this session continues to own all of its
	 * local representation objects for as long as the application retains references to them.</p>
     *
     * <p>For additional information, see
     * <a href="../../../../../guide/jgdPersistence.html#Longevity of Local Representations">
     * Longevity of Local Representations</a>.</p>
	 *
	 *
	 * @param 	 option		True if objects
	 * in an externally modified container are to be made dead upon
	 * detection through a fetch operation; false if they are not.</p>
	 *
	 *
	 * @see #isDeadenObjectsInExternallyModifiedContainers
	 * @see #setDeadenObjectsAfterCommit
	 */
	public void setDeadenObjectsInExternallyModifiedContainers(boolean option)
	{ persistor().setDeadenObjectsInExternallyModifiedContainers(option) ; }


	/**
	 * Captures a snapshot, which is a set of information about the state of an
	 * application in the current session, and lets you specify the scope of the
	 * output according to the <tt>scope</tt> parameter.</p>
	 *
	 * <p>A snapshot is written to standard output or to a file.
	 * You can use this information to debug an application or to improve
	 * performance or data availability.</p>
	 *
	 * @param 	 info  Specifies which state information to capture;
	 * one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt> <tt>NoInfo</tt> <dd>Specifies that no snapshot information is captured.</dd>
	 *  <dt> <tt>HeaderInfo</tt> <dd>Provides version information about the Objectivity for Java software,
	 *  the current date and time, and the name of the boot file for the federated database.</dd>
	 *  <dt> <tt>SessionInfo</tt> <dd>Provides the current date and time, session name, session number,
	 *  current open mode, current MROW mode, current index mode, information about waiting for
	 *  locks, information about server timeout, and the transaction ID.</dd>
	 *  <dt> <tt>DatabasesInfo</tt> <dd>For each open database, provides its OID, lock mode, file
	 *  descriptor, and page size.</dd>
	 *  <dt> <tt>ContainersInfo</tt> <dd>For each open container, provides its OID, lock mode, free pages,
	 *  file descriptor, version number,
	 *  and states whether or not the container was modified.</dd>
	 *  <dt> <tt>CachePagesInfo</tt> <dd>For each cached page, provides its OID, free space, pin count,
	 *  and states whether or not it was written.</dd>
	 *  <dt> <tt>ShadowPagesInfo</tt> <dd>For each shadow page, provides its OID, old physical page
	 *  number, and new physical page number.</dd>
	 *  <dt> <tt>ObjectsInfo</tt> <dd>For each open object, provides its OID, open mode, and type number.</dd>
	 *  <dt> <tt>VarraysInfo</tt> <dd>For each open array, provides its type number and owning object.</dd>
	 *  <dt> <tt>PrintRecentPages</tt> <dd>Provides information on the contents of the two most recently
	 *  accessed logical pages.</dd>
	 *  <dt> <tt>AllInfo</tt><dd>Provides all information that can be produced by a snapshot.</dd>
	 * </dd></dl></dl></p>
	 *
	 *
	 * @param 	 infoFormat	Specifies the format of the output; one of the following
	 * constants defined in the <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt> <tt>Readable</tt> <dd>Specifies plain text.</dd>
	 *  <dt> <tt>CSV</tt> <dd>Specifies a comma-separated values format.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @param 	 fileName The pathname of the output file to be
	 * created. Use a null string to print the snapshot to standard output.
	 * If a nonnull file name is specified, and the file cannot be opened, 
	 * the snapshot is redirected to standard output.</p>
	 *
	 * @param 	 onException  If true, write output upon
	 * throwing an exception (for multiple exceptions, multiple snapshots are captured).
	 * If false, write the output immediately.</p>
	 *
	 * @param 	 sortOrder Sorts the state information in the output; one
	 * of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt> <tt>Ascending</tt> <dd>Starts with the lowest OID and ends with the highest.</dd>
	 *  <dt> <tt>Decending</tt> <dd>Starts with the highest OID and ends with the lowest.</dd>
	 *  <dt> <tt>Recent</tt> <dd>Applies for CachePagesInfo only; starts with the most
	 *  recently accessed pages and ends with the least recently accessed pages.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @param 	 scope Specifies the object identifier that defines the
	 * scope of the report.
	 * You can specify a null object identifier to leave the state information unfiltered,
	 * so the snapshot includes information pertaining to any Objectivity/DB object
	 * accessed during the session.
	 */

	public void snapShot(int info, int infoFormat, String fileName, boolean onException, int sortOrder, ooId scope)
	{ persistor().snapShot(info, infoFormat, fileName, onException, sortOrder, scope) ; }

	/**
	 * Captures a snapshot, which is a set of information about the state of an
	 * application in the current session, for all OIDs in the session.
	 *
	 * <p>A snapshot is written to standard output or to a file.
	 * You can use this information to debug an application or to improve
	 * performance or data availability.</p>
	 *
	 * @param 	 info  Specifies which state information to capture;
	 * one of the following constants defined in the
	 * <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt> <tt>NoInfo</tt> <dd>Specifies that no snapshot information is captured.</dd>
	 *  <dt> <tt>HeaderInfo</tt> <dd>Provides version information about the Objectivity for Java software,
	 *  the current date and time, and the name of the boot file for the federated database.</dd>
	 *  <dt> <tt>SessionInfo</tt> <dd>Provides the current date and time, session name, session number,
	 *  current open mode, current MROW mode, current index mode, information about waiting for
	 *  locks, information about server timeout, and transaction IDs</dd>
	 *  <dt> <tt>DatabasesInfo</tt> <dd>For each open database, provides its OID, lock information, file
	 *  descriptor, and page size.</dd>
	 *  <dt> <tt>ContainersInfo</tt> <dd>For each open container, provides its OID, lock mode, free pages,
	 *  file descriptor, version number,
	 *  and states whether or not the container was modified.</dd>
	 *  <dt> <tt>CachePagesInfo</tt> <dd>For each cached page, provides its OID, free space, pin count,
	 *  and states whether or not it was written.</dd>
	 *  <dt> <tt>ShadowPagesInfo</tt> <dd>For each shadow page, provides its OID, old physical page
	 *  number, and new physical page number.</dd>
	 *  <dt> <tt>ObjectsInfo</tt> <dd>For each open object, provides its OID, open mode, and type number.</dd>
	 *  <dt> <tt>VarraysInfo</tt> <dd>For each open array, provides its type number and owning object.</dd>
	 *  <dt> <tt>PrintRecentPages</tt> <dd>Provides information on the contents of the two most recently
	 *  accessed logical pages.</dd>
	 *  <dt> <tt>AllInfo</tt><dd>Provides all information that can be produced by a snapshot.</dd>
	 * </dd></dl></dl></p>
	 *
	 *
	 * @param 	 infoFormat	Specifies the format of the output; one of the following
	 * constants defined in the <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt> <tt>Readable</tt> <dd>Specifies plain text.</dd>
	 *  <dt> <tt>CSV</tt> <dd>Specifies a comma-separated values format.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @param 	 fileName The pathname of the output file to be
	 * created. Use a null string to print the snapshot to standard output.
	 * If a nonnull file name is specified, and the file cannot be opened, 
	 * the snapshot is redirected to standard output.</p>
	 *
	 * @param 	 onException  If true, write output upon
	 * throwing an exception (for multiple exceptions, multiple snapshots are captured).
	 * If false, write the output immediately.</p>
	 *
	 * @param 	 sortOrder Sorts the state information in the output; one
	 * of the following constants defined in the <tt>com.objy.db.app.oo</tt> interface:
	 * <dl><dd><dl>
	 *  <dt> <tt>Ascending</tt> <dd>Starts with the lowest OID and ends with the highest.</dd>
	 *  <dt> <tt>Decending</tt> <dd>Starts with the highest OID and ends with the lowest.</dd>
	 *  <dt> <tt>Recent</tt> <dd>Applies for CachePagesInfo only; starts with the most
	 *  recently accessed pages and ends with the least recently accessed pages.</dd>
	 * </dd></dl></dl></p>
	 *
	 * @see #snapShot(int, int, String, boolean, int, ooId)
	 *
	 */
	public void snapShot(int info, int infoFormat, String fileName, boolean onException, int sortOrder)
	{ persistor().snapShot(info, infoFormat, fileName, onException, sortOrder, null) ; }

    /**
     * Optimizes the order in which an object iterator scans
     * a container or a database for basic objects.
     *
     * <p>You normally call this method when advised to do so by the
     * Objectivity/DB performance analyzer.
     *
     * <p> This method optimizes the scan order of
     * the next object iterator to be created
     * in the same transaction of this session,
     * provided that object iterator is initialized to find
     * basic objects by scanning one or more containers.
     * You must call this method once for each
     * object iterator to be optimized.
     *
     * <p>This method has no effect if the next newly created
     * object iterator  is initialized
     * to find containers, databases, or autonomous partitions,
     * or if it is initialized to find basic objects through a name
     * scope or a to-many relationship.
     * This method does not affect parallel queries.
     *
     * </p>This method has no effect if it is called outside a transaction,
     * or if it is called in a transaction that ends before
     * an applicable object iterator is initialized.
     *
     * <p>This method may change the order in which the object iterator
     * finds basic objects while scanning one or more containers.
     * Changing the scan order can speed up the search significantly,
     * but only if the containers being scanned are in databases that
     * need to be tidied.
     * There is no performance benefit, and possibly a small performance
     * penalty,
     * if the containers being scanned are in recently tidied databases.
     * See <i>Objectivity/DB Administration</i> for more information
     * about tidying databases.
     *
     * <p><b>Note: </b>If you plan to perform multiple scan operations
     * to find the same class of objects in the same containers,
     * and you want the found objects to be returned in the same order
     * each time,
     * you must perform these scan operations using the non-optimized
     * scan order.</p>
     *
     *
     * @param 	 state    Specify true to
     * optimize scan order of the next newly created object iterator;
     * specify false to cause that object iterator
     * to scan the logical pages of a container in order
     * by logical-page identifier.
     *
     */
    public void setOptimizeScanOrder(boolean state)
	{ persistor().setOptimizeScanOrder(state) ; }

    /**
     * Reserved for internal use; you should not call this method.</p>
     */
    public boolean existingTransientRelationship(com.objy.db.iapp.Persistent owner, Object to, PToOneTransientRelationshipManager transientManager)
	{ return persistor().existingTransientRelationship(owner, to, transientManager) ; }

    /**
     * Reserved for internal use; you should not call this method.</p>
     */
    public boolean existingTransientRelationship(com.objy.db.iapp.Persistent owner, Object to, PToManyTransientRelationshipManager transientManager)
	{ return persistor().existingTransientRelationship(owner, to, transientManager) ; }

    /**
     * Reserved for internal use; you should not call this method.</p>
     */
    public Object ffc(String lN, String mN, Object[] args)
	{ return persistor().ffc(lN, mN, args) ; }

	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public synchronized PSession persistor()
	{
        if (persistor == null)
            throw new ObjyRuntimeException("Attempted persistent operation on a terminated session") ;
        return persistor ;
    }

	/**
	 * Reserved for internal use; you should not call this method.</p>
	 */
    public synchronized void setPersistor(PSession persistor)
        { this.persistor = persistor ; }
}
