package com.objy.query.expression;
/**
 * Represents a literal value node.
 *
 */
public abstract class LiteralValueExpression extends Expression 
{
    
	// variable name for literal defined as variable
    //private String mVariableName = null;
    
    LiteralValueExpression() {}
    
    /**
     * Returns the variable name.
     */
    /*public String getVariableName() {
        // TODO: go native
        return mVariableName;
    }*/
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	visitor.visitLiteralValue(this);
    }
    
}
