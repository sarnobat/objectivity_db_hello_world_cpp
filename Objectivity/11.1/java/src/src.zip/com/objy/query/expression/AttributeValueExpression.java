package com.objy.query.expression;

/**
 * Represents a value node that models an attribute of a class.
 */
public class AttributeValueExpression extends Expression 
{

    /**
     * Constructor taking an attribute name optionally prefixed with the 
     * base class name, for example, person::name.
     */
    // TODO: fully qualified Java class name? 
    public AttributeValueExpression(String attributeName) 
    {
        Util.verifyStringArgument(attributeName);
        setIdAfterNullCheck(Binding.create(attributeName));
    }

    /**
     * Constructor taking an ID.
     * @param id
     */
    AttributeValueExpression(long id) 
    {
        setId(id);
    }

    /**
     * Returns the attribute's name.
     */
    public String getAttributeName()
    {
        throwExceptionIfInvalidOrClosed(getId());
        return Binding.getAttributeName(getId());
    }

    /**
     * Sets the attribute name.
     */
    public void setAttributeName(String name)
    {
        throwExceptionIfInvalidOrClosed(getId());
        Util.verifyStringArgument(name);
        Binding.setAttributeName(getId(), name);
    }

    /**
     * Returns the expression type (ooExpressionType.oocAttributeValueExpression).
     */
    @Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.AttributeValueExpression; 
    }
    
    /** 
     * Causes specific derived expression node types to call the 
     * corresponding visit method on the passed-in visitor. 
     */
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitAttributeValue(this);
    }
    
    static class Binding 
    {
        private static native long create(String string);
        private static native String getAttributeName(long id);
        private static native void setAttributeName(long id, String name);
    }
}