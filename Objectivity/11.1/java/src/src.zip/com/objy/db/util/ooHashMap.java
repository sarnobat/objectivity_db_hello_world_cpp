/*
 * @(#)ooHashMap.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.util;

import java.util.Collection;
import java.util.Map;
import java.util.Set;
import java.util.Iterator;
import com.objy.pm.ooHashMapPersistor;

import com.objy.db.app.ooObj;
import com.objy.db.app.storage.ooContObj;

/**
 * Persistence-capable class for unordered object maps.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You may not create your own subclasses of this class.
 *
 * <p><h2>About Unordered Object Maps</h2>
 *
 * <p>An <i>unordered object map</i> is a scalable unordered collection of 
 * key-value pairs; each key and each value is a persistent object.
 * No two elements of the object map may have the same key. As the name implies,
 * each element of an object map is a mapping from its key object to its
 * value object. 
 * For additional information, see
 * <a href="../../../../../guide/jgdCollections.html#Scalable Unordered Collections">
 * Scalable Unordered Collections</a>.
 *
 * <p><h2>Working With an Unordered Object Map</h2>
 *
 * <P>An unordered object map is transient when it is created; you can make 
 * it persistent in any of the ways that you make any basic object
 * persistent (see
 * <a href="../../../../../guide/jgdPersistence.html#Making an Object Persistent">
 * Making an Object Persistent</a>).
 * 
 * <p>After you have created an unordered object map, you can:
 * <ul>
 * <li>Add and remove elements as described in
 * <a href="../../../../../guide/jgdCollections.html#Building an Object Map">
 * Building an Object Map</a></p>
 *
 * <li>Look up particular objects in the unordered object map as described in
 * <a href="../../../../../guide/jgdLookup.html#Individual Lookup in Object Maps">
 * Individual Lookup in Object Maps</a></p>
 *
 * <li>Iterate over the unordered object map as described in
 * <a href="../../../../../guide/jgdGroupSearch.html#Finding the Keys and Values of an Object Map">
 * Finding the Keys and Values of an Object Map</a>
 *</ul>
 *
 * <p><b>Note: </b>You must make an unordered object map persistent before 
 * you call 
 * any methods defined by the <tt>ooHashMap</tt> or <tt>ooCollection</tt>
 * classes. See the <tt>ooObj</tt> method descriptions for
 * restrictions on methods inherited from that class.
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>Two additional classes represent persistent collections of key-value pairs:
 * <ul>
 * <li> <a href="ooTreeMap.html"><tt>ooTreeMap</tt></a> represents
 * a <i>sorted object map</i>. </p>
 *
 * <li> <a href="ooMap.html"><tt>ooMap</tt></a> represents
 * a nonscalable <i>unordered name map</i>, that is, a collection of 
 * key-value pairs in which the key is a string and the value is
 * a persistent object. </p>
 * </ul>
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Constructors</b></td>
 * 		<td>
 *     	<a href="#ooHashMap()">ooHashMap()</a><br>
 *     	<a href="#ooHashMap(com.objy.db.util.ooCompare)">ooHashMap(ooCompare)</a><br>
 *     	<a href="#ooHashMap(int)">ooHashMap(int)</a><br>
 *     	<a href="#ooHashMap(com.objy.db.util.ooCompare, int)">ooHashMap(ooCompare, int)</a><br>
 *      <a href="#ooHashMap(int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooHashMap(int, ooContObj, ooContObj)</a><br>
 *      <a href="#ooHashMap(com.objy.db.util.ooCompare, int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooHashMap(ooCompare, int, ooContObj, ooContObj)</a><br>
 *      <a href="#ooHashMap(com.objy.db.util.ooCompare, int, int, com.objy.db.app.storage.ooContObj, com.objy.db.app.storage.ooContObj)">ooHashMap(ooCompare, int, int, ooContObj, ooContObj)</a>
 * 	</td></tr>
 * <tr>	<td VALIGN="top" WIDTH="1%"><b>Adding,&nbsp;Removing,&nbsp;and Changing&nbsp;Elements</b></td>
 * 	   <td>
 *     <a href="#put(java.lang.Object, java.lang.Object)">put(Object, Object)</a><br>
 *     <a href="#putAll(java.util.Map)">putAll(Map)</a><br>
 *     <a href="#ooAddAll(com.objy.db.util.ooCollection)">ooAddAll(ooCollection)</a><br>
 *     <a href="#ooRemove(java.lang.Object)">ooRemove(Object)</a><br>
 *     <a href="#remove(java.lang.Object)">remove(Object)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Finding&nbsp;Elements</b></td>
 * 	<td>
 *     <a href="#get(java.lang.Object)">get(Object)</a><br>
 *     <a href="#keyIterator()">keyIterator()</a><br>
 *     <a href="#valueIterator()">valueIterator()</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Testing</b></td>
 * 	   <td>
 *     <a href="#containsKey(java.lang.Object)">containsKey(Object)</a><br>
 *     <a href="#containsValue(java.lang.Object)">containsValue(Object)</a>
 * 	</td></tr>
 * <tr><td VALIGN="top" WIDTH="1%"><b>Getting&nbsp;Information</b></td>
 * 	<td>
 *     <a href="#maxBucketsPerContainer(int)">maxBucketsPerContainer(int)</a>
 * 	</td></tr>
 * </table>
 */
final public class ooHashMap extends ooCollection implements Map
{
	/**
	 * Reserved for internal use.
	 */
    public transient int _bucketSize = 30011;

 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _adminContainer = null;

 	/**
	 * Reserved for internal use.
	 */	 
    public transient int _initialBuckets = 1;
    
 	/**
	 * Reserved for internal use.
	 */
    public transient ooContObj _bucketContainer = null;
	
	/**
	 * Constructs an empty unordered object map with a default comparator,
	 * the default 
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * hash-bucket size</a>, one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
	 * hash bucket</a>, a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
	 * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
	 * hash-bucket container</a>. </p>
	 */
    public ooHashMap() {}

	/**
	 * Constructs an empty unordered object map with the
	 * specified hash-bucket size, a default comparator,
	 * one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
	 * hash bucket</a>, a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
	 * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * hash-bucket container</a>. </p>
	 *
	 * @param		<tt><i>bucketSize</i></tt>	The size of a hash bucket 
     * in the new unordered object map's hash table. See
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size</a>.
	 */
    public ooHashMap(int bucketSize)
    {
        _bucketSize = bucketSize;
    }
    
	/**
	 * Constructs an empty unordered object map with the specified 
     * comparator, the default hash-bucket 
     * size, one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * hash bucket</a>, a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * hash-bucket container</a>. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new object
	 * map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.
	 */
    public ooHashMap(ooCompare compare)
    {
        _comparator = compare;
    }

	/**
	 * Constructs an empty unordered object map with the specified 
     * comparator and hash-bucket size, one initial 
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * hash bucket</a>, 
     * a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * administrator</a> container, and a newly created 
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * hash-bucket container</a>. </p>
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new object
	 * map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
	 *
	 * @param		<tt><i>bucketSize</i></tt>	The size of a hash bucket 
     * in the new unordered object map's hash table. See
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size</a>.
	 *
	 */
    public ooHashMap(ooCompare compare, int bucketSize)
    {
        _comparator = compare;
        _bucketSize = bucketSize;
    }
    
	/**
	 * Constructs an empty unordered object map with 
	 * a default comparator, the default 
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * hash-bucket size</a>, and the specified 
     * number of initial hash buckets, administrator container, 
     * and hash-bucket container. </p>  
	 *
	 * @param		<tt><i>initialBuckets</i></tt>	The minimum number of 
     * initial hash buckets to create for the new unordered object map. See
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * Hash Buckets</a>.</p>    
     *
	 * @param		<tt><i>adminContainer</i></tt>	The container in 
     * which to store the hash administrator for the new unordered 
     * object map; specify null to store the hash administrator in a newly 
     * created container. See
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * Hash Administrator</a>.</p>
     *
	 * @param		<tt><i>bucketContainer</i></tt>	The container in 
     * which to store the initial hash buckets for the new unordered 
     * object map; specify null to store each initial hash bucket in its 
     * own newly created container. See
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * Containers for Hash Buckets</a>.
	 */
	public ooHashMap(int initialBuckets, ooContObj adminContainer, ooContObj bucketContainer) 
    {
        _adminContainer = adminContainer;
        _initialBuckets = initialBuckets;
        _bucketContainer = bucketContainer;
    }
    
	/**
	 * Constructs an empty unordered object map with 
	 * the default 
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * hash-bucket size</a> and the specified 
     * comparator, number of initial hash buckets, administrator container, 
     * and hash-bucket container. </p>  
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new object
	 * map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>.</p>
     *
	 * @param		<tt><i>initialBuckets</i></tt>	The minimum number of 
     * initial hash buckets to create for the new unordered object map. See
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * Hash Buckets</a>.</p>    
     *
	 * @param		<tt><i>adminContainer</i></tt>	The container in 
     * which to store the hash administrator for the new unordered 
     * object map; specify null to store the hash administrator in a newly 
     * created container. See
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * Hash Administrator</a>.</p>
     *
	 * @param		<tt><i>bucketContainer</i></tt>	The container in 
     * which to store the initial hash buckets for the new unordered 
     * object map; specify null to store each initial hash bucket in its 
     * own newly created container. See
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * Containers for Hash Buckets</a>.
	 */
	public ooHashMap(ooCompare compare, int initialBuckets, ooContObj adminContainer, ooContObj bucketContainer) 
    {
        _comparator = compare;
        _adminContainer = adminContainer;
        _initialBuckets = initialBuckets;
        _bucketContainer = bucketContainer;
    }

	/**
	 * Constructs an empty unordered object map with the specified 
     * comparator, hash-bucket size, number of initial hash buckets, 
     * administrator container, and hash-bucket container. </p>  
	 *
	 * @param		<tt><i>compare</i></tt>	The comparator for the new object
	 * map; must be an instance of an application-specific subclass of
	 * <tt>ooCompare</tt>. Specify null to use a default comparator.</p>
	 *
	 * @param		<tt><i>bucketSize</i></tt>	The size of a hash bucket 
     * in the new unordered object map's hash table. See
	 * <a href="../../../../../guide/jgdCollections.html#Bucket Size">
	 * Hash-Bucket Size</a>.</p>
     *
	 * @param		<tt><i>initialBuckets</i></tt>	The minimum number of 
     * initial hash buckets to create for the new unordered object map. See
	 * <a href="../../../../../guide/jgdCollections.html#Hash Buckets">
     * Hash Buckets</a>.</p>    
	 *
	 * @param		<tt><i>adminContainer</i></tt>	The container in 
     * which to store the hash administrator for the new unordered 
     * object map; specify null to store the hash administrator in a newly 
     * created container. See
	 * <a href="../../../../../guide/jgdCollections.html#HashAdministrator">
     * Hash Administrator</a>.</p>
     *
	 * @param		<tt><i>bucketContainer</i></tt>	The container in 
     * which to store the initial hash buckets for the new unordered 
     * object map; specify null to store each initial hash bucket in its 
     * own newly created container. See
	 * <a href="../../../../../guide/jgdCollections.html#BucketContainers">
     * Containers for Hash Buckets</a>.
     */
    public ooHashMap(ooCompare compare, int bucketSize, int initialBuckets, ooContObj adminContainer, ooContObj bucketContainer)
    {
        _comparator = compare;
        _bucketSize = bucketSize;
        _adminContainer = adminContainer;
        _initialBuckets = initialBuckets;
        _bucketContainer = bucketContainer;
    }
    
	/**
	 * Tests whether the specified
	 * object is a key of this unordered object map.
	 *
	 * <p>This method is equivalent to
	 * {@link #containsKey <tt>containsKey</tt>}; the intention of your code
	 * will  be clearer if you call <tt>containsKey</tt> instead of this
	 * method. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The object to be tested for
	 * containment in this unordered object map.
	 *
	 * <p>Typically, <tt><i>object</i></tt> is a persistent object, namely
	 * the key of interest.  If this unordered object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>object</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Unordered Collections">
	 * Comparator Class for Unordered Collections</a>.</p>
	 *
	 * @return		True if this unordered object map contains an element
	 * with the specified key; otherwise, false.</p>
	 */
    public boolean contains(Object object) {
         return containsKey(object);
    }

	/**
	 * Tests whether this unordered object map contains an element with the specified key.
	 *
	 * <p>You can call this method to check whether this unordered object map
	 * maps the specified key to some value. </p>
	 *
	 * @param		<tt><i>key</i></tt>	The key to be tested for containment
	 * in this unordered object map.
	 *
	 * <p>Typically, <tt><i>key</i></tt> is a persistent object, namely
	 * the key of interest.  If this unordered object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>key</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Unordered Collections">
	 * Comparator Class for Unordered Collections</a>.</p>
	 *
	 * @return		True if this unordered object map contains an element
	 * with the specified key; otherwise, false.</p>
	 *
	 * @see #containsValue(Object)
	 */
    public boolean containsKey(Object key)
    {
        return ((ooHashMapPersistor)getCollectionPersistor()).containsKey(key);
    }

	/**
	 * Tests whether this unordered object map contains an element with the specified value.
	 *
	 * <p>You can call this method to check whether this unordered object map
	 * maps at least one key to the specified value. </p>
	 *
	 * @param		<tt><i>value</i></tt>	The value to be tested for containment
	 * in this unordered object map.</p>
	 *
	 * @return		True if this unordered object map contains an element whose value is
	 * <tt><i>value</i></tt>; otherwise, false.</p>
	 *
	 * @see #containsKey(Object)
	 */
    public boolean containsValue(Object value)
    {
        return ((ooHashMapPersistor)getCollectionPersistor()).containsValue(value);
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public Set entrySet()
     {
        throw new UnsupportedOperationException();
     }

	/**
	 * Finds the value associated with the specified key in this
	 * unordered object map. </p>
	 *
	 * @param		<tt><i>key</i></tt>	The key to be looked up.
	 *
	 * <p>Typically, <tt><i>key</i></tt> is a persistent object, namely
	 * the key of interest.  If this unordered object map
	 * has an application-defined
	 * comparator that can identify a persistent object based on class-specific
	 * data, <tt><i>key</i></tt> can instead be a transient object
	 * that identifies the key of interest. See
	 * <a href="../../../../../guide/jgdCollections.html#Comparator Class for Unordered Collections">
	 * Comparator Class for Unordered Collections</a>.</p>
	 *
	 * @return		The value in the element with the specified key, or
	 * null if this unordered object map contains no mapping for that key.
	 *
	 * <p>A return value of null does not necessarily indicate that no element
	 * has the specified key. It is possible that this unordered object map explicitly
	 * maps the specified key to null. The
	 * {@link #containsKey <tt>containsKey</tt>} method may be used to
	 * distinguish these two cases. </p>
	 *
	 * @see #put(Object, Object)
	 */
    public Object get(Object key)
    {
        return ((ooHashMapPersistor)getCollectionPersistor()).get(key);
    }

	/**
	 * Initializes a scalable-collection iterator to find all keys in this unordered
	 * object map. </p>
	 *
	 * @return		A scalable-collection iterator that finds all the persistent objects used as
	 * keys in this unordered object map. The iterator finds the
	 * keys in an undefined order; however, it iterates through the
	 * key-value pairs of this unordered object map in the same order as does
	 * an iterator returned by <tt>valueIterator</tt>.</p>
	 *
	 * @see	#valueIterator
	 */
    public ooCollectionIterator keyIterator()
    {
        return (ooCollectionIterator) ((ooHashMapPersistor)getCollectionPersistor()).keyIterator();
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public Set keySet()
    {
        throw new UnsupportedOperationException();
    }

	/**
	 * Sets the maximum number of hash buckets per container for this
	 * unordered object map. </p>
	 *
	 * @param		<tt><i>max</i></tt>	The maximum number of
	 * hash buckets for this unordered object map that can be stored in a
	 * single container.
	 */
    public void maxBucketsPerContainer(int max)
    {
        ((ooHashMapPersistor)getCollectionPersistor()).maxBucketsPerContainer(max);
    }

	/**
	 * Adds all elements in the specified collection to this unordered object
	 * map.
	 *
	 * <p>If <tt><i>collection</i></tt> is an object map, its elements are
	 * added to this unordered object map. If this unordered object map currently
	 * has an element with the same
	 * key as an element of <tt><i>collection</i></tt>, the existing element
	 * is replaced by the element of <tt><i>collection</i></tt>.
	 *
	 * <p>If <tt><i>collection</i></tt> is a collection of persistent objects,
	 * each of its elements is added as a key to this unordered object map; the
	 * associated values are null. If this unordered object map currently
	 * has an element whose key is an element of <tt><i>collection</i></tt>,
	 * the value of the existing element is replaced by null. </p>
	 *
	 * @param		<tt><i>collection</i></tt>	The collection
	 * whose elements are to be added to this unordered object
	 * map.</p>
	 *
	 * @return		True if any elements were added; otherwise, false.
	 */
    public boolean ooAddAll(ooCollection collection)
    {
        if (collection == null || collection.isEmpty())
            return false;
        Iterator kItr;
        Iterator vItr;
        if (collection instanceof ooHashMap)
            {
                kItr = ((ooHashMap) collection).keyIterator();
                vItr = ((ooHashMap) collection).valueIterator();
            }
        else if (collection instanceof ooTreeMap)
            {
                kItr = ((ooTreeMap) collection).keyIterator();
                vItr = ((ooTreeMap) collection).valueIterator();
            }
        else
            {
                kItr = collection.ooIterator();
                Object obj;
                while (kItr.hasNext())
                {
                    obj = kItr.next();
                    if (obj instanceof java.util.Map.Entry)
                        put(((java.util.Map.Entry)obj).getKey(), ((java.util.Map.Entry)obj).getValue());
                    else
                        put(obj, null);
                }
                return true;
            }

        while (kItr.hasNext())
            put(kItr.next(), vItr.next());
       return true;
    }

	/**
	 * Initializes a scalable-collection iterator to find all keys in this unordered object map.
	 *
	 * <p>This method is equivalent to
	 * {@link #keyIterator <tt>keyIterator</tt>}; the intention of your code
	 * will  be clearer if you call <tt>keyIterator</tt> instead of this
	 * method. </p>
	 *
	 * @return		A scalable-collection iterator that finds all the persistent objects used as
	 * keys in this unordered object map. The iterator finds the
	 * keys in an undefined order; however, it iterates through the
	 * key-value pairs of this unordered object map in the same order as does
	 * an iterator returned by <tt>valueIterator</tt>.</p>
	 *
	 * @see	#valueIterator
	 */
    public ooCollectionIterator ooIterator()
    {
        return keyIterator();
    }

	/**
	 * Removes the element of this unordered object map, if any, with the specified
	 * key. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The key of the element to be 
     * removed.</p> 
	 *
	 * @return		True if an element was removed; otherwise, false.</p>
	 *
	 * @see			#remove(Object)
	 */
   public boolean ooRemove(Object object)
   {
        return getCollectionPersistor().remove(object);
   }

	/**
	 * Maps the specified key to the specified value in this unordered object map.
	 *
	 * <p>If this unordered object map already contains an element with the specified
	 * key, this method replaces the value in that element.  Otherwise, this
	 * method adds a new element with the specified key and value. </p>
	 *
	 * @param		<tt><i>key</i></tt>	The key;
	 * must be an instance of a persistence-capable class.
	 * If <tt><i>key</i></tt> is transient, this method makes it
	 * persistent.</p>
	 *
	 * @param		<tt><i>value</i></tt>	The value;
	 * must be an instance of a persistence-capable class
	 * or null. If <tt><i>value</i></tt> is a transient object, this method
	 * makes it persistent.</p>
	 *
	 * @return		The value previously associated with <tt><i>key</i></tt>
	 * in this unordered object map, or null if there was no mapping for
	 * <tt><i>key</i></tt>.
	 *
	 * <p>Note that a null return might indicate that this unordered object
	 * map previously mapped <tt><i>key</i></tt> to null. </p>
	 *
	 * @see #get(Object)
	 * @see #putAll(Map)
	 */
    public Object put(Object key, Object value)
    {
        Object ret = get(key);
        getCollectionPersistor().put(key, value);
        return ret;
    }

	/**
	 * Adds all elements in the specified map to this unordered object map.
	 *
	 * <p>If this unordered object map currently has an element with the same
	 * key as an element of <tt><i>map</i></tt>, the existing element
	 * is replaced by the element of <tt><i>map</i></tt>. </p>
	 *
	 * @param		<tt><i>map</i></tt>	The map
	 * whose elements are to be added to this unordered object map. Every key
	 * and every value in <tt><i>map</i></tt> must be an instance of a
	 * persistence-capable class. If any key or value is transient, this
	 * method makes it persistent.</p>
	 *
	 * @see #put(Object, Object)
	 * @see #ooAddAll(ooCollection)
	 */
    public void putAll(Map map)
    {
        if (map instanceof ooCollection)
            ooAddAll((ooCollection) map);
        else
            {
                Iterator itr = map.entrySet().iterator();
                java.util.Map.Entry obj;
                 while (itr.hasNext())
                 {
                   obj = (java.util.Map.Entry) itr.next();
                   put(obj.getKey(), obj.getValue());
                 }
            }
    }

	/**
	 * Removes the element of this unordered object map, if any, with the specified
	 * key. </p>
	 *
	 * @param		<tt><i>object</i></tt>	The key of the element to be 
     * removed.</p> 
	 *
	 * @return		The value in the element that was removed, or null
	 * if there was no mapping for <tt><i>object</i></tt>.
     * A null return can also indicate that this unordered object map previously
	 * mapped the key <tt><i>object</i></tt> to null.</p>
	 *
	 * @see		#ooRemove(Object)
	 */
    public Object remove(Object object)
    {
        Object ret = get(object);
        getCollectionPersistor().remove(object);
        return ret;
    }

	/**
	 * Initializes a scalable-collection iterator to find all values in this unordered
	 * object map. </p>
	 *
	 * @return		A scalable-collection iterator that finds all the persistent objects used as values
	 * in elements of this object map. The iterator finds the
	 * values in an undefined order; however, it iterates through the
	 * key-value pairs of this unordered object map in the same order as does
	 * an iterator returned by <tt>keyIterator</tt>.</p>
	 *
	 * @see	#keyIterator
	 */
    public ooCollectionIterator valueIterator()
    {
        return (ooCollectionIterator) ((ooHashMapPersistor)getCollectionPersistor()).valueIterator();
    }

	/**
	 * Reserved for future use; you should not call this method. </p>
	 */
    public Collection values()
    {
        throw new UnsupportedOperationException();
    }

}
