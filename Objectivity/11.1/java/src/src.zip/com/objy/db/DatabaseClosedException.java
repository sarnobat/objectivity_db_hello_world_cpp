/*
 * @(#)DatabaseClosedException.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db ;

/**
 * Signals that a connection to the federated database was closed during an operation
 * that requires that connection to be open.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching checked exceptions.
 */
public class   DatabaseClosedException
       extends ODMGException
{
	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching checked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public DatabaseClosedException()
        { super() ; }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching checked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public DatabaseClosedException(String msg)
        { super(msg) ; }    
}


