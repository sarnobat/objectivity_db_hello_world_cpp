/*
 * @(#)ooAbstractObj.java
 *
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

/**
 * Abstract superclass for classes that represent Objectivity/DB objects,
 * namely, federated database, databases, containers, basic objects, and 
 * autonomous partitions.
 *
 * <p>Because this class is abstract, you never instantiate it; instead, you work with
 * instances of its derived classes.  You should not create a subclass of
 * this class, but you may create subclasses of certain derived classes, such
 * as <a href="ooObj.html"><tt>ooObj</tt></a> and
 * <a href="storage/ooContObj.html"><tt>ooContObj</tt></a>.
 *
*/
abstract public class ooAbstractObj
{
    /**
      * Reserved for internal use.
      */
  	public ooAbstractObj() {}
}


