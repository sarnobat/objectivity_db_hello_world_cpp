/*
 * @(#)ooAPObj.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app.storage ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.ObjectIsDeadException ;

import com.objy.db.app.Iterator;
import com.objy.db.app.Session;
import com.objy.db.app.ooAbstractObj;
import com.objy.db.app.ooFDObj;
import com.objy.db.app.ooId;
import com.objy.db.iapp.PooAPObj ;

/**
 * <p><i>(HA)</i> Represents an Objectivity/DB autonomous partition.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>You can create and work with autonomous partitions only if you have 
 * bought and installed Objectivity/DB High Availability 
 * (Objectivity/HA).  
 *
 * <p>An <i>autonomous partition</i> is an independent piece of a federated 
 * database. Each autonomous partition is self-sufficient in case a network 
 * or system failure occurs in another partition. Although data physically 
 * resides in database files, each autonomous partition controls access to 
 * particular databases.     
 *
 * <p>For additional information about autonomous partitions and a discussion 
 * of how an application can create and work with autonomous partitions,
 * see <A HREF="../../../../../../guide/jgdPartitions.html#_top_">
 * Autonomous Partitions</A>.
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 * 
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Modifying</B></TD>
 *
 * <TD><A HREF="#delete()">delete()<BR></A></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting&nbsp;Information</B></TD>
 *
 * <TD><A HREF="#getFD()">getFD()<BR>
 * </A><A HREF="#getSession()">getSession()</A> <BR>
 * <A HREF="#getName()">getName()<BR>
 * </A><A HREF="#getNumber()">getNumber()<BR>
 * </A><A HREF="#getLockServerHost()">getLockServerHost()</A><BR>
 * <A HREF="#getSystemDBFileHost()">getSystemDBFileHost()</A><BR>
 * <A HREF="#getSystemDBFilePath()">getSystemDBFilePath()</A><BR>
 * <A HREF="#getBootFileHost()">getBootFileHost()</A><BR>
 * <A HREF="#getBootFilePath()">getBootFilePath()</A><BR>
 * <A HREF="#getJournalDirHost()">getJournalDirHost()</A><BR>
 * <A HREF="#getJournalDirPath()">getJournalDirPath()</A><BR>
 * <A HREF="#getPartitionWeight()">getPartitionWeight()</A>
 * </TD></TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 * <TD><A HREF="#isDead()">isDead()</A> <BR>
 * <A HREF="#isAccessible()">isAccessible()</A> <BR>
 * <A HREF="#isOnline()">isOnline()</A></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Setting&nbsp;Information</B></TD>
 *
 * <TD><A HREF="#setOnline(boolean)">setOnline(boolean)<BR>
 * <A HREF="#setPartitionWeight(int)">setPartitionWeight(int)</A></TD>
 * </TR>
 * 
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Contained&nbsp;Objects</B></TD>
 *
 * <TD><A HREF="#imagesContainedIn()">imagesContainedIn()</A></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Managing&nbsp;Availability</B></TD>
 *
 * <TD><A HREF="#setOnline(boolean)">setOnline(boolean)</A><BR>
 * <A HREF="#isOnline()">isOnline()</A><BR>
 * <A HREF="#isAccessible()">isAccessible()</A> <BR>
 * <A HREF="#ensureAllImagesInQuorums()">ensureAllImagesInQuorums()</A></TD>
 * </TR>
 * </TABLE>
 *
 *
 */
final public class ooAPObj
    extends ooAbstractObj
{
    private transient PooAPObj persistor ;

    private ooAPObj()
        { }

	/**
     * Reserved for internal use; to create an autonomous partition object, call one of the
	 * <a href="../ooFDObj.html#newAP(java.lang.String, java.lang.String, java.lang.String, java.lang.String)"><tt>newAP</tt></a>
	 * methods of a federated database.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public ooAPObj(PooAPObj persistor) {
        if (persistor == null)
            throw new ObjyRuntimeException("Users should not directly instantiate ooAPObj");
        this.persistor = persistor ;
    }

    /**
     * Gets the session in which this autonomous partition was created
	 * or retrieved.</P>
	 *
     * @return  The session in which this autonomous partition was created
	 * or retrieved.
     */
    public Session getSession()
        { return persistor().getSession() ; }

    // DAD New HA Stuff
	/**
	 * Tests whether the current process can access this autonomous partition.
	 * 
	 * <p>This partition is considered accessible if the application can successfully
	 * open the partition's system-database file using AMS, contact the partition's lock 
	 * server, and write to the partition's journal directory. Consequently, this method
	 * could take a significant amount of time waiting for connection attempts to time out.</P>
	 *
	 * @return      True if the Objectivity/DB system resources of the partition are 
	 * accessible to the current process; otherwise; otherwise false.</P>
	 *
	 */
    public boolean isAccessible()
        { return persistor().isAccessible() ; }

    // DAD New HA Stuff
	/**
	 * Ensures the images controlled by this autonomous partition are in the 
	 * quorums for their respective databases.
	 * 
	 * <p>Calling this member function is equivalent to calling a database's 
	 * ensureImageInQuorum method for each database that has an image 
	 * controlled by this partition. In addition, this autonomous partition itself 
	 * is added to the quorum of partitions.
	 *  
	 * <p>If your application includes a reinitialization procedure that is executed when an 
	 * autonomous partition is restored into service, that procedure should call this 
	 * method for the restored partition. 
	 * 
	 * <p>This method ignores an image if it is already in the quorum or if it is the 
	 * only image of an unreplicated database. 
	 * 
	 * <p>This method updates the quorums for as many databases as possible, 
	 * and then throws an exception if any image could not be accessed, or if a quorum for 
	 * any database could not be accessed, or if the application is currently performing 
	 * nonquorum reading in any database. (Nonquorum reading prohibits further 
	 * quorum activity for the rest of the transaction. You can disable nonquorum 
	 * reading by ending the current transaction; then proceed in a new transaction.)</p>
	 *
	 * 
	 * @see ooDBObj#ensureImageInQuorum
	 *
	 */
    public void ensureAllImagesInQuorums()
        { persistor().ensureAllImagesInQuorums() ; }

    /**
     * Tests whether this autonomous partition is
     * enabled for unrestricted access by tools and applications.</P>
	 *
     * @return      True if the partition is accessible without restriction; otherwise false.</P>
	 *
     * @see Session#getOfflineMode
     * @see Session#setOfflineMode
     */
    public boolean isOnline()
        { return persistor().isOnline() ; }

	/**
	 * Tests whether this autonomous partition is dead.
	 *
     * <p>A partition is made dead when you <a href="#delete()">delete</a> it,
     * abort the transaction in which the partition was created,
     * or terminate the session to which it belongs.</P>
	 *
     * @return	    True if this object is dead; otherwise, false.
	 */
    public boolean isDead()
        { return persistor == null ; }

    /**
     * Gets the hostname of the machine that
     * contains this autonomous partition's boot file.</P>
	 *
     * @return      The hostname of the machine that
     * contains this autonomous partition's boot file.
     */
    public String getBootFileHost()
        { return persistor().getBootFileHost() ; }

    /**
     * Gets the full pathname of this autonomous
     * partition's boot file.</P>
	 *
     * @return      The full pathname of this autonomous partition's boot 
     * file. 
     */
    public String getBootFilePath()
        { return persistor().getBootFilePath() ; }

    /**
     * Gets the hostname of the machine that contains
     * this autonomous partition's journal directory.</P>
	 *
     * @return      The hostname of the machine that contains this autonomous
     * partition's journal directory.
     */
    public String getJournalDirHost()
        { return persistor().getJournalDirHost() ; }

    /**
     * Gets the full pathname of this autonomous
     * partition's journal directory.</P>
	 *
     * @return      The full pathname of this autonomous partition's journal 
     * directory. 
     */
    public String getJournalDirPath()
        { return persistor().getJournalDirPath() ; }

    /**
     * Gets the hostname of the machine running the lock-server process
     * used by this autonomous partition.</P>
	 *
     * @return  The hostname of the machine running the lock-server process
     * used by this autonomous partition.
     */
    public String getLockServerHost()
        { return persistor().getLockServerHost() ; }

    /**
     * Gets the system name of this autonomous partition.</P>
	 *
     * @return      The system name of this autonomous partition.
     */
    public String getName()
        { return persistor().getName() ; }

	/**
	 * 
	 *
   	 * @deprecated	Use {@link #getNumber <tt>getNumber</tt>}
	 */
    public ooId getOid()
        { return persistor().getOid() ; }

    /**
     * Gets the hostname of the machine that contains this autonomous
     * partition's system-database file.</P>
	 *
     * @return  The hostname of the machine that contains this autonomous
     * partition's system-database file.
     */
    public String getSystemDBFileHost()
        { return persistor().getSystemDBFileHost() ; }

    /**
     * Gets the full pathname of this autonomous
     * partition's system-database file.</P>
	 *
     * @return  The full pathname of this autonomous partition's
     * system-database file.
     */
    public String getSystemDBFilePath()
        { return persistor().getSystemDBFilePath() ; }

    /**
	 * Gets the federated database containing this autonomous partition.</P>
	 * 
	 * <p>This method must be called within a transaction.</p>

	 * @return		The federated database containing this autonomous
	 * partition.
     */
    public ooFDObj getFD()
        { return persistor().getFD() ; }

    /**
	 * Gets the partition weight for this autonomous partition.</P>
	 *
	 * @return		The partition weight for this autonomous
	 * partition.
     */
    public int getPartitionWeight()
        { return persistor().getPartitionWeight() ; }

    /**
	 * Sets the partition weight for this autonomous partition.</P>
	 *
	 * @param 	 weight The partition weight for this 
	 * autonomous partition.
     */
    public void setPartitionWeight(int weight)
        { persistor().setPartitionWeight(weight) ; }

    /**
     * Enables or restricts the accessibility of this autonomous partition
     * to tools and applications.</P>
	 *
     * @param 	 online True to enable unrestricted access to
     * this partition, and false to restrict the accessibility of this 
     * partition.</P> 
	 *
     * @see Session#getOfflineMode
     * @see Session#setOfflineMode
     * @see #isOnline
     */
    public void setOnline(boolean online)
        { persistor().setOnline(online) ; }

    /**
     * Deletes this autonomous partition.
     *
     * <p>When an autonomous partition is deleted:
     *
	 * <p><ul type=disc>
     * 
     * <li>All user data is cleared from the autonomous partition.
     * If the partition controls database images
     * and multiple images exist for the database, then the images in this
     * autonomous partition are deleted. If the partition controls the only image
     * of a database, the partition is left undeleted.</p>
     *
     * <li>The autonomous partition's system-database file and boot file are deleted
	 * from the file system.</p>
     * </ul>
     *
	 * <p>If the partition is in a Release 9.0 or later federated database,
	 * aborting the transaction restores 
	 * the deleted system-database file and boot file. 
	 *  
     * <p><b>Warning: </b>Aborting the transaction will <i>not</i> restore deleted files
	 * if the partition is in a pre-Release 9.0 federated database.
     */
    public void delete()
        { persistor().delete() ; }

    /**
     * Initializes an object iterator to find the database images
     * controlled by this autonomous partition.</P>
	 *
     * @return      An object iterator that finds the database images
     * controlled by this autonomous partition.
     * When the object iterator gets a database, it does not open or lock the database.
     */
    public Iterator imagesContainedIn()
        { return persistor().imagesContainedIn(); }

	/**
	 * @deprecated
	 * Names the specified object in the scope of this autonomous partition.
     *
	 */
    public void nameObj(Object object, String scopeName)
        { persistor().nameObj(object, scopeName) ; }

	/**
	 * @deprecated
	 * Removes the specified object's name from the
	 * name scope of this autonomous partition.
	 *
	 */
    public void unnameObj(Object object)
        { persistor().unnameObj(object) ; }

	/**
	 * @deprecated
	 * Looks up the object with the specified scope name in the scope defined
     * by this autonomous partition.</P>
	 *
	 */
    public Object lookupObj(String scopeName)
        { return persistor().lookupObj(scopeName) ; }

	/**
	 * @deprecated
	 * Looks up the object with the specified scope name in the scope defined
     * by this autonomous partition, locking the
	 * found object as specified.</P>
	 *
	 */
    public Object lookupObj(String scopeName, int lockMode)
        { return persistor().lookupObj(scopeName, lockMode) ; }

	/**
	 * @deprecated
	 * Looks up the name of the specified object in the scope defined
     * by this autonomous partition.</P>
	 *
	 */
    public String lookupObjName(Object object)
        { return persistor().lookupObjName(object) ; }

    /**
     * Gets the integer identifier of this autonomous partition.</p>
     *
     * @return      The integer identifier of this autonomous partition.
     */
    public long getNumber()
        { return persistor().getNumber() ; }

	/**
	 * Reserved for internal use; you should not call this method.
	 */
    public synchronized void setPersistor(PooAPObj persistor)
        { this.persistor = persistor ; }

    synchronized PooAPObj persistor() {
        if (persistor == null)
            throw new ObjectIsDeadException("Attempted persistent operation on dead partition");
        return persistor ;
    }
}
