/*
 * @(#)ooReference.java
 *
 * Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.iapp.Persistent ;
import com.objy.db.iapp.PooReference ;
import com.objy.pm.Access ;
import java.lang.ref.ReferenceQueue ;


/**
 * Represents a <i>garbage-collectible reference object</i> to be used to link persistent
 * objects.</p>
 * 
 * <p><h2>About Garbage-Collectible Reference Objects</h2>
 * 
 * <p>
 * <i>Garbage-collectible reference objects</i> can be used in place of 
 * an ordinary strong references to enable you to 
 * work with large application-defined data structures in local memory.  
 * Each garbage-collectible reference object
 * creates an <i>internal reference</i> that
 * extends either {@link java.lang.ref.WeakReference 
 * <tt>java.lang.ref.WeakReference</tt>} or {@link java.lang.ref.SoftReference
 * <tt>java.lang.ref.SoftReference</tt>}.</p>
 * 
 * <p> 
 * You use this class as the data type of <i>garbage-collectible reference fields</i>
 * in an application-defined persistence-capable class.
 * In memory, a persistent object uses each of its garbage-collectible reference fields to
 * hold a garbage-collectible reference object, which in turn 
 * has an internal weak or soft reference to  
 * some other persistent object (the <i>referent</i>).
 * The holding persistent object creates its garbage-collectible reference objects as necessary
 * when its data is fetched,
 * using information stored in a <a href = "ooReferenceData.html">reference-data object</a>.
 * </p>
 * 
 * <p>
 * You typically use garbage-collectible reference fields to represent the nodes or elements
 * of data structures that will need to link 
 * to more persistent objects than can fit in a session cache at the same time.
 * When such a data structure is in memory, 
 * the soft or weak references enable the garbage collector 
 * to release any elements of the data structure that are not otherwise being used.
 * </p>
 * 
 * <p><b>Note: </b>See the <a href="http://support.objectivity.com">Objectivity Developer Network</a> to 
 * download sample Objectivity for Java application code.</p>
 * 
 *
 */
public class ooReference 
{

    private transient PooReference persistor ;

    /**
     * Constructs a garbage-collectible reference object of the desired type.
     *
     * @param 	 referent The persistent object that is
     * referenced.</p>
     *
     * @param 	 refType The desired reference type; one
     * of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
     *  <dt><tt>WEAK</tt><dd>Create an internal weak reference.</dd>
     *  <dt><tt>SOFT</tt><dd>Create an internal soft reference.</dd>
     * </dd></dl></dl>
     */
    public ooReference(Persistent referent, int refType) {
	if (referent == null)
	    throw new ObjyRuntimeException("Must pass non-null referent") ;
	if (refType == oo.SOFT)
	    persistor = Access.new_ooSoftReferencePersistor(this, referent) ;
	else
	    persistor = Access.new_ooWeakReferencePersistor(this, referent) ;
    }

    /**
     * Constructs a garbage-collectible reference object of the desired type, registering it
     * with a reference queue.</p>
     *
     * @param 	 referent The persistent object that is
     * referenced.</p>
     *
     * @param 	 refType The desired reference type; one
     * of the following constants defined in the
     * <tt>com.objy.db.app.oo</tt> interface):
     * <dl><dd><dl>
     *  <dt><tt>WEAK</tt><dd>Create an internal weak reference.</dd>
     *  <dt><tt>SOFT</tt><dd>Create an internal soft reference.</dd>
     * </dd></dl></dl></p>
     *
     * @param 	 queue The reference queue with which to 
     * register the internal reference.</p>
     *
     * @param 	 data An optional array of long integers to be used
     * for restoring the referent to memory if it is needed again 
	 * after being garbage collected.
     */
    public ooReference(Persistent referent, int refType, ReferenceQueue queue, long[] data) {
	if (referent == null)
	    throw new ObjyRuntimeException("Must pass non-null referent") ;
	if (refType == oo.SOFT)
	    persistor = Access.new_ooSoftReferencePersistor(this, referent, queue, data) ;
	else
	    persistor = Access.new_ooWeakReferencePersistor(this, referent, queue, data) ;
    }

    /**
     * Gets the persistent object being referenced by this garbage-collectible reference object.</p>
     *
     * <p>If the referent has been garbage collected, it is first retrieved
     * from the connected federated database.</p>
     *
     * @return	The referent of the internal weak or soft reference.
     */
    public Object get() {
	return persistor.get() ;
    }

    /**
     * Gets this garbage-collectible reference object's long array of data, if it has one.</p>
     *
     * <p>If the referent is needed again after it has been garbage collected,
     * the information in the array of long integers can be used to restore it to local memory.
     * For example, if the garbage-collected referent is an element 
	 * in a custom persistent collection, 
	 * the array information could be used to restore pathways among the collection's
	 * intermediate nodes.</p>
     * 
     * @return	An array of long integers that can be used
     * for restoring the referent to memory if it is needed again 
	 * after being garbage collected.</p>
     *
     * @see #setData
     */
    public long[] getData() 
	{
	return persistor.getData() ;
    }

    /**
     * Sets an optional long array of data for this garbage-collectible reference object.</p>
     *
     * <p>If the referent is needed again after it has been garbage collected,
     * the information in the optional array of long integers 
	 * can be used to restore it to local memory.
     * For example, if the garbage-collected referent is an element 
	 * in a custom persistent collection, 
	 * the array information could be used to restore pathways among the collection's
	 * intermediate nodes.</p>
     * 
     * @param 	 data An array of long integers that can be used
     * for restoring the referent to memory if it is needed again 
	 * after being garbage collected.</p>
     *
     * @see #getData
     */
    public void setData(long[] data) 
	{
	persistor.setData(data) ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void setPersistor(PooReference persistor) {
	this.persistor.terminate() ;
	this.persistor = persistor ;
    }

}
