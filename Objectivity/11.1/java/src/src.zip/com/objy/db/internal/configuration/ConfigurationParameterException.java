package com.objy.db.internal.configuration;


import com.objy.db.ObjyRuntimeException;

/*
 * The equivalent C++ class has ParameterErrors as holder for the actual
 * errors. We just use an array of String instead so we don't need to wrap
 * that class, which is only used because we can't expose a vector (of strings)
 * in our api
 */

/**
 * Signals an error in the parameters for a tool execution
 * 
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class ConfigurationParameterException extends ObjyRuntimeException
{
    private String[] mErrors;
    /**
     * Reserved for internal use; you obtain an exception of this class
     * only by catching unchecked exceptions.
     *
     * <p>You should not use this constructor directly.
     */
    public ConfigurationParameterException(String message) {
        super(message) ;      
    }
    
    /**
     * Gets the number of errors from the parameters for tool execution.
     * @return Number of errors
     */
    public int getNumberOfErrors()
    {
        return mErrors.length;
    }
   
    /**
     * Gets the error string at the supplied index
     * @param index index of the error string to be obtained
     * @return Error string at the specified index
     */
    public String getError(int index)
    {        
        if(index >= mErrors.length)
            throw new IllegalArgumentException("Index must be less than number of errors.");
        return mErrors[index];
    }
}
