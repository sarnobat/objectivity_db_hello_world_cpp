/*
* @(#)QuerySplitter.java
*
* Copyright (c) 2006 Objectivity, Inc. All Rights Reserved.
*
* This software is the confidential and proprietary information of
* Objectivity, Inc. ("Confidential Information").  You shall not
* disclose such Confidential Information and shall use it only in
* accordance with the terms of the license agreement you entered into
* with Objectivity.
*
* OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
* OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
* THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
* PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
* DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
* DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
*
*/

package com.objy.db.app;

import com.objy.db.app.storage.ooContObj;
import com.objy.db.app.storage.ooDBObj;
import com.objy.query.expression.Expression;

/**
 * Defines behavior shared by all query splitters.</p>
 *  <p>
 *  <b>Note:</b> <i>For backward compatibility only. </i>QuerySplitter
 * should be used only in an application that performs explicit 
 * placement. Do not use a QuerySplitter in an application that 
 * accesses a placement-managed federated database. 
 * See <a href="./storage/package-summary.html#Placement">Mechanisms for Placing Persistent Objects</a>.
 * </p>
 * When you start a <a href="../../../../../guide/jgdPQE.html"> parallel query</a>  
 * to find persistent objects in a federated database or a database, 
 * the query manager of the parallel query uses a <i>query splitter</i> to split the overall query into individual
 * subtasks that can be performed in parallel by the threads of one or more query server processes running on separate hosts.
 * </p>
 * 
 * A standard parallel query uses an internal default query splitter
 * to split the search into individual tasks. A standard parallel query over a federated database scans 
 * every database in the federation; a standard parallel query over a database scans 
 * every container in the database.</p>
 * 
 * 
 * 
 * A custom parallel query can narrow its search by using a custom query splitter to filter out irrelevant databases 
 * or containers from the set of query tasks.  Such a query splitter prevents the parallel query from spending time 
 * scanning databases or containers that need not be searched.</p>
 * 
 * A custom query splitter is an instance of an application-defined class that implements the <tt>QuerySplitter</tt> interface. 
 * You invoke a custom query splitter by specifying it to one of the following methods that starts a custom
 * parallel query:
 * <ul type=disc>
 * <li><a href="storage/ooDBObj.html#parallelScan(java.lang.String, java.lang.String, com.objy.db.app.QuerySplitter)">
 * <tt>ooDBObj.parallelScan(String, String, QuerySplitter)</tt></a> 
 * <li><a href="ooFDObj.html#parallelScan(java.lang.String, java.lang.String, com.objy.db.app.QuerySplitter)">
 * <tt>ooFDObj.parallelScan(String, String, QuerySplitter)</tt></a>
 * </ul></p>
 * 
 * 
 */
public interface QuerySplitter {

	/**
	 * Performs any desired initialization work at the beginning of a parallel query.</p>
	 *
	 * <p>This method is called at the beginning of a parallel scan, before any of the other methods are called. This method
	 * is passed the OID of the database or federated database to be searched by the parallel query, 
	 * and the type number of the class of objects to be found. </p>
	 *
	 * @param 	 obj The database or federated database to be scanned (the query scope of the parallel query).</p>
	 *
	 * @param 	 typeNumber The type number of the class of objects to be found.</p>
	 *
	 * @param 	 expr Specify null. (Reserved for future use.) 
	 */
	public void initScan(ooId obj, long typeNumber, Expression expr) ;

	/**
	 * Performs any necessary cleanup work at the end of a parallel query.</p>
	 * 
	 * <p> This method is called when a parallel query terminates, either after all of the data
	 * has been processed or when the parallel query's iterator is closed.</p>
	 */
	public void endScan();

	/**
	 * Checks whether any databases or containers are eligible for assignment in a query task, 
	 * and, if so, defines a new query task as a range of database OIDs or container OIDs.</p>
	 *
	 * <p>This method is called repeatedly to split a parallel query into subtasks that can be assigned
	 * to one or more query servers. Each time this method is called,
	 * it sets <tt><i>start</i></tt> and <tt><i>end</i></tt> to designate an inclusive range 
	 * of databases or containers to be scanned as a single task by a particular query thread.
	 * If the range consists of a single database or container, this method  sets <tt><i>start</i></tt> and <tt><i>end</i></tt>
	 * to the same value.</p>
	 * 
	 * <p>This method can be implemented to call {@link #nextDB} or {@link #nextCont} to find the next  
	 * eligible database or container, if there is one.</p>
	 *
	 * @param 	 start The starting OID of the range.</p>
	 *
	 * @param 	 end The ending OID of the range.</p>
	 *
	 * @return True if a new query task is defined; otherwise, false.
	 */
	public boolean nextRange(ooIdPQ start, ooIdPQ end);

	/**
	 * Finds the next database, if there is one, that can be assigned in a query task.</p>
	 *
	 * This method can be implemented to call {@link #applicableDB} to filter out databases that should not be scanned.</p>
	 *
	 * @param 	 filterContainers True if the containers within the database
	 * are to be considered individually during task assignment; false if the entire database is to be assigned as a single task.</p>
	 *
	 * @return True if an eligible database is found; otherwise, false.
	 * 
	 */
	public boolean nextDB(boolean filterContainers);

	/**
	 * Finds the next container, if there is one, that can be assigned in a query task.</p>
	 *
	 *
	 * This method can be implemented to call {@link #applicableCont} to filter out containers that should not be scanned.</p>
	 * 
	 * @return True if an eligible container is found;
	 * otherwise, false.
	 */
	public boolean nextCont();

	/**
	 * Determines whether the specified object should be tested or ignored by the parallel query.</p>
	 *
	 * <p>This method uses application-specific criteria to determine whether the specified OID 
	 * should be further assigned to a query thread for testing.
	 * If so, the query thread will apply the predicate condition to the object as part of the parallel query.
	 * If not, the parallel query will skip over the object.</p>
	 *
	 * @param 	 oid  The object to be examined.</p>
	 *
	 * @return True if the object should be tested by the parallel query; false if it should be skipped.
	 */
	public boolean applicableObject(ooId oid);

	/**
	 * Determines whether the specified database should be scanned or ignored by the parallel query.</p>
	 *
	 * <p>This method uses application-specific criteria to determine whether the specified database is
	 * eligible for inclusion in a query task. If so, a query thread will scan the database's contents as part of the parallel query. 
	 * If not, the parallel query will skip over the database and its contents.
	 * </p>
	 *
	 * @param 	 db  The database to be examined.</p>
	 *
	 * @param 	 filterContainers True if the containers within the database
	 * are to be considered individually during task assignment; false if the entire database is to be assigned as a single task.</p>
	 *
	 * @return True if the database should be scanned; false if it should be skipped.
	 */
	public boolean applicableDB(ooDBObj db, boolean filterContainers);

	/**
	 * Determines whether the specified container should be scanned or ignored by the parallel query.</p>
	 *
	 * 
	 * <p>This method uses application-specific criteria to determine whether the specified container is
	 * eligible for inclusion in a query task. 
	 * If so, a query thread will scan the container's contents as part of the parallel query. 
	 * If not, the parallel query will skip over the container and its contents.</p>
	 *
	 * @param 	 cont  The container to be examined, typically an existing container in
	 * a database for which <tt>applicableDB</tt> returned true.</p>
	 *
	 * @return True if the container should be scanned; false if it should be skipped.
	 */
	public boolean applicableCont(ooContObj cont);

}


