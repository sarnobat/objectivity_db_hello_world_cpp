package com.objy.query.expression;
/**
 * Represents an integer literal value node.
 *
 */
public class IntLiteralValueExpression extends LiteralValueExpression 
{
    /**
     * Default constructor.
     */
    public IntLiteralValueExpression() 
    {
        this(Binding.create());
    }
    
    /**
     * Constructor taking an integer value.
     */
    public IntLiteralValueExpression(int val) 
    {
        this(Binding.create(val));
    }
    
    IntLiteralValueExpression(long id) 
    {
        setIdAfterNullCheck(id);
    }

    /**
     * Returns the type of the expression (oocIntLiteralValueExpression).
     */
    @Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.IntLiteralValueExpression; 
    }

    /**
     * Returns the integer literal value.
     */
    public long getValue() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getValue(mId);
    }

    /**
     * Sets the integer literal value.
     */
    public void setValue(int val) 
    {
        throwExceptionIfInvalidOrClosed(mId);
        Binding.setValue(mId, val);
    }

    @Override
    public String toString()
    {
        if (getId() != 0)
        {
            return Long.toString(getValue());
        }
        return "";
    }
    
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitIntLiteralValue(this);
    }
    
    static class Binding
    {
        private static native long create();
        private static native long create(int val);
        private static native long getValue(long id);
        private static native void setValue(long id, int value);
    }
}
