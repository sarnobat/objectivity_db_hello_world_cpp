package com.objy.query.expression;

/**
 * Represents an expression result specification.
 *
 */
public class ExpressionResultSpec extends AbstractExpression
{
    /**
     * Constructor taking an ID.
     */
    private ExpressionResultSpec(long id) 
    {
        setIdAfterNullCheck(id);
    }

    /**
     * Returns the expression result specification identified by the given ID.
     */
    public static ExpressionResultSpec getExpressionResultSpec(long id)
    {
    	if (id != 0)
        {
	        return new ExpressionResultSpec(id);
        }
    	return null;
    }

    /**
     * Returns the data type.
     */
    public DataType getDataType() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return DataType.fromValue(Binding.getDataType(mId));
    }

    /**
     * Returns a string representation of the data type.
     */
    public String getDataTypeName()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getDataTypeName(mId);
    }

    /**
     * Returns the element result spec for results whose data type includes
     * oocQCollection.
     */
    public ExpressionResultSpec getElementSpec()
    {
        throwExceptionIfInvalidOrClosed(mId);
    	long id = Binding.getElementSpec(mId);
        if (id == mId)
            return this;
        return ExpressionResultSpec.getExpressionResultSpec(id);
    }

    /**
     * Returns the referenced or embedded class for object results; 
     * 0 for other results.  
     */
    public long getAssociatedClass() 
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.getAssociatedClassTypeNumber(mId);
    }

    /**
     * Returns true if the value is a literal, meaning that its value is
     * not derived from objects being evaluated.
     */
    public boolean isLiteral()
    {
        throwExceptionIfInvalidOrClosed(mId);
    	return Binding.isLiteral(mId);
    }

    /**
     * Returns true if the specified result is a collection; false otherwise.
     */
    public boolean isCollection()
    {
        throwExceptionIfInvalidOrClosed(mId);
        return Binding.isCollection(mId);
    }

    static class Binding
    {
        // Returns the data type
        private static native int getDataType(long id);
        
        // Returns the element result spec for results whose data type includes
        // oocQCollection.
        private static native long getElementSpec(long id);
        
        // Returns the referenced or embedded class for object results; 
        // 0 for other results.  
        private static native long getAssociatedClassTypeNumber(long id);
        
        // Returns true if the value is a literal, meaning that its value is
        // not derived from objects being evaluated.
        private static native boolean isLiteral(long id);
        
        // Returns a string representation of the data type.
        private static native String getDataTypeName(long id);
        
        // Returns true if the specified result is a collection; false otherwise.
        private static native boolean isCollection(long id);
        
    }
}
