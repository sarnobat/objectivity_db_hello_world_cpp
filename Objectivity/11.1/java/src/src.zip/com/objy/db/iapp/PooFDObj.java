/*
 * @(#)PooFDObj.java
 * 
 * Copyright (c) 1999 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.iapp;

import com.objy.db.ObjectNameNotFoundException ;
import com.objy.db.ObjectNameNotUniqueException ;

import com.objy.db.app.ooObj ;
import com.objy.db.app.ooId ;
import com.objy.db.app.Session ;
import com.objy.db.app.ooFDObj ;
import com.objy.db.app.Iterator ;
import com.objy.db.app.QuerySplitter ;
import com.objy.db.app.storage.ooAPObj;
import com.objy.db.app.storage.ooContObj;
import com.objy.db.app.storage.ooDBObj;
import com.objy.query.ObjectQualifier;

/**
 * Reserved for internal use.
 */
public interface PooFDObj
       extends   PHasSession
{
    //
    // Accessing
    //
    long getNumber() ;

    String getLockServerName() ;

    String getName();

    long getPageSize() ;

    Session getSession() ;

    ooFDObj target() ;

    //--------------------------------------------------------------
    // DB Management - hasDB, getDB, newDB, containedDBs, defaultDB
    //--------------------------------------------------------------
    boolean hasDB(String dbName);

    boolean hasDB(int dbId);

    ooDBObj lookupDB(String name) ;

    ooDBObj lookupDB(int dbId) ;

    ooDBObj newDB(String name) ;

    ooDBObj newDB(String name, long defContInitPages, long defContGrowth,
            String hostName, String pathName, long weight );
            
    ooDBObj newDB(String name, long defContInitPages, long defContGrowth,
            String hostName, String pathName, long weight, long userDBID );
    
    ooDBObj newDB(String name, long defContInitPages, long defContGrowth,
            String hostName, String pathName, long weight, long userDBID,
            int pageSize );
    
    ooDBObj getDefaultDB() ;

    Iterator containedDBs();

    //-----------------------------------------------------------
    // AP Management - hasAP, getAP, newDB, containedAPs, bootAP
    //-----------------------------------------------------------
    boolean hasAP(String name) ;

    ooAPObj lookupAP(String name) ;

    ooAPObj newAP(
        String sysName, String lockServerHost,
        String sysDBFileHost, String sysDBFilePath);

    ooAPObj newAP(
        String sysName,
        String lockServerHost,
        String sysDBFileHost,
        String sysDBFilePath,
        String bootFileHost,
        String bootFilePath,
        String jnlDirHost,
        String jnlDirPath);

    ooAPObj newAP(
        String sysName,
        String lockServerHost,
        String sysDBFileHost,
        String sysDBFilePath,
        String bootFileHost,
        String bootFilePath,
        String jnlDirHost,
        String jnlDirPath,
	int weight);

    Iterator containedAPs() ;

    ooAPObj getBootAP() ;

    //---------------
    //  Iterators
    //---------------
    Iterator scan(String className) ;

    Iterator scan(String className, String predicate) ;

    Iterator scan(String className, String predicate, int access);

    Iterator scan(String className, ObjectQualifier oq);

    Iterator parallelScan(String className, String predicate) ;

    Iterator parallelScan(String className, String predicate, QuerySplitter qs);
	
    Iterator parallelScan(String className, ObjectQualifier oq, QuerySplitter qs);

    //
    // Root Names
    //
    void bind(Object object, String name) throws ObjectNameNotUniqueException ;

    void unbind(String name) throws ObjectNameNotFoundException ;
    
    Object lookup(String name) throws ObjectNameNotFoundException  ;

    Iterator rootNames() ;

    //
    // Indexes
    //
    void addIndex(String indexName, String className, String fieldList);

    void addUniqueIndex(String indexName, String className, String fieldList);

    void dropIndex(String indexName);

    boolean hasIndex(String indexName) ;

    boolean indexConsistent(String indexName) ;

    //
    // Misc Object Methods
    //
    Object objectFrom(ooId oid) ;

    Object objectFrom(String oidString) ;
    
    Object objectFrom(ooId oid, int lockMode) ;

    Object objectFrom(String oidString, int lockMode) ;

    Object objectFrom(long oidLong, long typeNumber) ;

    Object objectFrom(long oidLong, long typeNumber, int lockMode) ;
    
    void deleteReference(Object objectReference) ;
    
    void moveReference(Object object, Object nearObj) ; 
    
    //
    // Locking
    //
    void lock(int lockMode) ;

    //
    // Scope Names
    //
    void nameObj(Object o, String scopeName) ;

    void unnameObj(Object obj) ;

    String lookupObjName(Object obj) ;

    Object lookupObj(String scopeName) ;
    
    Object lookupObj(String scopeName, int lockMode) ;

    //
    // Maintenance
    //
    void dumpCatalog() ;

    // this function is here so we can have the option of putting
    // flush() on ooDBObj and ooContObj in the future...
    void flush() ;

    //---------------------
    // Conversion functions
    //---------------------
    void upgradeObjects() ;

    void upgradeObjects(boolean purge_schema) ;

    void convertObjects() ;

    void convertObjects(boolean purge_schema) ;

    //*************************
    // T E S T I N G    O N L Y
    //*************************
    String printString() ;

}


