/*
 * @(#)LogListener.java
 * 
 * Copyright (c) 2003 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */

package com.objy.db.app ;

/**
 * Abstract superclass for all log-listener classes. 
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>An instance of a class derived from LogListener is called a <i>log listener</i>.  
 * A log listener can be attached to a particular log � either the main log or a session log.
 * Whenever an item is added to a log, that log notifies any attached log listener by
 * calling the listener�s onLogItem method. This method can then take some application-defined action
 * in response to the notification. For example, an application-defined log-listener
 * class could override the onLogItem method to direct the log item to a graphical display.
 * 
 * <p>You attach a log listener to the main log by calling
 * a connection's 
 * {@link Connection#setMainLogListener <tt>setMainLogListener</tt>} method. 
 * You attach a log listener to a session log by calling the session's
 * {@link Session#setLogListener <tt>setLogListener</tt>} method. 
 * 
 * <p>Because this class is abstract, you never instantiate it; instead,
 * you work with instances of its derived classes.
 *
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Processing&nbsp;Events</B></TD>
 * <TD><A HREF="#onLogItem(long, java.lang.String, java.lang.String)">onLogItem(long, String, String)</A>
 * </TD></TR>
 * </TABLE>
 */
abstract public class LogListener
{
    /**
     * Reserved for internal use.
     */
    public LogListener() {}
    
    /**
     * Handles notification that an item has been added to this listener's
     * log.</p>
     *
     * @param 	 timeStamp	The timestamp of
     * the log item, represented as the number of milliseconds since the
     * application began executing.</p>
     *
     * @param 	 label	The label for the log item.</p>
     *
     * @param 	 text	The text of the log item.
     */
    protected void onLogItem(long timeStamp, String label, String text) {}
}
