/*
 * @(#)ToOneRelationship.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db.app ;

import com.objy.pm.Access ;
import com.objy.pm.TransientRelationshipManager;

import com.objy.db.iapp.Persistent ;
import com.objy.db.iapp.PooObj ;
import com.objy.db.iapp.PToOneRelationshipManager ;
import com.objy.db.iapp.PToOneTransientRelationshipManager ;

import com.objy.db.ObjyRuntimeException ;
import com.objy.db.ObjectIsDeadException ;

/**
 * Represents a relationship manager for a particular to-one 
 * <a href="../../../../../guide/jgdOrganization.html#Relationships">
 * relationship</a> of a source object.
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>The source class of the relationship must declare a <i>relationship 
 * field</i> whose type is <tt>ToOneRelationship</tt> and define a public 
 * static relationship-definition method. See
 * <a href="../../../../../guide/jgdDefiningClasses.html#Defining Relationships">
 * Defining Relationships</a>.
 *
 * <p>The relationship field of a source object is initialized to reference 
 * an object of this class, which manages the relationship for that source 
 * object. You call methods of this relationship manager to 
 * create, test, follow, and delete the source object's association links. 
 * See  <a href="../../../../../guide/jgdLinking.html#Linking With Relationships">
 * Linking With Relationships</a>.  
 *
 * <p><h2>Related Classes</h2>
 *
 * <p>The <a href = "ToManyRelationship.html"><tt>ToManyRelatioship</tt></a> 
 * class represents a relationship manager for a particular to-many 
 * relationship of a source class
 *
 * <p><h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%">
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Adding&nbsp;and&nbsp;Deleting&nbsp;Relationships</B></TD>
 *
 * <TD><A HREF="#form(java.lang.Object)">form(Object)<BR>
 * </A><A HREF="#drop(java.lang.Object)">drop(Object)<BR>
 * </A><A HREF="#clear()">clear()</A></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Testing</B></TD>
 *
 * <TD><A HREF="#includes(java.lang.Object)">includes(Object)<BR>
 * </A><A HREF="#exists()">exists()</A></TD>
 * </TR>
 *
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Finding&nbsp;Related&nbsp;Objects</B></TD>
 *
 * <TD><A HREF="#get()">get()</A> </TD>
 * </TR>
 * </TABLE>
 *
 */
//
public final class ToOneRelationship implements java.io.Serializable
{
    private transient Persistent owner ;
    private transient PToOneRelationshipManager toOneManager ;
    private transient PToOneTransientRelationshipManager transientManager ;
    private transient Boolean isBidirectional = null;

    private ToOneRelationship()
        { }

    private ToOneRelationship(Persistent owner)
    { 
        this.owner = owner ;
        
    }

    private ToOneRelationship(
        boolean    isBidirectional,
        byte       inlineMode,
        long       relationMap,
        Persistent owner)
    {
        this.owner = owner ;
        this.isBidirectional = new Boolean(isBidirectional);
        switch(inlineMode) {
            case Relationship.INLINE_LONG :
            case Relationship.INLINE_SHORT :
                toOneManager = Access.new_ToOneRelationshipInlineManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
                break ;
            case Relationship.INLINE_NONE :
                toOneManager = Access.new_ToOneRelationshipManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
                break ;
            default :
                throw new ObjyRuntimeException("Relationship inline mode is invalid") ;
        }
    }

    private void cpp_createManager(
        boolean    isBidirectional,
        byte       inlineMode,
        long       relationMap)
    {
        switch(inlineMode) {
            case Relationship.INLINE_LONG :
            case Relationship.INLINE_SHORT :
                toOneManager = Access.new_ToOneRelationshipInlineManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
                break ;
            case Relationship.INLINE_NONE :
                toOneManager = Access.new_ToOneRelationshipManager(
                    isBidirectional,
                    relationMap,
                    persistor()) ;
                break ;
            default :
                throw new ObjyRuntimeException("Relationship inline mode is invalid") ;
        }
	convertTransient() ;
    }
    
    private boolean isBidirectional()
    {
    	if(this.isBidirectional==null)
    		this.isBidirectional = TransientRelationshipManager.getRelationShipUsingReflection(owner,this).isBidirectional();
   		return this.isBidirectional.booleanValue();
    }

    /**
     * Forms a relationship between the source object and the specified 
     * destination object.
     *
     * <p>If the source object is already related to a destination object,
     * this method throws an exception. If you want to replace the existing 
     * destination object, you should first call 
     * <a href="#clear()"><tt>clear</tt></a> before you call this method.
	 * </p>
     *
     * @param 	 object   The destination object to which 
     * an association link is to be created.
     * <p>If <tt><i>object</i></tt> is transient, linking it to a persistent source object makes it 
     * persistent; otherwise, <tt><i>object</i></tt> remains transient. 
     * See <a href="../../../../../guide/jgdLinking.html#Relationships and Persistence">
	 * Relationships and Persistence</a>.
     * <p>If <tt><i>object</i></tt> is null, this method is equivalent to
     * <tt>clear</tt>.
     */
    public void form(Object object)
    {
    	PooObj per = persistor() ;
    	if (per == null) {
    		// SPR 21306 makes spr 19769 a user option 
    		boolean otherIsPersistent = object != null && ((Persistent)object).getPersistor() != null && !((Persistent)object).getPersistor().isDead() ;
    		// if (!useTransientRelationships() || otherIsPersistent)
    		if (!useTransientRelationships() ||  
    			(otherIsPersistent &&
    				(persistUnreachableTransientsWithRelToPersistent() || 
    						isBidirectional())))
    		{
    			Access.setRelationshipField(owner, (Persistent)object);
    		}
    		else {
    			if (transientManager != null && object != null)
    				throw new ObjyRuntimeException("Cannot add the relationship with cardinality 1 to the object because such a relationship already exists") ;
    			else
    				transientManager = Access.new_ToOneTransientRelationshipManager() ;
    			transientManager.form(object, owner, this) ;
    			return ;
    		}
    	}
    	toOneManager.form(persistor(), object) ;
    }

    /**
     * Drops a relationship between the 
     * source object and the specified destination object.
     *
     * <p>This method throws an <tt>ObjyRuntimeException</tt> if the source
	 * object is not related to the specified destination object.
	 * </p>
	 *
     * @param 	 object   The destination object.
     */
    public void drop(Object object)
    { 
        PooObj per = persistor() ;
        if (per != null) toOneManager.drop(per, object) ;
	else if (useTransientRelationships() && transientManager != null)
	    transientManager.drop(object, owner) ;
    }

    /**
     * Drops the relationship between the
     * source object and any destination object.
     */
    public void clear()
    {
        PooObj per = persistor() ;
        if (per != null) toOneManager.clear(per) ;
	else if (useTransientRelationships() && transientManager != null)
	    transientManager.clear(owner) ;
    }

    /**
     * Tests whether the source object is related to the specified 
     * destination object.</p>
     *
     * @param 	 object  The destination object 
	 * being tested.</P>
	 *
     * @return True if the source object is related to the specified object;
     * otherwise, false.
     */
    public boolean includes(Object object)
    { 
        PooObj per = persistor() ;
        if (per == null) {
	    if (useTransientRelationships() && transientManager != null)
		return transientManager.includes(object) ;
	    else
		return false ;
	}
        else return toOneManager.includes(per, object) ;
    }

    /**
     * Tests whether the source object is related to any destination 
     * object.</p>
     *
     * @return  True if the source object is related to some destination 
     * object; otherwise false.  
     *
     * <b>Note: </b>A dangling link from a unidirectional relationship
     * will also return true.
     */
    public boolean exists()
    { 
        PooObj per = persistor() ;
        if (per == null) {
	    if (useTransientRelationships() && transientManager != null)
		return transientManager.exists() ;
	    else
		return false ;
	}
        else return toOneManager.exists(per) ;
    }

     /**
     * Finds the destination object related to the source object.
     * </p>
     *
     * @return  The destination object  or null if no destination object
     * is related to the source object. The returned object is locked for read.</p>
     *
     * @exception ObjectNotFoundException If the relationship is 
     * unidirectional, and the destination object has been deleted or moved.
     */
    public Object get()
    { 
        PooObj per = persistor() ;
        if (per == null) {
	    if (useTransientRelationships() && transientManager != null)
		return transientManager.get() ;
	    else
		return null ;
	}
        else return toOneManager.get(per) ; 
    }
  
    private PooObj persistor() {
        PooObj answer = owner.getPersistor() ;

        if (answer != null && answer.isDead())
            throw new ObjectIsDeadException("Attempted persistent operation on dead object");

        return answer ;
    }

    private boolean useTransientRelationships() {
	if (Session.getCurrent() == null)
	    throw new ObjyRuntimeException("Attempted relationship operation without creating a session") ;
	return Connection.current().isPersistOnReachability() || Session.getCurrent().getFormTransientRelationships() ;
    }

    private boolean persistUnreachableTransientsWithRelToPersistent() {
    	return Session.getCurrent().getPersistUnreachableTransientsWithRelationshipToPersistent();
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public PToOneTransientRelationshipManager getTransientManager() {
	return transientManager ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void setTransientManager(PToOneTransientRelationshipManager transientManager) {
	this.transientManager =	transientManager ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void nullTransientManager() {
	transientManager = null ;
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public void convertTransient() {
	if (transientManager != null && transientManager.notFormed()) {
	    Object item = transientManager.get() ;
	    boolean form = Session.getCurrent().existingTransientRelationship(owner, item, transientManager) ;
	    transientManager.terminate(owner, item) ;
	    if (form)
		toOneManager.form(persistor(), item) ;
	    nullTransientManager() ;
	}
    }

    /**
     * Reserved for internal use; you should not call this method.
     */
    public Persistent getOwner() {
	return owner ;
    }
}
