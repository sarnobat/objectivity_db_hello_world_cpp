/*
 * @(#)ClusterStrategy.java
 *
 * Copyright (c) 2001 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */
package com.objy.db.app.storage ;

import com.objy.db.ObjyRuntimeException;
import com.objy.db.ObjectIsDeadException;
import com.objy.db.ObjectNotPersistentException;

import com.objy.db.app.Session;
import com.objy.db.app.ooFDObj;
import com.objy.db.app.ooId;
import com.objy.db.iapp.Persistent;
import com.objy.db.iapp.PooObj;

/**
 * Superclass for all clustering-strategy classes. 
 *
 * <p><table border=1 cellspacing=0 cellpadding=3>
 * <tr><td><a href="#APIsummary">API Summary</a></tr></td>
 * </table>
 *
 * <p>Each session has a <i>clustering strategy</i> that assists with 
 * clustering objects that are made persistent when that session is in a 
 * transaction: 
 * <ul>
 * <li>When a container or basic object is clustered implicitly, the 
 * clustering strategy selects the clustering object with which to cluster 
 * it. See 
 * <a href="../../../../../../guide/jgdClustering.html#Implicitly Clustering Containers or Basic Objects">
 * Implicitly Clustering Containers or Basic Objects</a>.</p>
 *
 * <li>When a basic object is clustered implicitly or explicitly, the clustering strategy
 * selects the object's location relative to the location of 
 * the clustering object.  See
 * <a href="../../../../../../guide/jgdClustering.html#Controlling the Placement of Basic Objects">
 * Controlling the Placement of Basic Objects</a>.</p>
 * </ul>
 *
 * <p>This class
 * implements the <i>standard clustering strategy</i>, which all sessions 
 * use by default. 
 * For additional information about clustering and standard clustering
 * strategies, see
 * <a href="../../../../../../guide/jgdClustering.html#_top_">
 * Clustering</a>.
 *
 * <p>You may define your own clustering-strategy classes by subclassing this class. 
 * An instance of an application-defined clustering-strategy class is called a 
 * <i>custom clustering strategy</i>; see  
 * <a href="../../../../../../guide/jgdClustering.html#Defining a Clustering-Strategy Class">
 * Defining a Clustering-Strategy Class.</a>
 *
 * <p> You can obtain a standard or custom clustering strategy and call its methods to change 
 * its properties.  For additional information, see
 * <a href="../../../../../../guide/jgdClustering.html#Working With Clustering Strategies">
 * Working With Clustering Strategies.</a>
 *
 * <h2><a name="APIsummary">API Summary</h2>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2"><a name = "ConstantTypes">
 * <B>Constant Types</B></FONT></TD>
 * </TR>
 * <tr><td valign=top><a name = "priorities"><b>Clustering Rules</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify how the clustering strategy should
 * position a new basic object in storage relative to another object (the 
 * clustering object) .</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#samePage">samePage</a><br>
 *     <a href="#otherPage">otherPage</a><br>
 *     <a href="#newPage">newPage</a><br>
 *     <a href="#newContainer">newContainer</a><br>
 *     <a href="#newDatabase">newDatabase</a>
 * 	</td></tr>
 * <tr><td valign=top><a name = "policies"><b>Container-Fill Policies</b></a><br>
 * &nbsp;&nbsp;&nbsp;&nbsp;Specify commonly used policies for limiting the number of logical pages 
 * that can be added to a container.</td>
 * <td VALIGN="top" WIDTH="1%">
 *     <a href="#reserveSpace">reserveSpace</a><br>
 *     <a href="#fastAccess">fastAccess</a><br>
 *     <a href="#maximum">maximum</a>
 * 	</td></tr>
 * </TABLE></p>
 *
 * <TABLE BORDER="1" CELLPADDING="3" CELLSPACING="0" WIDTH="100%"> 
 * <TR BGCOLOR="#CCCCFF" ID="TableHeadingColor">
 * <TD COLSPAN=2><FONT SIZE="+2">
 * <B>Functionality</B></FONT></TD>
 * </TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Constructors</B></TD>
 *
 * <TD>
 *     <A HREF="#ClusterStrategy()">ClusterStrategy()</A> <BR>
 *     <A HREF="#ClusterStrategy(int)">ClusterStrategy(int)</A> <BR>
 *     <A HREF="#ClusterStrategy(boolean)">ClusterStrategy(boolean)</A> <BR>
 *     <A HREF="#ClusterStrategy(int, boolean)">ClusterStrategy(int, boolean)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Getting Clustering Properties</B></TD>
 * <TD>
 *      <A HREF="#priorityBits()">priorityBits()</A><br>
 *      <A HREF="#containerPageLimit()">containerPageLimit()</A><br>
 *      <A HREF="#oogcCont()">oogcCont()</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Setting Clustering Properties</B></TD>
 * <TD>
 *      <A HREF="#setPriorityBits(int)">setPriorityBits(int)</A><br>
 *      <A HREF="#setContainerPageLimit(int)">setContainerPageLimit(int)</A><br>
 *      <A HREF="#setOogcCont(boolean)">setOogcCont(boolean)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Clustering</B></TD>
 * <TD><A HREF="#requestCluster(java.lang.Object, com.objy.db.app.storage.ClusterReason, java.lang.Object)">requestCluster(Object, ClusterReason, Object)</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Creating Storage&nbsp;Objects</B></TD>
 * <TD>
 *      <A HREF="#newContainer(java.lang.Object)">newContainer(Object)</A><br>
 *      <A HREF="#newDB(java.lang.Object)">newDB(Object)</A><br> 
 *      <A HREF="#setDefaultContainerName(java.lang.String)">setDefaultContainerName(String)</A><br>
 *      <A HREF="#setDefaultDatabasePrefix(java.lang.String)">setDefaultDatabasePrefix(String)</A><br>
 *      <A HREF="#defaultContainerName()">defaultContainerName()</A><br>
 *      <A HREF="#defaultDatabasePrefix()">defaultDatabasePrefix()</A>
 * </TD></TR>
 * <TR>
 * <td VALIGN="top" WIDTH="1%"><B>Clustering Scalable&nbsp;Collections</B></TD>
 * <TD>
 *      <A HREF="#requestClusterNative(long, com.objy.db.app.ooId)">requestClusterNative(long, ooId)</A><br> 
 *      <A HREF="#clusterNative(long, com.objy.db.app.ooId)">clusterNative(long, ooId)</A><br> 
 *      <A HREF="#isTreeNode(long)">isTreeNode(long)</A><br> 
 *      <A HREF="#isHashBucket(long)">isHashBucket(long)</A><br> 
 *      <A HREF="#getSchemaName(long)">getSchemaName(long)</A><br> 
 * </TD></TR>
 * 
 * </TABLE>
 */
public class ClusterStrategy
{
    transient int _priorityBits = samePage | otherPage | newPage | newContainer | newDatabase;
    transient boolean _oogcCont = true;
    transient int _containerPageLimit = reserveSpace;
	transient String _defaultContainerName = null;
	transient String _defaultDatabasePrefix = "autoDB";

    /**
     * Constructs a standard clustering strategy with default
     * clustering priorities, new-container type, and container-fill policy.
     *
     * <p>The new clustering strategy uses the 
     * <a href="../../../../../../guide/jgdClustering.html#Default Clustering Priorities">default clustering priorities</a>.</p>
     * 
	 * <p>When the clustering priorities include <tt>newPage</tt>,
	 * the clustering strategy uses the 
	 * {@link #reserveSpace <tt>reserveSpace</tt>} container-fill policy
	 * to determine whether it can add new logical pages to accommodate new persistent basic objects.</p>
	 * 
     * <p>When the clustering priorities include
     * <tt>newContainer</tt> or <tt>newDatabase</tt>, the clustering
     * strategy creates garbage-collectible containers when necessary to
     * accommodate new persistent basic objects.
     */
    public ClusterStrategy() { }
    
    /**
     * Constructs a standard clustering strategy with the specified
     * clustering priorities,  along with the default new-container type and container-fill policy.</p>
     * 
	 * <p>When the clustering priorities include <tt>newPage</tt>,
	 * the clustering strategy uses the 
	 * {@link #reserveSpace <tt>reserveSpace</tt>} container-fill policy
	 * to determine whether it can add new logical pages to accommodate new persistent persistent basic objects.</p>
	 * 
     * <p>When the clustering priorities include
     * <tt>newContainer</tt> or <tt>newDatabase</tt>, the clustering
     * strategy creates garbage-collectible containers when necessary to
     * accommodate new persistent persistent basic objects.</p>
     *
     * @param 	 bits    Integer value whose binary
     * representation can be interpreted as a bit mask that stores a
     * combination of
     * clustering rules. You can specify a combination by using
     * the Java bitwise OR operator (<tt>|</tt>) to combine the desired
     * <tt>priorities</tt>
     * clustering-rule constants</a> defined in the
     * <tt>ClusterStrategy</tt> interface.
     */
    public ClusterStrategy(int bits)
    {
	_priorityBits = bits;
    }
    
    /**
     * Constructs a standard clustering strategy with the specified
     * new-container type, along with the default clustering priorities and container-fill policy.</p>
     *
     * <p>The new clustering strategy uses the 
     * <a href="../../../../../../guide/jgdClustering.html#Default Clustering Priorities">default clustering priorities</a>.</p>
     *  
	 * <p>When the clustering priorities include <tt>newPage</tt>,
	 * the clustering strategy uses the 
	 * {@link #reserveSpace <tt>reserveSpace</tt>} container-fill policy
	 * to determine whether it can add new logical pages to accommodate new persistent basic objects.</p>
	 * 
     * <p>When the clustering priorities include
     * <tt>newContainer</tt> or <tt>newDatabase</tt>, the clustering
     * strategy creates containers of the specified type when necessary to
     * accommodate new persistent basic objects.</p>
     *
     * @param 	 oogcCont    True to create garbage-collectable
     * containers (instances of <tt>ooGCContObj</tt>) and false to create
     * non-garbage-collectable containers (instances of <tt>ooContObj</tt>).
     */
    public ClusterStrategy(boolean oogcCont)
    {
	_oogcCont = oogcCont;
    }
    
    /**
     * Constructs a standard clustering strategy with the specified
     * clustering priorities and new-container type, 
	 * along with the default container-fill policy.</p>
     * 
	 * <p>When the clustering priorities include <tt>newPage</tt>,
	 * the clustering strategy uses the 
	 * {@link #reserveSpace <tt>reserveSpace</tt>} container-fill policy
	 * to determine whether it can add new logical pages to accommodate new persistent basic objects.</p>
	 * 
     * <p>When the clustering priorities include
     * <tt>newContainer</tt> or <tt>newDatabase</tt>, the clustering
     * strategy creates containers of the specified type when necessary to
     * accommodate new persistent basic objects.</p>
     *
     * @param 	 bits    Integer value whose binary
     * representation can be interpreted as a bit mask that stores a
     * combination of
     * clustering rules. You can specify a combination by using
     * the Java bitwise OR operator (<tt>|</tt>) to combine the desired
     * <tt>priorities</tt>
     * clustering-rule constants</a> defined in the
     * <tt>ClusterStrategy</tt> interface.</p>
     *
     * @param 	 oogcCont    True to create garbage-collectable
     * containers (instances of <tt>ooGCContObj</tt>) and false to create
     * non-garbage-collectable containers (instances of <tt>ooContObj</tt>).
     */
    public ClusterStrategy(int bits, boolean oogcCont)
    {
	_priorityBits = bits;
	_oogcCont = oogcCont;
    }

    /**
     * Clustering rule: Clusters the new basic object on the same page as 
     * the clustering object, provided the page has enough space.
     * 
     * <p>Binary representation: 000010
     */
    public static final int samePage = 2;

    /**
     * Clustering rule: Clusters the new basic object on a different page 
     * in the container indicated by the clustering object, provided such 
     * a page exists and has enough space.
     * 
     * <p>Binary representation: 000100
     */
    public static final int otherPage = 4;
    
    /**
     * Clustering rule: Clusters the new basic object on a new page in 
     * the container indicated by the clustering object, provided the 
     * container has enough space.
     * 
     * <p>Binary representation: 001000
     */
    public static final int newPage = 8;
    
    /**
     * Clustering rule: Clusters the new basic object in a new container 
     * in the database indicated by the clustering object, provided the 
     * database has enough space.  
     *
     * <p>Binary representation: 010000
     */
    public static final int newContainer = 16;
    
    /**
     * Clustering rule: Clusters the new basic object in a new container 
     * in a new database. 
     * 
     * <p>Binary representation: 100000
     */
    public static final int newDatabase = 32;

	/**
	 * Container-fill policy: The clustering strategy calculates the logical-page limit 
	 * that will keep the container's page map small. 
	 * The calculated number is based on the storage-page size of the container, 
	 * and so may be different for different containers. This constant is stored as the special value 0. 
	 * 
	 * <p>
	 * The policy represented by this constant is particularly appropriate 
	 * if your performance requirements call for optimizing the runtime speed of operations 
	 * that will update the basic objects being clustered. 
	 * 
	 */
    public static final int fastAccess = 0;

	/**
	 * Container-fill policy: The clustering strategy leaves a small number of logical pages unused 
	 * in each container, 
	 * to accommodate any future expansion of arrays, to-many relationships, 
	 * or persistent collections stored in the container. 
	 * This constant represents the integer 65000. 
	 * 
	 * <p>
	 * The policy represented by this constant is set by default when a standard clustering strategy is created. 
	 * This policy is recommended for most applications 
	 * because it allows basic objects to be clustered on the majority of a container's logical pages, 
	 * while keeping some pages in reserve, 
	 * in case Objectivity/DB needs to grow an array or a persistent collection to accommodate added elements.
	 * 
	 */
    public static final int reserveSpace = 65000;

	/**
	 * Container-fill policy: The clustering strategy allows the maximum possible number of logical pages 
	 * in the container. This constant represents the integer 65534. 
	 * 
	 * <p>
	 * The policy represented by this constant is particularly appropriate 
	 * if your data requirements call for using a container's maximum addressing capacity 
	 * to store as many basic objects as possible. 
	 * 
	 */
    public static final int maximum = 65534;

    /**
     * Default implementation for creating a new database whenever this clustering strategy
	 * adds a database to accommodate a new basic object.
     *
     * <p>This method is called in response to the 
     * the <tt>newDatabase</tt> clustering rule.
     * An application should not call this method directly.</p>
     * 
     * <p>The default implementation creates a new database whose system name 
	 * is of the form <tt><i>prefixN</i></tt>,
	 * where <tt><i>prefix</i></tt> is the string returned by 
	 * the clustering strategy's {@link #defaultDatabasePrefix() <tt>defaultDatabasePrefix</tt>} method, and
	 * <tt><i>N</i></tt> is an incremented numerical index.
	 * 
	 * 
	 * <p>
     * The new database file is located on the same host and in the same
     * directory as the federated database's system-database file.
     * The default container initially has 4 pages and grows by 10%
     * when required. If Objectivity/DB High Availability (HA) is
     * being used, the weight of the first database image is 1.
     * Objectivity/DB assigns a unique database identifier to the new
     * database. </p>
     *
     * <p>If you want to create databases with different characteristics,
     * you can override this method in an application-defined 
     * clustering-strategy class. See
     * <a href="../../../../../../guide/jgdClustering.html#Customizing Database Creation">
     * Customizing Database Creation.</a></p>
     *
     * @param 	 nearObject	The clustering object. The 
     * new database is created in the same federated database as this 
     * object.</p>
     *
     * @return      The newly created database, or null if a database could 
     * not be created.</p>
	 * 
	 * @see #setDefaultDatabasePrefix
     */
    public ooDBObj newDB(Object nearObject)
    {
	ooDBObj db;
	String dbName = defaultDatabasePrefix();
	int i = 1;
	ooFDObj fd;

	if (nearObject instanceof ooDBObj)
	    fd = ((ooDBObj)nearObject).getFD();
	else
	    fd = ((Persistent)nearObject).getPersistor().getSession().getFD();

	while (fd.hasDB(dbName + i))
	    i++;
	return fd.newDB(dbName + i);
    }
  
    /**
     * Default implementation for creating a container whenever this clustering strategy
	 * adds a new container to accommodate a new basic object.
     *
     * <p>This method is called in response to either the <tt>newContainer</tt> or 
     * the <tt>newDatabase</tt> clustering rule.
     * An application should not call this method directly.</p>
     *
     * <p>The default implementation adds a container to the database indicated by <tt><i>nearObject</i></tt>.
	 * The container is unnamed if the clustering strategy's
	 * {@link #defaultContainerName() <tt>defaultContainerName</tt>} method returns null;
	 * if <tt>defaultContainerName</tt> returns a nonnull string, 
	 * that string is used as the container's system name.
	 * (If an existing container in the database has the same system name, 
	 * an {@link ObjyRuntimeException <tt>ObjyRuntimeException</tt>} is thrown.)
	 * 
	 * 
	 * 
     * <p>The new container initially has 100 pages and grows by 50%
     * when required. It is an instance of either
     * <tt>ooGCContObj</tt>, or
     * <tt>ooContObj</tt>, as specified by the value returned by
     * {@link #oogcCont <tt>oogcCont</tt>}.
	 * The new container is assigned to the database indicated by <tt><i>nearObject</i></tt>,
	 * which is either the database indicated by the clustering object,
	 * or a new database added by the clustering strategy 
	 * in response to the <tt>newDatabase</tt> clustering rule.
	 * The default implementation creates only embedded containers 
	 * (physically stored within the indicated database's file).</p>
     *
     * <p>If you want to create containers of an application-defined
     * container class or with different storage characteristics,
     * you can override this method in an application-defined 
     * clustering-strategy class. See
     * <a href="../../../../../../guide/jgdClustering.html#Customizing Container Creation">
     * Customizing Container Creation.</a></p>
     *
     * @param 	 nearObject	The clustering object. The 
     * new container is clustered with this object.</p>
     *
     * @return      The newly created container, or null if a container could 
     * not be created.</p>
	 * 
	 * @see #setDefaultContainerName
     */
	public ooContObj newContainer(Object nearObject)
	{
	ooDBObj db;
	String contName = defaultContainerName();
	if (nearObject instanceof ooDBObj)
		db = (ooDBObj)nearObject;
	else if (nearObject instanceof ooContObj)
		db = ((ooContObj)nearObject).getDB();
	else
		db = ((Persistent)nearObject).getPersistor().getContainer().getDB();
	if (_oogcCont) {
		ooGCContObj c = new ooGCContObj();
		db.addContainer(c, 0, contName, 100, 50);
		return c;
	}
	else {
		ooContObj c = new ooContObj();
		db.addContainer(c, 0, contName, 100, 50);
		return c;
	}
    }

    /**
     * Tests whether this clustering strategy creates garbage-collectible 
     * containers when it adds containers to accommodate new persistent basic 
     * objects.</p>
     *
     * @return      True if this clustering strategy creates garbage-collectable
     * containers (instances of <tt>ooGCContObj</tt>) and false if it creates
     * non-garbage-collectable containers (instances of <tt>ooContObj</tt>).
     */
    public boolean oogcCont()
    {
	return _oogcCont;
    }
         
    /**
     * Sets whether this clustering strategy creates garbage-collectible 
     * containers when it adds containers to accommodate new persistent basic 
     * objects.</p>
     *
     * @param 	 flag    True to create garbage-collectable
     * containers (instances of <tt>ooGCContObj</tt>) and false to create
     * non-garbage-collectable containers (instances of <tt>ooContObj</tt>).
     */
    public void setOogcCont(boolean flag)
    {
	_oogcCont = flag;
    }
     
    /**
     * Gets the 
     * <a href="../../../../../../guide/jgdClustering.html#Clustering Priorities">
     * clustering priorities</a> for this 
     * clustering strategy. 
     * 
     * <p>The returned value is a bit mask that stores a combination of 
     * clustering rules. You can test whether a 
     * given rule is included by using the Java bitwise AND 
     * operator (<tt>&</tt>) on the return value and one of the
     * <a href="#priorities">clustering-rule constants</a>.</p>
     *
     * @return      Integer value whose binary representation can be 
     * interpreted as a combination of clustering rules.
     */
    public int priorityBits()
    {
	return _priorityBits;
    }

    /**
     * Sets the 
     * <a href="../../../../../../guide/jgdClustering.html#Clustering Priorities">
     * clustering priorities</a> for this clustering strategy. </p>
     * 
     * @param 	 bits    Integer value whose binary 
     * representation can be interpreted as a bit mask that stores a 
     * combination of   
     * clustering rules. You can specify a combination by using
     * the Java bitwise OR operator (<tt>|</tt>) to combine the desired
     * <a href="#priorities">clustering-rule constants</a>.</p>
     */
    public void setPriorityBits(int bits)
    {
	_priorityBits = bits;
    }

	/**
	 * Gets the 
	 * <a href="../../../../../../guide/jgdClustering.html#Regulating the Growth of Existing Containers">
	 * container-fill policy</a> for this clustering strategy. </p>
	 * 
	 * 
	 * @return    Integer value representing the container-fill policy. 
	 * This value is either an integer number of logical pages, 
	 * or the special value 0, which represents the
	 * {@link ClusterStrategy#fastAccess <tt>fastAccess</tt>} policy.</p>
	 */
    public int containerPageLimit()
    {
	return _containerPageLimit;
    }

	/**
	 * Sets the 
	 * <a href="../../../../../../guide/jgdClustering.html#Regulating the Growth of Existing Containers">
	 * container-fill policy</a> for this clustering strategy. </p>
	 * 
	 * <p>The container-fill policy is the maximum number of logical pages 
	 * that a clustering strategy can allow in a container. 
	 * The policy enables a clustering strategy to regulate the growth of existing containers 
	 * in response to the <tt>newPage</tt> clustering rule.
	 * 
	 * <p>If this method is never called, the container-fill policy for this clustering strategy is 
	 * {@link ClusterStrategy#reserveSpace <tt>reserveSpace</tt>}.
	 * 
	 * @param   pagesPerContainer    Integer value representing the container-fill policy. 
	 * You can specify either an integer number of logical pages, 
	 * or one of the <a href="#policies">container-fill policy constants</a> defined by this class.</p>
	 */
    public void setContainerPageLimit(int pagesPerContainer)
    {
	_containerPageLimit = pagesPerContainer;
    }

	/**
	 * Gets the system-name prefix used for new databases that this clustering strategy creates
	 * to accommodate new persistent basic objects.</p>
	 * 
	 * <p>The standard prefix is <tt>autoDB</tt>,
	 * which you can change by calling the clustering strategy's
	 * {@link #setDefaultDatabasePrefix(java.lang.String) <tt>setDefaultDatabasePrefix</tt>} method.
	 * 
	 * @return	The string used as the system-name prefix for
	 * new databases created by this clustering strategy. 
	 * 
	 * @see #newDB(java.lang.Object)
	 * @see #setDefaultDatabasePrefix
	 * 
	 */
	public String defaultDatabasePrefix()
	{
		return _defaultDatabasePrefix;
	}

	/**
	 * Sets the system-name prefix to be used for new databases that this clustering strategy creates
	 * to accommodate new persistent basic objects. 
	 * 
	 * <p>
	 * The system-name prefix is the string that is used 
	 * as the initial portion of the system name
	 * of each new database created by this clustering strategy.
	 * If you never call this method,
	 * the prefix is <tt>autoDB</tt>.
	 * The default implementation of {@link #newDB <tt>newDB</tt>} 
	 * constructs a system name by appending an incremented numerical index after the prefix.
	 * 
	 * @param	prefix	The string prefix of the system names of any new databases 
	 * created by this clustering strategy. 
	 * A valid system name follows the same rules as for naming files within the operating system. 
	 * 
	 * @see #newDB(java.lang.Object)
	 * @see #defaultDatabasePrefix
	 */
	public void setDefaultDatabasePrefix(String prefix)
	{
		_defaultDatabasePrefix = prefix;
	}

	/**
	 * Gets the system name used for new containers that this clustering strategy creates 
	 * to accommodate new persistent basic objects.</p>
	 * 
	 * <p>The standard value for the system name is null, 
	 * which you can change by calling the clustering strategy's
	 * {@link #setDefaultContainerName <tt>setDefaultContainerName</tt>} method.
	 * 
	 * 
	 * @return	The string used as the system name of
	 * new containers created by this clustering strategy. 
	 * A return value of null indicates that unnamed containers are created.
	 * 
	 * @see #newContainer(java.lang.Object)
	 * @see #setDefaultContainerName
	 * 
	 */
	public String defaultContainerName()
	{
		return _defaultContainerName;
	}

	/**
	 * Sets the system name, if any, to be used for new containers that this clustering strategy creates
	 * to accommodate new persistent basic objects. 
	 * 
	 * <p>
	 * If you never call this method,
	 * the name is set to null, so new containers are unnamed.
	 * Unnamed containers can be added to any database
	 * without causing naming conflicts.
	 * 
	 * <p>
	 * You normally set a nonnull system name only 
	 * if you are defining or using a custom clustering-strategy class.
	 * For example, such a class could implement an override of the 
	 * {@link #newContainer(java.lang.Object) <tt>newContainer</tt>} method
	 * to append a unique index to the system name to prevent naming conflicts with existing containers.
	 * Similarly, an override of the {@link #requestCluster <tt>requestCluster</tt>} method
	 * could construct a system name, call <tt>setDefaultContainerName</tt> 
	 * to make the name available to {@link #newContainer(java.lang.Object) <tt>newContainer</tt>},
	 * call <tt>newContainer</tt>,
	 * and then reset the name to null.</p>
	 * 
	 * @param	name	The system name of new containers created by this clustering strategy,
	 * or null or an empty string to create unnamed containers. 
	 * A valid system name follows the same rules as for naming files within the operating system. 
	 * 
	 * @see #newContainer(java.lang.Object)
	 * @see #defaultContainerName
	 */
	public void setDefaultContainerName(String name)
	{
		_defaultContainerName = name;
	}

	/**
     * Default implementation for responding to a clustering request;
	 * makes the specified transient object persistent by clustering it with the
     * specified requesting object, subject to the clustering properties of this
     * clustering strategy.</p>
	 * 
	 * <p>
	 * This method is called by the current session's {@link Session#requestCluster <tt>requestCluster</tt>} method
	 * whenever an application performs an implicit clustering action; see
     * <a href="../../../../../../guide/jgdClustering.html#Implicitly Clustering Containers or Basic Objects">
     * Implicitly Clustering Containers or Basic Objects</a>.
	 * The parameters passed to this method are the clustering action's requesting object, 
	 * the reason for performing the clustering action, and the transient object 
	 * to be made persistent.
	 * An application can also call this method directly; see 
	 * <a href="../../../../../../guide/jgdClustering.html#Requesting Clustering Assistance Directly">
     * Requesting Clustering Assistance Directly</a>.
	 *
	 * <p>The default implementation of this method makes the transient <tt><i>object</i></tt> persistent
	 * by clustering it with the specified <tt><i>requestObject</i></tt>, 
	 * and ensuring that this clustering strategy's properties are applied.
	 * More specifically, the default implementation includes the following call:
	 * <pre>
	 * <i>requestObject</i>.cluster(<i>object</i>, this);
	 * </pre>
	 *
	 * At a minimum, an override of this method should select a clustering object, 
	 * which may be different from <tt><i>requestObject</i></tt>,
	 * and then call one of that object's <tt>cluster</tt> methods
	 * to make the transient object persistent.
	 * For example, if your override selects a database as the clustering object, 
	 * your override should call that database's 
	 * {@link ooDBObj#cluster(java.lang.Object, com.objy.db.app.storage.ClusterStrategy) <tt>cluster</tt>} method.
	 * The override may select an existing persistent object or database, or
	 * create a new one--for example, by calling the clustering strategy's 
	 * {@link #newContainer(java.lang.Object) <tt>newContainer</tt>}
	 * or {@link #newDB <tt>newDB</tt>} method.
	 * 
	 * <p>
	 * Your override may optionally arrange for different clustering properties to be applied--for example,
	 * by changing one or more properties of this clustering strategy before calling <tt>cluster</tt>,
	 * and then resetting the properties to their previous values afterward.
	 *  See <a href="../../../../../../guide/jgdClustering.html#Customizing the Response to Clustering Requests">
     * Customizing the Response to Clustering Requests.</a>
	 * </p>
	 * 
	 *
	 * @param 	 requestObject	The object requesting
	 * that <tt><i>object</i></tt> be made persistent.</p>
	 *
	 * @param 	 reason	The reason for making
	 * <tt><i>object</i></tt> persistent. 
	 * This parameter may be null if you are calling this method directly, 
	 * and you are not using clustering reasons. </p>
	 *
	 * @param 	 object	The transient object being made persistent.</p>
	 * 
	 * 
	 * @exception   com.objy.db.ObjyRuntimeException    If <tt><i>object</i></tt> is already persistent, 
	 * or if <tt><i>requestObject</i></tt> not a persistent object or a database.
	 * 
	 * @see	#requestClusterNative
	 *
	 */
    public void requestCluster(
        Object        requestObject,    // who is requesting the cluster
        ClusterReason reason,           // what is the reason
        Object        object)           // the object to be made persistent via a cluster
    {
	PooObj persistor = null;

	if (requestObject instanceof Persistent) {
	    persistor = ((Persistent)requestObject).getPersistor();
	    if (persistor == null)
		throw new ObjectNotPersistentException("Request object for cluster stategy must not be a transient object");
	    if (persistor.isDead())
		throw new ObjectIsDeadException("Request object for cluster stategy must not be a dead object");
	    persistor.cluster(object, this);
	}
	else if (!(requestObject instanceof ooDBObj))
	    throw new ObjyRuntimeException("Invalid cluster requesting object type " +
					   ((requestObject == null) ? "null" : requestObject.getClass().getName()));
	else
	    ((ooDBObj)requestObject).cluster(object, this);
    }

	/**
	 * Returns the schema class name of basic object being clustered by this clustering strategy.</p>
	 * 
	 * <p> You can call this method in an override of 
	 * the {@link #requestClusterNative <tt>requestClusterNative</tt>} method
	 * if you want to implement clustering behavior that 
	 * tests for the type of object being clustered.
	 * You use this technique instead of using the <tt>instanceof</tt> keyword,
	 * because <tt>requestClusterNative</tt>
	 * makes the object's type number available for testing, not the object itself.
	 * (In contrast, the <tt>instanceof</tt> keyword is normally used for type testing
	 * in an override of the {@link #requestCluster <tt>requestCluster</tt>} method, 
	 * which receives the object being clustered as a parameter.)
	 *  
	 * @param	typeNumber	Type number of the class of the basic object being clustered. 
	 * This value is passed as a parameter of the {@link #requestClusterNative <tt>requestClusterNative</tt>}
	 * method.</p>
	 * 
	 * @return	String name of the class in the federated database's schema.
	 * 
	 */
    public final String getSchemaName(long typeNumber)
        { return Session.getCurrent().persistor().getSchemaName(typeNumber); }


	/**
	 * Tests whether the basic object being clustered by this clustering strategy 
	 * is a hash bucket of a <a href="../../util/ooHashBasedCollection.html">scalable unordered collection</a>.</p>
	 * 
	 * <p> You can call this method in an override of 
	 * the {@link #requestClusterNative <tt>requestClusterNative</tt>} method
	 * if you want to implement clustering behavior 
	 * that is specific to hash buckets.
	 * (Hash buckets are internal objects created automatically 
	 * when a scalable unordered collection grows to accommodate added elements.)
	 * </p>
	 * 
	 * @param	typeNumber	Type number of the class of the basic object being clustered. 
	 * This value is passed as a parameter of the {@link #requestClusterNative <tt>requestClusterNative</tt>}
	 * method.</p>
	 * 
	 * @return	True if the specified type number identifies a hash bucket
	 * of a scalable unordered collection; 
	 * otherwise false.</p>
	 * 
	 */
    public final boolean isHashBucket(long typeNumber)
        { return Session.getCurrent().persistor().isHashBucket(typeNumber); }

	/**
	 * Tests whether the basic object being clustered by this clustering strategy 
	 * is a B-tree node of a <a href="../../util/ooTreeBasedCollection.html">scalable ordered collection</a>.</p>
	 * 
	 * <p> You can call this method in an override of 
	 * the {@link #requestClusterNative <tt>requestClusterNative</tt>} method
	 * if you want to implement clustering behavior 
	 * that is specific to B-tree nodes.
	 * (B-tree nodes are internal objects created automatically 
	 * when a scalable ordered collection grows to accommodate added elements.)
	 * </p>
	 * 
	 * @param	typeNumber	Type number of the class of the basic object being clustered. 
	 * This value is passed as a parameter of the {@link #requestClusterNative <tt>requestClusterNative</tt>}
	 * method.</p>
	 * 
	 * @return	True if the specified type number identifies a B-tree node
	 * of a scalable ordered collection; 
	 * otherwise false.</p>
	 * 
	 */
    public final boolean isTreeNode(long typeNumber)
        { return Session.getCurrent().persistor().isTreeNode(typeNumber); }

	/**
	 * Called by {@link #requestClusterNative <tt>requestClusterNative</tt>}
	 * to cluster a new internal object of a <a href="../../util/ooCollection.html">scalable collection</a> 
	 * with the identified clustering object. </p>
	 * 
	 * <p>You call this method only in an override of the 
	 * {@link #requestClusterNative <tt>requestClusterNative</tt>} method
	 * in a custom clustering-strategy class;
	 * see <a href="../../../../../../guide/jgdClustering.html#Custom Clustering of a Scalable Collection's Internal Objects">
	 * Custom Clustering of a Scalable Collection's Internal Objects.</a>
	 * An application should not call this method directly.
	 * 
	 * <p>This method selects the actual location 
	 * for the new internal object by starting with the identified clustering object,
	 * and applying this clustering strategy's clustering priorities
	 * and container-fill policy. 
	 * Each clustering rule is examined in order until a location is successfully chosen 
	 * (and the object is stored there) 
	 * or all the rules have been considered (and no suitable location is found).
	 * If no location can accommodate the new internal object,
	 * this method throws <tt>ObjyRuntimeException</tt>.
	 * 
	 * <p>This method responds to certain clustering rules by calling other methods of this clustering strategy.
	 * When responding to the <tt>newContainer</tt> rule, 
	 * this method calls the {@link #newContainer(java.lang.Object) <tt>newContainer</tt>} method.
	 * When responding to the <tt>newDatabase</tt> rule, this method calls 
	 * the {@link #newDB <tt>newDB</tt>}
	 * and {@link #newContainer(java.lang.Object) <tt>newContainer</tt>} methods.
	 *
	 * 
	 * @param	typeNumber	Type number of the class of the object being clustered.
	 * You should specify the same value that was passed to 
	 * {@link #requestClusterNative <tt>requestClusterNative</tt>}.</p>
	 * 
	 * @param	clusterObject	Object identifier of the object to be used as the clustering object.
	 * You may, but need not, specify the object that was passed as the requesting object
	 * to {@link #requestClusterNative <tt>requestClusterNative</tt>}.</p>
	 * 
	 * @return	The long integer representation of the object identifier of the newly clustered object.</p>
	 * @exception  ObjyRuntimeException	If the return value is 0.
	 * 
	 * 
	 */
    public final long clusterNative(long typeNumber, ooId clusterObject)
    {
	long newObjectAddress = Session.getCurrent().persistor().tryCreate(null, null, priorityBits(), typeNumber, clusterObject, containerPageLimit(), this);

	if (newObjectAddress == 0)
	    throw new ObjyRuntimeException("clusterNative failed");
	return newObjectAddress;
    }

	/**
	 * Default implementation for clustering
	 * a new internal object of a <a href="../../util/ooCollection.html">scalable collection</a>;
	 * clusters the new internal object with the identified requesting object,
	 * subject to the clustering properties of this clustering strategy.
	 * </p>
	 * 
	 * <p>This method is called by native code in the Objectivity/DB kernel
	 * during the following operations:
	 * <ul type=disc>
	 * <li>
	 * Creating a new persistent B-tree node to add to 
	 * a <a href="../../util/ooTreeBasedCollection.html">scalable ordered collection</a>
	 * when an existing B-tree node is full.
     * <li>
	 * Creating a new persistent hash bucket to add to
	 * a <a href="../../util/ooHashBasedCollection.html">scalable unordered collection</a>
	 * when an existing hash bucket is full.
	 * </ul>
	 * <p>The identifier of the full B-tree node or hash bucket is passed to this method 
	 * as <tt><i>requestObject</i></tt>.
	 * 
	 * <p>The default implementation of this method 
	 * calls the {@link #clusterNative <tt>clusterNative</tt>} method,
	 * passing <tt><i>requestObject</i></tt> as the clustering object.
	 * </p> 
	 *
	 * At a minimum, an override of this method should select a clustering object
	 * (which may be different from <tt><i>requestObject</i></tt>),
	 * pass its object identifier 
	 * to the {@link #clusterNative <tt>clusterNative</tt>} method,
	 * and return the result of <tt>clusterNative</tt>.
	 * Your override may optionally arrange for different clustering properties to be applied--for example,
	 * by changing one or more properties of this clustering strategy before calling <tt>clusterNative</tt>,
	 * and then resetting the properties to their previous values afterward.
	 * If desired, your override can distinguish B-tree nodes from hash buckets by calling
	 * {@link #isTreeNode <tt>isTreeNode</tt>} or {@link #isHashBucket <tt>isHashBucket</tt>}.
	 * See <a href="../../../../../../guide/jgdClustering.html#Custom Clustering of a Scalable Collection's Internal Objects">
	 * Custom Clustering of a Scalable Collection's Internal Objects.</a>
	 * </p>
	 * 
	 * @param	typeNumber	Type number of the new internal object's class.
	 * This value is passed by Objectivity/DB
	 * and should not be changed in an override of this method.</p>
	 * 
	 * @param	requestObject	Object identifier of the requesting object 
	 * associated with this clustering action;
	 * specifically, the existing full B-tree node or hash bucket that
	 * triggered the addition of the new one.
	 * This value is passed by Objectivity/DB
	 * and may be used, changed, or ignored by an override of this method.</p>
	 * 
	 * @return	The long integer representation of the object identifier of the newly clustered object.</p>
	 * 
	 * @see #isTreeNode 
	 * @see #isHashBucket 
	 * @see	#requestCluster
	 * 
	 */
    public long requestClusterNative(long typeNumber, ooId requestObject)
    {
	return clusterNative(typeNumber, requestObject);
    }
}
