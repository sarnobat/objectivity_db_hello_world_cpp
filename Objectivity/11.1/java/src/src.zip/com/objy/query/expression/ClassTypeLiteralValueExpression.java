package com.objy.query.expression;
/**
 * Represents a class type literal value node.
 *
 */
public class ClassTypeLiteralValueExpression extends LiteralValueExpression 
{

	/**
	 * Constructor taking a class name.
	 */
    public ClassTypeLiteralValueExpression(String className) 
    {
        this(Binding.create(className));
    }
    
    /**
     * Constructor taking an ID.
     * @param id
     */
	ClassTypeLiteralValueExpression(long id) 
    {
        setIdAfterNullCheck(id);
    }
	
	/**
	 * Returns the class name of this value node.
	 * @return The class name
	 */
	public String getClassName()
	{
	    throwExceptionIfInvalidOrClosed(getId());
	    return Binding.getClassName(getId());
	}
	
	/**
	 * Returns the expression type (oocClassTypeLiteralValueExpression).
	 */
	@Override
    public ExpressionType getExpressionType()
    { 
        return ExpressionType.ClassTypeLiteralValueExpression; 
    }
    
	/**
	 * Returns the string representation of this value node, which is of the format "class:&lt;class-name&gt;".
	 * @return The value as a string.
	 */
	public String getValue()
	{
	    String className = getClassName();
	    if (className != null)
	    {
	        return "Class:"+getClassName();
	    }
	    return null;
	}
	
	@Override
	public String toString()
	{
		return getValue();
	}
	
    @Override
    public void accept(ExpressionVisitor visitor)
    {
    	super.accept(visitor);
    	visitor.visitClassTypeLiteralValue(this);
    }
    
    static class Binding
    {     
        private static native long create(String className);
        private static native String getClassName(long id);
    }
}
