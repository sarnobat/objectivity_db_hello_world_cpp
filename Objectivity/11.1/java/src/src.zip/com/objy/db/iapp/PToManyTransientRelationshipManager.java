/*
 * @(#)PToManyTransientRelationshipManager.java
 * 
 * Copyright (c) 2004 Objectivity, Inc. All Rights Reserved.
 * 
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 * 
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY 
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO 
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY 
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR 
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 * 
 */
package com.objy.db.iapp ;

import com.objy.db.app.Iterator ;
import com.objy.db.iapp.Persistent ;

public interface PToManyTransientRelationshipManager
{
    void add(Object to, Persistent owner, Object relField) ;

    void remove(Object to, Persistent owner) ;

    void clear(Persistent owner) ;

    Iterator scan() ;

    Object get(int index) ;

    int indexOf(Object obj) ;

    Object[] toArray(Object obj[]) ;

    boolean includes(Object to) ;

    boolean exists() ;

    boolean notFormed() ;

    void terminate(Persistent owner, Object to) ;
}
