/*
 * @(#)JavaTypeNMismatchException.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db ;

/**
 * Signals an attempt to fetch or write an object whose Java class 
 * does not match its Objectivity/DB type number.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class   JavaTypeNMismatchException
       extends ObjyRuntimeException
{
	/**
	 * @serial
	 */
    //private long typeN ;

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public JavaTypeNMismatchException(String msg) {
        super(msg) ;
    }

	/**
	 * Gets the name of the class that caused this exception to be thrown.
	 *
	 * <p>An exception of this class can be thrown when a scan operation finds
	 * objects of some class for which the executing Java
	 * application has no corresponding class definition.
	 *
	 * @return  The name of the class that was not found.
	 */
    //public String getClassName()
    //    { return className ; }
}
