/*
 * @(#)JavaClassNotFoundException.java
 *
 * Copyright (c) 2000 Objectivity, Inc. All Rights Reserved.
 *
 * This software is the confidential and proprietary information of
 * Objectivity, Inc. ("Confidential Information").  You shall not
 * disclose such Confidential Information and shall use it only in
 * accordance with the terms of the license agreement you entered into
 * with Objectivity.
 *
 * OBJECTIVITY MAKES NO REPRESENTATIONS OR WARRANTIES ABOUT THE SUITABILITY
 * OF THE SOFTWARE, EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE, OR NON-INFRINGEMENT. OBJECTIVITY SHALL NOT BE LIABLE FOR ANY
 * DAMAGES SUFFERED BY LICENSEE AS A RESULT OF USING, MODIFYING OR
 * DISTRIBUTING THIS SOFTWARE OR ITS DERIVATIVES.
 *
 */

package com.objy.db ;

/**
 * Signals an attempt to get a class whose name is not found.
 *
 * <p>An exception of this class is thrown when a scan operation 
 * finds objects of some class for which the executing Java
 * application has no corresponding class definition.
 *
 * <p><b>Note:</b> You should not create or throw an exception of this class;
 * you obtain an instance of this class by catching unchecked exceptions.
 */
public class   JavaClassNotFoundException
       extends ObjyRuntimeException
{
	/**
	 * @serial
	 */
    private String className ;
    private long typeNumber = 0 ;

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public JavaClassNotFoundException(String msg, String className) {
        super(msg) ;
        this.className = className ;
    }

	/**
	 * Reserved for internal use; you obtain an exception of this class
	 * only by catching unchecked exceptions.
	 *
	 * <p>You should not use this constructor directly.
	 */
    public JavaClassNotFoundException(String msg, String className, long typeNumber) {
        super(msg) ;
        this.className = className ;
        this.typeNumber = typeNumber ;
    }

	/**
	 * Gets the name of the class that caused this exception to be 
     * thrown.</p> 
	 *
	 * @return  The name of the class that was not found.
	 */
    public String getClassName()
        { return className ; }
        
	/**
	 * Gets the Objectivity/DB type number of the class that caused this 
     * exception to be thrown.</p>
	 *
	 * @return  The type number of the class that was not found.
	 */
    public long getTypeNumber()
        { return typeNumber ; }
}


